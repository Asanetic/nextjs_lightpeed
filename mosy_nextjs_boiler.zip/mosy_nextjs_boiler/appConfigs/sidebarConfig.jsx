// sidebarConfig.js

export const sidebarConfig = [
  { type: "link", label: "Dashboard", icon: "fa fa-home", href: (routes) => `${routes.cms}/dashboard`, roles: [] },

  // Leads
  {
    type: "submenu",
    label: "Leads",
    icon: "fa fa-user-plus",
    roles: [],
    items: [
      { label: "Add Lead", href: (routes) => `${routes.cms}/leads/new`, roles: [] },
      { label: "All Leads", href: (routes) => `${routes.cms}/leads/list`, roles: [] },
      { label: "Pending Follow-ups", href: (routes) => `${routes.cms}/leads/pending`, roles: [] },
      { label: "Converted Leads", href: (routes) => `${routes.cms}/leads/converted`, roles: [] },
    ],
  },

  // Customers
  {
    type: "submenu",
    label: "Customers",
    icon: "fa fa-users",
    roles: [],
    items: [
      { label: "All Customers", href: (routes) => `${routes.cms}/customers/list`, roles: [] },
      { label: "Customer Segments", href: (routes) => `${routes.cms}/customers/segments`, roles: [] },
    ],
  },

  // Campaigns
  {
    type: "submenu",
    label: "Campaigns",
    icon: "fa fa-bullhorn",
    roles: [],
    items: [
      { label: "Send Campaign", href: (routes) => `${routes.cms}/campaigns/new`, roles: [] },
      { label: "All Campaigns", href: (routes) => `${routes.cms}/campaigns/list`, roles: [] },
      { label: "Scheduled Campaigns", href: (routes) => `${routes.cms}/campaigns/scheduled`, roles: [] },
      { label: "Analytics", href: (routes) => `${routes.cms}/campaigns/analytics`, roles: [] },
    ],
  },

  // Content / Blog
  {
    type: "submenu",
    label: "Content",
    icon: "fa fa-pencil",
    roles: [],
    items: [
      { label: "Write Article", href: (routes) => `${routes.cms}/content/new`, roles: [] },
      { label: "All Articles", href: (routes) => `${routes.cms}/content/list`, roles: [] },
      { label: "Categories", href: (routes) => `${routes.cms}/content/categories`, roles: [] },
    ],
  },

  // Reports
  {
    type: "submenu",
    label: "Reports",
    icon: "fa fa-copy",
    roles: [],
    items: [
      { label: "Leads Report", href: (routes) => `${routes.cms}/reports/leads`, roles: [] },
      { label: "Campaigns Report", href: (routes) => `${routes.cms}/reports/campaigns`, roles: [] },
      { label: "Content Report", href: (routes) => `${routes.cms}/reports/content`, roles: [] },
      { label: "Customer Report", href: (routes) => `${routes.cms}/reports/customers`, roles: [] },
    ],
  },

  // Settings
  {
    type: "submenu",
    label: "Settings",
    icon: "fa fa-gear",
    roles: [],
    items: [
      { label: "CMS Settings", href: (routes) => `${routes.cms}/settings`, roles: [] },
      { label: "Users & Roles", href: (routes) => `${routes.cms}/users`, roles: [] },
      { label: "Notification Preferences", href: (routes) => `${routes.cms}/notifications`, roles: [] },
    ],
  },

  // Actions
  { type: "action", label: "Sync Data", icon: "fa fa-refresh", onClick: () => console.log("Syncing CMS/CSM Data"), roles: [] },
  { type: "link", label: "My Account", icon: "fa fa-shield", href: (routes) => `${routes.cms}/account`, roles: [] },
];
