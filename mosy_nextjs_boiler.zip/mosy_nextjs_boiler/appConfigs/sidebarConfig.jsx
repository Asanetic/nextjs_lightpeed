export const sidebarConfig = [

  // DASHBOARD
  {
    type: "link",
    label: "Dashboard",
    icon: "fa fa-home",
    href: (routes) => `${routes.billing}/dashboard`,
    roles: []
  },

  // APPS
  {
    type: "submenu",
    label: "Apps",
    icon: "fa fa-th-large",
    roles: [],
    items: [
      { label: "App List", href: (routes) => `${routes.billing}/apps/list`, roles: [] },
      { label: "Register App", href: (routes) => `${routes.billing}/apps/profile`, roles: [] },
    ],
  },

  // PLANS
  {
    type: "submenu",
    label: "Plans",
    icon: "fa fa-tags",
    roles: [],
    items: [
      { label: "All Plans", href: (routes) => `${routes.billing}/plans/list`, roles: [] },
      { label: "Create Plan", href: (routes) => `${routes.billing}/plans/profile`, roles: [] },
    ],
  },

  // ACCOUNTS
  {
    type: "submenu",
    label: "Accounts",
    icon: "fa fa-building",
    roles: [],
    items: [
      { label: "Account List", href: (routes) => `${routes.billing}/accounts/list`, roles: [] },
      { label: "Create Account", href: (routes) => `${routes.billing}/accounts/create`, roles: [] },

      // Reports under accounts
      { label: "Active Accounts", href: (routes) => `${routes.billing}/accounts/active`, roles: [] },
      { label: "Expired Accounts", href: (routes) => `${routes.billing}/accounts/expired`, roles: [] },
      { label: "Overdue Accounts", href: (routes) => `${routes.billing}/accounts/overdue`, roles: [] },
    ],
  },

  // SUBSCRIPTIONS
  {
    type: "submenu",
    label: "Subscriptions",
    icon: "fa fa-repeat",
    roles: [],
    items: [
      { label: "All Subscriptions", href: (routes) => `${routes.billing}/subscriptions/list`, roles: [] },
      { label: "Trials", href: (routes) => `${routes.billing}/subscriptions/trials`, roles: [] },
      { label: "Canceled", href: (routes) => `${routes.billing}/subscriptions/canceled`, roles: [] },
    ],
  },

  // PAYMENTS
  {
    type: "submenu",
    label: "Payments",
    icon: "fa fa-credit-card",
    roles: [],
    items: [
      { label: "Payment History", href: (routes) => `${routes.billing}/payments/list`, roles: [] },
      { label: "Pending Payments", href: (routes) => `${routes.billing}/payments/pending`, roles: [] },
      { label: "Refunds", href: (routes) => `${routes.billing}/payments/refunds`, roles: [] },
    ],
  },

  // INVOICES
  {
    type: "submenu",
    label: "Invoices",
    icon: "fa fa-file-text",
    roles: [],
    items: [
      { label: "Invoice List", href: (routes) => `${routes.billing}/invoices/list`, roles: [] },
      { label: "Unpaid", href: (routes) => `${routes.billing}/invoices/unpaid`, roles: [] },
      { label: "Paid", href: (routes) => `${routes.billing}/invoices/paid`, roles: [] },
    ],
  },

  // NOTIFICATIONS
  {
    type: "submenu",
    label: "Notifications",
    icon: "fa fa-bell",
    roles: [],
    items: [
      { label: "Notification Rules", href: (routes) => `${routes.billing}/notifications/rules`, roles: [] },
      { label: "Notification Log", href: (routes) => `${routes.billing}/notifications/logs`, roles: [] },
    ],
  },

  // REPORTS
  {
    type: "submenu",
    label: "Reports",
    icon: "fa fa-bar-chart",
    roles: [],
    items: [
      { label: "Revenue Report", href: (routes) => `${routes.billing}/reports/revenue`, roles: [] },
      { label: "Plan Performance", href: (routes) => `${routes.billing}/reports/plans`, roles: [] },
      { label: "Churn & Retention", href: (routes) => `${routes.billing}/reports/churn`, roles: [] },
    ],
  },
];
