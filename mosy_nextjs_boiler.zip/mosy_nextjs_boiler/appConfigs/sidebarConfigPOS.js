// sidebarConfigPOS.js
//
// Links built from the modules that actually exist under app/smc/
// (each has a real *Schema.js + list/profile/import page.jsx). Every href
// uses routes.smc ('/ims/smc') — the previous version of this file
// pointed at routes.novaerpv9, a route prefix with no corresponding app
// directory in this project, so none of those links ever resolved.
//
// Modules that only have a *Schema.js so far (mosymetrics) are left out —
// there's no list/profile page to link to yet. calls/messages now have
// full pages and are grouped into "Communications" below alongside
// Message Templates and Reminders — every module that's a channel for
// reaching a contact (or the log/config behind one), in one place, instead
// of scattered standalone submenus.

export const sidebarConfig = [

  {
    type: "link",
    label: "Dashboard",
    icon: "fa fa-dashboard",
    href: (routes) => `${routes.smc}/dashboard/main`,
    roles: []
  },
  {
    type: "link",
    label: "Contacts",
    icon: "fa fa-address-book",
    href: (routes) => `${routes.smc}/contacts/list`,
    roles: []
  },
  {
    type: "link",
    label: "Campaigns",
    icon: "fa fa-bullhorn",
    href: (routes) => `${routes.smc}/content/list`,
    roles: []
  },
  {
    type: "link",
    label: "Site traffic",
    icon: "fa fa-line-chart",
    href: (routes) => `${routes.smc}/sitetraffic/list`,
    roles: []
  },
  {
    type: "link",
    label: "Catalogue",
    icon: "fa fa-copy",
    href: (routes) => `${routes.smc}/catalog/list`,
    roles: []
  },

  {
    type: "link",
    label: "Event history",
    icon: "fa fa-bolt",
    href: (routes) => `${routes.smc}/actionqueue/list`,
    roles: []
  },

  // Every channel for reaching a contact (or the config/log behind one),
  // grouped together instead of four standalone submenus.


  {
    type: "submenu",
    label: "Admin",
    icon: "fa fa-shield",
    roles: [],
    items: [
      { label: "System Users", href: (routes) => `${routes.smc}/systemusers/list`, roles: [] },
      { label: "Add System User", href: (routes) => `${routes.smc}/systemusers/profile`, roles: [] },
    ],
  },

];
