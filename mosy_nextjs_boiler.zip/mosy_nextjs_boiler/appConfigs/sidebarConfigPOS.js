// sidebarConfigPOS.js

export const sidebarConfig = [

  {
    type: "link",
    label: "Dashboard",
    icon: "fa fa-dashboard",
    href: (routes) => `${routes.novaerpv4}/dashboard/main`,
    roles: []
  },

  {
    type: "submenu",
    label: "Leads",
    icon: "fa fa-bullseye",
    roles: [],
    items: [
      { label: "All Leads", href: (routes) => `${routes.novaerpv4}/leads/list`, roles: [] },
      { label: "Add Lead", href: (routes) => `${routes.novaerpv4}/leads/profile`, roles: [] },
      { label: "Import Leads", href: (routes) => `${routes.novaerpv4}/leads/import`, roles: [] },
    ],
  },

  {
    type: "submenu",
    label: "Deals",
    icon: "fa fa-handshake-o",
    roles: [],
    items: [
      { label: "All Deals", href: (routes) => `${routes.novaerpv4}/deals/list`, roles: [] },
      { label: "Add Deal", href: (routes) => `${routes.novaerpv4}/deals/profile`, roles: [] },
      { label: "Import Deals", href: (routes) => `${routes.novaerpv4}/deals/import`, roles: [] },
    ],
  },

  {
    type: "submenu",
    label: "Communications",
    icon: "fa fa-comments",
    roles: [],
    items: [
      { label: "Messages", href: (routes) => `${routes.novaerpv4}/messages/list`, roles: [] },
      { label: "Compose Message", href: (routes) => `${routes.novaerpv4}/messages/profile`, roles: [] },
      { label: "Import Messages", href: (routes) => `${routes.novaerpv4}/messages/import`, roles: [] },
      { label: "Call History", href: (routes) => `${routes.novaerpv4}/callhistory/list`, roles: [] },
      { label: "Log a Call", href: (routes) => `${routes.novaerpv4}/callhistory/profile`, roles: [] },
      { label: "Import Call History", href: (routes) => `${routes.novaerpv4}/callhistory/import`, roles: [] },
    ],
  },

  {
    type: "submenu",
    label: "Access Control",
    icon: "fa fa-lock",
    roles: [],
    items: [
      { label: "Access Rules", href: (routes) => `${routes.novaerpv4}/accesscontrol/list`, roles: [] },
      { label: "Add Access Rule", href: (routes) => `${routes.novaerpv4}/accesscontrol/profile`, roles: [] },
      { label: "Access Matrix", href: (routes) => `${routes.novaerpv4}/accessmatrix`, roles: [] },
    ],
  },

];
