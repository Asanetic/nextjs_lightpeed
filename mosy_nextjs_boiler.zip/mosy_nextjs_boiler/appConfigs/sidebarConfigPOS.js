// sidebarConfigOriginLMS.js
//
// Origin LMS / College Management
//
// Principles:
// - Minimal navigation
// - Group related functions
// - Action-oriented labels
// - Avoid duplicate menu items
// - Simple enough for non-technical users

export const sidebarConfig = [

  // ============================================================
  // HOME
  // ============================================================

  {
    type: "link",
    label: "Home",
    icon: "fa fa-home",
    href: (routes) => `${routes.originlmsv2}/dashboard/main`,
    roles: []
  },

  // ============================================================
// QUICK ACTIONS
// ============================================================

{
  type: "link",
  label: "Clock In",
  icon: "fa fa-clock-o",
  href: (routes) => `${routes.hiveBaseRoute}/view/iot/clockin`,
  newTab: true,
  roles: []
},

{
  type: "link",
  label: "Enroll Student",
  icon: "fa fa-edit",
  href: (routes) => `${routes.originlmsv2}/enrollments/quickenroll`,
  roles: []
},

{
  type: "link",
  label: "Payment Arrears",
  icon: "fa fa-exclamation-triangle",
  href: (routes) => `${routes.originlmsv2}/fees/balances`,
  roles: []
},

  // ============================================================
  // ACADEMICS
  // ============================================================

  {
    type: "submenu",
    label: "Academics",
    icon: "fa fa-book",
    roles: [],
    items: [

      {
        label: "Courses",
        href: (routes) => `${routes.originlmsv2}/courses/list?setgv=table`,
        roles: []
      },
      {
        label: "Classes",
        href: (routes) => `${routes.originlmsv2}/classes/list?setgv=table`,
        roles: []
      },
      {
        label: "Timetable",
        href: (routes) => `${routes.originlmsv2}/classes/timetable`,
        roles: []
      },
      {
        label: "Enrollments",
        href: (routes) => `${routes.originlmsv2}/enrollments/list?setgv=table`,
        roles: []
      },
      {
        label: "Attendance",
        href: (routes) => `${routes.originlmsv2}/attendance/record`,
        roles: []
      },
      {
        label: "Attendance History",
        href: (routes) => `${routes.originlmsv2}/attendance/history`,
        roles: []
      },

    ],
  },

  // ============================================================
  // PEOPLE
  // ============================================================

  {
    type: "submenu",
    label: "People",
    icon: "fa fa-users",
    roles: [],
    items: [

      {
        label: "Students",
        href: (routes) => `${routes.originlmsv2}/students/list?setgv=table`,
        roles: []
      },
      {
        label: "Register Student",
        href: (routes) => `${routes.originlmsv2}/students/list?setgv=sheet`,
        roles: []
      },
      {
        label: "Trainers",
        href: (routes) => `${routes.originlmsv2}/trainers/list?setgv=table`,
        roles: []
      },
      {
        label: "Other Staff",
        href: (routes) => `${routes.originlmsv2}/staff/list?setgv=table`,
        roles: []
      },

    ],
  },

  // ============================================================
  // FINANCE
  // ============================================================

  {
    type: "submenu",
    label: "Finance",
    icon: "fa fa-money",
    roles: [],
    items: [

      {
        label: "Receive Payment",
        href: (routes) => `${routes.originlmsv2}/payments/list?setgv=sheet`,
        roles: []
      },
      {
        label: "Payment History",
        href: (routes) => `${routes.originlmsv2}/payments/list?setgv=table`,
        roles: []
      },
      {
        label: "Fee Balances",
        href: (routes) => `${routes.originlmsv2}/fees/balances`,
        roles: []
      },
      {
        label: "Cleared Fees",
        href: (routes) => `${routes.originlmsv2}/fees/cleared`,
        roles: []
      },
      {
        label: "Fee Structure",
        href: (routes) => `${routes.originlmsv2}/fees/structure`,
        roles: []
      },
      {
        label: "Expenses",
        href: (routes) => `${routes.originlmsv2}/expenses/list?setgv=table`,
        roles: []
      },

    ],
  },

  // ============================================================
  // EXAMS & CERTIFICATES
  // ============================================================

  {
    type: "submenu",
    label: "Exams & Results",
    icon: "fa fa-pencil-square-o",
    roles: [],
    items: [

      {
        label: "Exams",
        href: (routes) => `${routes.originlmsv2}/exams/list`,
        roles: []
      },
      {
        label: "Question Bank",
        href: (routes) => `${routes.originlmsv2}/examquestions/list`,
        roles: []
      },
      {
        label: "Exam Papers",
        href: (routes) => `${routes.originlmsv2}/examquestionpapers/list`,
        roles: []
      },
      {
        label: "Student Results",
        href: (routes) => `${routes.originlmsv2}/exams/studentsreport`,
        roles: []
      },
      {
        label: "Certificates",
        href: (routes) => `${routes.originlmsv2}/certificates/list?setgv=table`,
        roles: []
      },

    ],
  },

  // ============================================================
  // RESOURCES
  // ============================================================

  {
    type: "submenu",
    label: "Resources",
    icon: "fa fa-folder-open",
    roles: [],
    items: [

      {
        label: "File Manager",
        href: (routes) => `${routes.originlmsv2}/files/manage`,
        roles: []
      },
      {
        label: "Document Templates",
        href: (routes) => `${routes.originlmsv2}/documenttemplates/list?setgv=table`,
        roles: []
      },

    ],
  },

  // ============================================================
  // COLLEGE SETTINGS
  // ============================================================

  {
    type: "submenu",
    label: "College Settings",
    icon: "fa fa-cog",
    roles: [],
    items: [

      {
        label: "College Details",
        href: (routes) => `${routes.originlmsv2}/collegeprofile/list`,
        roles: []
      },
      {
        label: "Campuses",
        href: (routes) => `${routes.originlmsv2}/campuses/list`,
        roles: []
      },
      {
        label: "Departments",
        href: (routes) => `${routes.originlmsv2}/departments/list`,
        roles: []
      },
      {
        label: "Course Levels",
        href: (routes) => `${routes.originlmsv2}/courselevels/list`,
        roles: []
      },
      {
        label: "Units / Subjects",
        href: (routes) => `${routes.originlmsv2}/units/list`,
        roles: []
      },
      {
        label: "Interface Settings",
        href: (routes) => `${routes.originlmsv2}/settings`,
        roles: []
      },

    ],
  }

];