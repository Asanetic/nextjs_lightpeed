// sidebarConfigmaira.js
//
// MAIRA
// Members Awareness & Intelligent Relevance Assistant
//
// Admin navigation:
// Home
// Agents
// User Traffic
// Messages
// Templates
// Reminders
// Settings

export const sidebarConfig = [

  // =========================================================
  // HOME
  // =========================================================

  {
    type: "link",
    label: "Home",
    icon: "fa fa-home",
    href: (routes) => `${routes.maira}/dashboard/main`,
    roles: []
  },


  // =========================================================
  // AGENTS
  // =========================================================

  {
    type: "link",
    label: "Agents",
    icon: "fa fa-magic",
    href: (routes) => `${routes.maira}/agents/list`,
    roles: []
  },


  // =========================================================
  // USER TRAFFIC
  // =========================================================

  {
    type: "link",
    label: "User Traffic",
    icon: "fa fa-line-chart",
    href: (routes) => `${routes.maira}/usertraffic/list`,
    roles: []
  },


  // =========================================================
  // MESSAGES
  // =========================================================
  {
    type: "link",
    label: "Messages",
    icon: "fa fa-comments",
    href: (routes) => `${routes.maira}/messages/list`,
    roles: []
  },

  {
    type: "link",
    label: "Contacts",
    icon: "fa fa-users",
    href: (routes) => `${routes.maira}/contacts/list`,
    roles: []
  },

  // {
  //   type: "submenu",
  //   label: "Messages",
  //   icon: "fa fa-comments",
  //   roles: [],
  //   items: [

  //     {
  //       label: "All Messages",
  //       href: (routes) => `${routes.maira}/messages/list`,
  //       roles: []
  //     },

  //     {
  //       label: "Sent",
  //       href: (routes) => `${routes.maira}/messages/sent`,
  //       roles: []
  //     },

  //     {
  //       label: "Scheduled",
  //       href: (routes) => `${routes.maira}/messages/scheduled`,
  //       roles: []
  //     },

  //     {
  //       label: "Failed",
  //       href: (routes) => `${routes.maira}/messages/failed`,
  //       roles: []
  //     }

  //   ]
  // },


  // =========================================================
  // TEMPLATES
  // =========================================================

  {
    type: "link",
    label: "Templates",
    icon: "fa fa-file-text-o",
    href: (routes) => `${routes.maira}/templates/list`,
    roles: []
  },


  // =========================================================
  // REMINDERS
  // =========================================================
  {
    type: "link",
    label: "Nudges",
    icon: "fa fa-bell-o",
    href: (routes) => `${routes.maira}/reminders/list`,
    roles: []
  },
 

  {
    type: "link",
    label: "Nudge log",
    icon: "fa fa-history",
    href: (routes) => `${routes.maira}/reminderlogs/list`,
    roles: []
  },

  
  {
    type: "submenu",
    label: "Maira Data",
    icon: "fa fa-bolt",
    roles: [],
    items: [

      {
        label: "Maira Tasks",
        href: (routes) => `${routes.maira}/mairadata/list`,
        roles: []
      },
 
      {
        label: "MairaTask Logs",
        href: (routes) => `${routes.maira}/mairadatalogs/list`,
        roles: []
      }

    ]
  },

  // {
  //   type: "submenu",
  //   label: "Nudges",
  //   icon: "fa fa-bell-o",
  //   roles: [],
  //   items: [

  //     {
  //       label: "All Reminders",
  //       href: (routes) => `${routes.maira}/reminders/list`,
  //       roles: []
  //     },

  //     {
  //       label: "Active",
  //       href: (routes) => `${routes.maira}/reminders/active`,
  //       roles: []
  //     },

  //     {
  //       label: "Scheduled",
  //       href: (routes) => `${routes.maira}/reminders/scheduled`,
  //       roles: []
  //     },

  //     {
  //       label: "Completed",
  //       href: (routes) => `${routes.maira}/reminders/completed`,
  //       roles: []
  //     }

  //   ]
  // },


  // =========================================================
  // SETTINGS
  // =========================================================

  {
    type: "submenu",
    label: "Settings",
    icon: "fa fa-cog",
    roles: [],
    items: [

      {
        label: "General",
        href: (routes) => `${routes.maira}/settings/general`,
        roles: []
      },

      {
        label: "Users",
        href: (routes) => `${routes.maira}/sysusers/list`,
        roles: []
      }

    ]
  }

];