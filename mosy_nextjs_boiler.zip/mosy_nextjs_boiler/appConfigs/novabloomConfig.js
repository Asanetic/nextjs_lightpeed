// NovaBloom billing-guard identifiers for this app instance. One place
// to change per-deployment instead of hardcoding asset/account IDs into
// every module that checks billing status.
export const NOVABLOOM_ASSET_ID = 'IA8MWMH';
export const NOVABLOOM_ACCOUNT_ID = 'jerrylevav2';
