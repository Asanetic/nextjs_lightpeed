// src/app/mosy_utils/hiveRoutes.js

export const hiveRoutes = {
  hiveBaseRoute: '/gp',
  cms: '/gp/dsgportal',      // dairy sacco graders portal   relative to your Next.js routes
  auth: '/gp/auth'
  // add more as needed
};
