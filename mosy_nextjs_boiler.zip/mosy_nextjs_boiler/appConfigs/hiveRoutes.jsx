// src/app/mosy_utils/hiveRoutes.js

export const hiveRoutes = {
  hiveBaseRoute: '/tks',
  main: '/tks/ticksy',      // dairy sacco graders portal   relative to your Next.js routes
  ticksy: '/tks/ticksy', // CRM: clients/deals/revenueplan/messages/callhistory/payments/smartpaymentrequests
  auth: '/tks/auth',
  home: '/ticksy/dashboard/main',
  // add more as needed
};
