// src/app/mosy_utils/hiveRoutes.js

export const hiveRoutes = {
  revuio: '/revuio',      // relative to your Next.js routes
  auth: '/auth'
  // add more as needed
};
