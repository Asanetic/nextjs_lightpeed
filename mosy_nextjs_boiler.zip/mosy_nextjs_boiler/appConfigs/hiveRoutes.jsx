// src/app/mosy_utils/hiveRoutes.js

export const hiveRoutes = {
  hiveBaseRoute: '',
  cms: '/novaerp',      // dairy sacco graders portal   relative to your Next.js routes
  main: '/novaerp',      // dairy sacco graders portal   relative to your Next.js routes
  auth: '/auth',
  home: '/novaerp/dashboard',
  // add more as needed
};
