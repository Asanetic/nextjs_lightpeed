// src/app/mosy_utils/hiveRoutes.js

export const hiveRoutes = {
  hiveBaseRoute: '',
  cms: '/mosyappv7',      // dairy sacco graders portal   relative to your Next.js routes
  main: '/mosyappv7',      // dairy sacco graders portal   relative to your Next.js routes
  auth: '/auth',
  home: '/collectv3/dashboard',
  // add more as needed
};
