// src/app/mosy_utils/hiveRoutes.js

export const hiveRoutes = {
  revuio: '/revuiov2',      // relative to your Next.js routes
  revuiov2: '/revuiov2',      // relative to your Next.js routes
  auth: '/auth'
  // add more as needed
};
