// src/app/mosy_utils/hiveRoutes.js

export const hiveRoutes = {
  originproject: '/originproject',      // relative to your Next.js routes
  auth: '/auth'
  // add more as needed
};
