// src/app/mosy_utils/hiveRoutes.js

export const hiveRoutes = {
  hiveBaseRoute: '/cm',
  cms: '/cm/smc',      // dairy sacco graders portal   relative to your Next.js routes
  main: '/cm/smc',      // dairy sacco graders portal   relative to your Next.js routes
  smc: '/cm/smc', // CRM: clients/deals/revenueplan/messages/callhistory/payments/smartpaymentrequests
  auth: '/cm/auth',
  home: '/smc/dashboard/main',
  // add more as needed
};
