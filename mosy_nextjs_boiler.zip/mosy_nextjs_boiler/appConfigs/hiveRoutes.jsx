// src/app/mosy_utils/hiveRoutes.js

export const hiveRoutes = {
  emberbilling: '/emberbill',      // relative to your Next.js routes
  auth: '/auth'
  // add more as needed
};
