// src/app/mosy_utils/hiveRoutes.js

export const hiveRoutes = {
  hiveBaseRoute: '/ma',
  mas: '/ma/maira',      // dairy sacco graders portal   relative to your Next.js routes
  main: '/ma/maira',      // dairy sacco graders portal   relative to your Next.js routes
  maira: '/ma/maira', // CRM: clients/deals/revenueplan/messages/callhistory/payments/smartpaymentrequests
  auth: '/ma/auth',
  home: '/maira/dashboard/main',
  // add more as needed
};
