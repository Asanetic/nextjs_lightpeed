// src/app/mosy_utils/hiveRoutes.js

export const hiveRoutes = {
  hiveBaseRoute: '',
  cms: '/symphonygps',      // dairy sacco graders portal   relative to your Next.js routes
  auth: '/auth'
  // add more as needed
};
