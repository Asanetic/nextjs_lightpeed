// src/app/mosy_utils/hiveRoutes.js

export const hiveRoutes = {
  nextinvoice: '/nextinvoice',      // relative to your Next.js routes
  auth: '/auth'
  // add more as needed
};
