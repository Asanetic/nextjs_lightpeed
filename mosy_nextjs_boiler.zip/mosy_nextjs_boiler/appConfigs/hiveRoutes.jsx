// src/app/mosy_utils/hiveRoutes.js

export const hiveRoutes = {
  hiveBaseRoute: '/nebula',
  cms: '/nebula/appnebula',      // dairy sacco graders portal   relative to your Next.js routes
  auth: '/nebula/auth'
  // add more as needed
};
