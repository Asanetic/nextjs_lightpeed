// src/app/mosy_utils/hiveRoutes.js

export const hiveRoutes = {
  hiveBaseRoute: '/lms',
  main: '/lms/originlmsv2',      // dairy sacco graders portal   relative to your Next.js routes
  originlmsv2: '/lms/originlmsv2', // CRM: clients/deals/revenueplan/messages/callhistory/payments/smartpaymentrequests
  auth: '/lms/auth',
  home: '/originlmsv2/dashboard/main',
  // add more as needed
};
