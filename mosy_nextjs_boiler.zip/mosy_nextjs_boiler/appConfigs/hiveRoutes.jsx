// src/app/mosy_utils/hiveRoutes.js

export const hiveRoutes = {
  hiveBaseRoute: '/dairy',
  cms: '/dairy/dairysacco',      // relative to your Next.js routes
  auth: '/dairy/auth'
  // add more as needed
};
