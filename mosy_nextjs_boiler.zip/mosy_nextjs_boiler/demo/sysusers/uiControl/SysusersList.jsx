'use client';
import { SysusersSchema } from '../SysusersSchema';
import SmartGrid from '../../moduleControl/UiControl/SmartGrid';
import SysusersActions from '../logicControl/actionsRegistry';

// Thin wrapper only — all real grid logic lives in components/EntityGrid.jsx
// export default function SysusersList() {
//   return <SmartGrid moduleActions={SysusersActions} schema={SysusersSchema} title="Sysusers" />;
// }PaidInvoicesSchema.label
export default function SysusersList({
  fixedQuery = {},
  dataOut = {},
  title = SysusersSchema.label,
  description = `${SysusersSchema.label} list`,
  customProfilePath = './profile',
  moduleActions = SysusersActions,
  schema = SysusersSchema,
  hiddenActions=[],

}) {
  return (
    <SmartGrid
      moduleActions={moduleActions}
      schema={schema}
      title={title}
      description={description}
      customProfilePath={customProfilePath}
      fixedQuery={fixedQuery}
      dataOut={dataOut}
      hiddenActions={hiddenActions}
    />
  );
}