"use client";

import AccessDenied from "./MosyAccessDenied";

export function MosyUIGuard({ reason }) {

    return(<AccessDenied/>)
}