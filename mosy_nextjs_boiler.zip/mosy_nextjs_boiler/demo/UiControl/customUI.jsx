import { LiveSearchDropdown } from "./componentControl"
import { MosyCard } from "@/app/components/MosyCard"

import { mosyFilterUrl } from "../DataControl/MosyFilterEngine"

//dynamic live search / organic live search 
export function MosyLiveSearch()
{
   MosyCard("",    
    <>
    <div className='col-md-12 text-left h4 m-0 pt-2 pl-0 pr-0 pb-2'>
        <span className="m-0 p-0 label_text">Search categories</span>  
    </div>  

    <LiveSearchDropdown                        
            apiEndpoint="/api/originproject/sites/projects"
            tblName="site_list"
            inputName="qsite_name"
            hiddenInputName="qsitename"
            valueField="site_name"
            displayField="site_name"
            label=""
            onSelect={(id) => console.log("Just the ID:", id)}
            onSelectFull={(dataRes) =>
                mosyFilterUrl({tableName:`staff`, qstr:(`site_id= '${dataRes?.record_id}'`)}) }
            defaultColSize="col-md-12 hive_data_cell text-left m-0 p-0"
            context={{hostParent : "hostParent"}}
            labelClassName="d-none"
        />
    </>
   )
    
}