import { MosyNotify } from "@/app/MosyUtils/ActionModals";
import { MosyConfirm } from "./componentControl";
import { MosyLiveSearch } from "./customUI";

export function syncWorkSchedule()
{
    //MosyNotify({message :"Holla"})
    MosyLiveSearch()
}