import { MosyLiveSearch } from "./customUI";

export function syncWorkSchedule()
{
    //MosyNotify({message :"Holla"})
    MosyLiveSearch()
}