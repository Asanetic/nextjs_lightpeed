// dimev3MenuConfig.js
//
// Sidebar menu for the "dimev3" app. Extended by clone-module.js: modules you
// confirm are added below, grouped by the first word of their table name
// (fuel_stations, fuel_pumps -> "Fuel"). Modules already here are never duplicated,
// and the file is copied to _recycled/ before any change - so reorder, rename,
// regroup, add dashboards or quick actions and set `roles` freely.
// Your own grouping: app/<app>/AppRoutes/menuGroups.txt  ("Sales = fuel_sales, sales_orders").

export const dimev3SidebarConfig = [

  // ============================================================
  // HOME  (added by clone-module.js)
  // ============================================================

  {
    type: "link",
    label: "Dashboard",
    icon: "fa fa-dashboard",
    href: (routes) => `${routes.dimev3}/dashboard/main`,
    roles: []
  },


  // ============================================================
  // CLIENTS  (added by clone-module.js)
  // ============================================================

  {
    type: "submenu",
    label: "Clients",
    icon: "fa fa-users",
    roles: [],
    items: [

      {
        label: "Add New Client",
        href: (routes) => `${routes.dimev3}/clients/profile`,
        roles: []
      },
      {
        label: "Manage Clients",
        href: (routes) => `${routes.dimev3}/clients/list?setgv=sheet`,
        roles: []
      },
      {
        label: "View Clients",
        href: (routes) => `${routes.dimev3}/clients/list?setgv=table`,
        roles: []
      },
      {
        label: "Import Clients",
        href: (routes) => `${routes.dimev3}/clients/import`,
        roles: []
      }

    ]
  },

  // ============================================================
  // LOANS  (added by clone-module.js)
  // ============================================================

  {
    type: "submenu",
    label: "Loans",
    icon: "fa fa-money",
    roles: [],
    items: [

      {
        label: "Add New Loan",
        href: (routes) => `${routes.dimev3}/loans/profile`,
        roles: []
      },
      {
        label: "Manage Loans",
        href: (routes) => `${routes.dimev3}/loans/list?setgv=sheet`,
        roles: []
      },
      {
        label: "View Loans",
        href: (routes) => `${routes.dimev3}/loans/list?setgv=table`,
        roles: []
      },
      {
        label: "Import Loans",
        href: (routes) => `${routes.dimev3}/loans/import`,
        roles: []
      }

    ]
  }
];
