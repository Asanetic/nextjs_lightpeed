/**
 * Register real behavior here, once per action key. Both grid rowLinks
 * AND profile-level buttons (schema.profileActions) route through this
 * SAME registry — one place to add new behavior, works everywhere.
 *
 * Every registered function receives ONE ctx object instead of a fixed
 * list of positional args — see actionRegistryDocs.md (same folder) for
 * the full ctx field list and worked examples for every action shape
 * used elsewhere in this app (cross-module popups, preset create forms,
 * quick-edit modals, grid-toolbar smart filters, sending messages, etc).
 * Copy the block that matches what you're building from there.
 *
 * NOTE: "delete" and "clone" are intercepted directly by
 * useEntityFormController before they ever reach this registry — don't
 * register functions under those two keys, they will never fire.
 */

// <auto-relations:imports>
import React from 'react';
import { MosyCard } from "../../../components/MosyCard";
import { openSmartTagFilter } from "../../moduleControl/UiControl/smartFilterActions";
import { openSmartDateFilter } from "../../moduleControl/UiControl/smartFilterActions";
// </auto-relations:imports>


const MessagingActions = {
  // Bound by gridOptions.checkFunction in schema.js. Fires with every row
  // the user ticked in the grid's checkbox column. Swap the display-name
  // fallback chain for whatever field this module's rows actually have.
  gridCheckBoxAction: async ({ rows }) => {
    const displayName = (row) => row?.title || row?.name || row?.record_id || 'record';
    alert(`${rows.length} record(s) selected: ${rows.map(displayName).join(', ')}`);
  },

  // Add more as needed — see actionRegistryDocs.md for patterns to copy.
  // Every one of them gets whatever's on ctx: { rows, schema, router,
  // refresh, create, update, remove, filter, setFilterValue,
  // setAdvancedQuery, setDateRange, applyFilter, clearFilterValue }.

  // <auto-relations:actions>
  filter_messaging_group_name: (ctx) => openSmartTagFilter(ctx, {
    title: 'Filter by group name',
    columnKey: 'group_name',
    combine: true,
  }),

  filter_messaging_message_date: (ctx) => openSmartDateFilter(ctx, {
    title: 'Filter by message date',
    columnKey: 'message_date',
    inputType: 'datetime-local',
    combine: true,
  }),

  filter_messaging_message_type: (ctx) => openSmartTagFilter(ctx, {
    title: 'Filter by message type',
    columnKey: 'message_type',
    combine: true,
  }),

  filter_messaging_msg_read_state: (ctx) => openSmartTagFilter(ctx, {
    title: 'Filter by msg read state',
    columnKey: 'msg_read_state',
    combine: true,
  }),

  filter_messaging_sent_state: (ctx) => openSmartTagFilter(ctx, {
    title: 'Filter by sent state',
    columnKey: 'sent_state',
    combine: true,
  }),
  // </auto-relations:actions>
};


export default MessagingActions
