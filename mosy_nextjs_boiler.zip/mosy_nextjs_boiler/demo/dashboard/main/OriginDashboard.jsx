"use client";

import { createContext, useCallback, useContext, useEffect, useId, useMemo, useRef, useState } from "react";
import Link from "next/link";
import {
  Users, BookOpen, Coins, FileText, ArrowUp, ArrowRight, Download, ChevronDown, MoreVertical,
} from "lucide-react";
import { getGridPrefs, setGridPrefs, togglePresentation, replayGrids, useGridPrefs } from "../../moduleControl/UiControl/SmartGridClean";
import "./origin-dashboard.css"; // self-contained styles (no Bootstrap utilities required)

/* ════════════════════════════════════════════════════════════════
   ORIGIN DASHBOARD — renders ONLY what the API returns (api/originlmsv2/dashboard/main).
   Pass the payload as `data`; nothing is hardcoded or simulated.
   SCROLL REVEAL: below-the-fold blocks stay hidden until scrolled to, then slide in and play their own
   sequence. <OriginDashboard revealRepeat /> replays each block every time it re-enters the screen.
   Animations are controlled from /originlmsv2/settings and SHARED with SmartGridClean (same localStorage
   key, mosy.grid.prefs): presentation on + replay on → animated entrance. Press R to replay.
   <OriginDashboard demo={false} /> pins one instance static.
   ════════════════════════════════════════════════════════════════ */

const PRESETS = ["All Time", "Today", "Yesterday", "This Week", "This Month", "This Year"];

// card chrome only (icon / colours / link) — every value, series and alert comes from the API
const STAT_META = [
  { key: "students", label: "Total Students", icon: Users, href: "/originlmsv2/students/list", iconBg: "#e6efff", iconColor: "#2563eb", spark: "#3b82f6" },
  { key: "courses", label: "Total Courses", icon: BookOpen, href: "/originlmsv2/courses/list", iconBg: "#fff0d9", iconColor: "#f59e0b", spark: "#f59e0b" },
  { key: "collected", label: "Fees Collected", prefix: "KES ", icon: Coins, href: "/originlmsv2/payments/list", iconBg: "#fff0d9", iconColor: "#f59e0b", spark: "#22c55e" },
  { key: "pending", label: "Pending Fees", prefix: "KES ", icon: FileText, href: "/originlmsv2/enrollments/list", iconBg: "#e6efff", iconColor: "#2563eb", spark: "#ef4444" },
];

/* ============================ LIVE DATA → MODEL ============================ */

const METHOD_COLORS = ["#1f4f9f", "#f5a623", "#58a6ff", "#38c172", "#8b5cf6", "#ef4444"];
const fmtDate = (v) => {
  const d = new Date(String(v || "").replace(" ", "T"));
  return Number.isNaN(d.getTime()) ? String(v || "") : d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
};
// axis ticks sized to the data: ~5 intervals on a 1/2/5 step, top tick >= the highest value
const niceTicks = (max) => {
  const raw = Math.max(max, 1) / 5;
  const mag = 10 ** Math.floor(Math.log10(raw));
  const step = Math.max(1, ([1, 2, 5, 10].find((m) => m * mag >= raw) || 10) * mag);
  return Array.from({ length: Math.ceil(Math.max(max, 1) / step) + 1 }, (_, i) => i * step);
};

// API payload (api/originlmsv2/dashboard/main) → the shapes the dashboard renders.
function buildModel(data) {
  const t = data.totals || {};
  const s = data.summary || {};
  const sp = data.sparklines || {};
  const stats = STAT_META.map((st) => {
    if (st.key === "students") return { ...st, value: t.students || 0, series: sp.students };
    if (st.key === "courses") return { ...st, value: t.courses || 0, series: sp.courses };
    if (st.key === "collected") return { ...st, value: t.feesCollected || 0, series: sp.payments };
    return { ...st, value: s.feeArrears || 0, alert: t.unpaidStudents ? `${t.unpaidStudents} students` : undefined };
  });
  const courses = (data.enrollmentsByCourse || []).map((c, i, a) => ({ label: c.course, value: c.total, tone: i >= a.length - 2 && a.length > 3 ? "amber" : "blue" }));
  const methods = (data.paymentsByMethod || []).map((m, i) => ({ key: m.label, label: m.label, color: METHOD_COLORS[i % METHOD_COLORS.length], amount: m.value }));
  const payments = (data.latestPayments || []).map((p) => ({
    ...p, date: fmtDate(p.date), student: p.student || "—", course: p.course || "", method: p.method || "", reference: p.reference || "",
    status: String(p.status || "").toLowerCase() === "pending" ? "Pending" : "Completed",
  }));
  const person = (r, dateKey) => ({
    id: r.enrollment_id, student: r.student || "—", admission: r.admission_number || "", course: r.course || "—",
    date: r[dateKey] ? fmtDate(r[dateKey]) : "—", status: r.completion_status || "Active",
  });
  return { enrollments: (data.latestEnrollments || []).map((r) => person(r, "enrollment_date")), graduates: (data.latestGraduates || []).map((r) => person(r, "completion_date")), stats, courses, monthly: data.enrollmentsByMonth || [],
    paymentMonths: (data.paymentsByMonth || []).length > 1 ? data.paymentsByMonth : [{ label: "—", value: 0 }, { label: "—", value: 0 }], methods, payments, collected: t.feesCollected || 0, pending: s.feeArrears || 0 };
}

/* ============================ HELPERS ============================ */

const r2 = (n) => Math.round(n * 100) / 100;

// smooth curve through points (Catmull-Rom → cubic Bézier)
function smoothPath(pts) {
  let d = `M ${r2(pts[0][0])} ${r2(pts[0][1])}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
    d += ` C ${r2(p1[0] + (p2[0] - p0[0]) / 6)} ${r2(p1[1] + (p2[1] - p0[1]) / 6)}, ${r2(p2[0] - (p3[0] - p1[0]) / 6)} ${r2(p2[1] - (p3[1] - p1[1]) / 6)}, ${r2(p2[0])} ${r2(p2[1])}`;
  }
  return d;
}

// fixed-height charts need the real pixel width so text stays crisp at any screen size
function useElementWidth() {
  const ref = useRef(null);
  const [w, setW] = useState(0);
  useEffect(() => {
    const el = ref.current;
    if (!el) return undefined;
    setW(Math.round(el.getBoundingClientRect().width));
    if (typeof ResizeObserver === "undefined") return undefined;
    const ro = new ResizeObserver(([e]) => setW(Math.round(e.contentRect.width)));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return [ref, w];
}

// cursor spotlight: CSS vars on the element, no re-render
const spotlight = (e) => {
  const r = e.currentTarget.getBoundingClientRect();
  e.currentTarget.style.setProperty("--mx", `${e.clientX - r.left}px`);
  e.currentTarget.style.setProperty("--my", `${e.clientY - r.top}px`);
};

/* ============================ SCROLL REVEAL ============================ */

const StageCtx = createContext({ show: false, repeat: false });
const RevealCtx = createContext({ on: true, ms: 0 }); // on = revealed, ms = delay before its sequence starts

// Wraps a block. In demo mode it stays invisible (opacity 0, still laid out) until it scrolls into
// view; then `is-in` is added, which starts its slide-in AND every effect inside it. Blocks visible
// at load reveal after `delay` ms (a staggered intro); blocks reached by scrolling start at once.
function Reveal({ as: Tag = "div", variant = "rise", delay = 0, onReveal, className = "", style, children, ...rest }) {
  const { show, repeat } = useContext(StageCtx);
  const ref = useRef(null);
  const [state, setState] = useState({ on: !show, ms: 0 });
  const cb = useRef(onReveal);
  cb.current = onReveal;

  useEffect(() => {
    if (!show) return undefined;
    const el = ref.current;
    if (!el) return undefined;
    if (typeof IntersectionObserver === "undefined") { setState({ on: true, ms: delay }); return undefined; }
    let first = true;
    let shown = false;
    const io = new IntersectionObserver((entries) => {
      const e = entries[entries.length - 1];
      const vh = (e.rootBounds && e.rootBounds.height) || window.innerHeight;
      // "enough" = a good slice of it is on screen (or it fills half the screen, for very tall blocks)
      const enough = e.isIntersecting && (e.intersectionRatio >= 0.22 || e.intersectionRect.height >= vh * 0.5);
      if (enough && !shown) {
        shown = true;
        setState({ on: true, ms: first ? delay : 60 });
        if (cb.current) cb.current();
        if (!repeat) io.disconnect();
      } else if (!e.isIntersecting && shown && repeat) {
        shown = false; // fully off-screen → reset, so it plays again next time
        setState({ on: false, ms: 0 });
      }
      first = false;
    }, { threshold: [0, 0.1, 0.22, 0.35, 0.5, 0.75] });
    io.observe(el);
    return () => io.disconnect();
  }, [show, repeat, delay]);

  const cls = `${className} ${show ? `od-rv od-rv-${variant}` : ""} ${show && state.on ? "is-in" : ""}`.replace(/\s+/g, " ").trim();
  return (
    <RevealCtx.Provider value={state}>
      <Tag ref={ref} className={cls} style={{ ...style, "--rd": `${state.ms / 1000}s` }} {...rest}>
        {children}
      </Tag>
    </RevealCtx.Provider>
  );
}

/* ============================ COUNT-UP ============================ */

// Animates from its current value to `value` (from 0 on first mount). Also tweens live updates.
function CountUp({ value, prefix = "", suffix = "", delay = 0, duration = 1200, animate = true }) {
  const [shown, setShown] = useState(animate ? 0 : value);
  const shownRef = useRef(animate ? 0 : value);
  const mounted = useRef(false);
  const rv = useContext(RevealCtx);

  useEffect(() => {
    const reduce = typeof window !== "undefined" && window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    if (!animate || reduce) {
      shownRef.current = value;
      setShown(value);
      mounted.current = true;
      return undefined;
    }
    if (!rv.on) { // block not revealed yet → hold at 0 (and reset, if it hid again)
      shownRef.current = 0;
      setShown(0);
      mounted.current = false;
      return undefined;
    }
    const from = shownRef.current;
    const wait = mounted.current ? 0 : delay + rv.ms;
    mounted.current = true;
    let raf;
    const timer = setTimeout(() => {
      const t0 = performance.now();
      const tick = (now) => {
        const p = Math.min(1, (now - t0) / duration);
        const eased = p === 1 ? 1 : 1 - 2 ** (-10 * p); // easeOutExpo: fast start, long settle
        const v = from + (value - from) * eased;
        shownRef.current = v;
        setShown(v);
        if (p < 1) raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    }, wait);
    return () => { clearTimeout(timer); cancelAnimationFrame(raf); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value, animate, rv.on]);

  return <>{prefix}{Math.round(shown).toLocaleString("en-US")}{suffix}</>;
}

/* ============================ FILTER BAR ============================ */

const pad = (n) => String(n).padStart(2, "0");
const fmt = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

function presetRange(name) {
  if (name === "All Time") return { from: "", to: "" };
  const t = new Date();
  const from = new Date(t);
  if (name === "Yesterday") {
    from.setDate(t.getDate() - 1);
    return { from: fmt(from), to: fmt(from) };
  }
  if (name === "This Week") {
    from.setDate(t.getDate() - ((t.getDay() + 6) % 7)); // Monday
    return { from: fmt(from), to: fmt(t) };
  }
  if (name === "This Month") {
    from.setDate(1);
    return { from: fmt(from), to: fmt(t) };
  }
  if (name === "This Year") {
    from.setMonth(0, 1);
    return { from: fmt(from), to: fmt(t) };
  }
  return { from: fmt(t), to: fmt(t) };
}

function FilterBar({ onApply }) {
  const [preset, setPreset] = useState("All Time");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  // Set dates after mount so server and client markup match (no hydration mismatch)
  useEffect(() => {
    setFrom("");
    setTo("");
  }, []);

  // picking a preset applies it straight away; custom dates wait for the Apply button
  const choose = (name) => {
    const r = presetRange(name);
    setPreset(name);
    setFrom(r.from);
    setTo(r.to);
    if (onApply) onApply({ preset: name, from: r.from, to: r.to });
  };

  return (
    <Reveal className="od-card od-filters" variant="pop" delay={250}>
      <div className="od-presets">
        {PRESETS.map((p, i) => (
          <button key={p} type="button" onClick={() => choose(p)} style={{ "--b": i }} className={`od-chip ${preset === p ? "active" : ""}`}>
            {p}
          </button>
        ))}
      </div>

      <div className="od-divider" />

      <label className="od-field">
        <span>From</span>
        <input type="date" className="od-input" value={from} onChange={(e) => { setFrom(e.target.value); setPreset(null); }} />
      </label>
      <label className="od-field">
        <span>To</span>
        <input type="date" className="od-input" value={to} onChange={(e) => { setTo(e.target.value); setPreset(null); }} />
      </label>

      <button type="button" className="od-apply" onClick={() => onApply && onApply({ preset, from, to })}>
        Apply
      </button>

    </Reveal>
  );
}

/* ============================ STAT CARDS ============================ */

function Sparkline({ series, color }) {
  const gid = useId();
  const W = 92, H = 40, P = 3;
  const max = Math.max(...series), min = Math.min(...series);
  const x = (i) => P + (i / (series.length - 1)) * (W - 2 * P);
  const y = (v) => H - P - ((v - min) / (max - min || 1)) * (H - 2 * P);
  const pts = series.map((v, i) => [x(i), y(v)]);
  const line = smoothPath(pts);
  const area = `${line} L ${r2(x(series.length - 1))} ${H} L ${r2(x(0))} ${H} Z`;

  return (
    <svg className="od-spark" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" aria-hidden="true">
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.3" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path className="od-area" d={area} fill={`url(#${gid})`} />
      <path className="od-line" d={line} pathLength="1" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}

function StatCard({ stat, value, show, index, bump }) {
  const Icon = stat.icon;
  const style = {};
  if (bump > 0) style.animation = `od-bump-${bump % 2} .9s var(--od-spring)`; // alternate names so it re-fires on every payment

  return (
    <Reveal className="od-statwrap" variant="card" delay={450 + index * 120}>
      <Link href={stat.href} className="od-card od-stat" style={style} onMouseMove={show ? spotlight : undefined}>
        <span className="od-stat-ic" style={{ background: stat.iconBg, color: stat.iconColor }}>
          <Icon size={20} />
        </span>
        <span className="od-stat-body">
          <span className="od-stat-label">{stat.label}</span>
          <span className="od-stat-value">
            {stat.prefix && <small className="od-cur">{stat.prefix.trim()}</small>}
            <CountUp value={value} animate={show} delay={350} />
          </span>
          <span className="od-trend">
            {stat.trend && (
              <span style={{ display: "inline-flex", alignItems: "center", gap: 4, color: "#16a34a" }}>
                <ArrowUp size={13} />
                <CountUp value={stat.trend.value} suffix={stat.trend.suffix} animate={show} delay={600} duration={900} />
              </span>
            )}
            {stat.alert && (
              <span style={{ display: "inline-flex", alignItems: "center", gap: 5, color: "#ef4444" }}>
                <Users size={13} /> {stat.alert}
              </span>
            )}
          </span>
        </span>
        {stat.series && stat.series.length > 1 ? <Sparkline series={stat.series} color={stat.spark} /> : null}
      </Link>
    </Reveal>
  );
}

/* ============================ SECTION + CHARTS ============================ */

function Section({ title, action, badge, fill = false, variant = "rise", delay = 0, onReveal, children }) {
  return (
    <Reveal as="section" variant={variant} delay={delay} onReveal={onReveal} className={`od-card od-section ${fill ? "od-fill" : ""}`.trim()}>
      <div className="od-section-head">
        <h3 className="od-section-title">{title}{badge}</h3>
        {action}
      </div>
      {children}
    </Reveal>
  );
}

const ViewLink = ({ href, children }) => (
  <Link href={href} className="od-vlink">{children} <ArrowRight size={13} /></Link>
);

function BarChart({ data, show, height = 260, focus = null }) {
  const ticks = niceTicks(Math.max(0, ...data.map((x) => x.value)));
  const top = ticks[ticks.length - 1];

  return (
    <div className="od-bars">
      <div className="od-bars-y" style={{ height }}>
        {ticks.map((t) => (
          <span key={t} style={{ bottom: `${(t / top) * 100}%` }}>{t}</span>
        ))}
      </div>
      <div className="od-bars-main">
        <div className="od-bars-plot" style={{ height }}>
          {ticks.map((t) => (
            <div key={t} className="od-bars-grid" style={{ bottom: `${(t / top) * 100}%` }} />
          ))}
          <div className="od-bars-cols">
            {data.map((x, i) => (
              <div key={x.label} className="od-bars-col" style={{ "--i": i, opacity: focus == null || focus === i ? 1 : 0.35 }}>
                <span className="od-bar-value">
                  <CountUp value={x.value} animate={show} delay={700 + i * 80} duration={900} />
                </span>
                <div className={`od-bar od-bar-${x.tone}`} style={{ height: `${(x.value / top) * 100}%` }} title={`${x.label}: ${x.value}`} />
              </div>
            ))}
          </div>
        </div>
        <div className="od-bars-labels">
          {data.map((x) => <span key={x.label}>{x.label}</span>)}
        </div>
      </div>
    </div>
  );
}

// Interactive area chart: hover/touch moves an amber marker + tooltip along the line.
// In demo mode the marker starts at Jan and glides to the peak once the line has drawn.
function TrendChart({ labels, values, show, height = 280, yTicks = [0, 20, 40, 60, 80, 100], unit = "enrollments", tickFmt = (v) => v, valueFmt = (v) => v }) {
  const [wrapRef, w] = useElementWidth();
  const rv = useContext(RevealCtx);
  const uid = useId();
  const n = values.length;
  const peak = Math.max(0, values.indexOf(Math.max(...values)));
  const start = show ? 0 : peak;

  const [pos, setPos] = useState(start); // fractional index of the marker
  const posRef = useRef(start);
  const targetRef = useRef(start);
  const easeRef = useRef(0.2);
  const rafRef = useRef(0);

  const step = useCallback(() => {
    const diff = targetRef.current - posRef.current;
    if (Math.abs(diff) < 0.004) {
      posRef.current = targetRef.current;
      setPos(posRef.current);
      rafRef.current = 0;
      return;
    }
    posRef.current += diff * easeRef.current;
    setPos(posRef.current);
    rafRef.current = requestAnimationFrame(step);
  }, []);

  const moveTo = useCallback((i, ease = 0.2) => {
    targetRef.current = i;
    easeRef.current = ease;
    if (!rafRef.current) rafRef.current = requestAnimationFrame(step);
  }, [step]);

  useEffect(() => () => { cancelAnimationFrame(rafRef.current); rafRef.current = 0; }, []);

  // demo: once revealed and the line has drawn, glide the marker from Jan to the peak
  useEffect(() => {
    if (!show) return undefined;
    if (!rv.on) { posRef.current = 0; targetRef.current = 0; setPos(0); return undefined; }
    const t = setTimeout(() => moveTo(peak, 0.07), rv.ms + 2050);
    return () => clearTimeout(t);
  }, [show, rv.on, rv.ms, peak, moveTo]);

  const H = height;
  if (!w) return <div ref={wrapRef} className="od-trend-chart" style={{ height: H }} />;

  const PAD = { l: 46, r: 20, t: 58, b: 34 };
  const iw = Math.max(1, w - PAD.l - PAD.r);
  const ih = H - PAD.t - PAD.b;
  const yMax = yTicks[yTicks.length - 1];
  const x = (i) => PAD.l + (i / (n - 1)) * iw;
  const y = (v) => PAD.t + ih - (v / yMax) * ih;
  const base = PAD.t + ih;

  const pts = values.map((v, i) => [x(i), y(v)]);
  const line = smoothPath(pts);
  const area = `${line} L ${r2(pts[n - 1][0])} ${base} L ${r2(pts[0][0])} ${base} Z`;

  const lo = Math.min(n - 2, Math.max(0, Math.floor(pos)));
  const f = Math.min(1, Math.max(0, pos - lo));
  const hx = pts[lo][0] + (pts[lo + 1][0] - pts[lo][0]) * f;
  const hy = pts[lo][1] + (pts[lo + 1][1] - pts[lo][1]) * f;
  const idx = Math.min(n - 1, Math.max(0, Math.round(pos)));

  const tipW = 124;
  const tipLeft = Math.min(Math.max(hx, tipW / 2 + 4), w - tipW / 2 - 4);

  const track = (clientX) => {
    const r = wrapRef.current.getBoundingClientRect();
    const i = Math.round(((clientX - r.left - PAD.l) / iw) * (n - 1));
    moveTo(Math.min(n - 1, Math.max(0, i)), 0.25);
  };

  return (
    <div
      ref={wrapRef}
      className="od-trend-chart"
      style={{ height: H }}
      onMouseMove={(e) => track(e.clientX)}
      onMouseLeave={() => moveTo(peak, 0.12)}
      onTouchMove={(e) => track(e.touches[0].clientX)}
      onTouchEnd={() => moveTo(peak, 0.12)}
    >
      <svg width={w} height={H} role="img" aria-label="Monthly enrollments">
        <defs>
          <linearGradient id={`${uid}a`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.3" />
            <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.02" />
          </linearGradient>
          <radialGradient id={`${uid}g`}>
            <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.55" />
            <stop offset="100%" stopColor="#f59e0b" stopOpacity="0" />
          </radialGradient>
          <clipPath id={`${uid}c`}><path d={area} /></clipPath>
        </defs>

        {yTicks.map((t) => (
          <g key={t}>
            <line x1={PAD.l} x2={w - PAD.r} y1={y(t)} y2={y(t)} stroke="#eef1f6" />
            <text x={PAD.l - 12} y={y(t) + 4} textAnchor="end" fontSize="11" fill="#64748b">{tickFmt(t)}</text>
          </g>
        ))}

        <path className="od-area" d={area} fill={`url(#${uid}a)`} />
        <g className="od-area" clipPath={`url(#${uid}c)`}>
          <circle cx={hx} cy={hy} r="190" fill={`url(#${uid}g)`} />
        </g>

        <line className="od-hl" x1={hx} x2={hx} y1={hy} y2={base} stroke="#f2b25c" strokeWidth="1.5" />
        <path className="od-line" d={line} pathLength="1" fill="none" stroke="#1b2f6b" strokeWidth="2.4" strokeLinecap="round" />
        {pts.map(([px, py], i) => (
          <circle key={i} className="od-dot" style={{ "--i": i }} cx={px} cy={py} r="3.6" fill="#1b2f6b" />
        ))}
        <g className="od-hl">
          <circle cx={hx} cy={hy} r="13" fill="#f59e0b" opacity="0.22" />
          <circle cx={hx} cy={hy} r="6.5" fill="#f59e0b" stroke="#fff" strokeWidth="2.5" />
        </g>

        {labels.map((l, i) => (
          <text key={l} x={x(i)} y={H - 8} textAnchor="middle" fontSize="11" fill="#64748b">{l}</text>
        ))}
      </svg>

      <div className="od-tip" style={{ left: tipLeft, top: hy - 16, "--shift": `${hx - tipLeft}px` }}>
        <small>{labels[idx]}</small>
        <b>{valueFmt(values[idx])} {unit}</b>
      </div>
    </div>
  );
}

/* ============================ PAYMENT METHODS ============================ */

function PaymentMethods({ methods, total, show }) {
  const [active, setActive] = useState(null);
  const R = 74, SW = 26, CX = 120, C = 2 * Math.PI * R, GAP = 2.5;

  const fracs = methods.map((m) => (total ? m.amount / total : 0));
  const pcts = fracs.map((f) => Math.floor(f * 100 + 1e-6));
  if (total) {
    const order = fracs.map((f, i) => [f * 100 - pcts[i], i]).sort((a, b) => b[0] - a[0]);
    for (let k = 0, rem = 100 - pcts.reduce((a, b) => a + b, 0); k < rem && k < order.length; k++) pcts[order[k][1]] += 1;
  }

  let acc = 0;
  const segs = methods.map((m, i) => {
    const frac = fracs[i];
    const len = Math.max(0, frac * C - GAP);
    const startFrac = acc;
    acc += frac;
    const ang = (startFrac + frac / 2) * Math.PI * 2 - Math.PI / 2;
    const lr = R + SW / 2 + 17;
    return { ...m, i, pct: pcts[i], len, offset: -startFrac * C, lx: CX + lr * Math.cos(ang), ly: CX + lr * Math.sin(ang) };
  });
  const act = active == null ? null : segs[active];

  return (
    <div className="od-donut">
      <svg className="od-donut-svg" viewBox="0 0 240 240" role="img" aria-label="Payment methods">
        <circle cx={CX} cy={CX} r={R} fill="none" stroke="#eef1f6" strokeWidth={SW} />
        {segs.map((s) => (
          <circle
            key={s.key}
            className="od-seg"
            cx={CX} cy={CX} r={R}
            stroke={s.color}
            strokeWidth={active === s.i ? SW + 6 : SW}
            transform={`rotate(-90 ${CX} ${CX})`}
            style={{ "--C": C, "--i": s.i, strokeDasharray: `${s.len} ${C - s.len}`, strokeDashoffset: s.offset, opacity: active == null || active === s.i ? 1 : 0.45 }}
            onMouseEnter={() => setActive(s.i)}
            onMouseLeave={() => setActive(null)}
          />
        ))}
        {segs.map((s) => (
          <text key={`p-${s.key}`} className="od-pct" style={{ "--i": s.i }} x={s.lx} y={s.ly} textAnchor="middle" dominantBaseline="central">
            <CountUp value={s.pct} suffix="%" animate={show} delay={1000 + s.i * 150} duration={900} />
          </text>
        ))}
        <g textAnchor="middle">
          <text x={CX} y={CX - 15} fontSize="11" fontWeight="600" fill={act ? act.color : "#64748b"}>{act ? act.label : "KES"}</text>
          <text x={CX} y={CX + 9} fontSize="22" fontWeight="800" fill="#0b1f4a" style={{ fontVariantNumeric: "tabular-nums" }}>
            <CountUp value={act ? act.amount : total} animate={show} delay={400} duration={act ? 500 : 1300} />
          </text>
          <text x={CX} y={CX + 28} fontSize="10.5" fill="#64748b">{act ? `${act.pct}% of total` : "Total Collected"}</text>
        </g>
      </svg>

      <div className="od-legend">
        {segs.map((s) => (
          <div
            key={s.key}
            className={`od-leg-row ${active === s.i ? "hot" : ""}`}
            style={{ "--i": s.i }}
            onMouseEnter={() => setActive(s.i)}
            onMouseLeave={() => setActive(null)}
          >
            <i className="od-leg-dot" style={{ background: s.color }} />
            <span className="od-leg-name">{s.label}</span>
            <b className="od-leg-pct">{s.pct}%</b>
            <span className="od-leg-amt">
              KES <CountUp value={s.amount} animate={show} delay={700 + s.i * 100} duration={1100} />
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ============================ LATEST PAYMENTS ============================ */

function StatusIcon({ status }) {
  return (
    <svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true">
      <circle cx="8" cy="8" r="8" fill="currentColor" />
      {status === "Completed" && <path d="M4.6 8.2l2.3 2.3 4.5-4.7" fill="none" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />}
      {status === "Pending" && <path d="M8 4.4V8l2.4 1.5" fill="none" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />}
      {status === "Failed" && <path d="M5.4 5.4l5.2 5.2M10.6 5.4l-5.2 5.2" fill="none" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" />}
    </svg>
  );
}

function PaymentsTable({ payments, show, live, newId, tick, delay, onReveal }) {
  const baseMs = 450;
  return (
    <Section
      variant="right"
      delay={delay}
      onReveal={onReveal}
      title="Latest Payments"
      badge={live ? <span className="od-live"><i /> Live</span> : null}
      action={<ViewLink href="/originlmsv2/payments/list">View All</ViewLink>}
    >
      <div className="od-table-wrap">
        <table className="od-table">
          <thead>
            <tr>
              {["Date", "Student", "Amount (KES)", "Status", ""].map((h, i) => <th key={i}>{h}</th>)}
            </tr>
          </thead>
          <tbody>
            {payments.map((p, idx) => {
              const isLive = String(p.id).startsWith("live-");
              const isNew = p.id === newId;
              const trStyle = { "--i": isLive ? 0 : idx, "--base": isLive ? "0s" : undefined };
              // existing rows slide down to make room for the new one
              if (tick > 0 && !isNew) trStyle.animation = `od-shift-${tick % 2} .55s var(--od-spring)`;
              const cell = (c) => ({ "--c": c });
              return (
                <tr
                  key={p.id}
                  className={isNew && show ? "od-row-new" : undefined}
                  style={trStyle}
                  title={`${p.course} · ${p.method} · ${p.reference}`}
                  onMouseMove={show ? spotlight : undefined}
                >
                  <td style={cell(0)}><span className="od-cellv">{p.date}</span></td>
                  <td style={cell(1)}><span className="od-cellv">{p.student}</span></td>
                  <td style={cell(2)}>
                    <span className="od-cellv od-amt">
                      <CountUp value={p.amount} animate={show} delay={isLive ? 250 : baseMs + idx * 60 + 2 * 35 + 250} duration={1000} />
                    </span>
                  </td>
                  <td style={cell(3)}>
                    <span className={`od-pill od-pill-${p.status.toLowerCase()}`}>
                      <StatusIcon status={p.status} /> {p.status}
                    </span>
                  </td>
                  <td style={{ ...cell(4), textAlign: "right" }}>
                    <button type="button" aria-label="Row actions" className="od-icon-btn"><MoreVertical size={15} /></button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Section>
  );
}

/* ============================ PEOPLE TABLES (latest enrollments / graduates) ============================ */

function PeopleTable({ title, rows, dateLabel, href, empty, show, delay, variant }) {
  return (
    <Section variant={variant} delay={delay} title={title} action={<ViewLink href={href}>View All</ViewLink>}>
      <div className="od-table-wrap">
        <table className="od-table">
          <thead>
            <tr>{["Student", "Course", dateLabel, "Status"].map((h) => <th key={h}>{h}</th>)}</tr>
          </thead>
          <tbody>
            {rows.length ? rows.map((r, idx) => {
              const done = /complete|graduat/i.test(r.status);
              return (
                <tr key={r.id} style={{ "--i": idx }} onMouseMove={show ? spotlight : undefined}>
                  <td style={{ "--c": 0 }}><span className="od-cellv">{r.student}{r.admission ? <small style={{ display: "block", opacity: 0.6 }}>{r.admission}</small> : null}</span></td>
                  <td style={{ "--c": 1 }}><span className="od-cellv">{r.course}</span></td>
                  <td style={{ "--c": 2 }}><span className="od-cellv">{r.date}</span></td>
                  <td style={{ "--c": 3 }}><span className={`od-pill od-pill-${done ? "completed" : "pending"}`}>{r.status}</span></td>
                </tr>
              );
            }) : (
              <tr><td colSpan={4} style={{ padding: 16, opacity: 0.6 }}>{empty}</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </Section>
  );
}

/* ============================ STAGE (remounts on replay → resets everything) ============================ */

function DashboardStage({ show, model, brand, userName, greeting, onApplyFilters }) {
  const { payments, methods, collected } = model;
  const [course, setCourse] = useState("all");
  const monthLabels = model.monthly.length ? model.monthly.map((m) => m.label) : ["—", "—"];
  const monthValues = model.monthly.length ? model.monthly.map((m) => m.value) : [0, 0];
  const focus = course === "all" ? null : model.courses.findIndex((c) => c.label === course);

  return (
    <div className="od-stage">
      <div>
        <div className="od-eyebrow">{brand}</div>
        <h1 className="od-title">{greeting}, {userName} <span className="od-wave">👋</span></h1>
      </div>

      <FilterBar onApply={onApplyFilters} />

      <div className="od-grid-stats">
        {model.stats.map((s, i) => (
          <StatCard
            key={s.key}
            stat={s}
            index={i}
            show={show}
            value={s.value}
            bump={0}
          />
        ))}
      </div>

      <Section
        variant="rise"
        delay={950}
        title="Enrollments by Course"
        action={
          <div className="od-actions">
            <select className="od-select" value={course} onChange={(e) => setCourse(e.target.value)} aria-label="Course filter">
              <option value="all">All Courses</option>
              {model.courses.map((c) => <option key={c.label} value={c.label}>{c.label}</option>)}
            </select>
            <ViewLink href="/originlmsv2/enrollments/list">View Report</ViewLink>
          </div>
        }
      >
        <BarChart data={model.courses.length ? model.courses : [{ label: "No enrollments yet", value: 0, tone: "blue" }]} show={show} focus={focus} />
      </Section>

      <Section
        variant="wipe"
        delay={1250}
        title="Monthly Enrollments"
        action={
          <div className="od-actions">
            <ViewLink href="/originlmsv2/enrollments/list">View Report</ViewLink>
          </div>
        }
      >
        <TrendChart labels={monthLabels} values={monthValues} show={show} yTicks={niceTicks(Math.max(...monthValues))} />
      </Section>

      <Section
        variant="wipe"
        delay={1400}
        title="Payments by Month"
        action={<ViewLink href="/originlmsv2/payments/list">View Report</ViewLink>}
      >
        <TrendChart
          labels={model.paymentMonths.map((m) => m.label)}
          values={model.paymentMonths.map((m) => m.value)}
          show={show}
          unit=""
          yTicks={niceTicks(Math.max(...model.paymentMonths.map((m) => m.value)))}
          tickFmt={(v) => (v >= 1e6 ? `${+(v / 1e6).toFixed(1)}M` : v >= 1e3 ? `${+(v / 1e3).toFixed(1)}K` : v)}
          valueFmt={(v) => `KES ${Number(v).toLocaleString("en-US")}`}
        />
      </Section>

      <div className="od-grid-bottom">
        <Section variant="left" delay={1550} title="Payment Methods" fill>
          <PaymentMethods methods={methods} total={collected} show={show} />
        </Section>
        <PaymentsTable payments={payments} show={show} live newId={null} tick={0} delay={1700} />
      </div>

      <PeopleTable variant="rise" delay={1900} title="Latest Enrollments" dateLabel="Enrolled" href="/originlmsv2/enrollments/list" rows={model.enrollments} empty="No enrollments yet." show={show} />
      <PeopleTable variant="rise" delay={2100} title="Latest Graduates" dateLabel="Completed" href="/originlmsv2/enrollments/list" rows={model.graduates} empty="No graduates yet." show={show} />
    </div>
  );
}

/* ============================ MAIN COMPONENT ============================ */

export default function OriginDashboard({
  brand = "Origin LMS",
  userName = "Superadmin",
  greeting = "Good Morning",
  onApplyFilters, // ({ preset, from, to }) => void — from/to are '' for All Time
  demo, // true/false pins this instance; undefined → follow the saved setting
  revealRepeat = false, // true → every block replays each time it re-enters the screen (default: reveal once)
  data, // API payload from api/originlmsv2/dashboard/main (required)
}) {
  const prefs = useGridPrefs();
  const show = demo ?? (prefs.presentation && prefs.replay); // entrance animations: presentation on AND replay on
  const model = useMemo(() => (data ? buildModel(data) : null), [data]);
  const stageCtx = useMemo(() => ({ show, repeat: revealRepeat }), [show, revealRepeat]);

  // `replayTick` is stored: remember the value we loaded with so only a CHANGE after mount replays
  const [baseTick] = useState(() => getGridPrefs().replayTick);
  const replayKey = prefs.replayTick === baseTick ? 0 : prefs.replayTick;

  // press R anywhere (not while typing) to replay the entrance
  useEffect(() => {
    if (!show) return undefined;
    const onKey = (e) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const t = e.target;
      if (t && (t.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(t.tagName))) return;
      if (e.key === "r" || e.key === "R") replayGrids();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [show]);

  if (!model) return null;

  return (
    <div className={`od-dashboard ${show ? "od-show" : ""}`}>
      <StageCtx.Provider value={stageCtx}>
      <DashboardStage
        key={`${show ? 1 : 0}-${replayKey}`}
        show={show}
        model={model}
        brand={brand}
        userName={userName}
        greeting={greeting}
        onApplyFilters={onApplyFilters}
      />
      </StageCtx.Provider>
    </div>
  );
}
