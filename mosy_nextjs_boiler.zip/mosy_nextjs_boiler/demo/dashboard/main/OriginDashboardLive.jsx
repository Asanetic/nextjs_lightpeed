'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import OriginDashboard from './OriginDashboard';
import { mosyGetData, mosyGetLSData, dayTime } from '../../../MosyUtils/hiveUtils';
import { getApiRoutes } from '../../AppRoutes/apiRoutesHandler';
import saAuthConfigs from '../../../auth/featureConfig/saAuthConfigs';

const apiRoutes = getApiRoutes();
const REFRESH_MS = 30000; // live: re-pull the dashboard payload every 30s

// Fetches the dashboard payload and feeds it to <OriginDashboard data={…} />.
export default function OriginDashboardLive() {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [userName, setUserName] = useState('there');
  const range = useRef({ from: '', to: '' }); // current filter; the 30s refresh keeps using it

  const load = useCallback(async () => {
    const r = await mosyGetData({ endpoint: apiRoutes.dashboard.main, params: { ...range.current } });
    if (r?.status === 'success') { setData(r); setError(null); }
    else setError((prev) => prev || r?.message || 'Unable to load dashboard data.');
  }, []);

  const applyFilters = useCallback(({ from, to }) => {
    range.current = { from: from || '', to: to || '' };
    load();
  }, [load]);

  useEffect(() => {
    const { sessionPrefix, usernameCol } = saAuthConfigs;
    const raw = mosyGetLSData(`${sessionPrefix}_sa_authsess_${usernameCol}_val`);
    if (raw) setUserName(String(raw).split(' ')[0]);
    load();
    const t = setInterval(load, REFRESH_MS);
    return () => clearInterval(t);
  }, [load]);

  if (!data) 
  {

    return error ? (
      <div className="alert alert-danger text-center">
        <p className="mb-3">{error}</p>
        <button className="btn btn-outline-danger btn-sm" onClick={load}>Try Again</button>
      </div>
    ) : <p className="text-muted p-4">Loading dashboard…</p>;

  }
  
  return <OriginDashboard data={data} userName={userName} greeting={`Good ${dayTime()}`} onApplyFilters={applyFilters} />;
}
