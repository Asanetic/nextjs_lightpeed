'use client';

import { useState } from 'react';

const PRESETS = [
  { key: 'today', label: 'Today' },
  { key: 'yesterday', label: 'Yesterday' },
  { key: 'week', label: 'This week' },
  { key: 'month', label: 'This month' },
];

// Local YYYY-MM-DD — NOT toISOString(), which shifts a day back in UTC+ zones.
const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

export function presetRange(preset) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  if (preset === 'yesterday') {
    const d = new Date(today);
    d.setDate(d.getDate() - 1);
    return { start: iso(d), end: iso(d) };
  }
  if (preset === 'week') {
    const d = new Date(today);
    d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); // week starts Monday
    return { start: iso(d), end: iso(today) };
  }
  if (preset === 'month') {
    return { start: iso(new Date(today.getFullYear(), today.getMonth(), 1)), end: iso(today) };
  }
  return { start: iso(today), end: iso(today) };
}

// Presets apply immediately. Custom start/end apply via the Apply button
// (so typing a date doesn't refetch on every change).
export default function DashboardDateFilter({ value, onApply }) {
  const [preset, setPreset] = useState('today');
  const [custom, setCustom] = useState(value);

  const pick = (key) => {
    const r = presetRange(key);
    setPreset(key);
    setCustom(r);
    onApply(r);
  };

  const canApply = custom.start && custom.end;

  return (
    <div className="dfilter">
      {PRESETS.map((p) => (
        <button key={p.key} type="button" className={`dfilter-pill ${preset === p.key ? 'is-active' : ''}`} onClick={() => pick(p.key)}>
          {p.label}
        </button>
      ))}
      <label className="dfilter-field">
        <span>Start</span>
        <input type="date" value={custom.start} max={custom.end || undefined}
          onChange={(e) => { setPreset('custom'); setCustom({ ...custom, start: e.target.value }); }} />
      </label>
      <label className="dfilter-field">
        <span>End</span>
        <input type="date" value={custom.end} min={custom.start || undefined}
          onChange={(e) => { setPreset('custom'); setCustom({ ...custom, end: e.target.value }); }} />
      </label>
      <button type="button" className="dfilter-apply" disabled={!canApply} onClick={() => onApply(custom)}>Apply</button>

      <style jsx>{`
        .dfilter { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; margin-bottom: 20px; }
        .dfilter-pill {
          height: 32px; padding: 0 14px; border-radius: 999px; font-size: 12px; font-weight: 600;
          border: 1px solid rgba(0, 0, 0, 0.12); background: #fff; color: #555; cursor: pointer;
        }
        .dfilter-pill:hover { border-color: #2563eb; color: #2563eb; }
        .dfilter-pill.is-active { background: #2563eb; border-color: #2563eb; color: #fff; }
        .dfilter-field { display: flex; align-items: center; gap: 6px; margin: 0; font-size: 12px; font-weight: 600; color: #888; }
        .dfilter-field input {
          height: 32px; padding: 0 10px; border: 1px solid rgba(0, 0, 0, 0.12); border-radius: 8px; font-size: 13px;
        }
        .dfilter-apply {
          height: 32px; padding: 0 16px; border: 0; border-radius: 8px; background: #2563eb; color: #fff;
          font-size: 12px; font-weight: 600; cursor: pointer;
        }
        .dfilter-apply:disabled { opacity: 0.5; cursor: not-allowed; }
      `}</style>
    </div>
  );
}
