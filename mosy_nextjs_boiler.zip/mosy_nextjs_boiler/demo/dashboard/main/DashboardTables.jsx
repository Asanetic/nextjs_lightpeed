'use client';

import { mosyFormatDateOnly, toNum } from '../../../MosyUtils/hiveUtils';

function TableSection({ title, empty, emptyText, children }) {
  return (
    <div className="dash-section">
      <div className="dash-section-head">
        <h5>{title}</h5>
      </div>
      {empty ? <div className="dash-empty">{emptyText}</div> : (
        <div className="dash-table-wrap">{children}</div>
      )}

      <style jsx>{`
        .dash-section {
          background: #fff;
          border: 1px solid #e6e8ec;
          border-radius: 14px;
          padding: 18px;
          height: 100%;
        }
        .dash-section-head h5 {
          margin: 0 0 12px;
          font-weight: 700;
          font-size: 1rem;
          color: #0f172a;
        }
        .dash-empty {
          color: #94a3b8;
          font-size: 0.88rem;
          padding: 18px 4px;
        }
        .dash-table-wrap {
          overflow-x: auto;
        }
      `}</style>
    </div>
  );
}

export function PaymentByClient({ items = [] }) {
  return (
    <TableSection title="Payment by Client" empty={items.length === 0} emptyText="No payments logged yet.">
      <table className="dash-table">
        <thead>
          <tr>
            <th>Client</th>
            <th>Paid</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item, i) => (
            <tr key={i}>
              <td>{item.label}</td>
              <td>{toNum(item.value, 0)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <style jsx>{`
        .dash-table { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
        .dash-table th { text-align: left; color: #94a3b8; font-weight: 600; font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.03em; padding: 6px 8px; border-bottom: 1px solid #f1f5f9; white-space: nowrap; }
        .dash-table td { padding: 10px 8px; border-bottom: 1px solid #f8fafc; color: #334155; white-space: nowrap; }
      `}</style>
    </TableSection>
  );
}

export function TopTrafficSources({ items = [] }) {
  return (
    <TableSection title="Top Traffic Sources / Pages" empty={items.length === 0} emptyText="No site traffic logged yet.">
      <table className="dash-table">
        <thead>
          <tr>
            <th>Page</th>
            <th>Source</th>
            <th>Visits</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item, i) => (
            <tr key={i}>
              <td>{item.page || '—'}</td>
              <td>{item.source || '—'}</td>
              <td>{toNum(item.value, 0)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <style jsx>{`
        .dash-table { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
        .dash-table th { text-align: left; color: #94a3b8; font-weight: 600; font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.03em; padding: 6px 8px; border-bottom: 1px solid #f1f5f9; white-space: nowrap; }
        .dash-table td { padding: 10px 8px; border-bottom: 1px solid #f8fafc; color: #334155; max-width: 220px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      `}</style>
    </TableSection>
  );
}

export function OverduePayments({ items = [] }) {
  return (
    <TableSection title="Overdue Payments" empty={items.length === 0} emptyText="No overdue payments — nice.">
      <table className="dash-table">
        <thead>
          <tr>
            <th>Client</th>
            <th>Phone</th>
            <th>Reference</th>
            <th>Amount</th>
            <th>Due</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item, i) => (
            <tr key={i}>
              <td>{item.contact_name || '—'}</td>
              <td>{item.phone_number || '—'}</td>
              <td>{item.reference || '—'}</td>
              <td>{toNum(item.amount, 0)}</td>
              <td className="dash-table-time">{mosyFormatDateOnly(item.due_date)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <style jsx>{`
        .dash-table { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
        .dash-table th { text-align: left; color: #94a3b8; font-weight: 600; font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.03em; padding: 6px 8px; border-bottom: 1px solid #f1f5f9; white-space: nowrap; }
        .dash-table td { padding: 10px 8px; border-bottom: 1px solid #f8fafc; color: #334155; white-space: nowrap; }
        .dash-table-time { font-weight: 600; color: #b91c1c; }
      `}</style>
    </TableSection>
  );
}
