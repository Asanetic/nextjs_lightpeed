'use client';

import ElforgeChart from '../../../components/ElforgeChart';

function ChartBox({ title, empty, children, wide = false }) {
  return (
    <div className={wide ? 'col-md-12 mb-3' : 'col-md-6 mb-3'}>
      <div className="dash-section">
        <div className="dash-section-head">
          <h5>{title}</h5>
        </div>
        {empty ? <div className="dash-empty">No data yet.</div> : children}
      </div>

      <style jsx>{`
        .dash-section {
          background: #fff;
          border: 1px solid #e6e8ec;
          border-radius: 14px;
          padding: 18px;
          height: 100%;
        }
        .dash-section-head h5 {
          margin: 0 0 8px;
          font-weight: 700;
          font-size: 1rem;
          color: #0f172a;
        }
        .dash-empty {
          color: #94a3b8;
          font-size: 0.88rem;
          padding: 40px 4px;
          text-align: center;
        }
      `}</style>
    </div>
  );
}

function allZero(rows, keys) {
  return rows.length === 0 || rows.every((r) => keys.every((k) => !Number(r[k])));
}

export default function DashboardCharts({
  leadsByMonth = [],
  revenueByMonth = [],
  trafficByMonth = [],
  callsMessagesByMonth = [],
  leadFunnelByStage = [],
}) {
  return (
    <div className="row m-0">
      <ChartBox title="Leads by Month" empty={allZero(leadsByMonth, ['value'])}>
        <ElforgeChart
          chartType="bar"
          dataKey="label"
          data={leadsByMonth}
          series={[{ key: 'value', color: '#2E6CF5', name: 'New Leads' }]}
          height={280}
        />
      </ChartBox>

      <ChartBox title="Revenue Collected vs Pending by Month" empty={allZero(revenueByMonth, ['paid', 'pending'])}>
        <ElforgeChart
          chartType="bar"
          dataKey="label"
          data={revenueByMonth}
          series={[
            { key: 'paid', color: '#16a34a', name: 'Collected' },
            { key: 'pending', color: '#94a3b8', name: 'Pending' },
          ]}
          height={280}
        />
      </ChartBox>

      <ChartBox title="Traffic by Month" empty={allZero(trafficByMonth, ['value'])}>
        <ElforgeChart
          chartType="bar"
          dataKey="label"
          data={trafficByMonth}
          series={[{ key: 'value', color: '#845EC2', name: 'Visits' }]}
          height={280}
        />
      </ChartBox>

      <ChartBox title="Calls & Messages by Month" empty={allZero(callsMessagesByMonth, ['calls', 'messages'])}>
        <ElforgeChart
          chartType="bar"
          dataKey="label"
          data={callsMessagesByMonth}
          series={[
            { key: 'calls', color: '#16a34a', name: 'Calls' },
            { key: 'messages', color: '#2563eb', name: 'Messages' },
          ]}
          height={280}
        />
      </ChartBox>

      <ChartBox title="Lead Funnel by Stage" empty={allZero(leadFunnelByStage, ['value'])} wide>
        <ElforgeChart
          chartType="bar"
          dataKey="label"
          data={leadFunnelByStage}
          series={[{ key: 'value', color: '#FF922B', name: 'Opportunities' }]}
          height={280}
        />
      </ChartBox>
    </div>
  );
}
