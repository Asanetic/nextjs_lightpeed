'use client';

import { useEffect, useState } from 'react';
import { ResponsiveContainer, AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';

import DashboardHeader from './DashboardHeader';
import DashboardKpiCard from './DashboardKpiCard';
import DashboardSectionCard from './DashboardSectionCard';
import DashboardSkeleton from './DashboardSkeleton';
import DashboardDateFilter, { presetRange } from './DashboardDateFilter';

import { mosyGetData } from '../../../MosyUtils/hiveUtils';
import { getApiRoutes } from '../../AppRoutes/apiRoutesHandler';
import { MosyTitleTag } from '../../UiControl/componentControl';

const apiRoutes = getApiRoutes();

const EMPTY_DATA = {
  summary: { visits: 0, visitors: 0, messages: 0, reminders: 0 },
  visitsByAgent: [],
  dailyActivity: [],
  latestTraffic: [],
  logs: { total: 0, success: 0, failed: 0, remindersSet: 0 },
  logsPerDay: [],
};

const fmtDateTime = (d) =>
  d ? new Date(d).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—';

const fmtDay = (iso) =>
  new Date(`${iso}T00:00:00`).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });

export default function DashboardHolder() {
  const [range, setRange] = useState(presetRange('today'));
  const [data, setData] = useState(EMPTY_DATA);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  async function fetchData() {
    setLoading(true);
    setError(null);

    const response = await mosyGetData({ endpoint: apiRoutes.dashboard.main, params: range });

    if (response?.status === 'success') {
      setData({
        summary: response.summary || EMPTY_DATA.summary,
        visitsByAgent: response.visitsByAgent || [],
        dailyActivity: response.dailyActivity || [],
        latestTraffic: response.latestTraffic || [],
        logs: response.logs || EMPTY_DATA.logs,
        logsPerDay: response.logsPerDay || [],
      });
    } else {
      setError(response?.message || 'Unable to load dashboard data.');
    }

    setLoading(false);
  }

  useEffect(() => { fetchData(); }, [range.start, range.end]); // eslint-disable-line react-hooks/exhaustive-deps

  const { summary: s, visitsByAgent, dailyActivity, latestTraffic, logs, logsPerDay } = data;
  const n = (v) => Number(v || 0).toLocaleString('en-US');
  const hasActivity = dailyActivity.some((d) => d.visits > 0 || d.messages > 0);
  const hasLogs = logsPerDay.some((d) => d.success > 0 || d.failed > 0);
  const successRate = logs.total ? Math.round((logs.success / logs.total) * 100) : 0;
  const rangeLabel = range.start === range.end ? fmtDay(range.start) : `${fmtDay(range.start)} – ${fmtDay(range.end)}`;

  const cards = [
    { label: 'Visits', value: s.visits, sublabel: rangeLabel, icon: 'fa fa-eye', accent: 'blue' },
    { label: 'Unique visitors', value: s.visitors, sublabel: rangeLabel, icon: 'fa fa-users', accent: 'blue' },
    { label: 'Messages sent', value: s.messages, sublabel: rangeLabel, icon: 'fa fa-comments', accent: 'green' },
    { label: 'Reminders run', value: s.reminders, sublabel: rangeLabel, icon: 'fa fa-bell', accent: 'orange' },
  ];

  // Maira data logs — filtered by execution time (run_at) for the same range.
  const logCards = [
    { label: 'Data requests', value: n(logs.total), sublabel: `Executed ${rangeLabel}`, icon: 'fa fa-exchange', accent: 'blue' },
    { label: 'Success rate', value: `${successRate}%`, sublabel: `${n(logs.success)} of ${n(logs.total)} succeeded`, icon: 'fa fa-check-circle', accent: successRate >= 80 ? 'green' : successRate >= 50 ? 'orange' : 'red' },
    { label: 'Not successful', value: n(logs.failed), sublabel: 'Failed / skipped / error', icon: 'fa fa-exclamation-triangle', accent: logs.failed > 0 ? 'red' : 'green' },
    { label: 'Reminders set', value: n(logs.remindersSet), sublabel: 'From data requests', icon: 'fa fa-bell', accent: 'orange' },
  ];

  return (
    <div className="dash-wrapper col-md-12 p-0 m-0">
      <DashboardHeader />
      <DashboardDateFilter value={range} onApply={setRange} />
      <MosyTitleTag title="App usages and notifications" className="my-2" />

      {loading ? (
        <DashboardSkeleton />
      ) : error ? (
        <div className="alert alert-danger text-center">
          <p className="mb-3">{error}</p>
          <button className="btn btn-outline-danger btn-sm" onClick={fetchData}>Try Again</button>
        </div>
      ) : (
        <>
          {/* Cards — for the selected range */}
          <div className="row m-0 mb-4" style={{ rowGap: 16 }}>
            {cards.map((c) => (
              <div className="col-12 col-sm-6 col-xl-3" key={c.label}>
                <DashboardKpiCard label={c.label} value={n(c.value)} sublabel={c.sublabel} icon={c.icon} accent={c.accent} />
              </div>
            ))}
          </div>

          {/* Charts */}
          <div className="row m-0 mb-4" style={{ rowGap: 16 }}>
            <div className="col-12 col-lg-7">
              <DashboardSectionCard title="Activity" description="Visits and messages sent per day.">
                {hasActivity ? (
                  <ResponsiveContainer width="100%" height={260}>
                    <AreaChart data={dailyActivity} margin={{ top: 4, right: 12, left: -12, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee" />
                      <XAxis dataKey="label" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                      <YAxis allowDecimals={false} tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                      <Tooltip />
                      <Legend />
                      <Area type="monotone" dataKey="visits" name="Visits" stroke="#2563eb" fill="#2563eb" fillOpacity={0.15} />
                      <Area type="monotone" dataKey="messages" name="Messages" stroke="#16a34a" fill="#16a34a" fillOpacity={0.15} />
                    </AreaChart>
                  </ResponsiveContainer>
                ) : (
                  <p className="text-muted small mb-0">No activity in this period.</p>
                )}
              </DashboardSectionCard>
            </div>

            <div className="col-12 col-lg-5">
              <DashboardSectionCard title="Visits by agent" description="Top agents in this period.">
                {visitsByAgent.length ? (
                  <ResponsiveContainer width="100%" height={Math.max(260, visitsByAgent.length * 40)}>
                    <BarChart data={visitsByAgent} layout="vertical" margin={{ top: 4, right: 20, left: 8, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#eee" />
                      <XAxis type="number" allowDecimals={false} tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                      <YAxis type="category" dataKey="label" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} width={110} />
                      <Tooltip />
                      <Bar dataKey="value" name="Visits" fill="#2563eb" radius={[0, 6, 6, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <p className="text-muted small mb-0">No visits recorded in this period.</p>
                )}
              </DashboardSectionCard>
            </div>
          </div>
          <MosyTitleTag title="Maira Data logs" className="my-2" />
          {/* Maira data logs — by execution time */}
          <div className="row m-0 mb-4" style={{ rowGap: 16 }}>
            {logCards.map((c) => (
              <div className="col-12 col-sm-6 col-xl-3" key={c.label}>
                <DashboardKpiCard label={c.label} value={c.value} sublabel={c.sublabel} icon={c.icon} accent={c.accent} />
              </div>
            ))}
          </div>

          <div className="row m-0 mb-4">
            <div className="col-12">
              <DashboardSectionCard title="Maira data logs by date" description="Requests by execution time, successful vs not.">
                {hasLogs ? (
                  <ResponsiveContainer width="100%" height={260}>
                    <BarChart data={logsPerDay} margin={{ top: 4, right: 12, left: -12, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee" />
                      <XAxis dataKey="label" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                      <YAxis allowDecimals={false} tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="success" name="Successful" stackId="logs" fill="#16a34a" />
                      <Bar dataKey="failed" name="Not successful" stackId="logs" fill="#dc2626" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <p className="text-muted small mb-0">No data requests executed in this period.</p>
                )}
              </DashboardSectionCard>
            </div>
          </div>

          {/* Latest traffic logs */}
          <div className="row m-0">
            <div className="col-12">
              <DashboardSectionCard title="Latest traffic logs">
                {latestTraffic.length ? (
                  <div className="table-responsive">
                    <table className="table mb-0" style={{ fontSize: 13.5 }}>
                      <thead>
                        <tr className="text-muted" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                          <th>Date</th>
                          <th>Agent</th>
                          <th>Asset</th>
                          <th>Page visited</th>
                          <th>Visitor</th>
                          <th>Device</th>
                        </tr>
                      </thead>
                      <tbody>
                        {latestTraffic.map((r, i) => (
                          <tr key={i}>
                            <td>{fmtDateTime(r.visitdate)}</td>
                            <td>{r.agent || '—'}</td>
                            <td>{r.asset || '—'}</td>
                            <td>{r.pagevisited || '—'}</td>
                            <td>{r.visitor_code || '—'}</td>
                            <td>{r.device || '—'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p className="text-muted small mb-0">No traffic recorded in this period.</p>
                )}
              </DashboardSectionCard>
            </div>
          </div>
        </>
      )}

      <DashGlobalStyles />
    </div>
  );
}

// Shared premium card shell (KPI cards + chart/table sections) — one
// definition, so every dashboard card looks and behaves identically.
function DashGlobalStyles() {
  return (
    <style jsx global>{`
      .dash-card {
        background: #fff;
        border: 1px solid rgba(0, 0, 0, 0.06);
        border-radius: 16px;
        padding: 22px;
        min-height: 150px;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
      }
      .dash-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
      }
      .dash-card-label {
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: #888;
      }
      .dash-card-value {
        font-size: 30px;
        font-weight: 700;
        line-height: 1.15;
        margin-top: 4px;
      }
      .dash-card-desc {
        font-size: 13px;
        color: #888;
        margin-top: 2px;
      }
      .dash-wrapper .row > div {
        padding-left: 8px;
        padding-right: 8px;
      }
      .dash-wrapper .row {
        margin-left: -8px;
        margin-right: -8px;
      }
    `}</style>
  );
}
