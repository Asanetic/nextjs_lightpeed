'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { ResponsiveContainer, AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';

import DashboardKpiCard from './DashboardKpiCard';
import DashboardSectionCard from './DashboardSectionCard';
import DashboardSkeleton from './DashboardSkeleton';

import { mosyGetData } from '../../../MosyUtils/hiveUtils';
import { getApiRoutes } from '../../AppRoutes/apiRoutesHandler';

const apiRoutes = getApiRoutes();

const EMPTY_DATA = {
  summary: { paymentsThisMonth: 0, activeEnrollments: 0, feeArrears: 0, certificatesIssued: 0 },
  paymentsPerMonth: [],
  paymentsPerCourse: [],
  enrollmentCourseMonths: [],
  enrollmentsByCourse: [],
  arrears: [],
  attendance: { present: 0, absent: 0, notMarked: 0 },
  assessment: { assessments: 0, exams: 0, resultsPending: 0 },
  certificatesPerMonth: [],
  latestEnrollments: [],
  attention: { unpaidStudents: 0, resultsPending: 0, noRecentAttendance: 0, awaitingCompletion: 0 },
};

const n = (v) => Number(v || 0).toLocaleString('en-US');
const kes = (v) => `KES ${n(v)}`;
// 2,400,000 -> "2.4M", 840,000 -> "840K"
const kesShort = (v) => {
  const x = Number(v || 0);
  if (x >= 1e6) return `KES ${+(x / 1e6).toFixed(1)}M`;
  if (x >= 1e3) return `KES ${+(x / 1e3).toFixed(0)}K`;
  return `KES ${n(x)}`;
};

const MONTH_COLORS = ['#2563eb', '#16a34a', '#ea8a00', '#dc2626', '#7c3aed', '#0f766e'];
const axis = { tick: { fontSize: 12 }, axisLine: false, tickLine: false };
const Empty = ({ text }) => <p className="text-muted small mb-0">{text}</p>;

function StatRow({ label, value, tone }) {
  return (
    <div className="d-flex justify-content-between py-2 border-bottom" style={{ fontSize: 14 }}>
      <span>{label}</span>
      <strong className={tone ? `text-${tone}` : ''}>{n(value)}</strong>
    </div>
  );
}

export default function DashboardHolder() {
  const [data, setData] = useState(EMPTY_DATA);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  async function fetchData() {
    setLoading(true);
    setError(null);

    const r = await mosyGetData({ endpoint: apiRoutes.dashboard.main, params: {} });

    if (r?.status === 'success') {
      setData({ ...EMPTY_DATA, ...r });
    } else {
      setError(r?.message || 'Unable to load dashboard data.');
    }
    setLoading(false);
  }

  useEffect(() => { fetchData(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const { summary: s, paymentsPerMonth, paymentsPerCourse, enrollmentCourseMonths, enrollmentsByCourse, arrears, attendance: att, assessment: asm, certificatesPerMonth, latestEnrollments, attention } = data;

  const cards = [
    { label: 'Payments', value: kesShort(s.paymentsThisMonth), sublabel: 'This month', icon: 'fa fa-money', accent: 'green' },
    { label: 'Enrollments', value: n(s.activeEnrollments), sublabel: 'Active', icon: 'fa fa-pencil-square-o', accent: 'blue' },
    { label: 'Fee arrears', value: kesShort(s.feeArrears), sublabel: 'Outstanding', icon: 'fa fa-exclamation-triangle', accent: s.feeArrears > 0 ? 'red' : 'green' },
    { label: 'Certificates', value: n(s.certificatesIssued), sublabel: 'Issued', icon: 'fa fa-graduation-cap', accent: 'orange' },
  ];

  const attentionItems = [
    { count: attention.unpaidStudents, text: 'students have unpaid balances' },
    { count: attention.resultsPending, text: 'exams are awaiting results' },
    { count: attention.noRecentAttendance, text: 'active students have no attendance in the last 7 days' },
    { count: attention.awaitingCompletion, text: 'enrollments are past their completion date and still open' },
  ];

  return (
    <div className="dash-wrapper col-md-12 p-0 m-0">
      <div className="mb-4">
        <h4 className="mb-1" style={{ fontWeight: 700 }}>Dashboard</h4>
        <p className="text-muted mb-0" style={{ fontSize: 14 }}>Welcome back. Here&apos;s what&apos;s happening at the college.</p>
      </div>

      {loading ? (
        <DashboardSkeleton />
      ) : error ? (
        <div className="alert alert-danger text-center">
          <p className="mb-3">{error}</p>
          <button className="btn btn-outline-danger btn-sm" onClick={fetchData}>Try Again</button>
        </div>
      ) : (
        <>
          <div className="row m-0 mb-4" style={{ rowGap: 16 }}>
            {cards.map((c) => (
              <div className="col-12 col-sm-6 col-xl-3" key={c.label}>
                <DashboardKpiCard {...c} />
              </div>
            ))}
          </div>

          <div className="row m-0 mb-4">
            <div className="col-12">
              <DashboardSectionCard title="Payments per month" description="Last 12 months.">
                {paymentsPerMonth.some((d) => d.value > 0) ? (
                  <ResponsiveContainer width="100%" height={260}>
                    <AreaChart data={paymentsPerMonth} margin={{ top: 4, right: 12, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee" />
                      <XAxis dataKey="label" {...axis} />
                      <YAxis {...axis} tickFormatter={(v) => (v >= 1000 ? `${v / 1000}K` : v)} />
                      <Tooltip formatter={(v) => kes(v)} />
                      <Area type="monotone" dataKey="value" name="Payments" stroke="#16a34a" fill="#16a34a" fillOpacity={0.15} />
                    </AreaChart>
                  </ResponsiveContainer>
                ) : <Empty text="No payments recorded in the last 12 months." />}
              </DashboardSectionCard>
            </div>
          </div>

          <div className="row m-0 mb-4">
            <div className="col-12">
              <DashboardSectionCard title="Enrollments per course / month" description={`Last ${enrollmentCourseMonths.length} months, top courses.`}>
                {enrollmentsByCourse.length ? (
                  <ResponsiveContainer width="100%" height={320}>
                    <BarChart data={enrollmentsByCourse} margin={{ top: 4, right: 12, left: -12, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee" />
                      <XAxis dataKey="course" {...axis} />
                      <YAxis allowDecimals={false} {...axis} />
                      <Tooltip />
                      <Legend />
                      {enrollmentCourseMonths.map((m, i) => (
                        <Bar key={m} dataKey={m} name={m} fill={MONTH_COLORS[i % MONTH_COLORS.length]} radius={[4, 4, 0, 0]} />
                      ))}
                    </BarChart>
                  </ResponsiveContainer>
                ) : <Empty text="No enrollments in this period." />}
              </DashboardSectionCard>
            </div>
          </div>

          <div className="row m-0 mb-4">
            <div className="col-12">
              <DashboardSectionCard title="Payments per course" description="All-time totals, top 10.">
                {paymentsPerCourse.length ? (
                  <ResponsiveContainer width="100%" height={320}>
                    <BarChart data={paymentsPerCourse} margin={{ top: 4, right: 12, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee" />
                      <XAxis dataKey="label" {...axis} />
                      <YAxis {...axis} tickFormatter={kesShort} />
                      <Tooltip formatter={(v) => kes(v)} />
                      <Bar dataKey="value" name="Payments" fill="#2563eb" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                ) : <Empty text="No payments linked to courses yet." />}
              </DashboardSectionCard>
            </div>
          </div>

          <div className="row m-0 mb-4">
            <div className="col-12">
              <DashboardSectionCard title="Fee arrears analysis">
                {arrears.length ? (
                  <div className="table-responsive">
                    <table className="table mb-2" style={{ fontSize: 13.5 }}>
                      <thead>
                        <tr className="text-muted" style={{ fontSize: 11, textTransform: 'uppercase' }}>
                          <th>Course</th><th className="text-end">Students</th><th className="text-end">Outstanding</th>
                        </tr>
                      </thead>
                      <tbody>
                        {arrears.map((r) => (
                          <tr key={r.course}>
                            <td>{r.course}</td>
                            <td className="text-end">{n(r.students)}</td>
                            <td className="text-end">{kes(r.outstanding)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : <Empty text="No outstanding balances." />}
                <Link href="/originlmsv2/fees/balances" className="btn btn-outline-primary btn-sm mt-2">View all balances</Link>
              </DashboardSectionCard>
            </div>
          </div>

          <div className="row m-0 mb-4" style={{ rowGap: 16 }}>
            <div className="col-12 col-lg-6">
              <DashboardSectionCard title="Attendance today">
                <StatRow label="Present" value={att.present} tone="success" />
                <StatRow label="Absent" value={att.absent} tone="danger" />
                <StatRow label="Not marked" value={att.notMarked} tone="warning" />
                <Link href="/originlmsv2/attendance/students" className="btn btn-outline-primary btn-sm mt-3">Take attendance</Link>
              </DashboardSectionCard>
            </div>
            <div className="col-12 col-lg-6">
              <DashboardSectionCard title="Assessment">
                <StatRow label="Assessments" value={asm.assessments} />
                <StatRow label="Exams" value={asm.exams} />
                <StatRow label="Results pending" value={asm.resultsPending} tone="warning" />
                <Link href="/originlmsv2/results/list" className="btn btn-outline-primary btn-sm mt-3">View results</Link>
              </DashboardSectionCard>
            </div>
          </div>

          <div className="row m-0 mb-4">
            <div className="col-12">
              <DashboardSectionCard title="Certificates issued" description="Per month, last 12 months.">
                {certificatesPerMonth.some((d) => d.value > 0) ? (
                  <ResponsiveContainer width="100%" height={240}>
                    <BarChart data={certificatesPerMonth} margin={{ top: 4, right: 12, left: -12, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee" />
                      <XAxis dataKey="label" {...axis} />
                      <YAxis allowDecimals={false} {...axis} />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="value" name="Certificates" fill="#ea8a00" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                ) : <Empty text="No certificates issued in the last 12 months." />}
              </DashboardSectionCard>
            </div>
          </div>

          <div className="row m-0">
            <div className="col-12">
              <DashboardSectionCard title="Needs attention">
                {attentionItems.some((a) => a.count > 0) ? (
                  <ul className="mb-0 ps-3" style={{ fontSize: 14, lineHeight: 2 }}>
                    {attentionItems.filter((a) => a.count > 0).map((a) => (
                      <li key={a.text}><strong>{n(a.count)}</strong> {a.text}</li>
                    ))}
                  </ul>
                ) : <Empty text="Nothing needs attention right now." />}
              </DashboardSectionCard>
            </div>
          </div>

          <div className="row m-0 mt-4">
            <div className="col-12">
              <DashboardSectionCard title="Latest enrollments">
                {latestEnrollments.length ? (
                  <div className="table-responsive">
                    <table className="table mb-2" style={{ fontSize: 13.5 }}>
                      <thead>
                        <tr className="text-muted" style={{ fontSize: 11, textTransform: 'uppercase' }}>
                          <th>Date</th><th>Admission no.</th><th>Student</th><th>Course</th><th>Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {latestEnrollments.map((r) => (
                          <tr key={r.enrollment_id}>
                            <td>{r.enrollment_date ? new Date(r.enrollment_date).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—'}</td>
                            <td>{r.admission_number || '—'}</td>
                            <td>{r.student || '—'}</td>
                            <td>{r.course || '—'}</td>
                            <td>{r.completion_status || 'Active'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : <Empty text="No enrollments yet." />}
                <Link href="/originlmsv2/enrollments/list" className="btn btn-outline-primary btn-sm mt-2">View all enrollments</Link>
              </DashboardSectionCard>
            </div>
          </div>
        </>
      )}

      <DashGlobalStyles />
    </div>
  );
}

// Shared premium card shell (KPI cards + chart/table sections).
function DashGlobalStyles() {
  return (
    <style jsx global>{`
      .dash-card {
        background: #fff;
        border: 1px solid rgba(0, 0, 0, 0.06);
        border-radius: 16px;
        padding: 22px;
        min-height: 150px;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
      }
      .dash-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
      }
      .dash-card-label {
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: #888;
      }
      .dash-card-value {
        font-size: 30px;
        font-weight: 700;
        line-height: 1.15;
        margin-top: 4px;
      }
      .dash-card-desc {
        font-size: 13px;
        color: #888;
        margin-top: 2px;
      }
      .dash-wrapper .row > div {
        padding-left: 8px;
        padding-right: 8px;
      }
      .dash-wrapper .row {
        margin-left: -8px;
        margin-right: -8px;
      }
    `}</style>
  );
}
