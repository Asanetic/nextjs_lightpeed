'use client';

import { useEffect, useState } from 'react';

import DashboardHeader from './DashboardHeader';
import SimpleCards from './SimpleCards';
import DashboardCharts from './DashboardCharts';
import FollowUpHistory from './FollowUpHistory';
import { PaymentByClient, TopTrafficSources, OverduePayments } from './DashboardTables';

import { mosyGetData } from '../../../MosyUtils/hiveUtils';
import { getApiRoutes } from '../../AppRoutes/apiRoutesHandler';

const apiRoutes = getApiRoutes();

const EMPTY_DATA = {
  is_superadmin: false,
  sites: [],
  selected_site: '',
  today_cards: [],
  month_cards: [],
  leads_by_month: [],
  revenue_by_month: [],
  traffic_by_month: [],
  calls_messages_by_month: [],
  lead_funnel_by_stage: [],
  payment_by_client: [],
  follow_up_action_log: [],
  top_traffic_sources: [],
  overdue_payments: [],
};

export default function DashboardHolder() {
  const [data, setData] = useState(EMPTY_DATA);
  const [selectedSite, setSelectedSite] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchData() {
      setLoading(true);

      const response = await mosyGetData({
        endpoint: apiRoutes.dashboard.admin,
        params: selectedSite ? { hive_site_id: selectedSite } : {},
      });

      if (response?.status === 'success') {
        setData({
          is_superadmin: !!response?.is_superadmin,
          sites: response?.sites || [],
          selected_site: response?.selected_site || '',
          today_cards: response?.today_cards || [],
          month_cards: response?.month_cards || [],
          leads_by_month: response?.leads_by_month || [],
          revenue_by_month: response?.revenue_by_month || [],
          traffic_by_month: response?.traffic_by_month || [],
          calls_messages_by_month: response?.calls_messages_by_month || [],
          lead_funnel_by_stage: response?.lead_funnel_by_stage || [],
          payment_by_client: response?.payment_by_client || [],
          follow_up_action_log: response?.follow_up_action_log || [],
          top_traffic_sources: response?.top_traffic_sources || [],
          overdue_payments: response?.overdue_payments || [],
        });
        setError(null);
      } else {
        setError(response?.message || 'Failed to load dashboard data');
      }

      setLoading(false);
    }

    fetchData();
  }, [selectedSite]);

  if (loading) {
    return (
      <div className="col-md-12 text-center py-5">
        <div className="spinner-border text-primary" role="status" style={{ width: '2.5rem', height: '2.5rem' }}>
          <span className="visually-hidden d-none">Loading...</span>
        </div>
        <p className="text-muted mt-3 mb-0">Loading dashboard...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="col-md-12 py-5">
        <div className="alert alert-danger text-center mb-0">
          <i className="fa fa-exclamation-triangle mr-2"></i>
          {error}
        </div>
      </div>
    );
  }

  return (
    <div className="dash-wrapper col-md-12 p-0 m-0">
      <DashboardHeader
        isSuperadmin={data.is_superadmin}
        sites={data.sites}
        selectedSite={selectedSite}
        onSiteChange={setSelectedSite}
      />

      <SimpleCards title="Today" cards={data.today_cards} />
      <SimpleCards title="This Month" cards={data.month_cards} />

      <DashboardCharts
        leadsByMonth={data.leads_by_month}
        revenueByMonth={data.revenue_by_month}
        trafficByMonth={data.traffic_by_month}
        callsMessagesByMonth={data.calls_messages_by_month}
        leadFunnelByStage={data.lead_funnel_by_stage}
      />

      <div className="row m-0">
        <div className="col-md-6 mb-3">
          <PaymentByClient items={data.payment_by_client} />
        </div>
        <div className="col-md-6 mb-3">
          <FollowUpHistory items={data.follow_up_action_log} />
        </div>
        <div className="col-md-6 mb-3">
          <TopTrafficSources items={data.top_traffic_sources} />
        </div>
        <div className="col-md-6 mb-3">
          <OverduePayments items={data.overdue_payments} />
        </div>
      </div>

      <style jsx global>{`
        .dash-wrapper .row > div {
          padding-left: 8px;
          padding-right: 8px;
        }
        .dash-wrapper .row {
          margin-left: -8px;
          margin-right: -8px;
        }
      `}</style>
    </div>
  );
}
