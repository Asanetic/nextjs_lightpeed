import { Suspense } from 'react';
export const metadata = {
  title: 'Groups contact list  | revuiov2',
  description: 'revuiov2 Groups contact list',
};

import ElforgeChart from "@/app/components/ElforgeChart";
import DashboardCards from './DashboardCards';
import AdsCampaignsList from '../../campaigns/uiControl/AdsCampaignsList';
import { MosyTitleTag, MosySpace } from '../../UiControl/componentControl';

const dummyData = [
  { name: 'Jan', sales: 400, profit: 240 },
  { name: 'Feb', sales: 300, profit: 220 },
  { name: 'Mar', sales: 500, profit: 260 },
];

export default function MyDashboard() {
  return (

            <>
             <div className="main-wrapper">
               <div className="page-wrapper">
                  <div className="content container-fluid p-0 m-0 ">
                      <Suspense fallback={<div>Loading...</div>}>  
                      <DashboardCards />                                  
                      <div className="p-4 bg-white rounded-xl shadow">
                      <MosyTitleTag title="Monthly views"/>

                        <ElforgeChart
                          chartType="line"
                          data={dummyData}
                          dataKey="name"
                          series={[
                            { key: 'sales', color: '#8884d8', name: 'Total Sales' },
                            { key: 'profit', color: '#82ca9d', name: 'Net Profit' },
                          ]}
                          height={350}
                        />
                        <MosySpace spaceClass='p-4'/>
                        <MosyTitleTag title="Recent Campaigns"/>
                        <AdsCampaignsList showDataControlSections={false}/>
                      </div>                        
                        
                      </Suspense>                 
                  </div>
                </div>
              </div>
            </>



  );
}
