      import { Suspense } from 'react';
      import DashboardHolder from './DashboardHolder';

      export const metadata = {
        title: 'Dashboard  | revuiov2',
        description: 'revuiov2 Advert Payments',
      };
      export default function MainDashboard() {
      return (
        <>
         <div className="main-wrapper">
           <div className="page-wrapper">
              <div className="content container-fluid p-2 m-0 ">
                  <Suspense fallback={<div>Loading...</div>}>              
                    <DashboardHolder />
                  </Suspense>                 
              </div>
            </div>
          </div>
        </>
      );
    }