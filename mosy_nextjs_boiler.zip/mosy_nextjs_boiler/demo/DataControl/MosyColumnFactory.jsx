const MosyColumnFactory = {

   //-- account_apps cols--//
  account_apps: ["record_id", "account_id", "app_id", "plan_id", "plan_name", "plan_amount", "currency", "plan_type", "plan_period", "status", "expiry_date", "hive_site_id", "hive_site_name", "created_at", "updated_at", "payment_account", "deactivated_at", "activated_at"],

   //-- app_features cols--//
  app_features: ["record_id", "feature_name", "feature_description", "feature_id", "app_id", "order_number", "hive_site_id", "hive_site_name"],

   //-- app_list cols--//
  app_list: ["app_id", "app_name", "logo", "account_id", "remark", "payment_redirect", "pricing_page_message", "hive_site_id", "hive_site_name", "app_category"],

   //-- billing_account cols--//
  billing_account: ["record_id", "account_name", "account_no", "account_tel", "account_email", "plan_id", "plan_name", "plan_amount", "plan_type", "plan_period", "expiring_on", "active_status", "hive_site_id", "hive_site_name", "app_id", "date_created", "previous_plan"],

   //-- billing_log cols--//
  billing_log: ["trx_key", "transaction_ref", "trx_type", "trx_time", "amount", "trx_source", "ref_id", "site_id", "message", "appid", "hive_site_id", "hive_site_name"],

   //-- billing_transactions cols--//
  billing_transactions: ["trxkey", "trx_id", "trx_date", "trx_month_year", "trx_remark", "amount", "trx_type", "business_id", "client_id", "admin_id", "TransactionType", "BusinessShortCode", "BillRefNumber", "InvoiceNumber", "OrgAccountBalance", "ThirdPartyTransID", "MSISDN", "FirstName", "MiddleName", "LastName", "trx_msg", "account_id", "used_status", "filter_date", "flw_id", "flag_state", "reconciled", "corrected_number", "hive_site_id", "hive_site_name", "app_id"],

   //-- checkout_orders cols--//
  checkout_orders: ["record_id", "payment_account", "checkout_date", "amount", "tel", "account_number", "hive_site_id", "hive_site_name"],

   //-- invoice_items cols--//
  invoice_items: ["record_id", "invoice_no", "invoice_id", "item_name", "item_description", "quantity", "unit_price", "line_total", "tax_rate", "tax_amount", "discount_amount", "item_order", "created_at", "updated_at", "hive_site_id", "hive_site_name"],

   //-- invoices cols--//
  invoices: ["record_id", "invoice_no", "invoice_date", "due_date", "account_id", "account_name", "amount", "tax_amount", "total_amount", "currency", "status", "payment_status", "description", "created_at", "updated_at", "hive_site_id", "hive_site_name"],

   //-- mosy_sql_roll_back cols--//
  mosy_sql_roll_back: ["roll_bk_key", "table_name", "roll_type", "where_str", "roll_timestamp", "value_entries", "hive_site_id", "hive_site_name"],

   //-- mosycomms_array cols--//
  mosycomms_array: ["messageid", "receiver_contacts", "reciver_names", "message_type", "site_id", "group_name", "message_date", "sent_state", "msg_read_state", "subject", "message_label", "message", "delvery_receipt", "mosycomms_dictionary", "sms_cost", "page_count", "hive_site_id", "hive_site_name"],

   //-- mosycomms_settings cols--//
  mosycomms_settings: ["record_id", "company_name", "company_email", "hive_site_id", "hive_site_name"],

   //-- page_manifest_ cols--//
  page_manifest_: ["manikey", "page_group", "site_id", "page_url", "hive_site_id", "hive_site_name"],

   //-- plan_features cols--//
  plan_features: ["record_id", "feature_id", "feature_name", "app_id", "plan_id", "hive_site_id", "hive_site_name"],

   //-- plans cols--//
  plans: ["record_id", "plan_id", "plan_name", "plan_amount", "plan_type", "plan_period", "active_status", "hive_site_id", "hive_site_name", "remark", "app_id", "currency"],

   //-- system_users cols--//
  system_users: ["user_id", "name", "email", "tel", "login_password", "ref_id", "regdate", "user_no", "user_pic", "user_gender", "last_seen", "about", "hive_site_id", "hive_site_name", "auth_token", "token_status", "token_expiring_in"],

   //-- user_manifest_ cols--//
  user_manifest_: ["admin_mkey", "user_id", "user_name", "role_id", "site_id", "role_name", "hive_site_id", "hive_site_name"],


};
export default MosyColumnFactory;