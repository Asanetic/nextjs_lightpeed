const MosyColumnFactory = {

   //-- acc_renewals cols--//
  acc_renewals: ["record_id", "account_name", "mobile_no", "credits_available", "package_name", "package_amount", "credits_deducted", "new_credit_balance", "next_expiry_date", "activated_on", "activated_by", "renid", "client_type", "invoice_signature", "client_names", "team_id", "last_expiry_date", "old_balance", "disconnection_message", "hive_site_id", "hive_site_name"],

   //-- account_urls cols--//
  account_urls: ["record_id", "url_name", "url", "description", "hive_site_id", "hive_site_name"],

   //-- admin_roles cols--//
  admin_roles: ["role_id", "admin_id", "role_key", "role_value", "assigned_by", "ref_id", "assigned_on", "hive_site_id", "hive_site_name"],

   //-- admins cols--//
  admins: ["user_id", "name", "email", "tel", "login_password", "ref_id", "regdate", "user_no", "user_pic", "user_gender", "last_seen", "about", "hive_site_id", "hive_site_name"],

   //-- billing_log cols--//
  billing_log: ["trx_key", "transaction_ref", "trx_type", "trx_time", "amount", "trx_source", "ref_id", "site_id", "message", "hive_site_id", "hive_site_name"],

   //-- billing_transactions cols--//
  billing_transactions: ["trxkey", "trx_id", "trx_date", "trx_month_year", "trx_remark", "amount", "trx_type", "business_id", "client_id", "admin_id", "TransactionType", "BusinessShortCode", "BillRefNumber", "InvoiceNumber", "OrgAccountBalance", "ThirdPartyTransID", "MSISDN", "FirstName", "MiddleName", "LastName", "trx_msg", "account_id", "used_status", "filter_date", "flw_id", "flag_state", "reconciled", "corrected_number", "hive_site_id", "hive_site_name"],

   //-- cashbook_table cols--//
  cashbook_table: ["entryid", "source_table", "dr_amt", "cr_amt", "dr_particulars", "cr_particulars", "dr_acc_id", "cr_acc_id", "transaction_tag", "transaction_date", "hive_site_id", "hive_site_name"],

   //-- checkout_orders cols--//
  checkout_orders: ["record_id", "payment_account", "checkout_date", "amount", "tel", "hive_site_id", "hive_site_name"],

   //-- client_accounts cols--//
  client_accounts: ["client_id", "client_name", "client_email", "client_tel", "client_location", "client_photo", "gender", "date_registered", "password", "admin_id", "hive_site_id", "hive_site_name"],

   //-- client_invoices cols--//
  client_invoices: ["record_id", "invoice_no", "account_name", "tel_no", "email", "client_names", "invoice_date", "item_name", "quantity", "amount", "tax_rate", "amount_paid", "payment_mode", "payment_ref", "invoice_remark", "hive_site_id", "hive_site_name"],

   //-- clients cols--//
  clients: ["user_id", "name", "email", "tel", "login_password", "ref_id", "regdate", "user_no", "user_pic", "user_gender", "last_seen", "city", "town", "client_type", "about", "active_state", "expiry_date", "group_name", "team_id", "last_follow_up_date", "follow_up_state", "package_id", "package_name", "package_price", "last_sync", "online_status", "online_class", "uptime", "hive_site_id", "hive_site_name"],

   //-- daily_leads cols--//
  daily_leads: ["leadkey", "lead_date", "lead_location", "apartment_name", "client_name", "client_tel", "followup_date", "remark", "lead_potential", "team_id", "lead_ref", "followup_type", "lead_state", "account_name", "date_signed_up", "hive_site_id", "hive_site_name"],

   //-- daily_leads_followups cols--//
  daily_leads_followups: ["leadkey", "followup_date", "followup_type", "account_name", "client_name", "client_tel", "remark", "lead_location", "apartment_name", "lead_potential", "lead_state", "team_id", "lead_ref", "lead_date", "hive_site_id", "hive_site_name"],

   //-- data_flow cols--//
  data_flow: ["record_id", "entry_date", "sequence_name", "sequence_id", "item_name", "item_id", "sequence_required", "sequence_number", "log_message", "parent_event", "hive_site_id", "hive_site_name"],

   //-- data_sequence_monitor cols--//
  data_sequence_monitor: ["record_id", "parent_event", "sequence_name", "sequence_number", "hive_site_id", "hive_site_name"],

   //-- direct_income cols--//
  direct_income: ["deposit_id", "reference_no", "debit_account", "credit_account", "client_id", "received_from", "deposit_date", "amount", "transaction_remark", "hive_site_id", "hive_site_name"],

   //-- employees cols--//
  employees: ["staff_id", "name", "email", "tel", "login_password", "position", "employment_date", "staff_number", "user_pic", "user_gender", "department", "job_group", "about", "hive_site_id", "hive_site_name"],

   //-- event_log cols--//
  event_log: ["event_id", "event_link", "event_type", "event_date", "event_descr", "hive_site_id", "hive_site_name"],

   //-- expenses cols--//
  expenses: ["expense_id", "receipt_id", "debit_account", "credit_account", "expense_date", "amount", "expense_notes", "account_subcategory", "hive_site_id", "hive_site_name"],

   //-- faq_table cols--//
  faq_table: ["faq_key", "faq_subject", "faq_details", "faq_tag", "hive_site_id", "hive_site_name"],

   //-- growth_tracker cols--//
  growth_tracker: ["goal_id", "objective", "goal_value", "goal_type", "goal_status", "duration", "goal_date", "goal_month", "objective_plan", "hive_site_id", "hive_site_name"],

   //-- internet_packages cols--//
  internet_packages: ["record_id", "plan_name", "description", "package_data_rate", "onexpiry_service", "package_amount", "package_duration", "package_type", "download_rate", "upload_rate", "package_code", "local_address", "remote_address", "hive_site_id", "hive_site_name"],

   //-- inventory_history cols--//
  inventory_history: ["record_id", "item_id", "item_name", "stock_type", "quantity", "purchase_price", "selling_price", "authorised_by", "supplier", "remark", "inventory_date", "invoice_id", "invoice_edit_key", "transfer_type", "staff_id", "price_invoice", "inventory_item", "client_id", "client_name", "item_location", "hive_site_id", "hive_site_name"],

   //-- inventory_list cols--//
  inventory_list: ["item_id", "item_no", "name", "buying_price", "selling_price", "stock_date", "supplier", "remark", "description", "recorded_by", "stock_type", "invoice_edit_key", "invoice_id", "user_pic", "stock_level_alert", "hive_site_id", "hive_site_name"],

   //-- job_groups cols--//
  job_groups: ["job_group", "group_name", "group_salary", "description", "hive_site_id", "hive_site_name"],

   //-- ledger_accounts cols--//
  ledger_accounts: ["ledger_id", "account_number", "account_name", "account_type", "cashbook_category", "document_link", "details", "hive_site_id", "hive_site_name"],

   //-- letterhead_settings cols--//
  letterhead_settings: ["record_id", "company_name", "company_logo", "tel", "email", "website", "remark", "location", "hive_site_id", "hive_site_name"],

   //-- messaging cols--//
  messaging: ["messageid", "receiver_contacts", "reciver_names", "message_type", "site_id", "group_name", "message_date", "sent_state", "msg_read_state", "subject", "message_label", "about", "sms_cost", "page_count", "hive_site_id", "hive_site_name", "custom_dictionary", "message_signature"],

   //-- mosy_sql_roll_back cols--//
  mosy_sql_roll_back: ["roll_bk_key", "table_name", "roll_type", "where_str", "roll_timestamp", "value_entries", "hive_site_id", "hive_site_name"],

   //-- mosycomms_array cols--//
  mosycomms_array: ["messageid", "receiver_contacts", "reciver_names", "message_type", "site_id", "group_name", "message_date", "sent_state", "msg_read_state", "subject", "message_label", "message", "delvery_receipt", "sms_cost", "page_count", "hive_site_id", "hive_site_name"],

   //-- mosycomms_settings cols--//
  mosycomms_settings: ["record_id", "company_name", "company_email", "hive_site_id", "hive_site_name"],

   //-- page_manifest_ cols--//
  page_manifest_: ["manikey", "page_group", "site_id", "page_url", "hive_site_id", "hive_site_name", "project_id", "project_name"],

   //-- payroll_list cols--//
  payroll_list: ["payroll_id", "payroll_month_year", "payroll_date", "staff_id", "job_group", "basicsalary", "bonus_and_commissions", "deductions", "net_salary", "payroll_number", "payroll_notes", "hive_site_id", "hive_site_name"],

   //-- petty_cash cols--//
  petty_cash: ["reqid", "request_date", "team_id", "amount", "reason_for_request", "vendor", "approved_date", "approval_status", "payment_date", "ref_no", "payment_remark", "admin_remark", "approved_by", "requested_by", "request_remark", "amount_paid", "receipt_file", "hive_site_id", "hive_site_name"],

   //-- pety_cash_post cols--//
  pety_cash_post: ["postkey", "amount_posted", "posted_by", "date_posted", "posting_remark", "admin_name", "hive_site_id", "hive_site_name"],

   //-- phonebook cols--//
  phonebook: ["contact_id", "name", "email", "tel", "profile_photo", "username", "site_id", "hive_site_id", "hive_site_name"],

   //-- reconciliations cols--//
  reconciliations: ["trxkey", "trx_id", "trx_date", "trx_month_year", "trx_remark", "amount", "trx_type", "business_id", "client_id", "admin_id", "TransactionType", "BusinessShortCode", "BillRefNumber", "InvoiceNumber", "OrgAccountBalance", "ThirdPartyTransID", "MSISDN", "FirstName", "MiddleName", "LastName", "trx_msg", "account_id", "used_status", "filter_date", "flag_state", "reconciled", "hive_site_id", "hive_site_name"],

   //-- requisition_items cols--//
  requisition_items: ["record_id", "invoice_id", "item_id", "item_name", "quantity", "rate", "tax", "discount", "date_created", "account_context", "account_name", "item_key", "stock_type", "invoice_edit_key", "selling_price", "sale_state", "remaining_qty", "add_to_stock", "item_remark", "hive_site_id", "hive_site_name"],

   //-- requisitions cols--//
  requisitions: ["invoice_id", "invoice_no", "date_created", "date_due", "paid_status", "created_by", "name", "invoice_stage", "remark", "client_id", "paid_on", "supplier_id", "invoice_type", "account_affect", "inv_no_int", "invoice_key", "client_name", "client_tel", "client_email", "requested_by", "approval_status", "amount_paid", "payment_ref", "payment_date", "receipt_file", "vendor", "hive_site_id", "hive_site_name"],

   //-- sales_history cols--//
  sales_history: ["record_id", "item_id", "sales_date", "qty_sold", "remark", "hive_site_id", "hive_site_name"],

   //-- send_list cols--//
  send_list: ["send_list_key", "send_list_name", "site_id", "contact_id", "contact_names", "mobile", "email", "ref_no", "group_name", "date_created", "description", "active_state", "service_id", "service_name", "hive_site_id", "hive_site_name", "entry_context"],

   //-- system_files cols--//
  system_files: ["fileid", "item_id", "file_url", "file_type", "ref_id", "upload_date", "hive_site_id", "hive_site_name"],

   //-- system_role_bundles cols--//
  system_role_bundles: ["record_id", "bundle_id", "bundle_name", "remark", "hive_site_id", "hive_site_name"],

   //-- system_users cols--//
  system_users: ["user_id", "name", "email", "tel", "login_password", "ref_id", "regdate", "user_no", "user_pic", "user_gender", "last_seen", "about", "hive_site_id", "hive_site_name", "auth_token", "token_status", "token_expiring_in", "project_id", "project_name"],

   //-- team_target cols--//
  team_target: ["target_key", "target_name", "target_value", "target_type", "remark", "hive_site_id", "hive_site_name"],

   //-- team_tbl cols--//
  team_tbl: ["user_id", "name", "email", "tel", "login_password", "signup_date", "account_no", "user_pic", "gender", "last_seen", "about", "sales_target", "hive_site_id", "hive_site_name"],

   //-- tickets cols--//
  tickets: ["ticket_no", "ticket_date", "subject", "ticket_id", "user_name", "tickect_details", "agent_id", "ticket_state", "thread_id", "last_seen", "sender", "receiver", "transffered", "hive_site_id", "hive_site_name"],

   //-- transactions cols--//
  transactions: ["trxkey", "trx_id", "trx_date", "trx_month_year", "trx_remark", "amount", "trx_type", "business_id", "client_id", "admin_id", "TransactionType", "BusinessShortCode", "BillRefNumber", "InvoiceNumber", "OrgAccountBalance", "ThirdPartyTransID", "MSISDN", "FirstName", "MiddleName", "LastName", "trx_msg", "account_id", "used_status", "filter_date", "flag_state", "reconciled", "site_id", "hive_site_id", "hive_site_name"],

   //-- user_bundle_role_functions cols--//
  user_bundle_role_functions: ["record_id", "bundle_id", "bundle_name", "role_id", "role_name", "remark", "hive_site_id", "hive_site_name"],

   //-- user_manifest_ cols--//
  user_manifest_: ["admin_mkey", "user_id", "user_name", "role_id", "site_id", "role_name", "hive_site_id", "hive_site_name", "project_id", "project_name"],

   //-- ux_table cols--//
  ux_table: ["ux_id", "ux_key", "ux_value", "ux_type", "ux_state", "remark", "hive_site_id", "hive_site_name"],


};
export default MosyColumnFactory;