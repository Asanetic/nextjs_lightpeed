const MosyColumnFactory = {

   //-- activities cols--//
  activities: ["lead_id", "client_id", "type", "notes", "next_action_date", "done_by", "created_at", "hive_site_id", "hive_site_name"],

   //-- blog_posts cols--//
  blog_posts: ["title", "slug", "content", "author_id", "status", "publish_date", "hive_site_id", "hive_site_name"],

   //-- calls cols--//
  calls: ["lead_id", "client_id", "call_type", "duration", "summary", "call_date", "hive_site_id", "hive_site_name"],

   //-- clients cols--//
  clients: ["client_name", "company_name", "email", "phone", "location", "industry", "status", "account_manager_id", "date_onboarded", "hive_site_id", "hive_site_name"],

   //-- content_schedule cols--//
  content_schedule: ["post_id", "channel", "scheduled_date", "status", "hive_site_id", "hive_site_name"],

   //-- leads cols--//
  leads: ["lead_name", "company_name", "email", "phone", "status", "source", "assigned_to", "date_created", "date_converted", "hive_site_id", "hive_site_name"],

   //-- messages cols--//
  messages: ["lead_id", "client_id", "channel", "message_body", "status", "sent_at", "hive_site_id", "hive_site_name"],

   //-- page_manifest_ cols--//
  page_manifest_: ["page_group", "site_id", "page_url", "hive_site_id", "hive_site_name", "project_id", "project_name"],

   //-- reports cols--//
  reports: ["report_type", "generated_by", "report_data", "generated_at", "hive_site_id", "hive_site_name"],

   //-- system_role_bundles cols--//
  system_role_bundles: ["bundle_id", "bundle_name", "remark", "hive_site_id", "hive_site_name"],

   //-- system_users cols--//
  system_users: ["name", "email", "tel", "login_password", "ref_id", "regdate", "user_no", "user_pic", "user_gender", "last_seen", "about", "hive_site_id", "hive_site_name", "auth_token", "token_status", "token_expiring_in", "project_id", "project_name"],

   //-- user_bundle_role_functions cols--//
  user_bundle_role_functions: ["bundle_id", "bundle_name", "role_id", "role_name", "remark", "hive_site_id", "hive_site_name"],

   //-- user_manifest_ cols--//
  user_manifest_: ["user_id", "user_name", "role_id", "site_id", "role_name", "hive_site_id", "hive_site_name", "project_id", "project_name"],

   //-- users cols--//
  users: ["name", "email", "phone", "role", "password_hash", "last_login", "hive_site_id", "hive_site_name"],


};
export default MosyColumnFactory;