const MosyColumnFactory = {

   //-- account_urls cols--//
  account_urls: ["url_name", "url", "description", "hive_site_id", "hive_site_name"],

   //-- attendance_list cols--//
  attendance_list: ["name", "mobile", "national_id", "daily_wages", "remark", "paid_status", "paid_ref_no", "site_id", "site_name", "date_paid", "roll_date", "day_count", "deductions", "deduction_remark", "task_assigned", "project_phase", "hive_site_id", "hive_site_name"],

   //-- cash_deposits cols--//
  cash_deposits: ["amount_posted", "posted_by", "date_posted", "posting_remark", "admin_name", "project_id", "project_name", "hive_site_id", "hive_site_name"],

   //-- disbursment_schedule cols--//
  disbursment_schedule: ["remark", "send_on", "authorized_by", "authorized_on", "status", "project_id", "project_name", "otp", "date_sent", "otp_verified", "otp_verified_by", "disbursment_status", "disbursed_on", "hive_site_id", "hive_site_name", "week_number"],

   //-- doc_settings cols--//
  doc_settings: ["company_name", "company_tel", "company_email", "logo", "address", "company_description", "active_status", "hive_site_id", "hive_site_name"],

   //-- expenses cols--//
  expenses: ["expense_name", "expense_category", "rate", "quantity", "ref_no", "expense_remark", "site_id", "expense_date", "week_no", "hive_site_id", "hive_site_name"],

   //-- message_templates cols--//
  message_templates: ["template_name", "message_subject", "message_template", "template_code"],

   //-- messaging cols--//
  messaging: ["receiver_contacts", "reciver_names", "message_type", "site_id", "group_name", "message_date", "sent_state", "msg_read_state", "subject", "message_label", "about", "sms_cost", "page_count", "hive_site_id", "hive_site_name", "custom_dictionary", "message_signature"],

   //-- mosy_sql_roll_back cols--//
  mosy_sql_roll_back: ["table_name", "roll_type", "where_str", "roll_timestamp", "value_entries", "project_id", "project_name", "hive_site_id", "hive_site_name"],

   //-- mosycomms_array cols--//
  mosycomms_array: ["receiver_contacts", "reciver_names", "message_type", "site_id", "group_name", "message_date", "sent_state", "msg_read_state", "subject", "message_label", "message", "delvery_receipt", "mosycomms_dictionary", "sms_cost", "page_count", "hive_site_id", "hive_site_name", "project_id", "project_name"],

   //-- mosycomms_settings cols--//
  mosycomms_settings: ["company_name", "company_email", "hive_site_id", "hive_site_name", "project_id", "project_name"],

   //-- page_manifest_ cols--//
  page_manifest_: ["page_group", "site_id", "page_url", "hive_site_id", "hive_site_name", "project_id", "project_name"],

   //-- paybill_disbursments cols--//
  paybill_disbursments: ["trx_id", "trx_date", "trx_month_year", "trx_remark", "amount", "trx_type", "business_id", "client_id", "admin_id", "TransactionType", "BusinessShortCode", "BillRefNumber", "InvoiceNumber", "OrgAccountBalance", "ThirdPartyTransID", "MSISDN", "FirstName", "MiddleName", "LastName", "trx_msg", "account_id", "used_status", "filter_date", "flw_id", "flag_state", "reconciled", "trx_timestamp", "hive_site_id", "hive_site_name"],

   //-- payment_confirmations cols--//
  payment_confirmations: ["result_type", "result_code", "result_desc", "originator_conversation_id", "conversation_id", "transaction_id", "transaction_amount", "transaction_receipt", "recipient_registered", "charges_paid_funds", "receiver_public_name", "transaction_date_time", "utility_funds", "working_funds", "queue_timeout_url", "created_at", "hive_site_id", "hive_site_name"],

   //-- payment_receivers cols--//
  payment_receivers: ["receiver_name", "receiver_mobile", "receiver_remark", "amount_to_send", "schedule_id", "schedule_remark", "time_sent", "status", "import_signature", "project_id", "project_name", "no_of_days", "staff_id", "daily_wages", "transaction_ref", "tracking_id", "payment_request_response", "sms_notification_response", "notification_number", "hive_site_id", "hive_site_name"],

   //-- phonebook cols--//
  phonebook: ["name", "email", "tel", "profile_photo", "username", "site_id", "hive_site_id", "hive_site_name"],

   //-- project_phases cols--//
  project_phases: ["phase_name", "project_type", "phase_remark", "section", "hive_site_id", "hive_site_name"],

   //-- send_list cols--//
  send_list: ["send_list_name", "site_id", "contact_id", "contact_names", "mobile", "email", "ref_no", "group_name", "date_created", "description", "active_state", "service_id", "service_name", "hive_site_id", "hive_site_name", "entry_context"],

   //-- site_list cols--//
  site_list: ["site_name", "site_location", "contact_person", "contact_person_mobile", "remark", "project_id", "project_name", "account_number", "stk_flag", "hive_site_id", "hive_site_name"],

   //-- site_managers cols--//
  site_managers: ["site_id", "site_name", "user_id", "user_name", "remark", "hive_site_id", "hive_site_name"],

   //-- staff cols--//
  staff: ["name", "mobile", "national_id", "daily_wages", "staff_role", "site_id", "site_name", "notification_number", "hive_site_id", "hive_site_name"],

   //-- staff_categories cols--//
  staff_categories: ["work_title", "category_name", "wages", "remark", "hive_site_id", "hive_site_name"],

   //-- system_role_bundles cols--//
  system_role_bundles: ["bundle_id", "bundle_name", "remark", "hive_site_id", "hive_site_name"],

   //-- system_users cols--//
  system_users: ["name", "email", "tel", "login_password", "ref_id", "regdate", "user_no", "user_pic", "user_gender", "last_seen", "about", "hive_site_id", "hive_site_name", "auth_token", "token_status", "token_expiring_in", "project_id", "project_name"],

   //-- transactions cols--//
  transactions: ["trx_id", "trx_date", "trx_month_year", "trx_remark", "amount", "trx_type", "business_id", "client_id", "admin_id", "TransactionType", "BusinessShortCode", "BillRefNumber", "InvoiceNumber", "OrgAccountBalance", "ThirdPartyTransID", "MSISDN", "FirstName", "MiddleName", "LastName", "trx_msg", "account_id", "used_status", "filter_date", "flw_id", "flag_state", "reconciled", "trx_timestamp", "hive_site_id", "hive_site_name"],

   //-- user_bundle_role_functions cols--//
  user_bundle_role_functions: ["bundle_id", "bundle_name", "role_id", "role_name", "remark", "hive_site_id", "hive_site_name"],

   //-- user_manifest_ cols--//
  user_manifest_: ["user_id", "user_name", "role_id", "site_id", "role_name", "hive_site_id", "hive_site_name", "project_id", "project_name"],

   //-- user_site_allocation cols--//
  user_site_allocation: ["site_id", "site_name", "remark", "user_id", "user_name", "hive_site_id", "hive_site_name"],

   //-- work_schedule cols--//
  work_schedule: ["site_id", "task_description", "subtotal", "date_", "client", "week_no", "hive_site_id", "hive_site_name"],


};
export default MosyColumnFactory;