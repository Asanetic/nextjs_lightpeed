const MosyColumnFactory = {

   //-- ad_views cols--//
  ad_views: ["viewer_id", "ad_id", "view_time", "payment_amount"],

   //-- ads cols--//
  ads: ["advertiser_id", "ad_title", "ad_description", "video_url", "pay_per_view", "total_budget", "views_so_far", "ad_status", "created_at"],

   //-- advertisers cols--//
  advertisers: ["business_name", "contact_person", "email", "phone_number", "reg_date"],

   //-- page_manifest_ cols--//
  page_manifest_: ["page_group", "site_id", "page_url", "hive_site_id", "hive_site_name", "project_id", "project_name"],

   //-- payout_requests cols--//
  payout_requests: ["viewer_id", "amount", "payment_method", "payment_status", "requested_on"],

   //-- system_role_bundles cols--//
  system_role_bundles: ["bundle_id", "bundle_name", "remark", "hive_site_id", "hive_site_name"],

   //-- system_users cols--//
  system_users: ["name", "email", "tel", "login_password", "ref_id", "regdate", "user_no", "user_pic", "user_gender", "last_seen", "about", "hive_site_id", "hive_site_name", "auth_token", "token_status", "token_expiring_in", "project_id", "project_name"],

   //-- user_bundle_role_functions cols--//
  user_bundle_role_functions: ["bundle_id", "bundle_name", "role_id", "role_name", "remark", "hive_site_id", "hive_site_name"],

   //-- user_manifest_ cols--//
  user_manifest_: ["user_id", "user_name", "role_id", "site_id", "role_name", "hive_site_id", "hive_site_name", "project_id", "project_name"],

   //-- viewers cols--//
  viewers: ["full_name", "email", "phone_number", "password", "joined_on"],

   //-- wallets cols--//
  wallets: ["viewer_id", "current_balance", "last_updated"],


};
export default MosyColumnFactory;