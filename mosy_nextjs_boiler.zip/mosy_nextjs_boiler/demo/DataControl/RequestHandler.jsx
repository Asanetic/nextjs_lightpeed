'use client';
//hive / data utils
import { mosyPostFormData, mosyGetData, mosyUrlParam, mosyUpdateUrlParam , deleteUrlParam, magicRandomStr, mosyGetLSData  } from '../../../MosyUtils/hiveUtils';

//action modals 
import { MosyNotify , closeMosyModal, MosyAlertCard } from '../../../MosyUtils/ActionModals';

//filter util
import { MosyFilterEngine } from '../../DataControl/MosyFilterEngine';

//custom event manager 
import { customEventHandler } from '../../DataControl/customDataFunction';

//routes manager
///handle routes 
import { getApiRoutes } from '../../AppRoutes/apiRoutesHandler';

// Use default base root (/)
const apiRoutes = getApiRoutes();

//insert data
export async function insert() {
 //console.log(`Form ux_table insert sent `)

  return await mosyPostFormData({
    formId: 'ux_table_profile_form',
    url: apiRoutes..base,
    method: 'POST',
    isMultipart: true,
  });
}

//update record 
export async function update() {

  //console.log(`Form ux_table update sent `)

  return await mosyPostFormData({
    formId: 'ux_table_profile_form',
    url: apiRoutes..base,
    method: 'POST',
    isMultipart: true,
  });
}


///receive form actions from profile page  
export async function inteprateFormAction(e, setters) {
  e.preventDefault();

  const form = e.target;
  const formDataObj = new FormData(form);
  const actionType = formDataObj.get('ux_table_mosy_action');
 
 //console.log(`Form ux_table submission received action : ${actionType}`)

  try {
    let result = null;
    let actionMessage ='Record added succesfully!';

    if (actionType === 'add_ux_table') {

      actionMessage ='Record added succesfully!';

      result = await insert();
    }

    if (actionType === 'update_ux_table') {

      actionMessage ='Record updated succesfully!';

      result = await update();
    }

    if (result?.status === 'success') {
      
      const ux_tableUptoken = btoa(result.ux_table_uptoken || '');

      //set id key
      setters.setUptoken(ux_tableUptoken);
      
      //update url with new ux_tableUptoken
      mosyUpdateUrlParam('ux_table_uptoken', ux_tableUptoken)

      setters.setActionStatus('update_ux_table')
    
      setters.setSnackMessage(actionMessage);

      return {
        status: 'success',
        message: actionMessage,
        newToken: ux_tableUptoken,
        actionName : actionType,
        actionType : 'ux_table_form_submission'
      };
            
      
    } else {
      MosyNotify({message:"A small error occured. Kindly try again", iconColor :'text-danger'})
      
      return {
        status: 'error',
        message: result,
        actionName: actionType,
        newToken: null
      };
      
    }

  } catch (error) {
    console.error('Form error:', error);
    
    MosyNotify({message:`A small error occured.  ${error}`, iconColor :'text-danger'})
    
      return {
        status: 'error',
        message: result,
        actionName: actionType,
        newToken: null
      };
      
  } 
}


export async function initProfileData(rawQstr) {

  //add the following data in response
  const rawMutations = {
     
  }
  

  MosyNotify({message : 'Refreshing ' , icon:'refresh', addTimer:false})

  const encodedMutations = btoa(JSON.stringify(rawMutations));

  try {
    // Fetch the  data with the given key
    const response = await mosyGetData({
      endpoint: apiRoutes..base,
      params: { 
      q: btoa(rawQstr),         
      mutations: encodedMutations,
      fullQ : true,
      aw : btoa(``),
      src : btoa(`initProfileData`)
      },
    });

    // Handle the successful response
    if (response.status === 'success') {
      //console.log(' Data:', response.data);  // Process the data

       closeMosyModal()

      return response.data?.[0] || {};  // Return the actual record

    } else {
          
      console.log('Error fetching  data:', response.message);  // Handle error

      closeMosyModal()

      return {}
    }
  } catch (err) {

    closeMosyModal()

    console.log('Error:', err);
    return {}
  }
}


export async function Delete(token = '') {

    try {
      MosyNotify({message:"Sending delete request",icon:"send", addTimer : false})
    
      const response = await mosyGetData({
        endpoint: apiRoutes..delete,
        params: { 
          _ux_table_delete_record: (token), 
          },
      });

      console.log('Token Delete '+token)
      if (response.status === 'success') {

        closeMosyModal();

        return response.data; // ✅ Return the data
      } else {
        console.error('Error deleting systemusers data:', response.message);
        closeMosyModal();
        
        return []; // Safe fallback
      }
    } catch (err) {
      console.error('Error:', err);
      closeMosyModal();
      
      return []; //  Even safer fallback
    }

}


export async function getListData(qstr = "") {
   let fullWhere = true
  if(qstr=='')
  {
   fullWhere = false 
   qstr=btoa(``)
  }
  
  //add the following data in response
  const rawMutations = {
     
  }
  
  const encodedMutations = btoa(JSON.stringify(rawMutations));

  //manage pagination 
  const pageNo = mosyUrlParam('qux_table_page','0')
  const recordsPerPage = mosyGetLSData('systemDataLimit', '11')

  try {
    const response = await mosyGetData({
      endpoint: apiRoutes..base,
      params: { 
        q: qstr, 
        mutations: encodedMutations,
        fullQ : fullWhere,
        pagination : `l:qux_table_page:${recordsPerPage}:${pageNo}`,
        aw : btoa(`order by  desc`),
        src : btoa(`getListData`)
        },
    });

    if (response.status === 'success') {
      //console.log(' Data:', response.data);
      return response; // ✅ Return the data
    } else {
      console.log('Error fetching  data:', response);
      return []; // Safe fallback
    }
  } catch (err) {
    console.log('Error:', err);
    return []; //  Even safer fallback
  }
}


export async function loadListData(customQueryStr, setters) {

    const gft = MosyFilterEngine('ux_table', true);
    let finalFilterStr = btoa(gft);    

    if(customQueryStr!='')
    {
      finalFilterStr = customQueryStr;
    }

    setters.setLoading(true);
    
    const ListData = await getListData(finalFilterStr);
    
    setters.setLoading(false)
    setters.setListData(ListData?.data)

    setters.setListPageCount(ListData?.page_count)


    return ListData

}
  
  
export async function ProfileData(customQueryStr, setters, router, customProfileData={}) {

    const TokenId = mosyUrlParam('ux_table_uptoken');
    
    const deleteParam = mosyUrlParam('ux_table_delete');

    //manage  the staff_uptoken value  basically detect primkey
    let decodedToken = '0';
    if (TokenId) {
      
      decodedToken = atob(TokenId); // Decode the record_id
      setters.setUptoken(TokenId);
      setters.setActionStatus('update_ux_table');
      
    }
    
    //override customQueryStr if there is an active staff_uptoken else use customQueryStr if any
    let rawQueryStr =`where primkey ='${decodedToken}'`
    if(customQueryStr!='')
    {
      // if no ux_table_uptoken set , use customQueryStr
      if (!TokenId) {
       rawQueryStr = customQueryStr
      }
    }

    const profileDataRecord = await initProfileData(rawQueryStr)

    if(deleteParam){
      popDeleteDialog(TokenId, setters, router)
    }
    
    // Merge with custom injected values (custom wins)
    const finalProfileData = {
      ...profileDataRecord,
      ...customProfileData,    
    };
      

    setters.setNode(finalProfileData)
    
    
}
  
  

export function InteprateEvent(data) {
     
  //console.log('🎯  Child gave us:', data);

  const actionName = data?.actionName

  const childActionName = { [actionName]: true };

  if(childActionName.select_ux_table){

    if(data?.profile)
    {
      const router = data?.router
      
      const url = data?.url

      router.push(url, { scroll: false });

    }else{

    //const childStateSetters = data?.setters.childSetters

    const parentSetter = data?.setters.parentStateSetters 

    parentSetter?.setCustomProfileQuery(data?.qstr)

    parentSetter?.setLocalEventSignature(magicRandomStr())
    parentSetter?.setParentUseEffectKey(magicRandomStr())
    parentSetter?.setActiveScrollId('ProfileTray')

    
    mosyUpdateUrlParam('ux_table_uptoken', btoa(data?.token))
    
    }
  }

  if(childActionName.add_ux_table){

    const stateSetter =data?.setters.childStateSetters
    const parentStateSetter =data?.setters.parentStateSetters

    //console.log(`add ux_table `, data?.setters)

    if(stateSetter.setLocalEventSignature){
     stateSetter?.setLocalEventSignature(magicRandomStr())
    }

    if(parentStateSetter){
      if(parentStateSetter.setLocalEventSignature){
        parentStateSetter?.setLocalEventSignature(magicRandomStr())
        parentStateSetter?.setActiveScrollId('ProfileTray')
      }
    }
     
  }

  if(childActionName.update_ux_table){
    const stateSetter =data?.setters.childStateSetters
    const parentStateSetter =data?.setters.parentStateSetters

    //console.log(`update ux_table `, data?.setters)

    if(stateSetter.setLocalEventSignature){
     stateSetter?.setLocalEventSignature(magicRandomStr())
    }

    if(parentStateSetter){
      if(parentStateSetter.setLocalEventSignature){
        parentStateSetter?.setLocalEventSignature(magicRandomStr())
        parentStateSetter?.setActiveScrollId('ProfileTray')
        
      }
    }
  }

  if(childActionName.delete_ux_table){

    popDeleteDialog(btoa(data?.token), data?.setters)

 }

  
}


export function popDeleteDialog(deleteToken, setters, router, afterDeleteUrl='..//list')
{     

  //console.log(`popDeleteDialog`, setters)
  const childSetters = setters?.childStateSetters
  
  MosyAlertCard({
  
    icon : "trash",
  
    message: "Are you sure you want to delete this record?",

    autoDismissOnClick : false,
  
    onYes: () => {
  
      Delete(deleteToken).then(data=>{
  
        childSetters?.setSnackMessage("Record deleted succesfully!")
        childSetters?.setParentUseEffectKey(magicRandomStr());
        childSetters?.setLocalEventSignature(magicRandomStr());

        if(router){
          router.push(`${afterDeleteUrl}?snack_alert=Record Deleted successfully!`)
        }
                  
      })
  
    },
  
    onNo: () => {
  
      // Remove the param from the URL
       closeMosyModal()
       deleteUrlParam('ux_table_delete');
        
    }
  
  });

}