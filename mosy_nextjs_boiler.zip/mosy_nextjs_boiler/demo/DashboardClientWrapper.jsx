'use client';

import SessionMonitor from '../auth/SessionMonitor';
import saAuthConfigs from '../auth/features_config/saAuthConfigs'; 

export default function DashboardClientWrapper({ children }) {
  return (
    <>
      <SessionMonitor
        sessionPrefix={saAuthConfigs.sessionPrefix}
        loginPath={`../../auth/${saAuthConfigs.loginUrl}`}
      />
      {children}
    </>
  );
}
