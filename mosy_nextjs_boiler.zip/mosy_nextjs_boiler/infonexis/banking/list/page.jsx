import { Suspense } from 'react';

import BankdepositsList from '../uiControl/BankdepositsList';

import { InteprateBankdepositsEvent } from '../dataControl/BankdepositsRequestHandler';
    
export async function generateMetadata({ searchParams }) {
  const mosyTitle = "Bank deposits"//searchParams?.mosyTitle || "Bank deposits";

  return {
    title: mosyTitle ? decodeURIComponent(mosyTitle) : `Bank deposits`,
    description: 'infonexis Bank deposits',
    
    icons: {
      icon: "/logo.png"
    },    
  };
}

export default function BankdepositsMainListPage() {

return (
        <>
         <div className="main-wrapper">
           <div className="page-wrapper">
              <div className="content container-fluid p-0 m-0 ">
               <Suspense fallback={<div className="col-md-12 p-5 text-center h3">Loading...</div>}>
               
                    <BankdepositsList  
                    
                     dataIn={{ parentUseEffectKey: "loadBankdepositsList" }}
                       
                     dataOut={{
                       setChildDataOut: InteprateBankdepositsEvent
                     }}
                    />
                    
                  </Suspense>                 
              </div>
            </div>
          </div>
        </>
      );
    }