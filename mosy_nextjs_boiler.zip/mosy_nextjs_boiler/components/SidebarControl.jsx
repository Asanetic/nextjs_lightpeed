"use client"; // Required if you're in the app directory (Next.js 13+)

import { useEffect } from "react";

export default function SidebarControl() {
  useEffect(() => {
    // Submenu toggle
    const links = document.querySelectorAll("#sidebar-menu a");

    links.forEach(link => {
      link.addEventListener("click", e => {
        const parentLi = link.parentElement;

        if (parentLi.classList.contains("submenu")) {
          e.preventDefault();

          const isOpen = link.classList.contains("subdrop");

          // Close all
          document.querySelectorAll("#sidebar-menu a.subdrop").forEach(a => {
            a.classList.remove("subdrop");
            const ul = a.nextElementSibling;
            if (ul && ul.tagName === "UL") ul.style.display = "none";
          });

          // Toggle current
          if (!isOpen) {
            link.classList.add("subdrop");
            const ul = link.nextElementSibling;
            if (ul && ul.tagName === "UL") ul.style.display = "block";
          }
        }
      });
    });

    // Mobile menu overlay toggle
    const mobileBtn = document.getElementById("mobile_btn");
    const overlay = document.createElement("div");
    overlay.classList.add("sidebar-overlay");
    document.body.appendChild(overlay);

    const toggleMobileMenu = () => {
      document.querySelector(".main-wrapper")?.classList.toggle("slide-nav");
      overlay.classList.toggle("opened");
      document.documentElement.classList.toggle("menu-opened");
    };

    mobileBtn?.addEventListener("click", toggleMobileMenu);
    overlay.addEventListener("click", toggleMobileMenu);

    // Clean up
    return () => {
      mobileBtn?.removeEventListener("click", toggleMobileMenu);
      overlay.removeEventListener("click", toggleMobileMenu);
      document.body.removeChild(overlay);
    };
  }, []);

  return null;
}
