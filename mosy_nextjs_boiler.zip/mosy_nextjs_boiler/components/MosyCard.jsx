// File: DynamicModal.js
import React, { useEffect, useRef } from 'react';
import ReactDOM from 'react-dom/client';

let modalRoot = null;
export let closeMosyCard = () => {}; // ✅ Export early

function DynamicModal({ title, body, onClose, dismissOnOutsideClick = true }) {
  const modalRef = useRef();

  useEffect(() => {
    function handleClickOutside(e) {
      if (
        dismissOnOutsideClick &&
        modalRef.current &&
        !modalRef.current.contains(e.target)
      ) {
        onClose(); // Properly call onClose
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [dismissOnOutsideClick, onClose]);

  useEffect(() => {
    document.body.classList.add('modal-open');
    return () => document.body.classList.remove('modal-open');
  }, []);

  return (
    <>
      <div className="modal-backdrop fade show"></div>

      <div
        className="modal fade show"
        tabIndex="-1"
        role="dialog"
        style={{ display: 'block', zIndex: 1055 }}
      >
        <div className="modal-dialog modal-dialog-centered" role="document">
          <div className="modal-content col-md-12 shadow" ref={modalRef}>
            <div className="modal-header col-md-12">
              <h5 className="modal-title col-md-12">{title}</h5>
              <button
                style={{maginTop : "-20px"}}
                type="button"
                className="btn-close bg-white border-0"
                onClick={onClose}
              >
                <i className="fa fa-times"></i>
              </button>
            </div>
            <div className="modal-body col-md-12">{body}</div>
          </div>
        </div>
      </div>
    </>
  );
}

export function MosyCard(title, body, dismissOnOutsideClick = true) 
{

  const container = document.getElementById('alert_box');

  if (!container) {
    console.error("🚨 No #alert_box found in DOM");
    return;
  }

  if (!modalRoot) {
    modalRoot = ReactDOM.createRoot(container);
  }

  const closeModal = () => {
    modalRoot.render(null);
  };
  
  closeMosyCard = () => modalRoot.render(null); // ✅ Assign later

  try{
  modalRoot.render(
    <DynamicModal
      title={title}
      body={body}
      onClose={closeModal}
      dismissOnOutsideClick={dismissOnOutsideClick}
    />
    
  );
  }catch(err){
    
  }
}
