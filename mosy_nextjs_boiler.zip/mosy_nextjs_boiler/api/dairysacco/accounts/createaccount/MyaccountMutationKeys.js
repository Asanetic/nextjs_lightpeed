
//pass listMyaccountRowMutationsKeys to mosy select 

const listMyaccountRowMutationsKeys = {

};

export default listMyaccountRowMutationsKeys;

