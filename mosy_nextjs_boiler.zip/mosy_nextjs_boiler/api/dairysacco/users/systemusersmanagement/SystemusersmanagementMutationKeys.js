
//pass listSystemusersmanagementRowMutationsKeys to mosy select 

const listSystemusersmanagementRowMutationsKeys = {

};

export default listSystemusersmanagementRowMutationsKeys;

