
import { mosySqlInsert, mosySqlUpdate, base64Decode, mosyFlexSelect, mosyUploadFile, mosyDeleteFile } from '../../../be/data_control/dataUtils';
import { magicRandomStr } from '../../../../MosyUtils/hiveUtils';

import {AdsCampaignsRowMutations} from './AdsCampaignsRowMutations';

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const queryParams = Object.fromEntries(searchParams.entries());

    const encodedMutations = searchParams.get('mutations');

    let mutationsObj = {};
    if (encodedMutations) {
      try {
        const decodedMutations = Buffer.from(encodedMutations, 'base64').toString('utf-8');
        mutationsObj = JSON.parse(decodedMutations);
      } catch (err) {
        console.error('Mutation decode failed:', err);
      }
    }


    // ✅ Provide default fallbacks
    const enhancedParams = {
      tbl: 'ads',
      colstr: queryParams.colstr || 'Kg==', // default to *
      ...queryParams 
    };

    // 🧠 Clean up optional params if missing
    if (!enhancedParams.pagination) delete enhancedParams.pagination;
    if (!enhancedParams.q) delete enhancedParams.q;
    if (!enhancedParams.function_cols) enhancedParams.function_cols = '';

    const result = await mosyFlexSelect(enhancedParams, mutationsObj, AdsCampaignsRowMutations);

    return Response.json({
      status: 'success',
      message: 'AdsCampaigns data retrieved',
      ...result,
    });

  } catch (err) {
    console.error('GET AdsCampaigns failed:', err);
    return Response.json(
      { status: 'error', message: err.message },
      { status: 500 }
    );
  }
}



export async function POST(AdsCampaignsRequest) {
  try {
    let body;
    let isMultipart = false;

    const contentType = AdsCampaignsRequest.headers.get("content-type") || "";

    if (contentType.includes("multipart/form-data")) {
      isMultipart = true;
      const formData = await AdsCampaignsRequest.formData();

      // Convert FormData to plain object
      body = {};
      for (let [key, value] of formData.entries()) {
        body[key] = value;
      }

    } else {
      body = await AdsCampaignsRequest.json();
    }
    
    
    const AdsCampaignsFormAction = body.ads_mosy_action;
    const ads_uptoken_value = base64Decode(body.ads_uptoken);

		//--- Begin  ads inputs array ---// 

const AdsCampaignsInputsArr = {
  "advertiser_id" : "?", 
  "ad_title" : "?", 
  "ad_description" : "?", 
  "video_url" : "?", 
  "pay_per_view" : "?", 
  "total_budget" : "?", 
  "views_so_far" : "?", 
  "ad_status" : "?", 
  "created_at" : "?", 

};

//--- End ads inputs array --//

    
    if (AdsCampaignsFormAction === "add_ads") 
    {
      
      const newId = magicRandomStr(7);
      AdsCampaignsInputsArr.record_is = newId;
      
      // Insert into table AdsCampaigns
      const result = await mosySqlInsert("ads", AdsCampaignsInputsArr, body);

       

      return Response.json({
        status: 'success',
        message: result.message,
        ads_uptoken: result.record_id
      });
      
    }
    
    if (AdsCampaignsFormAction === "update_ads") {
      
      // update table AdsCampaigns
      const result = await mosySqlUpdate("ads", AdsCampaignsInputsArr, body, `primkey='${ads_uptoken_value}'`);


      

      return Response.json({
        status: 'success',
        message: result.message,
        ads_uptoken: ads_uptoken_value
      });
    }    

    // Optional: catch unrecognized actions
    return Response.json({
      status: 'error',
      message: `Invalid action: ${AdsCampaignsFormAction}`
    }, { status: 400 });

  } catch (err) {
    console.error(`Request failed:`, err);
    return Response.json(
      { status: 'error', 
      message: `Data Post error ${err.message}` },
      { status: 500 }
    );
  }
}