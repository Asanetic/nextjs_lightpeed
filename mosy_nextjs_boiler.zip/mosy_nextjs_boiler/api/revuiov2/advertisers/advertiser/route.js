
import { mosySqlInsert, mosySqlUpdate, base64Decode, mosyFlexSelect, mosyUploadFile, mosyDeleteFile } from '../../../be/data_control/dataUtils';
import { magicRandomStr } from '../../../../MosyUtils/hiveUtils';

import {AdvertisersAdvertiserRowMutations} from './AdvertisersAdvertiserRowMutations';

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const queryParams = Object.fromEntries(searchParams.entries());

    const encodedMutations = searchParams.get('mutations');

    let mutationsObj = {};
    if (encodedMutations) {
      try {
        const decodedMutations = Buffer.from(encodedMutations, 'base64').toString('utf-8');
        mutationsObj = JSON.parse(decodedMutations);
      } catch (err) {
        console.error('Mutation decode failed:', err);
      }
    }


    // ✅ Provide default fallbacks
    const enhancedParams = {
      tbl: 'advertisers',
      colstr: queryParams.colstr || 'Kg==', // default to *
      ...queryParams 
    };

    // 🧠 Clean up optional params if missing
    if (!enhancedParams.pagination) delete enhancedParams.pagination;
    if (!enhancedParams.q) delete enhancedParams.q;
    if (!enhancedParams.function_cols) enhancedParams.function_cols = '';

    const result = await mosyFlexSelect(enhancedParams, mutationsObj, AdvertisersAdvertiserRowMutations);

    return Response.json({
      status: 'success',
      message: 'AdvertisersAdvertiser data retrieved',
      ...result,
    });

  } catch (err) {
    console.error('GET AdvertisersAdvertiser failed:', err);
    return Response.json(
      { status: 'error', message: err.message },
      { status: 500 }
    );
  }
}



export async function POST(AdvertisersAdvertiserRequest) {
  try {
    let body;
    let isMultipart = false;

    const contentType = AdvertisersAdvertiserRequest.headers.get("content-type") || "";

    if (contentType.includes("multipart/form-data")) {
      isMultipart = true;
      const formData = await AdvertisersAdvertiserRequest.formData();

      // Convert FormData to plain object
      body = {};
      for (let [key, value] of formData.entries()) {
        body[key] = value;
      }

    } else {
      body = await AdvertisersAdvertiserRequest.json();
    }
    
    
    const AdvertisersAdvertiserFormAction = body.advertisers_mosy_action;
    const advertisers_uptoken_value = base64Decode(body.advertisers_uptoken);

		//--- Begin  advertisers inputs array ---// 

const AdvertisersAdvertiserInputsArr = {
  "business_name" : "?", 
  "contact_person" : "?", 
  "email" : "?", 
  "phone_number" : "?", 
  "reg_date" : "?", 

};

//--- End advertisers inputs array --//

    
    if (AdvertisersAdvertiserFormAction === "add_advertisers") 
    {
      
      const newId = magicRandomStr(7);
      AdvertisersAdvertiserInputsArr.record_is = newId;
      
      // Insert into table AdvertisersAdvertiser
      const result = await mosySqlInsert("advertisers", AdvertisersAdvertiserInputsArr, body);

       

      return Response.json({
        status: 'success',
        message: result.message,
        advertisers_uptoken: result.record_id
      });
      
    }
    
    if (AdvertisersAdvertiserFormAction === "update_advertisers") {
      
      // update table AdvertisersAdvertiser
      const result = await mosySqlUpdate("advertisers", AdvertisersAdvertiserInputsArr, body, `primkey='${advertisers_uptoken_value}'`);


      

      return Response.json({
        status: 'success',
        message: result.message,
        advertisers_uptoken: advertisers_uptoken_value
      });
    }    

    // Optional: catch unrecognized actions
    return Response.json({
      status: 'error',
      message: `Invalid action: ${AdvertisersAdvertiserFormAction}`
    }, { status: 400 });

  } catch (err) {
    console.error(`Request failed:`, err);
    return Response.json(
      { status: 'error', 
      message: `Data Post error ${err.message}` },
      { status: 500 }
    );
  }
}