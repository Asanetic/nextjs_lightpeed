
import { mosySqlInsert, mosySqlUpdate, base64Decode, mosyFlexSelect, mosyUploadFile, mosyDeleteFile } from '../../../be/data_control/dataUtils';
import { magicRandomStr } from '../../../../MosyUtils/hiveUtils';

import {ViewersViewerRowMutations} from './ViewersViewerRowMutations';

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const queryParams = Object.fromEntries(searchParams.entries());

    const encodedMutations = searchParams.get('mutations');

    let mutationsObj = {};
    if (encodedMutations) {
      try {
        const decodedMutations = Buffer.from(encodedMutations, 'base64').toString('utf-8');
        mutationsObj = JSON.parse(decodedMutations);
      } catch (err) {
        console.error('Mutation decode failed:', err);
      }
    }


    // ✅ Provide default fallbacks
    const enhancedParams = {
      tbl: 'viewers',
      colstr: queryParams.colstr || 'Kg==', // default to *
      ...queryParams 
    };

    // 🧠 Clean up optional params if missing
    if (!enhancedParams.pagination) delete enhancedParams.pagination;
    if (!enhancedParams.q) delete enhancedParams.q;
    if (!enhancedParams.function_cols) enhancedParams.function_cols = '';

    const result = await mosyFlexSelect(enhancedParams, mutationsObj, ViewersViewerRowMutations);

    return Response.json({
      status: 'success',
      message: 'ViewersViewer data retrieved',
      ...result,
    });

  } catch (err) {
    console.error('GET ViewersViewer failed:', err);
    return Response.json(
      { status: 'error', message: err.message },
      { status: 500 }
    );
  }
}



export async function POST(ViewersViewerRequest) {
  try {
    let body;
    let isMultipart = false;

    const contentType = ViewersViewerRequest.headers.get("content-type") || "";

    if (contentType.includes("multipart/form-data")) {
      isMultipart = true;
      const formData = await ViewersViewerRequest.formData();

      // Convert FormData to plain object
      body = {};
      for (let [key, value] of formData.entries()) {
        body[key] = value;
      }

    } else {
      body = await ViewersViewerRequest.json();
    }
    
    
    const ViewersViewerFormAction = body.viewers_mosy_action;
    const viewers_uptoken_value = base64Decode(body.viewers_uptoken);

		//--- Begin  viewers inputs array ---// 

const ViewersViewerInputsArr = {
  "full_name" : "?", 
  "email" : "?", 
  "phone_number" : "?", 
  "password" : "?", 
  "joined_on" : "?", 

};

//--- End viewers inputs array --//

    
    if (ViewersViewerFormAction === "add_viewers") 
    {
      
      const newId = magicRandomStr(7);
      ViewersViewerInputsArr.record_is = newId;
      
      // Insert into table ViewersViewer
      const result = await mosySqlInsert("viewers", ViewersViewerInputsArr, body);

       

      return Response.json({
        status: 'success',
        message: result.message,
        viewers_uptoken: result.record_id
      });
      
    }
    
    if (ViewersViewerFormAction === "update_viewers") {
      
      // update table ViewersViewer
      const result = await mosySqlUpdate("viewers", ViewersViewerInputsArr, body, `primkey='${viewers_uptoken_value}'`);


      

      return Response.json({
        status: 'success',
        message: result.message,
        viewers_uptoken: viewers_uptoken_value
      });
    }    

    // Optional: catch unrecognized actions
    return Response.json({
      status: 'error',
      message: `Invalid action: ${ViewersViewerFormAction}`
    }, { status: 400 });

  } catch (err) {
    console.error(`Request failed:`, err);
    return Response.json(
      { status: 'error', 
      message: `Data Post error ${err.message}` },
      { status: 500 }
    );
  }
}