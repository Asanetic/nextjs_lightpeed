
import { base64Decode, mosyFlexSelect , mosyQddata, mosySumRows, mosyCountRows , mosyQuickSel} from '../../../be/data_control/dataUtils';

export const ViewersViewerRowMutations = {

}
