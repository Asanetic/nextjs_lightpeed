
import { mosySqlInsert, mosySqlUpdate, base64Decode, mosyFlexSelect, mosyUploadFile, mosyDeleteFile } from '../../../be/data_control/dataUtils';
import { magicRandomStr } from '../../../../MosyUtils/hiveUtils';

import {SystemUsersUsersRowMutations} from './SystemUsersUsersRowMutations';

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const queryParams = Object.fromEntries(searchParams.entries());

    const encodedMutations = searchParams.get('mutations');

    let mutationsObj = {};
    if (encodedMutations) {
      try {
        const decodedMutations = Buffer.from(encodedMutations, 'base64').toString('utf-8');
        mutationsObj = JSON.parse(decodedMutations);
      } catch (err) {
        console.error('Mutation decode failed:', err);
      }
    }


    // ✅ Provide default fallbacks
    const enhancedParams = {
      tbl: 'system_users',
      colstr: queryParams.colstr || 'Kg==', // default to *
      ...queryParams 
    };

    // 🧠 Clean up optional params if missing
    if (!enhancedParams.pagination) delete enhancedParams.pagination;
    if (!enhancedParams.q) delete enhancedParams.q;
    if (!enhancedParams.function_cols) enhancedParams.function_cols = '';

    const result = await mosyFlexSelect(enhancedParams, mutationsObj, SystemUsersUsersRowMutations);

    return Response.json({
      status: 'success',
      message: 'SystemUsersUsers data retrieved',
      ...result,
    });

  } catch (err) {
    console.error('GET SystemUsersUsers failed:', err);
    return Response.json(
      { status: 'error', message: err.message },
      { status: 500 }
    );
  }
}



export async function POST(SystemUsersUsersRequest) {
  try {
    let body;
    let isMultipart = false;

    const contentType = SystemUsersUsersRequest.headers.get("content-type") || "";

    if (contentType.includes("multipart/form-data")) {
      isMultipart = true;
      const formData = await SystemUsersUsersRequest.formData();

      // Convert FormData to plain object
      body = {};
      for (let [key, value] of formData.entries()) {
        body[key] = value;
      }

    } else {
      body = await SystemUsersUsersRequest.json();
    }
    
    
    const SystemUsersUsersFormAction = body.system_users_mosy_action;
    const system_users_uptoken_value = base64Decode(body.system_users_uptoken);

		//--- Begin  system_users inputs array ---// 

const SystemUsersUsersInputsArr = {
  "name" : "?", 
  "email" : "?", 
  "tel" : "?", 
  "login_password" : "?", 
  "ref_id" : "?", 
  "regdate" : "?", 
  "user_no" : "?", 
  "user_pic" : "?", 
  "user_gender" : "?", 
  "last_seen" : "?", 
  "about" : "?", 
  "hive_site_id" : "?", 
  "hive_site_name" : "?", 
  "auth_token" : "?", 
  "token_status" : "?", 
  "token_expiring_in" : "?", 
  "project_id" : "?", 
  "project_name" : "?", 

};

//--- End system_users inputs array --//

    
    if (SystemUsersUsersFormAction === "add_system_users") 
    {
      
      const newId = magicRandomStr(7);
      SystemUsersUsersInputsArr.user_id = newId;
      
      // Insert into table SystemUsersUsers
      const result = await mosySqlInsert("system_users", SystemUsersUsersInputsArr, body);

       

      return Response.json({
        status: 'success',
        message: result.message,
        system_users_uptoken: result.record_id
      });
      
    }
    
    if (SystemUsersUsersFormAction === "update_system_users") {
      
      // update table SystemUsersUsers
      const result = await mosySqlUpdate("system_users", SystemUsersUsersInputsArr, body, `primkey='${system_users_uptoken_value}'`);


      

      return Response.json({
        status: 'success',
        message: result.message,
        system_users_uptoken: system_users_uptoken_value
      });
    }    

    // Optional: catch unrecognized actions
    return Response.json({
      status: 'error',
      message: `Invalid action: ${SystemUsersUsersFormAction}`
    }, { status: 400 });

  } catch (err) {
    console.error(`Request failed:`, err);
    return Response.json(
      { status: 'error', 
      message: `Data Post error ${err.message}` },
      { status: 500 }
    );
  }
}