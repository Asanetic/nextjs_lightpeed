// Reception kiosk endpoint. The kiosk runs in a browser tab that is signed in (Bearer token), so
// everything is scoped to the token's college (hive_site_id).
//   GET  -> { college, campuses }  to build the kiosk header + campus picker
//   POST -> a student / trainer types their admission / staff number: first tap of the day = clock in,
//           next tap = clock out. Only writes to `attendance`; returns no more than the person's name.
import { connectDB, activeDB } from '../../apiUtils/dataControl/conn';
import crypto from 'crypto';
import saAuthConfigs from '../../../auth/featureConfig/saAuthConfigs';
import { processAuthToken } from '../../auth/authManager';
import { magicRandomStr } from '../../apiUtils/dataControl/dataUtils';

const TZ = 'Africa/Nairobi';
const DOUBLE_TAP_MS = 60 * 1000; // a second tap inside this window is ignored, not treated as clock-out

const nowStr = () => new Date().toLocaleString('sv-SE', { timeZone: TZ }); // 'YYYY-MM-DD HH:mm:ss'

async function findPerson(conn, code, site) {
  const [students] = await conn.execute(
    `SELECT student_id AS id, full_name, first_name, hive_site_id, hive_site_name FROM \`${activeDB}\`.students WHERE admission_number = ? AND hive_site_id = ? LIMIT 1`,
    [code, site]
  );
  if (students[0]) return { ...students[0], kind: 'student' };
  const [trainers] = await conn.execute(
    `SELECT trainer_id AS id, full_name, first_name, hive_site_id, hive_site_name FROM \`${activeDB}\`.trainers WHERE staff_number = ? AND hive_site_id = ? LIMIT 1`,
    [code, site]
  );
  return trainers[0] ? { ...trainers[0], kind: 'trainer' } : null;
}

// Stored passwords are either plain (legacy login compares the column directly) or `salt:scrypt` (signup).
const passwordMatches = (candidate, stored) => {
  const s = String(stored || '');
  if (s === candidate) return true;
  const [salt, hash] = s.split(':');
  if (!salt || !hash) return false;
  try {
    return crypto.timingSafeEqual(Buffer.from(crypto.scryptSync(candidate, salt, 64).toString('hex'), 'hex'), Buffer.from(hash, 'hex'));
  } catch { return false; }
};

// Tiny brute-force guard: 5 wrong passwords per account per 5 minutes.
const fails = new Map();
const locked = (k) => (fails.get(k) || []).filter((t) => Date.now() - t < 5 * 60 * 1000).length >= 5;
const noteFail = (k) => fails.set(k, [...(fails.get(k) || []).filter((t) => Date.now() - t < 5 * 60 * 1000), Date.now()]);

const unauthorized = (reason) => Response.json({ ok: false, message: 'Please sign in to use the kiosk.', reason }, { status: 403 });

export async function GET(request) {
  try {
    const { valid, reason, data: auth } = processAuthToken(request);
    if (!valid) return unauthorized(reason);

    const conn = await connectDB();
    const [colleges] = await conn.execute(
      `SELECT college_name, city, logo FROM \`${activeDB}\`.college_profile WHERE hive_site_id = ? LIMIT 1`,
      [auth.hive_site_id]
    );
    const [campuses] = await conn.execute(
      `SELECT campus_id, campus_name, campus_code, city, address FROM \`${activeDB}\`.campuses WHERE hive_site_id = ? AND (status IS NULL OR LOWER(status) NOT IN ('inactive', 'closed', 'disabled')) ORDER BY campus_name`,
      [auth.hive_site_id]
    );
    return Response.json({
      ok: true,
      college: { name: colleges[0]?.college_name || auth.hive_site_name || '' },
      campuses,
    });
  } catch (err) {
    console.error('IoT kiosk info failed:', err);
    return Response.json({ ok: false, message: 'Could not load the kiosk details.' }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const { valid, reason, data: auth } = processAuthToken(request);
    if (!valid) return unauthorized(reason);

    const body = await request.json();

    // Re-check the signed-in admin's password before the kiosk campus can be changed.
    if (body.action === 'verify_admin') {
      const email = auth[saAuthConfigs.emailCol];
      const key = `${auth.hive_site_id}:${email}`;
      if (!email || !body.password) return Response.json({ ok: false, message: 'Enter the admin password.' });
      if (locked(key)) return Response.json({ ok: false, message: 'Too many attempts. Try again in a few minutes.' }, { status: 429 });

      const conn = await connectDB();
      const [users] = await conn.execute(
        `SELECT \`${saAuthConfigs.passwordCol}\` AS pw FROM \`${activeDB}\`.\`${saAuthConfigs.oauthTable}\` WHERE \`${saAuthConfigs.emailCol}\` = ? AND hive_site_id = ? LIMIT 1`,
        [email, auth.hive_site_id]
      );
      if (!users[0] || !passwordMatches(String(body.password), users[0].pw)) {
        noteFail(key);
        return Response.json({ ok: false, message: 'Incorrect password.' });
      }
      fails.delete(key);
      return Response.json({ ok: true });
    }

    const { admission_no: raw, campus_id: campusId = '' } = body;
    const code = String(raw ?? '').trim();
    if (!code || code.length > 40) {
      return Response.json({ ok: false, message: 'Enter your admission number.' });
    }

    const conn = await connectDB();
    let campus = '';
    if (campusId) {
      const [c] = await conn.execute(
        `SELECT campus_name FROM \`${activeDB}\`.campuses WHERE campus_id = ? AND hive_site_id = ? LIMIT 1`,
        [String(campusId), auth.hive_site_id]
      );
      campus = c[0]?.campus_name || '';
    }
    const person = await findPerson(conn, code, auth.hive_site_id);
    if (!person) {
      return Response.json({ ok: false, message: 'Admission number not found. Please try again.' });
    }

    const idCol = person.kind === 'student' ? 'student_id' : 'trainer_id';
    const now = nowStr();
    const today = now.slice(0, 10);
    const name = person.full_name || person.first_name || '';

    const [open] = await conn.execute(
      `SELECT primkey, clock_in FROM \`${activeDB}\`.attendance WHERE ${idCol} = ? AND attendance_date = ? AND clock_out IS NULL ORDER BY primkey DESC LIMIT 1`,
      [person.id, today]
    );

    if (open[0]) {
      const since = Date.now() - new Date(String(open[0].clock_in).replace(' ', 'T')).getTime();
      if (since < DOUBLE_TAP_MS) {
        return Response.json({ ok: true, name, action: 'in', message: 'You are already clocked in.' });
      }
      await conn.execute(`UPDATE \`${activeDB}\`.attendance SET clock_out = ? WHERE primkey = ?`, [now, open[0].primkey]);
      return Response.json({ ok: true, name, action: 'out', message: 'Clocked out. Goodbye!' });
    }

    await conn.execute(
      `INSERT INTO \`${activeDB}\`.attendance (attendance_id, ${idCol}, attendance_date, clock_in, status, remarks, hive_site_id, hive_site_name) VALUES (?, ?, ?, ?, 'present', ?, ?, ?)`,
      [magicRandomStr(7), person.id, today, now, ['Kiosk', campus].filter(Boolean).join(' - '), person.hive_site_id || '', person.hive_site_name || '']
    );
    return Response.json({ ok: true, name, action: 'in', message: 'Clocked in. Welcome!' });
  } catch (err) {
    console.error('IoT clock-in failed:', err);
    return Response.json({ ok: false, message: 'Could not record attendance. Please try again.' }, { status: 500 });
  }
}
