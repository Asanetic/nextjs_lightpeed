export function sendReminders()
{
  //

}