
//pass listMessageoutboxRowMutationsKeys to mosy select 

const listMessageoutboxRowMutationsKeys = {
_invoices_invoice_no_ref_number : [],

};

export default listMessageoutboxRowMutationsKeys;

