
//pass listSmsremindersRowMutationsKeys to mosy select 

const listSmsremindersRowMutationsKeys = {
_invoices_invoice_no_ref_number : [],

};

export default listSmsremindersRowMutationsKeys;

