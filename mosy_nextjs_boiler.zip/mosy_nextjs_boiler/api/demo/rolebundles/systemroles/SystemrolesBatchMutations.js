
/**
 * AUTO-GENERATED BATCH MUTATIONS
 * DO NOT EDIT MANUALLY
 */

export const SystemrolesBatchMutations = {
"permissions": {"type":"count","table":"user_bundle_role_functions","link":"bundle_id:record_id"},
"permission_list": {"type":"mini","table":"user_bundle_role_functions","link":"bundle_id:record_id","columns":"role_name","limit":"20"}
};

export const listSystemrolesMutationKeys = {
"permissions": [],
"permission_list": [],

};

export default listSystemrolesMutationKeys;
