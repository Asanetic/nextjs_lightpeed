import {mosyFlexSelect} from '../../../apiUtils/dataControl/dataUtils';
import { AdsCampaignsRowMutations } from '../../campaigns/campaigns/AdsCampaignsRowMutations';

export async function GET() {
      // ✅ Provide default fallbacks
      const adByMerchant = {
        tbl: 'ads',
        colstr: btoa("advertiser_id , count(*) as value"), // default to *
        q : btoa("group by advertiser_id") 
      };

      const adByCategory = {
        tbl: 'ads',
        colstr: btoa("advertiser_id , sum(daily_budget) as value"), // default to *
        q : btoa("group by advertiser_id") 
      };

  
      //chart data 
      const mutations = {_advertisers_business_name_advertiser_id : []}
 
      const adByMerchantResult = await mosyFlexSelect(adByMerchant,mutations, AdsCampaignsRowMutations);
      const adByCategoryResult = await mosyFlexSelect(adByCategory,mutations, AdsCampaignsRowMutations);

      const chartData = [
        {
          title: "Ad by Merchant",
          chartType: "doughnut",
          dataKey: "_advertisers_business_name_advertiser_id",
          data: adByMerchantResult?.data ?? [],
          containerClass: "col-md-6"
        },
        {
          title: "Advertiser spending",
          chartType: "pie",
          dataKey: "_advertisers_business_name_advertiser_id",
          data: adByCategoryResult?.data ?? [],
          containerClass: "col-md-6"

        },

        {
          title: "Ad by Views",
          chartType: "bar",
          dataKey: "_advertisers_business_name_advertiser_id",
          data: adByMerchantResult?.data ?? [],
          series: [{ key: "value", color: "#2663A6", name: "Views" }],
          height: 350,
          containerClass: "col-md-12"

        },
      ];
      
      //card data 
      const adsCount = await mosyFlexSelect({tbl:"ads",colstr:btoa("count(*) as total_ads")})
      const adsBudget = await mosyFlexSelect({tbl:"ads",colstr:btoa("sum(daily_budget) as ad_budget")})
      const clientCount = await mosyFlexSelect({tbl:"advertisers",colstr:btoa("count(*) as total_clients")})
      const totalPaid = await mosyFlexSelect({tbl:"advertisers_payment",colstr:btoa("sum(amount_paid) as total_paid")})

      const cardData = [
        {
          title: 'Posted ads',
          value: `${adsCount?.data[0].total_ads}`,
          percentage: '',
          icon: "FaCopy",
        },
        {
          title: 'Clients',
          value: `${clientCount?.data[0].total_clients}`,
          percentage: '',
          icon: "FaUsers",
        },
        {
          title: 'Total revenue',
          value: `KES ${totalPaid?.data[0].total_paid}`,
          percentage: '',
          icon: "FaCheckCircle",
        },
        {
          title: 'Total ad budget',
          value: `KES ${adsBudget?.data[0].ad_budget}`,
          percentage: '',
          icon: "FaCreditCard",
        },
      
      ];

      return Response.json({
        status: "success",
        message: "Chart data ready!",
        chart_data: chartData,
        cards_data: cardData,
      });

}
