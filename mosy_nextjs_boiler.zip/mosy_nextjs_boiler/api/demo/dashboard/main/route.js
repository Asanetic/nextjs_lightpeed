import { mosySmartSelect } from '../../../apiUtils/dataControl/dataUtils';
import { processAuthToken } from '../../../auth/authManager';

// Consolidated College dashboard payload: payments, enrollments, fee
// arrears, certificates, attendance and assessments in one request.
// Site-scoped via hive_site_id. Monthly charts cover the last 12 months.

const MONTHS = 12;
const COURSE_MONTHS = 6;
const SPARK_MONTHS = 9; // stat-card sparklines
const INACTIVE = `('completed','graduated','dropped','withdrawn','cancelled','suspended')`;

function ym(date) {
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}`;
}
// Last `n` months (oldest first) as YYYY-MM keys.
function lastMonths(n) {
  const now = new Date();
  const out = [];
  for (let i = n - 1; i >= 0; i--) out.push(ym(new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i, 1))));
  return out;
}
const monthLabel = (key) =>
  new Date(`${key}-01T00:00:00Z`).toLocaleDateString('en-GB', { month: 'short', timeZone: 'UTC' });

export async function GET(request) {
  const { valid, reason, data: authData } = processAuthToken(request);
  if (!valid) {
    return Response.json({ status: 'unauthorized', message: reason }, { status: 403 });
  }

  const isSuperadmin = !authData?.hive_site_id;
  const { searchParams } = new URL(request.url);
  const siteFilterId = isSuperadmin ? searchParams.get('hive_site_id') || '' : authData.hive_site_id;

  function site(tbl) {
    if (!siteFilterId) return '1=1';
    const safe = String(siteFilterId).replace(/\\/g, '\\\\').replace(/'/g, "\\'");
    return `${tbl}.hive_site_id='${safe}'`;
  }

  async function safeSelect(sql, fallback = []) {
    try {
      return await mosySmartSelect(sql);
    } catch (err) {
      console.error('dashboard/main query failed:', err.message, '\nSQL:', sql);
      return fallback;
    }
  }

  // Optional date range (YYYY-MM-DD) from the dashboard filter bar: scopes payments + enrollments-by-course.
  const dateParam = (k) => { const v = searchParams.get(k) || ''; return /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : ''; };
  const from = dateParam('from');
  const to = dateParam('to');
  const range = (col) => `${from ? ` AND DATE(${col}) >= '${from}'` : ''}${to ? ` AND DATE(${col}) <= '${to}'` : ''}`;
  const payRange = range('p.payment_date');
  const enrRange = range('e.enrollment_date');

  const months = lastMonths(MONTHS);
  const courseMonths = months.slice(-COURSE_MONTHS);
  const monthStart = `${months[0]}-01 00:00:00`;
  const courseStart = `${courseMonths[0]}-01 00:00:00`;
  const thisMonth = months[months.length - 1];

  // Enrollments still in progress (anything not finished/stopped).
  const activeEnr = `${site('e')} AND LOWER(COALESCE(NULLIF(e.completion_status,''),'active')) NOT IN ${INACTIVE}`;

  // Outstanding balance per active enrollment = fees due for its course
  // (+ level, when the fee row is level-specific) minus payments received.
  const balanceSql = `
    SELECT e.enrollment_id, e.course_id,
      COALESCE((SELECT SUM(f.amount) FROM fee_structure f
                WHERE f.course_id = e.course_id AND (f.level_id IS NULL OR f.level_id = '' OR f.level_id = e.level_id)), 0)
      - COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.enrollment_id = e.enrollment_id), 0) AS balance
    FROM enrollments e
    WHERE ${activeEnr}`;

  const [
    payMonth, payPerMonth, payPerCourse,
    enrActive, enrPerCourseMonth, enrPending,
    arrears,
    certTotal, certPerMonth,
    attPresent, attAbsent, attMarked,
    assessCount, examCount, resultsPending,
    unpaidStudents, noAttendance, latestEnrollments,
    studentCount, courseCount, payTotal, payByMethod, latestPayments, enrPerMonth, enrByCourse, latestGraduates, studentsPerMonth, coursesPerMonth,
  ] = await Promise.all([
    safeSelect(`SELECT COALESCE(SUM(amount),0) AS value FROM payments WHERE ${site('payments')} AND DATE_FORMAT(payment_date,'%Y-%m') = '${thisMonth}'`),
    safeSelect(`SELECT DATE_FORMAT(payment_date,'%Y-%m') AS label, COALESCE(SUM(amount),0) AS value FROM payments
      WHERE ${site('payments')} AND payment_date >= '${lastMonths(24)[0]}-01 00:00:00' GROUP BY label`),
    safeSelect(`SELECT COALESCE(c.course_name,'Unknown') AS label, COALESCE(SUM(p.amount),0) AS value
      FROM payments p LEFT JOIN enrollments e ON e.enrollment_id = p.enrollment_id
      LEFT JOIN courses c ON c.course_id = e.course_id
      WHERE ${site('p')} GROUP BY label ORDER BY value DESC LIMIT 10`),

    safeSelect(`SELECT COUNT(*) AS value FROM enrollments e WHERE ${activeEnr}`),
    safeSelect(`SELECT COALESCE(c.course_name,'Unknown') AS course, DATE_FORMAT(e.enrollment_date,'%Y-%m') AS label, COUNT(*) AS value
      FROM enrollments e LEFT JOIN courses c ON c.course_id = e.course_id
      WHERE ${site('e')} AND e.enrollment_date >= '${courseStart}' GROUP BY course, label`),
    safeSelect(`SELECT COUNT(*) AS value FROM enrollments e WHERE ${activeEnr} AND e.completion_date IS NOT NULL AND e.completion_date <= NOW()`),

    safeSelect(`SELECT COALESCE(c.course_name,'Unknown') AS course, COUNT(*) AS students, SUM(b.balance) AS outstanding
      FROM (${balanceSql}) b LEFT JOIN courses c ON c.course_id = b.course_id
      WHERE b.balance > 0 GROUP BY course ORDER BY outstanding DESC`),

    safeSelect(`SELECT COUNT(*) AS value FROM certificates WHERE ${site('certificates')}`),
    safeSelect(`SELECT DATE_FORMAT(issue_date,'%Y-%m') AS label, COUNT(*) AS value FROM certificates
      WHERE ${site('certificates')} AND issue_date >= '${monthStart}' GROUP BY label`),

    safeSelect(`SELECT COUNT(DISTINCT student_id) AS value FROM attendance WHERE ${site('attendance')} AND DATE(attendance_date) = CURDATE() AND clock_in IS NOT NULL`),
    safeSelect(`SELECT COUNT(DISTINCT student_id) AS value FROM attendance WHERE ${site('attendance')} AND DATE(attendance_date) = CURDATE() AND clock_in IS NULL`),
    safeSelect(`SELECT COUNT(DISTINCT student_id) AS value FROM attendance WHERE ${site('attendance')} AND DATE(attendance_date) = CURDATE()`),

    safeSelect(`SELECT COUNT(*) AS value FROM assessments WHERE ${site('assessments')}`),
    safeSelect(`SELECT COUNT(*) AS value FROM exams WHERE ${site('exams')}`),
    // Exams that have no result recorded yet.
    safeSelect(`SELECT COUNT(*) AS value FROM exams x WHERE ${site('x')}
      AND NOT EXISTS (SELECT 1 FROM exam_results r WHERE r.exam_id = x.exam_id)`),

    safeSelect(`SELECT COUNT(DISTINCT enrollment_id) AS value FROM (${balanceSql}) b WHERE b.balance > 0`),
    // Active students with no attendance record in the last 7 days.
    safeSelect(`SELECT COUNT(DISTINCT e.student_id) AS value FROM enrollments e WHERE ${activeEnr}
      AND NOT EXISTS (SELECT 1 FROM attendance a WHERE a.student_id = e.student_id AND a.attendance_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY))`),
    safeSelect(`SELECT e.enrollment_id, e.enrollment_date, e.completion_status,
        s.full_name AS student, s.admission_number,
        c.course_name AS course
      FROM enrollments e
      LEFT JOIN students s ON s.student_id = e.student_id
      LEFT JOIN courses c ON c.course_id = e.course_id
      WHERE ${site('e')}
      ORDER BY e.enrollment_date DESC, e.primkey DESC
      LIMIT 10`),
    safeSelect(`SELECT COUNT(*) AS value FROM students WHERE ${site('students')}`),
    safeSelect(`SELECT COUNT(*) AS value FROM courses WHERE ${site('courses')}`),
    safeSelect(`SELECT COALESCE(SUM(p.amount),0) AS value FROM payments p WHERE ${site('p')}${payRange}`),
    safeSelect(`SELECT COALESCE(NULLIF(p.payment_method,''),'Other') AS label, COALESCE(SUM(p.amount),0) AS value FROM payments p
      WHERE ${site('p')}${payRange} GROUP BY label ORDER BY value DESC`),
    safeSelect(`SELECT p.payment_id, p.payment_date, p.amount, p.payment_method, p.reference, p.status,
        s.full_name AS student, c.course_name AS course
      FROM payments p
      LEFT JOIN students s ON s.student_id = p.student_id
      LEFT JOIN courses c ON c.course_id = p.course_id
      WHERE ${site('p')}${payRange}
      ORDER BY p.payment_date DESC, p.primkey DESC
      LIMIT 5`),
    safeSelect(`SELECT DATE_FORMAT(e.enrollment_date,'%Y-%m') AS label, COUNT(*) AS value FROM enrollments e
      WHERE ${site('e')} AND e.enrollment_date IS NOT NULL AND e.enrollment_date > '1990-01-01' GROUP BY label`),
    safeSelect(`SELECT COALESCE(c.course_name,'Unknown') AS course, COUNT(*) AS value
      FROM enrollments e LEFT JOIN courses c ON c.course_id = e.course_id
      WHERE ${site('e')}${enrRange} GROUP BY course ORDER BY value DESC LIMIT 8`),
    safeSelect(`SELECT e.enrollment_id, e.completion_date, e.completion_status,
        s.full_name AS student, s.admission_number, c.course_name AS course
      FROM enrollments e
      LEFT JOIN students s ON s.student_id = e.student_id
      LEFT JOIN courses c ON c.course_id = e.course_id
      WHERE ${site('e')} AND LOWER(e.completion_status) IN ('completed','graduated')
      ORDER BY e.completion_date DESC, e.primkey DESC
      LIMIT 10`),
    safeSelect(`SELECT DATE_FORMAT(reg_date,'%Y-%m') AS label, COUNT(*) AS value FROM students
      WHERE ${site('students')} AND reg_date >= '${months[months.length - SPARK_MONTHS]}-01 00:00:00' GROUP BY label`),
    safeSelect(`SELECT DATE_FORMAT(reg_date,'%Y-%m') AS label, COUNT(*) AS value FROM courses
      WHERE ${site('courses')} AND reg_date >= '${months[months.length - SPARK_MONTHS]}-01 00:00:00' GROUP BY label`),
  ]);

  const val = (rows) => Number(rows?.[0]?.value || 0);
  const monthMap = (rows) => Object.fromEntries((rows || []).map((r) => [r.label, Number(r.value) || 0]));
  const pMap = monthMap(payPerMonth);
  const cMap = monthMap(certPerMonth);

  // Enrollments per course/month -> [{course, months:[n,...], total}]
  const courseRows = {};
  (enrPerCourseMonth || []).forEach((r) => {
    courseRows[r.course] ||= Object.fromEntries(courseMonths.map((m) => [m, 0]));
    if (r.label in courseRows[r.course]) courseRows[r.course][r.label] = Number(r.value) || 0;
  });
  const enrollmentsByCourseMonthly = Object.entries(courseRows)
    .map(([course, m]) => ({ course, ...Object.fromEntries(courseMonths.map((k) => [monthLabel(k), m[k]])), total: Object.values(m).reduce((a, b) => a + b, 0) }))
    .sort((a, b) => b.total - a.total)
    .slice(0, 8);

  const arrearsRows = (arrears || []).map((r) => ({
    course: r.course,
    students: Number(r.students) || 0,
    outstanding: Number(r.outstanding) || 0,
  }));
  const present = val(attPresent);
  const absent = val(attAbsent);
  const activeCount = val(enrActive);

  // Monthly series run from the first month that has data to the current month (2–24 points), no empty Jan–Dec padding.
  const monthSpan = (map) => {
    const first = Object.keys(map).sort()[0];
    if (!first) return [];
    const [fy, fm] = first.split('-').map(Number);
    const now = new Date();
    const total = (now.getUTCFullYear() - fy) * 12 + (now.getUTCMonth() + 1 - fm) + 1;
    return lastMonths(Math.min(Math.max(total, 2), 24)).map((k) => ({
      label: `${monthLabel(k)} '${k.slice(2, 4)}`,
      value: map[k] || 0,
    }));
  };
  const enrollmentsByMonth = monthSpan(monthMap(enrPerMonth));
  const paymentsByMonth = monthSpan(pMap);

  return Response.json({
    status: 'success',
    message: 'Dashboard ready!',
    is_superadmin: isSuperadmin,
    selected_site: siteFilterId || null,
    range: { from, to },

    summary: {
      paymentsThisMonth: val(payMonth),
      activeEnrollments: activeCount,
      feeArrears: arrearsRows.reduce((a, r) => a + r.outstanding, 0),
      certificatesIssued: val(certTotal),
    },
    totals: {
      students: val(studentCount),
      courses: val(courseCount),
      feesCollected: val(payTotal),
      unpaidStudents: val(unpaidStudents),
    },
    paymentsByMethod: (payByMethod || []).map((r) => ({ label: r.label, value: Number(r.value) || 0 })),
    latestPayments: (latestPayments || []).map((r) => ({
      id: r.payment_id, date: r.payment_date, student: r.student, course: r.course,
      method: r.payment_method, reference: r.reference, amount: Number(r.amount) || 0, status: r.status,
    })),
    enrollmentsByMonth,
    sparklines: {
      students: months.slice(-SPARK_MONTHS).map((m) => monthMap(studentsPerMonth)[m] || 0),
      courses: months.slice(-SPARK_MONTHS).map((m) => monthMap(coursesPerMonth)[m] || 0),
      payments: months.slice(-SPARK_MONTHS).map((m) => pMap[m] || 0),
    },
    paymentsByMonth,
    paymentsPerMonth: months.map((m) => ({ label: monthLabel(m), value: pMap[m] || 0 })),
    paymentsPerCourse: (payPerCourse || []).map((r) => ({ label: r.label, value: Number(r.value) || 0 })),
    enrollmentCourseMonths: courseMonths.map(monthLabel),
    enrollmentsByCourse: (enrByCourse || []).map((r) => ({ course: r.course, total: Number(r.value) || 0 })),
    enrollmentsByCourseMonthly,
    arrears: arrearsRows,
    attendance: { present, absent, notMarked: Math.max(activeCount - val(attMarked), 0) },
    assessment: { assessments: val(assessCount), exams: val(examCount), resultsPending: val(resultsPending) },
    latestEnrollments: latestEnrollments || [],
    latestGraduates: latestGraduates || [],
    certificatesPerMonth: months.map((m) => ({ label: monthLabel(m), value: cMap[m] || 0 })),
    attention: {
      unpaidStudents: val(unpaidStudents),
      resultsPending: val(resultsPending),
      noRecentAttendance: val(noAttendance),
      awaitingCompletion: val(enrPending),
    },
  });
}
