import { mosySmartSelect } from '../../../apiUtils/dataControl/dataUtils';
import { processAuthToken } from '../../../auth/authManager';

// Consolidated payload for the Maira dashboard: visits, messages and
// reminders for a date range (?start=YYYY-MM-DD&end=YYYY-MM-DD, default
// today), visits by agent, daily activity and latest traffic.
// One request, backend-aggregated. Site-scoped via hive_site_id.

const MAX_CHART_DAYS = 92;
const isDate = (v) => /^\d{4}-\d{2}-\d{2}$/.test(v || '');

function nairobiDateStr(date) {
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'Africa/Nairobi' }).format(date);
}
// Inclusive list of YYYY-MM-DD between two dates (UTC math avoids DST/tz drift).
function daysBetween(start, end) {
  const out = [];
  const d = new Date(`${start}T00:00:00Z`);
  const last = new Date(`${end}T00:00:00Z`);
  while (d <= last) {
    out.push(d.toISOString().slice(0, 10));
    d.setUTCDate(d.getUTCDate() + 1);
  }
  return out;
}

export async function GET(request) {
  const { valid: isTokenValid, reason: tokenError, data: authData } = processAuthToken(request);
  if (!isTokenValid) {
    return Response.json({ status: 'unauthorized', message: tokenError }, { status: 403 });
  }

  const isSuperadmin = !authData?.hive_site_id;
  const { searchParams } = new URL(request.url);
  const requestedSite = searchParams.get('hive_site_id') || '';
  const siteFilterId = isSuperadmin ? requestedSite : authData.hive_site_id;

  function site(tbl) {
    if (!siteFilterId) return '1=1';
    const safe = String(siteFilterId).replace(/\\/g, '\\\\').replace(/'/g, "\\'");
    return `${tbl}.hive_site_id='${safe}'`;
  }

  async function safeSelect(sql, fallback = []) {
    try {
      return await mosySmartSelect(sql);
    } catch (err) {
      console.error('dashboard/main query failed:', err.message, '\nSQL:', sql);
      return fallback;
    }
  }

  // Range — dates are regex-validated so they are safe to inline.
  const today = nairobiDateStr(new Date());
  let start = isDate(searchParams.get('start')) ? searchParams.get('start') : today;
  let end = isDate(searchParams.get('end')) ? searchParams.get('end') : today;
  if (start > end) [start, end] = [end, start];
  const from = `${start} 00:00:00`;
  const to = `${end} 23:59:59`;

  const allDays = daysBetween(start, end);
  const days = allDays.slice(-MAX_CHART_DAYS); // chart window only
  const between = (col) => `${col} >= '${from}' AND ${col} <= '${to}'`;
  const chartFrom = `${days[0]} 00:00:00`;

  const count = (tbl, col) =>
    safeSelect(`SELECT COUNT(*) AS value FROM ${tbl} WHERE ${site(tbl)} AND ${between(col)}`);

  const agentJoin = `LEFT JOIN (SELECT platform, MIN(agent_name) AS agent_name FROM agents GROUP BY platform) a ON a.platform = v.asset`;

  const [
    visits, visitors, messages, reminders,
    visitsByAgent, visitsPerDay, messagesPerDay, latestTraffic,
    logStats, logRemindersSet, logsPerDay,
  ] = await Promise.all([
    count('visitors_log', 'visitdate'),
    safeSelect(`SELECT COUNT(DISTINCT visitor_code) AS value FROM visitors_log WHERE ${site('visitors_log')} AND ${between('visitdate')}`),
    count('smart_messages', 'sent_on'),
    count('mosy_reminder_log', 'reg_date'),

    // Agent = the agents row whose platform matches the visit's asset.
    safeSelect(`
      SELECT COALESCE(a.agent_name, v.asset, 'Unknown') AS label, COUNT(*) AS value
      FROM visitors_log v ${agentJoin}
      WHERE ${site('v')} AND ${between('v.visitdate')}
      GROUP BY label
      ORDER BY value DESC
      LIMIT 10
    `),
    safeSelect(`
      SELECT DATE_FORMAT(visitdate,'%Y-%m-%d') AS label, COUNT(*) AS value
      FROM visitors_log
      WHERE ${site('visitors_log')} AND visitdate >= '${chartFrom}' AND visitdate <= '${to}'
      GROUP BY label
    `),
    safeSelect(`
      SELECT DATE_FORMAT(sent_on,'%Y-%m-%d') AS label, COUNT(*) AS value
      FROM smart_messages
      WHERE ${site('smart_messages')} AND sent_on >= '${chartFrom}' AND sent_on <= '${to}'
      GROUP BY label
    `),
    safeSelect(`
      SELECT v.visitdate, v.asset, v.visitor_code, v.pagevisited, v.device, v.sourcename,
        COALESCE(a.agent_name, v.asset) AS agent
      FROM visitors_log v ${agentJoin}
      WHERE ${site('v')} AND ${between('v.visitdate')}
      ORDER BY v.visitdate DESC
      LIMIT 10
    `),

    // Maira data logs, by execution time (run_at). "Success" = the platform's
    // response status is ready / success.
    safeSelect(`
      SELECT COUNT(*) AS total,
        COALESCE(SUM(CASE WHEN LOWER(status) IN ('ready','success') THEN 1 ELSE 0 END),0) AS ok
      FROM maira_data_logs
      WHERE ${site('maira_data_logs')} AND ${between('run_at')}
    `),
    // Separate so a missing reminder_set column can't zero the other log stats.
    safeSelect(`
      SELECT COUNT(*) AS value FROM maira_data_logs
      WHERE ${site('maira_data_logs')} AND ${between('run_at')} AND LOWER(reminder_set) = 'set'
    `),
    safeSelect(`
      SELECT DATE_FORMAT(run_at,'%Y-%m-%d') AS label,
        COALESCE(SUM(CASE WHEN LOWER(status) IN ('ready','success') THEN 1 ELSE 0 END),0) AS success,
        COALESCE(SUM(CASE WHEN LOWER(status) IN ('ready','success') THEN 0 ELSE 1 END),0) AS failed
      FROM maira_data_logs
      WHERE ${site('maira_data_logs')} AND run_at >= '${chartFrom}' AND run_at <= '${to}'
      GROUP BY label
    `),
  ]);

  const val = (rows) => Number(rows?.[0]?.value || 0);
  const dayMap = (rows) => Object.fromEntries((rows || []).map((r) => [r.label, Number(r.value) || 0]));
  const vMap = dayMap(visitsPerDay);
  const mMap = dayMap(messagesPerDay);
  const lMap = Object.fromEntries((logsPerDay || []).map((r) => [r.label, r]));
  const logTotal = Number(logStats?.[0]?.total || 0);
  const logOk = Number(logStats?.[0]?.ok || 0);

  return Response.json({
    status: 'success',
    message: 'Dashboard ready!',
    is_superadmin: isSuperadmin,
    selected_site: siteFilterId || null,
    range: { start, end },

    summary: {
      visits: val(visits),
      visitors: val(visitors),
      messages: val(messages),
      reminders: val(reminders),
    },

    visitsByAgent: (visitsByAgent || []).map((r) => ({ label: r.label || 'Unknown', value: Number(r.value) || 0 })),
    dailyActivity: days.map((d) => ({ label: d.slice(5), visits: vMap[d] || 0, messages: mMap[d] || 0 })),
    latestTraffic: latestTraffic || [],

    logs: {
      total: logTotal,
      success: logOk,
      failed: logTotal - logOk,
      remindersSet: val(logRemindersSet),
    },
    logsPerDay: days.map((d) => ({
      label: d.slice(5),
      success: Number(lMap[d]?.success || 0),
      failed: Number(lMap[d]?.failed || 0),
    })),
  });
}
