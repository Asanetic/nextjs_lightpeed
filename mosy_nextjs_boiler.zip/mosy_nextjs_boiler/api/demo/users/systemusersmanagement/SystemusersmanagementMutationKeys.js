
//pass listSystemusersmanagementRowMutationsKeys to mosy select 

const listSystemusersmanagementRowMutationsKeys = {
last_seen : [],
};

export default listSystemusersmanagementRowMutationsKeys;

