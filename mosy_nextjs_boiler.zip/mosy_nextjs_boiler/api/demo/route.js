
//utils 
import { mosySqlInsert, mosySqlUpdate, base64Decode, mosyFlexSelect, mosyUploadFile, mosyDeleteFile, magicRandomStr } from '../../../apiUtils/dataControl/dataUtils';

import {RowMutations} from './RowMutations';

import listRowMutationsKeys from './MutationKeys';

//be gate keeper and auth 
import { validateSelect , mosyMutateQuery, mutateInputArray } from '../../beMonitor';
import { processAuthToken } from '../../../auth/authManager';

import { Add, Update } from './DbGateway';


export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const queryParams = Object.fromEntries(searchParams.entries());

    const encodedMutations = searchParams.get('mutations');

    let requestedMutationsObj = {};
    if (encodedMutations) {
      try {
        const decodedMutations = Buffer.from(encodedMutations, 'base64').toString('utf-8');
        requestedMutationsObj = JSON.parse(decodedMutations);
      } catch (err) {
        console.error('Mutation decode failed:', err);
      }
    }

    const { valid: isTokenValid, reason: tokenError, data: authData } = processAuthToken(request);
     
    if (!isTokenValid) {
      return Response.json(
        { status: 'unauthorized', message: tokenError },
        { status: 403 }
      );
    }
    

    // ✅ Provide default fallbacks
    const enhancedParams = {
      tbl: 'ux_table',
      colstr: queryParams.colstr || 'Kg==', // default to *
      ...queryParams 
    };

    // 🧠 Clean up optional params if missing
    if (!enhancedParams.pagination) delete enhancedParams.pagination;
    if (!enhancedParams.q) delete enhancedParams.q;
    if (!enhancedParams.function_cols) enhancedParams.function_cols = '';

    //append further queries to client query request , account filters order by group by  etc
    const mutatedQparam = mosyMutateQuery('ux_table', searchParams, authData, '')

    enhancedParams.q=mutatedQparam
    
    let requestValid =validateSelect('ux_table', queryParams, authData)

    if(!requestValid)
    {
      return Response.json(
        { status: 'error', message: 'Request is invalid' },
        { status: 400 }
      );

    }
 
    const isEmpty = (obj) => !obj || Object.keys(obj).length === 0;
    const mutationsObj = isEmpty(requestedMutationsObj) ? listRowMutationsKeys : requestedMutationsObj;
    
    if(requestValid){
    
      const result = await mosyFlexSelect(enhancedParams, mutationsObj, RowMutations);

      return Response.json({
        status: 'success',
        message: ' data retrieved',
        ...result,
      });
      
   }
  } catch (err) {
    console.error('GET  failed:', err);
    return Response.json(
      { status: 'error', message: err.message },
      { status: 500 }
    );
  }
}



export async function POST(Request) {
  try {
    let body;
    let isMultipart = false;

    const contentType = Request.headers.get("content-type") || "";

    if (contentType.includes("multipart/form-data")) {
      isMultipart = true;
      const formData = await Request.formData();

      // Convert FormData to plain object
      body = {};
      for (let [key, value] of formData.entries()) {
        body[key] = value;
      }

    } else {
      body = await Request.json();
    }
    
    
    const { valid: isTokenValid, reason: tokenError, data: authData } = processAuthToken(Request);
     
    if (!isTokenValid) {
      return Response.json(
        { status: 'unauthorized', message: tokenError },
        { status: 403 }
      );
    }
    
    const FormAction = body.ux_table_mosy_action;
    const ux_table_uptoken_value = base64Decode(body.ux_table_uptoken);
    
    const newId = magicRandomStr(7);


		
  
  //--- Begin  acc_renewals inputs array ---// 
  const InputsArr = {

    "account_name" : "?", 
    "mobile_no" : "?", 
    "credits_available" : "?", 
    "package_name" : "?", 
    "package_amount" : "?", 
    "credits_deducted" : "?", 
    "new_credit_balance" : "?", 
    "next_expiry_date" : "?", 
    "activated_on" : "?", 
    "activated_by" : "?", 
    "renid" : "?", 
    "client_type" : "?", 
    "invoice_signature" : "?", 
    "client_names" : "?", 
    "team_id" : "?", 
    "last_expiry_date" : "?", 
    "old_balance" : "?", 
    "disconnection_message" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End acc_renewals inputs array --//

  
  //--- Begin  account_urls inputs array ---// 
  const InputsArr = {

    "url_name" : "?", 
    "url" : "?", 
    "description" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End account_urls inputs array --//

  
  //--- Begin  admin_roles inputs array ---// 
  const InputsArr = {

    "admin_id" : "?", 
    "role_key" : "?", 
    "role_value" : "?", 
    "assigned_by" : "?", 
    "ref_id" : "?", 
    "assigned_on" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End admin_roles inputs array --//

  
  //--- Begin  admins inputs array ---// 
  const InputsArr = {

    "name" : "?", 
    "email" : "?", 
    "tel" : "?", 
    "login_password" : "?", 
    "ref_id" : "?", 
    "regdate" : "?", 
    "user_no" : "?", 
    "user_pic" : "?", 
    "user_gender" : "?", 
    "last_seen" : "?", 
    "about" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End admins inputs array --//

  
  //--- Begin  billing_log inputs array ---// 
  const InputsArr = {

    "transaction_ref" : "?", 
    "trx_type" : "?", 
    "trx_time" : "?", 
    "amount" : "?", 
    "trx_source" : "?", 
    "ref_id" : "?", 
    "site_id" : "?", 
    "message" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End billing_log inputs array --//

  
  //--- Begin  billing_transactions inputs array ---// 
  const InputsArr = {

    "trx_id" : "?", 
    "trx_date" : "?", 
    "trx_month_year" : "?", 
    "trx_remark" : "?", 
    "amount" : "?", 
    "trx_type" : "?", 
    "business_id" : "?", 
    "client_id" : "?", 
    "admin_id" : "?", 
    "TransactionType" : "?", 
    "BusinessShortCode" : "?", 
    "BillRefNumber" : "?", 
    "InvoiceNumber" : "?", 
    "OrgAccountBalance" : "?", 
    "ThirdPartyTransID" : "?", 
    "MSISDN" : "?", 
    "FirstName" : "?", 
    "MiddleName" : "?", 
    "LastName" : "?", 
    "trx_msg" : "?", 
    "account_id" : "?", 
    "used_status" : "?", 
    "filter_date" : "?", 
    "flw_id" : "?", 
    "flag_state" : "?", 
    "reconciled" : "?", 
    "corrected_number" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End billing_transactions inputs array --//

  
  //--- Begin  cashbook_table inputs array ---// 
  const InputsArr = {

    "source_table" : "?", 
    "dr_amt" : "?", 
    "cr_amt" : "?", 
    "dr_particulars" : "?", 
    "cr_particulars" : "?", 
    "dr_acc_id" : "?", 
    "cr_acc_id" : "?", 
    "transaction_tag" : "?", 
    "transaction_date" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End cashbook_table inputs array --//

  
  //--- Begin  checkout_orders inputs array ---// 
  const InputsArr = {

    "payment_account" : "?", 
    "checkout_date" : "?", 
    "amount" : "?", 
    "tel" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End checkout_orders inputs array --//

  
  //--- Begin  client_accounts inputs array ---// 
  const InputsArr = {

    "client_name" : "?", 
    "client_email" : "?", 
    "client_tel" : "?", 
    "client_location" : "?", 
    "client_photo" : "?", 
    "gender" : "?", 
    "date_registered" : "?", 
    "password" : "?", 
    "admin_id" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End client_accounts inputs array --//

  
  //--- Begin  client_invoices inputs array ---// 
  const InputsArr = {

    "invoice_no" : "?", 
    "account_name" : "?", 
    "tel_no" : "?", 
    "email" : "?", 
    "client_names" : "?", 
    "invoice_date" : "?", 
    "item_name" : "?", 
    "quantity" : "?", 
    "amount" : "?", 
    "tax_rate" : "?", 
    "amount_paid" : "?", 
    "payment_mode" : "?", 
    "payment_ref" : "?", 
    "invoice_remark" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End client_invoices inputs array --//

  
  //--- Begin  clients inputs array ---// 
  const InputsArr = {

    "name" : "?", 
    "email" : "?", 
    "tel" : "?", 
    "login_password" : "?", 
    "ref_id" : "?", 
    "regdate" : "?", 
    "user_no" : "?", 
    "user_pic" : "?", 
    "user_gender" : "?", 
    "last_seen" : "?", 
    "city" : "?", 
    "town" : "?", 
    "client_type" : "?", 
    "about" : "?", 
    "active_state" : "?", 
    "expiry_date" : "?", 
    "group_name" : "?", 
    "team_id" : "?", 
    "last_follow_up_date" : "?", 
    "follow_up_state" : "?", 
    "package_id" : "?", 
    "package_name" : "?", 
    "package_price" : "?", 
    "last_sync" : "?", 
    "online_status" : "?", 
    "online_class" : "?", 
    "uptime" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End clients inputs array --//

  
  //--- Begin  daily_leads inputs array ---// 
  const InputsArr = {

    "lead_date" : "?", 
    "lead_location" : "?", 
    "apartment_name" : "?", 
    "client_name" : "?", 
    "client_tel" : "?", 
    "followup_date" : "?", 
    "remark" : "?", 
    "lead_potential" : "?", 
    "team_id" : "?", 
    "lead_ref" : "?", 
    "followup_type" : "?", 
    "lead_state" : "?", 
    "account_name" : "?", 
    "date_signed_up" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End daily_leads inputs array --//

  
  //--- Begin  daily_leads_followups inputs array ---// 
  const InputsArr = {

    "followup_date" : "?", 
    "followup_type" : "?", 
    "account_name" : "?", 
    "client_name" : "?", 
    "client_tel" : "?", 
    "remark" : "?", 
    "lead_location" : "?", 
    "apartment_name" : "?", 
    "lead_potential" : "?", 
    "lead_state" : "?", 
    "team_id" : "?", 
    "lead_ref" : "?", 
    "lead_date" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End daily_leads_followups inputs array --//

  
  //--- Begin  data_flow inputs array ---// 
  const InputsArr = {

    "entry_date" : "?", 
    "sequence_name" : "?", 
    "sequence_id" : "?", 
    "item_name" : "?", 
    "item_id" : "?", 
    "sequence_required" : "?", 
    "sequence_number" : "?", 
    "log_message" : "?", 
    "parent_event" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End data_flow inputs array --//

  
  //--- Begin  data_sequence_monitor inputs array ---// 
  const InputsArr = {

    "parent_event" : "?", 
    "sequence_name" : "?", 
    "sequence_number" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End data_sequence_monitor inputs array --//

  
  //--- Begin  direct_income inputs array ---// 
  const InputsArr = {

    "reference_no" : "?", 
    "debit_account" : "?", 
    "credit_account" : "?", 
    "client_id" : "?", 
    "received_from" : "?", 
    "deposit_date" : "?", 
    "amount" : "?", 
    "transaction_remark" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End direct_income inputs array --//

  
  //--- Begin  employees inputs array ---// 
  const InputsArr = {

    "name" : "?", 
    "email" : "?", 
    "tel" : "?", 
    "login_password" : "?", 
    "position" : "?", 
    "employment_date" : "?", 
    "staff_number" : "?", 
    "user_pic" : "?", 
    "user_gender" : "?", 
    "department" : "?", 
    "job_group" : "?", 
    "about" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End employees inputs array --//

  
  //--- Begin  event_log inputs array ---// 
  const InputsArr = {

    "event_link" : "?", 
    "event_type" : "?", 
    "event_date" : "?", 
    "event_descr" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End event_log inputs array --//

  
  //--- Begin  expenses inputs array ---// 
  const InputsArr = {

    "receipt_id" : "?", 
    "debit_account" : "?", 
    "credit_account" : "?", 
    "expense_date" : "?", 
    "amount" : "?", 
    "expense_notes" : "?", 
    "account_subcategory" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End expenses inputs array --//

  
  //--- Begin  faq_table inputs array ---// 
  const InputsArr = {

    "faq_subject" : "?", 
    "faq_details" : "?", 
    "faq_tag" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End faq_table inputs array --//

  
  //--- Begin  growth_tracker inputs array ---// 
  const InputsArr = {

    "objective" : "?", 
    "goal_value" : "?", 
    "goal_type" : "?", 
    "goal_status" : "?", 
    "duration" : "?", 
    "goal_date" : "?", 
    "goal_month" : "?", 
    "objective_plan" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End growth_tracker inputs array --//

  
  //--- Begin  internet_packages inputs array ---// 
  const InputsArr = {

    "plan_name" : "?", 
    "description" : "?", 
    "package_data_rate" : "?", 
    "onexpiry_service" : "?", 
    "package_amount" : "?", 
    "package_duration" : "?", 
    "package_type" : "?", 
    "download_rate" : "?", 
    "upload_rate" : "?", 
    "package_code" : "?", 
    "local_address" : "?", 
    "remote_address" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End internet_packages inputs array --//

  
  //--- Begin  inventory_history inputs array ---// 
  const InputsArr = {

    "item_id" : "?", 
    "item_name" : "?", 
    "stock_type" : "?", 
    "quantity" : "?", 
    "purchase_price" : "?", 
    "selling_price" : "?", 
    "authorised_by" : "?", 
    "supplier" : "?", 
    "remark" : "?", 
    "inventory_date" : "?", 
    "invoice_id" : "?", 
    "invoice_edit_key" : "?", 
    "transfer_type" : "?", 
    "staff_id" : "?", 
    "price_invoice" : "?", 
    "inventory_item" : "?", 
    "client_id" : "?", 
    "client_name" : "?", 
    "item_location" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End inventory_history inputs array --//

  
  //--- Begin  inventory_list inputs array ---// 
  const InputsArr = {

    "item_no" : "?", 
    "name" : "?", 
    "buying_price" : "?", 
    "selling_price" : "?", 
    "stock_date" : "?", 
    "supplier" : "?", 
    "remark" : "?", 
    "description" : "?", 
    "recorded_by" : "?", 
    "stock_type" : "?", 
    "invoice_edit_key" : "?", 
    "invoice_id" : "?", 
    "user_pic" : "?", 
    "stock_level_alert" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End inventory_list inputs array --//

  
  //--- Begin  job_groups inputs array ---// 
  const InputsArr = {

    "group_name" : "?", 
    "group_salary" : "?", 
    "description" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End job_groups inputs array --//

  
  //--- Begin  ledger_accounts inputs array ---// 
  const InputsArr = {

    "account_number" : "?", 
    "account_name" : "?", 
    "account_type" : "?", 
    "cashbook_category" : "?", 
    "document_link" : "?", 
    "details" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End ledger_accounts inputs array --//

  
  //--- Begin  letterhead_settings inputs array ---// 
  const InputsArr = {

    "company_name" : "?", 
    "company_logo" : "?", 
    "tel" : "?", 
    "email" : "?", 
    "website" : "?", 
    "remark" : "?", 
    "location" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End letterhead_settings inputs array --//

  
  //--- Begin  messaging inputs array ---// 
  const InputsArr = {

    "receiver_contacts" : "?", 
    "reciver_names" : "?", 
    "message_type" : "?", 
    "site_id" : "?", 
    "group_name" : "?", 
    "message_date" : "?", 
    "sent_state" : "?", 
    "msg_read_state" : "?", 
    "subject" : "?", 
    "message_label" : "?", 
    "about" : "?", 
    "sms_cost" : "?", 
    "page_count" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 
    "custom_dictionary" : "?", 
    "message_signature" : "?", 

  };

  //--- End messaging inputs array --//

  
  //--- Begin  mosy_sql_roll_back inputs array ---// 
  const InputsArr = {

    "table_name" : "?", 
    "roll_type" : "?", 
    "where_str" : "?", 
    "roll_timestamp" : "?", 
    "value_entries" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End mosy_sql_roll_back inputs array --//

  
  //--- Begin  mosycomms_array inputs array ---// 
  const InputsArr = {

    "receiver_contacts" : "?", 
    "reciver_names" : "?", 
    "message_type" : "?", 
    "site_id" : "?", 
    "group_name" : "?", 
    "message_date" : "?", 
    "sent_state" : "?", 
    "msg_read_state" : "?", 
    "subject" : "?", 
    "message_label" : "?", 
    "message" : "?", 
    "delvery_receipt" : "?", 
    "sms_cost" : "?", 
    "page_count" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End mosycomms_array inputs array --//

  
  //--- Begin  mosycomms_settings inputs array ---// 
  const InputsArr = {

    "company_name" : "?", 
    "company_email" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End mosycomms_settings inputs array --//

  
  //--- Begin  page_manifest_ inputs array ---// 
  const InputsArr = {

    "page_group" : "?", 
    "site_id" : "?", 
    "page_url" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 
    "project_id" : "?", 
    "project_name" : "?", 

  };

  //--- End page_manifest_ inputs array --//

  
  //--- Begin  payroll_list inputs array ---// 
  const InputsArr = {

    "payroll_month_year" : "?", 
    "payroll_date" : "?", 
    "staff_id" : "?", 
    "job_group" : "?", 
    "basicsalary" : "?", 
    "bonus_and_commissions" : "?", 
    "deductions" : "?", 
    "net_salary" : "?", 
    "payroll_number" : "?", 
    "payroll_notes" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End payroll_list inputs array --//

  
  //--- Begin  petty_cash inputs array ---// 
  const InputsArr = {

    "request_date" : "?", 
    "team_id" : "?", 
    "amount" : "?", 
    "reason_for_request" : "?", 
    "vendor" : "?", 
    "approved_date" : "?", 
    "approval_status" : "?", 
    "payment_date" : "?", 
    "ref_no" : "?", 
    "payment_remark" : "?", 
    "admin_remark" : "?", 
    "approved_by" : "?", 
    "requested_by" : "?", 
    "request_remark" : "?", 
    "amount_paid" : "?", 
    "receipt_file" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End petty_cash inputs array --//

  
  //--- Begin  pety_cash_post inputs array ---// 
  const InputsArr = {

    "amount_posted" : "?", 
    "posted_by" : "?", 
    "date_posted" : "?", 
    "posting_remark" : "?", 
    "admin_name" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End pety_cash_post inputs array --//

  
  //--- Begin  phonebook inputs array ---// 
  const InputsArr = {

    "name" : "?", 
    "email" : "?", 
    "tel" : "?", 
    "profile_photo" : "?", 
    "username" : "?", 
    "site_id" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End phonebook inputs array --//

  
  //--- Begin  reconciliations inputs array ---// 
  const InputsArr = {

    "trx_id" : "?", 
    "trx_date" : "?", 
    "trx_month_year" : "?", 
    "trx_remark" : "?", 
    "amount" : "?", 
    "trx_type" : "?", 
    "business_id" : "?", 
    "client_id" : "?", 
    "admin_id" : "?", 
    "TransactionType" : "?", 
    "BusinessShortCode" : "?", 
    "BillRefNumber" : "?", 
    "InvoiceNumber" : "?", 
    "OrgAccountBalance" : "?", 
    "ThirdPartyTransID" : "?", 
    "MSISDN" : "?", 
    "FirstName" : "?", 
    "MiddleName" : "?", 
    "LastName" : "?", 
    "trx_msg" : "?", 
    "account_id" : "?", 
    "used_status" : "?", 
    "filter_date" : "?", 
    "flag_state" : "?", 
    "reconciled" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End reconciliations inputs array --//

  
  //--- Begin  requisition_items inputs array ---// 
  const InputsArr = {

    "invoice_id" : "?", 
    "item_id" : "?", 
    "item_name" : "?", 
    "quantity" : "?", 
    "rate" : "?", 
    "tax" : "?", 
    "discount" : "?", 
    "date_created" : "?", 
    "account_context" : "?", 
    "account_name" : "?", 
    "item_key" : "?", 
    "stock_type" : "?", 
    "invoice_edit_key" : "?", 
    "selling_price" : "?", 
    "sale_state" : "?", 
    "remaining_qty" : "?", 
    "add_to_stock" : "?", 
    "item_remark" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End requisition_items inputs array --//

  
  //--- Begin  requisitions inputs array ---// 
  const InputsArr = {

    "invoice_no" : "?", 
    "date_created" : "?", 
    "date_due" : "?", 
    "paid_status" : "?", 
    "created_by" : "?", 
    "name" : "?", 
    "invoice_stage" : "?", 
    "remark" : "?", 
    "client_id" : "?", 
    "paid_on" : "?", 
    "supplier_id" : "?", 
    "invoice_type" : "?", 
    "account_affect" : "?", 
    "inv_no_int" : "?", 
    "invoice_key" : "?", 
    "client_name" : "?", 
    "client_tel" : "?", 
    "client_email" : "?", 
    "requested_by" : "?", 
    "approval_status" : "?", 
    "amount_paid" : "?", 
    "payment_ref" : "?", 
    "payment_date" : "?", 
    "receipt_file" : "?", 
    "vendor" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End requisitions inputs array --//

  
  //--- Begin  sales_history inputs array ---// 
  const InputsArr = {

    "item_id" : "?", 
    "sales_date" : "?", 
    "qty_sold" : "?", 
    "remark" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End sales_history inputs array --//

  
  //--- Begin  send_list inputs array ---// 
  const InputsArr = {

    "send_list_name" : "?", 
    "site_id" : "?", 
    "contact_id" : "?", 
    "contact_names" : "?", 
    "mobile" : "?", 
    "email" : "?", 
    "ref_no" : "?", 
    "group_name" : "?", 
    "date_created" : "?", 
    "description" : "?", 
    "active_state" : "?", 
    "service_id" : "?", 
    "service_name" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 
    "entry_context" : "?", 

  };

  //--- End send_list inputs array --//

  
  //--- Begin  system_files inputs array ---// 
  const InputsArr = {

    "item_id" : "?", 
    "file_url" : "?", 
    "file_type" : "?", 
    "ref_id" : "?", 
    "upload_date" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End system_files inputs array --//

  
  //--- Begin  system_role_bundles inputs array ---// 
  const InputsArr = {

    "bundle_id" : "?", 
    "bundle_name" : "?", 
    "remark" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End system_role_bundles inputs array --//

  
  //--- Begin  system_users inputs array ---// 
  const InputsArr = {

    "user_id" : "?", 
    "name" : "?", 
    "email" : "?", 
    "tel" : "?", 
    "ref_id" : "?", 
    "regdate" : "?", 
    "user_no" : "?", 
    "user_pic" : "?", 
    "user_gender" : "?", 
    "last_seen" : "?", 
    "about" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 
    "auth_token" : "?", 
    "token_status" : "?", 
    "token_expiring_in" : "?", 
    "project_id" : "?", 
    "project_name" : "?", 

  };

  //--- End system_users inputs array --//

  
  //--- Begin  team_target inputs array ---// 
  const InputsArr = {

    "target_name" : "?", 
    "target_value" : "?", 
    "target_type" : "?", 
    "remark" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End team_target inputs array --//

  
  //--- Begin  team_tbl inputs array ---// 
  const InputsArr = {

    "name" : "?", 
    "email" : "?", 
    "tel" : "?", 
    "login_password" : "?", 
    "signup_date" : "?", 
    "account_no" : "?", 
    "user_pic" : "?", 
    "gender" : "?", 
    "last_seen" : "?", 
    "about" : "?", 
    "sales_target" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End team_tbl inputs array --//

  
  //--- Begin  tickets inputs array ---// 
  const InputsArr = {

    "ticket_date" : "?", 
    "subject" : "?", 
    "ticket_id" : "?", 
    "user_name" : "?", 
    "tickect_details" : "?", 
    "agent_id" : "?", 
    "ticket_state" : "?", 
    "thread_id" : "?", 
    "last_seen" : "?", 
    "sender" : "?", 
    "receiver" : "?", 
    "transffered" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End tickets inputs array --//

  
  //--- Begin  transactions inputs array ---// 
  const InputsArr = {

    "trx_id" : "?", 
    "trx_date" : "?", 
    "trx_month_year" : "?", 
    "trx_remark" : "?", 
    "amount" : "?", 
    "trx_type" : "?", 
    "business_id" : "?", 
    "client_id" : "?", 
    "admin_id" : "?", 
    "TransactionType" : "?", 
    "BusinessShortCode" : "?", 
    "BillRefNumber" : "?", 
    "InvoiceNumber" : "?", 
    "OrgAccountBalance" : "?", 
    "ThirdPartyTransID" : "?", 
    "MSISDN" : "?", 
    "FirstName" : "?", 
    "MiddleName" : "?", 
    "LastName" : "?", 
    "trx_msg" : "?", 
    "account_id" : "?", 
    "used_status" : "?", 
    "filter_date" : "?", 
    "flag_state" : "?", 
    "reconciled" : "?", 
    "site_id" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End transactions inputs array --//

  
  //--- Begin  user_bundle_role_functions inputs array ---// 
  const InputsArr = {

    "bundle_id" : "?", 
    "bundle_name" : "?", 
    "role_id" : "?", 
    "role_name" : "?", 
    "remark" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End user_bundle_role_functions inputs array --//

  
  //--- Begin  user_manifest_ inputs array ---// 
  const InputsArr = {

    "user_id" : "?", 
    "user_name" : "?", 
    "role_id" : "?", 
    "site_id" : "?", 
    "role_name" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 
    "project_id" : "?", 
    "project_name" : "?", 

  };

  //--- End user_manifest_ inputs array --//

  
  //--- Begin  ux_table inputs array ---// 
  const InputsArr = {

    "ux_key" : "?", 
    "ux_value" : "?", 
    "ux_type" : "?", 
    "ux_state" : "?", 
    "remark" : "?", 
    "hive_site_id" : "?", 
    "hive_site_name" : "?", 

  };

  //--- End ux_table inputs array --//

    //mutate requested values
    const mutatedDataArray =mutateInputArray('ux_table',InputsArr, Request, newId, authData)

    if (FormAction === "add_ux_table") 
    {
      
      mutatedDataArray. = newId;
      
      // Insert into table 
      const result = await Add(newId, mutatedDataArray, body, authData);     

       

      return Response.json({
        status: 'success',
        message: result.message,
        ux_table_uptoken: result.record_id
      });
      
    }
    
    if (FormAction === "update_ux_table") {
      
      // update table 
      const result = await Update(newId, mutatedDataArray, body, authData, `='${ux_table_uptoken_value}'`)

      

      return Response.json({
        status: 'success',
        message: result.message,
        ux_table_uptoken: ux_table_uptoken_value
      });
    }    

    // Optional: catch unrecognized actions
    return Response.json({
      status: 'error',
      message: `Invalid action: ${FormAction}`
    }, { status: 400 });

  } catch (err) {
    console.error(`Request failed:`, err);
    return Response.json(
      { status: 'error', 
      message: `Data Post error ${err.message}` },
      { status: 500 }
    );
  }
}