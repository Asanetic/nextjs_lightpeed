//====BACKEND====
import {
  mosyQuickSel,
  mosySumRows,
  mosySqlInsert
} from "../../apiUtils/dataControl/dataUtils";

export async function sendRentInvoiceSms({ auth, payload }) {
  const normalizedPhone = await normalizePhoneNumber(payload.recipient);
  const tenant = await loadTenantByPhone(normalizedPhone);

  if (!tenant) {
    return respond({
      status: "error",
      message: "Tenant not found"
    });
  }

  const currentMonth = await resolveCurrentMonth();
  const isDuplicate = await checkDuplicateInvoiceNotification(
    tenant,
    currentMonth
  );

  await rentInvoiceDecision(isDuplicate, tenant, currentMonth);

  return respond({
    status: isDuplicate ? "duplicate" : "success",
    tenant_name: tenant.full_name,
    phone_number: normalizedPhone,
    month: currentMonth,
    balance: isDuplicate ? 0 : tenant.balance,
    sms_sent: !isDuplicate
  });
}

//====BACKEND HELPERS====
export async function normalizePhoneNumber(recipient) {
  let phone = recipient.trim();
  if (phone.startsWith("0")) {
    phone = "254" + phone.slice(1);
  }
  return phone;
}

export async function loadTenantByPhone(phone) {
  return await mosyQuickSel(
    "tenants",
    `WHERE phone='${phone}' LIMIT 1`,
    "r"
  );
}

export async function resolveCurrentMonth() {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, "0");
  return `${y}-${m}`;
}

export async function checkDuplicateInvoiceNotification(tenant, month) {
  const rows = await mosyQuickSel(
    "notifications",
    `WHERE tenant_id='${tenant.record_id}'
     AND ref_month='${month}'
     AND type='rent_invoice' LIMIT 1`,
    "l"
  );
  return rows.length > 0;
}

export async function rentInvoiceDecision(isDuplicate, tenant, month) {
  if (isDuplicate === true) {
    return;
  }

  const rentDue = await mosySumRows(
    "rent_charges",
    "amount",
    `WHERE tenant_id='${tenant.record_id}'
     AND charge_month='${month}'`
  );

  const payments = await mosySumRows(
    "rent_payments",
    "amount",
    `WHERE tenant_id='${tenant.record_id}'
     AND payment_month='${month}'`
  );

  const balance = rentDue - payments;
  tenant.balance = balance;

  const message = await buildInvoiceSmsMessage(
    tenant,
    month,
    balance
  );

  await sendAsanetSms(tenant.phone, message);

  await logInvoiceNotification(tenant, month, balance);
}

export async function buildInvoiceSmsMessage(tenant, month, balance) {
  return `Dear ${tenant.full_name}, your rent balance for ${month} is KES ${balance}. Please pay promptly.`;
}

export async function sendAsanetSms(phone, message) {
  const smsRequest =
    "pushsms&recp=" +
    encodeURIComponent(phone) +
    "&body=" +
    encodeURIComponent(message);

  try {
    const res = await fetch("https://asanetic.com/sms/sendsms", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: smsRequest
    });

    if (!res.ok) {
      throw new Error("SMS API call failed");
    }
    
    console.log(`sms requesttttttttt`, res)

    // Asanet returns HTTP 200 on accepted request
    return {
      status: "sent",
      recipient: phone,
      message
    };

  } catch (err) {
    console.error("[ASANET SMS ERROR]", err.message);

    return {
      status: "error",
      message: "SMS API request error"
    };
  }
}


export async function logInvoiceNotification(tenant, month, balance) {
  await mosySqlInsert(
    "notifications",
    {
      tenant_id: tenant.record_id,
      ref_month: month,
      type: "rent_invoice",
      amount: balance
    },
    {}
  );
}

export function respond(data) {
  return data;
}
