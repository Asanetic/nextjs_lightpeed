//===BACKEND : RENEWAL / PAYMENT ACTIVATION ===
import {
    mosyQuickSel,
    mosySqlUpdate,
    mosySqlInsert
  } from "../../../apiUtils/dataControl/dataUtils";
  
  //===BACKEND : RENEWAL / PAYMENT ACTIVATION ===

  import { sendAsanetSms } from "../beLogics";

  export async function activateAccountAfterPayment({ auth, payload }) {
    const {
      accountAppRef,
      amountPaid,
      refNo,
      paymentDate,
      remark
    } = payload;
  
    // 1️⃣ Parse ACCID#APPID
    const [accountId, appId] = accountAppRef.split("#");
    if (!accountId || !appId) {
      throw new Error("Invalid account reference format");
    }
  
    // 2️⃣ Load account app
    const accountApp = await loadAccountApp(accountId, appId);
  
    // 3️⃣ Load plan
    const plan = await loadPlan(accountApp.plan_id);
  
    // 4️⃣ Load billing account (customer info)
    const billingAccount = await loadBillingAccount(accountId);
  
    // 5️⃣ Load app name
    const app = await loadApp(appId);

    // 6️⃣ Check if payment is sufficient (USING ACCOUNT_APPS AMOUNT)
    if (amountPaid < accountApp.plan_amount) {
        await notifyTopUpRequired(
        billingAccount.account_tel,
        billingAccount.account_name,
        accountApp.plan_name,
        amountPaid,
        accountApp.plan_amount,
        app.app_name
        );
    
        return respond({
        status: "pending_topup",
        message: "Insufficient amount. Top-up required.",
        data: {
            account_id: accountId,
            app_id: appId,
            service: accountApp.plan_name,
            required_amount: accountApp.plan_amount,
            paid_amount: amountPaid,
            balance: accountApp.plan_amount - amountPaid
        }
        });
    }
  
  
    // 6️⃣ Calculate expiry (early / expired / partial payment)
    const { newExpiry, appliedDays } = calculateExpiryWithAmount(
      accountApp.expiry_date,
      plan.plan_period,
      accountApp.plan_amount,
      amountPaid
    );
  
    // 7️⃣ Update account_apps
    await mosySqlUpdate(
      "account_apps",
      {
        status: "active",
        expiry_date: newExpiry
      },
      {},
      `primkey='${accountApp.primkey}'`
    );
  
    // 8️⃣ Log billing transaction (SCHEMA-CORRECT)
    await mosySqlInsert(
      "billing_transactions",
      {
        trxkey: `${accountId}_${appId}_${refNo}`,
        account_id: accountId,
        app_id: appId,
        amount: amountPaid,
        trx_id: refNo,
        trx_date: paymentDate,
        trx_remark: remark,
  
        hive_site_id: auth.hive_site_id,
        hive_site_name: auth.hive_site_name
      },
      {}
    );
  
    // 9️⃣ Send renewal SMS
    await sendAsanetSms(
      billingAccount.account_tel,
      buildRenewalMessage(
        billingAccount.account_name,
        plan.plan_name,
        newExpiry,
        app.app_name
      )
    );
  
    return respond({
      status: "success",
      data: {
        account_id: accountId,
        app_id: appId,
        plan_name: plan.plan_name,
        expiry_date: newExpiry,
        paid_amount: amountPaid,
        applied_days: appliedDays
      }
    });
  }
  
  /* ---------------- LOADERS ---------------- */
  
  async function loadAccountApp(accountId, appId) {
    const rows = await mosyQuickSel(
      "account_apps",
      `WHERE account_id='${accountId}' AND app_id='${appId}'`
    );
    if (!rows.length) throw new Error("Account service not found");
    return rows[0];
  }
  
  async function loadPlan(planId) {
    const rows = await mosyQuickSel(
      "plans",
      `WHERE plan_id='${planId}'`
    );
    if (!rows.length) throw new Error("Plan not found");
    return rows[0];
  }
  
  async function loadBillingAccount(accountId) {
    const rows = await mosyQuickSel(
      "billing_account",
      `WHERE record_id='${accountId}'`
    );
    if (!rows.length) throw new Error("Billing account not found");
    return rows[0];
  }
  
  async function loadApp(appId) {
    const rows = await mosyQuickSel(
      "app_list",
      `WHERE app_id='${appId}'`
    );
    if (!rows.length) throw new Error("App not found");
    return rows[0];
  }
  
  /* ---------------- CORE LOGIC ---------------- */
  
  function calculateExpiryWithAmount(currentExpiry, planDays, planAmount, paid) {
    const today = new Date();
    const expiry = new Date(currentExpiry);
    const startDate = expiry < today ? today : expiry;
  
    const ratio = Math.min(1, paid / planAmount);
    const appliedDays = Math.max(1, Math.floor(planDays * ratio));
  
    startDate.setDate(startDate.getDate() + appliedDays);
  
    return {
      newExpiry: startDate.toISOString().split("T")[0],
      appliedDays
    };
  }
  
  function buildRenewalMessage(customerName, serviceName, expiryDate, appName) {
    return (
`Hello ${customerName}, 
Your ${serviceName} subscription has been successfully renewed. 
Your next expiry date is ${expiryDate}.
Thank you for choosing ${appName} — we are happy to have you with us.`
    );
  }
  
  function respond(response) {
    return response;
  }
  
  async function notifyTopUpRequired(
    phone,
    customerName,
    serviceName,
    paidAmount,
    requiredAmount,
    appName
  ) {
    if (!phone) return true;
  
    const balance = requiredAmount - paidAmount;
  
    const message =
`Hello ${customerName},
To activate your ${serviceName} service, please top up ${balance}.
Once completed, your service will be activated immediately.
Amount paid  ${paidAmount} 
Thank you for choosing ${appName}.`;
  
    await sendAsanetSms(phone, message);
  
    return true;
  }
  