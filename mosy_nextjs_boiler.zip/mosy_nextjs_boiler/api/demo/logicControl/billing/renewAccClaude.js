//====BACKEND====
import { 
    mosyQddata, 
    mosySqlUpdate, 
    mosySqlInsert, 
    magicRandomStr 
  } from '../../../apiUtils/dataControl/dataUtils';
  import { sendAsanetSms } from "../beLogics";
  
  export async function renewAccountBackend({ auth, payload }) {
    
    const accountApp = await loadAccountApp(payload.accountAppRef);
    
    if (!accountApp) {
      return {
        status: "error",
        message: "Account not found"
      };
    }
  
    const plan = await loadPlan(payload.planId);
    
    if (!plan) {
      return {
        status: "error",
        message: "Plan not found"
      };
    }
  
    const billingAccount = await loadBillingAccount(accountApp.account_id);
    
    if (!billingAccount) {
      return {
        status: "error",
        message: "Billing account not found"
      };
    }
  
    const app = await loadApp(accountApp.app_id);
  
    const newExpiryDate = calculateNewExpiryDate(accountApp.expiry_date, plan.plan_period);
  
    await updateAccountAppExpiry(payload.accountAppRef, newExpiryDate, plan);
  
    await logBillingTransaction({
      accountId: accountApp.account_id,
      planAmount: plan.plan_amount,
      planName: plan.plan_name,
      auth
    });
  
    await sendRenewalAcknowledgementSMS({
      phone: billingAccount.account_tel,
      accountName: billingAccount.account_name,
      appName: app?.app_name || "Our Service",
      newExpiryDate
    });
  
    return {
      status: "success",
      message: "Account renewed successfully",
      data: {
        new_expiry_date: newExpiryDate,
        plan_name: plan.plan_name
      }
    };
  }
  
  // Helper: Load account app by record_id
  async function loadAccountApp(accountAppRef) {
    const accountApp = await mosyQddata("account_apps", "record_id", accountAppRef);
    
    if (!accountApp) {
      throw new Error("Account app not found");
    }
    
    return accountApp;
  }
  
  // Helper: Load plan by plan_id
  async function loadPlan(planId) {
    const plan = await mosyQddata("plans", "plan_id", planId);
    
    if (!plan) {
      throw new Error("Plan not found");
    }
    
    return plan;
  }
  
  // Helper: Load billing account by record_id
  async function loadBillingAccount(accountId) {
    const billingAccount = await mosyQddata("billing_account", "record_id", accountId);
    
    return billingAccount;
  }
  
  // Helper: Load app by app_id
  async function loadApp(appId) {
    const app = await mosyQddata("app_list", "app_id", appId);
    
    return app;
  }
  
  // Helper: Calculate new expiry date based on plan period
  function calculateNewExpiryDate(currentExpiry, planPeriod) {
    const now = new Date();
    const currentExpiryDate = new Date(currentExpiry);
    
    // Use whichever is later: current expiry or now
    const baseDate = currentExpiryDate > now ? currentExpiryDate : now;
    
    // Parse plan period (e.g., "30" for 30 days, "monthly", "yearly")
    let daysToAdd = 30; // default
    
    if (!isNaN(parseInt(planPeriod))) {
      daysToAdd = parseInt(planPeriod);
    } else if (planPeriod === "monthly") {
      daysToAdd = 30;
    } else if (planPeriod === "yearly") {
      daysToAdd = 365;
    } else if (planPeriod === "weekly") {
      daysToAdd = 7;
    }
    
    const newExpiry = new Date(baseDate);
    newExpiry.setDate(newExpiry.getDate() + daysToAdd);
    
    // Format as YYYY-MM-DD HH:MM:SS
    const year = newExpiry.getFullYear();
    const month = String(newExpiry.getMonth() + 1).padStart(2, '0');
    const day = String(newExpiry.getDate()).padStart(2, '0');
    const hours = String(newExpiry.getHours()).padStart(2, '0');
    const minutes = String(newExpiry.getMinutes()).padStart(2, '0');
    const seconds = String(newExpiry.getSeconds()).padStart(2, '0');
    
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  }
  
  // Helper: Update account app with new expiry and plan details
  async function updateAccountAppExpiry(accountAppRef, newExpiryDate, plan) {
    const updateFields = {
      expiry_date: newExpiryDate,
      plan_id: plan.plan_id,
      plan_name: plan.plan_name,
      plan_amount: plan.plan_amount,
      plan_type: plan.plan_type,
      plan_period: plan.plan_period,
      status: "active",
      updated_at: new Date().toISOString().slice(0, 19).replace('T', ' ')
    };
    
    await mosySqlUpdate(
      "account_apps",
      updateFields,
      {},
      `record_id = '${accountAppRef}'`
    );
    
    return true;
  }
  
  // Helper: Log billing transaction for audit
  async function logBillingTransaction({ accountId, planAmount, planName, auth }) {
    const now = new Date();
    const trxDate = now.toISOString().slice(0, 19).replace('T', ' ');
    const trxMonthYear = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    
    const transactionData = {
      trxkey: magicRandomStr(12),
      trx_id: magicRandomStr(10),
      trx_date: trxDate,
      trx_month_year: trxMonthYear,
      trx_remark: `Account renewal - ${planName}`,
      amount: planAmount,
      trx_type: "renewal",
      account_id: accountId,
      used_status: "used",
      filter_date: trxDate.split(' ')[0],
      hive_site_id: auth.hive_site_id,
      hive_site_name: auth.hive_site_name
    };
    
    await mosySqlInsert("billing_transactions", transactionData, {});
    
    return true;
  }
  
  // Helper: Send renewal acknowledgement SMS to user
  async function sendRenewalAcknowledgementSMS({ phone, accountName, appName, newExpiryDate }) {
    const formattedExpiry = formatExpiryDateForSMS(newExpiryDate);
    
    const message = `Hello ${accountName}, your ${appName} subscription has been activated. Your next expiry is ${formattedExpiry}. Thank you for choosing ${appName}, we are happy to have you with us.`;
    
    await sendAsanetSms(phone, message);
    
    return true;
  }
  
  // Helper: Format expiry date for SMS display
  function formatExpiryDateForSMS(expiryDate) {
    const date = new Date(expiryDate);
    const day = date.getDate();
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const month = monthNames[date.getMonth()];
    const year = date.getFullYear();
    
    return `${day} ${month} ${year}`;
  }