//===BACKEND===
import {
    mosySqlInsert,
    mosySqlUpdate,
    mosyQuickSel
  } from "../../../apiUtils/dataControl/dataUtils";
  
  import { sendAsanetSms } from "../beLogics";
  
  /**
   * Sync a single account app/service.
   * - If not existing → allocate TRIAL + notify user via SMS
   * - If existing → sync expiry vs status
   */
  export async function syncAccountApp({ auth, payload }) {
    const accountApp = await loadAccountApp(
      payload.accountId,
      payload.appId
    );
  
    // 🆕 Allocate TRIAL if missing
    if (!accountApp) {
      const trialPlan = await loadTrialPlan(payload.appId);
      const billingAccount = await loadBillingAccount(payload.accountId);
      const app = await loadApp(trialPlan.app_id);
  
      const created = await allocateTrialApp(
        payload.accountId,
        payload.appId,
        trialPlan,
        auth
      );
  
      await notifyServiceActivated(
        billingAccount.account_tel,
        billingAccount.account_name,
        trialPlan.plan_name,
        created.expiry_date,
        app.app_name
      );
  
      return respond({
        status: "success",
        data: created
      });
    }
  
    // 🔁 Sync existing record
    const synced = await syncAccountAppStatus(accountApp);
  
    return respond({
      status: "success",
      data: synced
    });
  }
  
  /**
   * Load account ↔ app subscription
   */
  export async function loadAccountApp(accountId, appId) {
    const rows = await mosyQuickSel(
      "account_apps",
      `WHERE account_id='${accountId}' AND app_id='${appId}'`
    );
  
    return rows && rows.length ? rows[0] : null;
  }
  
  /**
   * Load billing account (for phone & name)
   */
  export async function loadBillingAccount(accountId) {
    const rows = await mosyQuickSel(
      "billing_account",
      `WHERE record_id='${accountId}'`
    );
  
    if (!rows || rows.length === 0) {
      throw new Error("Billing account not found");
    }
  
    return rows[0];
  }
  
  /**
   * Load app (for app name)
   */
  export async function loadApp(appId) {
    const rows = await mosyQuickSel(
      "app_list",
      `WHERE app_id='${appId}'`
    );
  
    if (!rows || rows.length === 0) {
      throw new Error("App not found");
    }
  
    return rows[0];
  }
  
  /**
   * Load active TRIAL plan for an app
   */
  export async function loadTrialPlan(appId) {
    const rows = await mosyQuickSel(
      "plans",
      `WHERE app_id='${appId}'
       AND plan_type='trial'
       AND active_status='active'`
    );
  
    if (!rows || rows.length === 0) {
      throw new Error("No active trial plan found for app");
    }
  
    return rows[0];
  }
  
  /**
   * Allocate trial plan into account_apps (MULTI-TENANT SAFE)
   */
  export async function allocateTrialApp(
    accountId,
    appId,
    plan,
    auth
  ) {
    const expiry = new Date();
    expiry.setDate(expiry.getDate() + parseInt(plan.plan_period));
  
    const insert = await mosySqlInsert(
      "account_apps",
      {
        record_id: `${accountId}_${appId}`,
        account_id: accountId,
        app_id: appId,
        plan_id: plan.plan_id,
        plan_name: plan.plan_name,
        plan_amount: plan.plan_amount,
        currency: plan.currency,
        plan_type: plan.plan_type,
        plan_period: plan.plan_period,
        status: "active",
        expiry_date: expiry.toISOString().split("T")[0],
  
        // 🔐 MULTI-TENANT LAW
        hive_site_id: auth.hive_site_id,
        hive_site_name: auth.hive_site_name
      },
      {}
    );
  
    return {
      primkey: insert.record_id,
      account_id: accountId,
      app_id: appId,
      plan_id: plan.plan_id,
      plan_name: plan.plan_name,
      plan_type: "trial",
      status: "active",
      expiry_date: expiry.toISOString().split("T")[0]
    };
  }
  
  /**
   * Sync expiry vs stored status
   */
  export async function syncAccountAppStatus(accountApp) {
    const now = new Date();
    const expiryDate = new Date(accountApp.expiry_date);
  
    if (accountApp.status === "active" && expiryDate < now) {
      await mosySqlUpdate(
        "account_apps",
        { status: "expired" },
        {},
        `primkey='${accountApp.primkey}'`
      );
  
      accountApp.status = "expired";
    }
  
    return accountApp;
  }
  
  /**
   * Notify user when service is activated
   */
  export async function notifyServiceActivated(
    phone,
    customerName,
    serviceName,
    expiryDate,
    appName
  ) {
    if (!phone) return true;
  
    const message =
      `Hello ${customerName}, ` +
      `Your ${serviceName} service has been activated. ` +
      `Next expiry: ${expiryDate}. ` +
      `Thank you for choosing ${appName}.`;
  
    await sendAsanetSms(phone, message);
  
    return true;
  }
  
  /**
   * Final response
   */
  export async function respond(response) {
    return response;
  }
  