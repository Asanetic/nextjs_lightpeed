
/**
 * AUTO-GENERATED BATCH MUTATIONS
 * DO NOT EDIT MANUALLY
 */

export const SystemmodulemanifestBatchMutations = {

};

export const listSystemmodulemanifestMutationKeys = {

};

export default listSystemmodulemanifestMutationKeys;
