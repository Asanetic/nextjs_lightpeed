
import { mosySqlDelete  , mosySqlInsert , mosySqlUpdate } from "../../../apiUtils/dataControl/dataUtils";

//insert ux_table 
export async function Add(newId, mutatedDataArray, body, authData)
{

  const result = await mosySqlInsert("ux_table", mutatedDataArray, body);
   
  return result;
}


//update ux_table 
export async function Update(newId, mutatedDataArray, body, authData, whereStr)
{

  const result = await mosySqlUpdate("ux_table", mutatedDataArray, body, whereStr);
  
  return result;
}


//delete ux_table 
export async function Delete(tokenId, whereStr)
{  
  const result = await mosySqlDelete("ux_table", whereStr);

  return result;
}

