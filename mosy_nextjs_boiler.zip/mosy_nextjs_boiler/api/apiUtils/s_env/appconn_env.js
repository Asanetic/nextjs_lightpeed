
const mosyDbConfig = {
  local: {
    DB_HOST: 'localhost',
    DB_USER: 'root',
    DB_PASS: '',
    // DB_NAME: 'ticksy',
    // DB_NAME: 'octaneorbit',
    //DB_NAME: 'nextpos',
    DB_NAME: 'simukopav1',
    dateStrings: true
  },
  production: {
    DB_HOST: '127.0.0.1',
    DB_USER: 'nextadmin',
    DB_PASS: 'UltraSecurePass123!',
    DB_NAME: 'ticksy',
    dateStrings: true

  }
};

export default mosyDbConfig; 