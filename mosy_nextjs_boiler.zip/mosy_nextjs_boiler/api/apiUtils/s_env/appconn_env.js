
const mosyDbConfig = {
  local: {
    DB_HOST: 'localhost',
    DB_USER: 'root',
    DB_PASS: '',
    DB_NAME: 'guardian',
    dateStrings: true
  },
  production: {
    DB_HOST: '127.0.0.1',
    DB_USER: 'root',
    DB_PASS: 'yourprodpassword',
    DB_NAME: 'bloomcrm',
    dateStrings: true

  }
};

export default mosyDbConfig; 