
const mosyDbConfig = {
  local: {
    DB_HOST: 'localhost',
    DB_USER: 'root',
    DB_PASS: '',
    DB_NAME: 'revuiov2',
  },
  production: {
    DB_HOST: '127.0.0.1',
    DB_USER: 'root',
    DB_PASS: 'revu@2025',
    DB_NAME: 'revuio',
  }
};

export default mosyDbConfig; 