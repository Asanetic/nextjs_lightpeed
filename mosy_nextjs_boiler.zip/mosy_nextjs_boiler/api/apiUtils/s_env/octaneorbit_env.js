
const mosyDbConfig = {
  local: {
    DB_HOST: 'localhost',
    DB_USER: 'root',
    DB_PASS: '',
    DB_NAME: 'octaneorbit',
  },
  production: {
    DB_HOST: '127.0.0.1',
    DB_USER: 'octaneorbit',
    DB_PASS: 'octaneorbit',
    DB_NAME: 'octaneorbit',
  }
};

export default mosyDbConfig; 