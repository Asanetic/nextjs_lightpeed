
const mosyDbConfig = {
  local: {
    DB_HOST: 'localhost',
    DB_USER: 'root',
    DB_PASS: '',
    DB_NAME: 'revuiov2',
  },
  production: {
    DB_HOST: 'prod.db.sedco.org',
    DB_USER: 'admin_sedco',
    DB_PASS: 'supersecurepass123',
    DB_NAME: 'mosy_live',
  }
};

export default mosyDbConfig; 