
//pass listSmsmessagesRowMutationsKeys to mosy select 

const listSmsmessagesRowMutationsKeys = {
delivery_receipt : [],
};

export default listSmsmessagesRowMutationsKeys;

