
//pass listFarmersRowMutationsKeys to mosy select 

const listFarmersRowMutationsKeys = {

};

export default listFarmersRowMutationsKeys;

