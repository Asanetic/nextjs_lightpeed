
//pass listMilkcollectionsRowMutationsKeys to mosy select 

const listMilkcollectionsRowMutationsKeys = {
_farmers_farmer_name_farmer_id : [],
_graders_grader_name_grader_id : [],
sms_mosy_action : [],sms_uptoken : [],collection_ref : [],generated_sms : [],
};

export default listMilkcollectionsRowMutationsKeys;

