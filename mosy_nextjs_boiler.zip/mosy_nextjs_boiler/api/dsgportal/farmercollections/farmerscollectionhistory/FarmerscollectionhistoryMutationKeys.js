
//pass listFarmerscollectionhistoryRowMutationsKeys to mosy select 

const listFarmerscollectionhistoryRowMutationsKeys = {
collection_history : [],
};

export default listFarmerscollectionhistoryRowMutationsKeys;

