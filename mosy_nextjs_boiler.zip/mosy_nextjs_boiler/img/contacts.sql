-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2026 at 08:17 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `imsv1`
--

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE IF NOT EXISTS `contacts` (
  `primkey` int(11) NOT NULL,
  `contact_id` varchar(100) NOT NULL,
  `contact_name` varchar(255) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `phone_number` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `type` varchar(50) DEFAULT 'lead',
  `status` varchar(50) DEFAULT 'active',
  `source` varchar(100) DEFAULT NULL,
  `notes` text,
  `reg_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `hive_site_id` varchar(500) NOT NULL,
  `hive_site_name` varchar(500) NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `industry` varchar(255) DEFAULT NULL,
  `rating` varchar(255) DEFAULT NULL,
  `reviews` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`primkey`, `contact_id`, `contact_name`, `company_name`, `phone_number`, `email`, `type`, `status`, `source`, `notes`, `reg_date`, `hive_site_id`, `hive_site_name`, `logo`, `industry`, `rating`, `reviews`) VALUES
(1, '6B1H6VC', 'San diego', 'Asanetic digital', '0710766390', 'jereasanya@gmail.com', 'isp', 'active', '', '', '2026-08-22 07:33:00', 'LLRR0ZKOXRTCOHN_2024-12-28-07-45-56-pm', 'Superadmin', NULL, NULL, NULL, NULL),
(2, 'EN95HGO', 'Shapeskills foundation', 'Asanetic digital', '0710766390', 'jereasanya@gmail.com', '', '', '', '', '2026-08-23 08:33:00', 'LLRR0ZKOXRTCOHN_2024-12-28-07-45-56-pm', 'Superadmin', NULL, NULL, NULL, NULL),
(3, 'T01L77U', 'Shapeskills foundation', 'Asanetic digital', '0710766390', 'jereasanya@gmail.com', '', '', '', '', '2026-08-23 08:33:00', 'LLRR0ZKOXRTCOHN_2024-12-28-07-45-56-pm', 'Superadmin', NULL, NULL, NULL, NULL),
(4, 'MOU56FA6R5', 'Kenya institute of finance and applied management', 'Kenya institute of finance and applied management', '020 8098825', '', 'College', 'New', 'Google Maps', NULL, '2026-09-09 18:04:05', 'LLRR0ZKOXRTCOHN_2024-12-28-07-45-56-pm', 'Superadmin', NULL, NULL, NULL, NULL),
(5, 'X0NJWLYTQJ', 'Kenya institute of finance and applied management', 'Kenya institute of finance and applied management', '020 8098825', '', 'College', 'New', 'Google Maps', NULL, '2026-09-09 18:04:05', 'LLRR0ZKOXRTCOHN_2024-12-28-07-45-56-pm', 'Superadmin', NULL, NULL, NULL, NULL),
(6, 'XHSEFZQE2B', 'Westford International Training Centre', 'Westford International Training Centre', '0718 336285', '', 'College', 'New', 'Google Maps', NULL, '2026-09-09 18:04:05', 'LLRR0ZKOXRTCOHN_2024-12-28-07-45-56-pm', 'Superadmin', NULL, NULL, NULL, NULL),
(7, 'M4PSDD1T4J', 'Westford International Training Centre', 'Westford International Training Centre', '0718 336285', '', 'College', 'New', 'Google Maps', NULL, '2026-09-09 18:04:05', 'LLRR0ZKOXRTCOHN_2024-12-28-07-45-56-pm', 'Superadmin', NULL, NULL, NULL, NULL),
(8, 'XEDNU83SLS', 'Westford International Training Centre', 'Westford International Training Centre', '0718 336285', '', 'College', 'New', 'Google Maps', NULL, '2026-09-09 18:04:05', 'LLRR0ZKOXRTCOHN_2024-12-28-07-45-56-pm', 'Superadmin', NULL, NULL, NULL, NULL),
(9, 'BFJXA1YU94', 'Computer Pride Training College', 'Computer Pride Training College', '', '', 'University', 'New', 'Google Maps', NULL, '2026-09-09 18:04:05', 'LLRR0ZKOXRTCOHN_2024-12-28-07-45-56-pm', 'Superadmin', NULL, NULL, NULL, NULL),
(10, '5JIITKG3M3', 'Computer Pride Training College', 'Computer Pride Training College', '', '', 'University', 'New', 'Google Maps', NULL, '2026-09-09 18:04:06', 'LLRR0ZKOXRTCOHN_2024-12-28-07-45-56-pm', 'Superadmin', NULL, NULL, NULL, NULL),
(11, 'W8F7UZLZQT', 'Zetech University', 'Zetech University', '0706 622557', '', 'College', 'New', 'Google Maps', NULL, '2026-09-09 18:04:06', 'LLRR0ZKOXRTCOHN_2024-12-28-07-45-56-pm', 'Superadmin', NULL, NULL, NULL, NULL),
(12, 'MHF4PWB0QO', 'Zetech University', 'Zetech University', '0706 622557', '', 'College', 'New', 'Google Maps', NULL, '2026-09-09 18:04:06', 'LLRR0ZKOXRTCOHN_2024-12-28-07-45-56-pm', 'Superadmin', NULL, NULL, NULL, NULL),
(13, 'R93DEAMI3W', 'Zetech University', 'Zetech University', '0706 622557', '', 'College', 'New', 'Google Maps', '', '2026-09-09 18:04:06', 'LLRR0ZKOXRTCOHN_2024-12-28-07-45-56-pm', 'Superadmin', 'media/contacts/1789041937528_amara.jpg', 'Real Estate', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`primkey`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `primkey` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
