-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2026 at 06:00 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cora`
--

-- --------------------------------------------------------

--
-- Table structure for table `advert_agents`
--

CREATE TABLE IF NOT EXISTS `advert_agents` (
  `primkey` int(255) NOT NULL,
  `record_id` varchar(500) NOT NULL,
  `agent_name` varchar(500) NOT NULL,
  `platform` varchar(500) NOT NULL,
  `agent_lastseen` varchar(500) NOT NULL,
  `current_task` varchar(500) NOT NULL,
  `config_info` longtext NOT NULL,
  `hive_site_id` varchar(500) NOT NULL,
  `hive_site_name` varchar(500) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `advert_agents`
--

INSERT INTO `advert_agents` (`primkey`, `record_id`, `agent_name`, `platform`, `agent_lastseen`, `current_task`, `config_info`, `hive_site_id`, `hive_site_name`) VALUES
(1, '32651884-44', 'Asanetic digital -facebook', 'Facebook classic', '01-01-2020 07:13 PM', 'idle', ' [\r\n    {\r\n        "domain": ".facebook.com",\r\n        "expirationDate": 1785652286.695658,\r\n        "hostOnly": false,\r\n        "httpOnly": false,\r\n        "name": "c_user",\r\n        "path": "/",\r\n        "sameSite": "no_restriction",\r\n        "secure": true,\r\n        "session": false,\r\n        "storeId": "0",\r\n        "value": "100003134371797",\r\n        "id": 1\r\n    },\r\n    {\r\n        "domain": ".facebook.com",\r\n        "expirationDate": 1787735953.13957,\r\n        "hostOnly": false,\r\n        "httpOnly": true,\r\n        "name": "datr",\r\n        "path": "/",\r\n        "sameSite": "no_restriction",\r\n        "secure": true,\r\n        "session": false,\r\n        "storeId": "0",\r\n        "value": "jVd_aJEIEWe1PEfLDzjsI1Iw",\r\n        "id": 2\r\n    },\r\n    {\r\n        "domain": ".facebook.com",\r\n        "expirationDate": 1754721606,\r\n        "hostOnly": false,\r\n        "httpOnly": false,\r\n        "name": "dpr",\r\n        "path": "/",\r\n        "sameSite": "no_restriction",\r\n        "secure": true,\r\n        "session": false,\r\n        "storeId": "0",\r\n        "value": "0.800000011920929",\r\n        "id": 3\r\n    },\r\n    {\r\n        "domain": ".facebook.com",\r\n        "expirationDate": 1761892286.695873,\r\n        "hostOnly": false,\r\n        "httpOnly": true,\r\n        "name": "fr",\r\n        "path": "/",\r\n        "sameSite": "no_restriction",\r\n        "secure": true,\r\n        "session": false,\r\n        "storeId": "0",\r\n        "value": "1v8ZfODaSJI83MVUm.AWfik1lNYEbzGkMVqbbyezpj2ZmD6fzYbTfFZmwBPSqu_Q3NBFk.BojbC5..AAA.0.0.BojbC5.AWeiYoaMmfnf-L0lJaASZ2vzRWM",\r\n        "id": 4\r\n    },\r\n    {\r\n        "domain": ".facebook.com",\r\n        "expirationDate": 1785652805.943523,\r\n        "hostOnly": false,\r\n        "httpOnly": false,\r\n        "name": "i_user",\r\n        "path": "/",\r\n        "sameSite": "no_restriction",\r\n        "secure": true,\r\n        "session": false,\r\n        "storeId": "0",\r\n        "value": "100064200486190",\r\n        "id": 5\r\n    },\r\n    {\r\n        "domain": ".facebook.com",\r\n        "expirationDate": 1788676807.719394,\r\n        "hostOnly": false,\r\n        "httpOnly": true,\r\n        "name": "ps_l",\r\n        "path": "/",\r\n        "sameSite": "lax",\r\n        "secure": true,\r\n        "session": false,\r\n        "storeId": "0",\r\n        "value": "1",\r\n        "id": 6\r\n    },\r\n    {\r\n        "domain": ".facebook.com",\r\n        "expirationDate": 1788676807.719543,\r\n        "hostOnly": false,\r\n        "httpOnly": true,\r\n        "name": "ps_n",\r\n        "path": "/",\r\n        "sameSite": "no_restriction",\r\n        "secure": true,\r\n        "session": false,\r\n        "storeId": "0",\r\n        "value": "1",\r\n        "id": 7\r\n    },\r\n    {\r\n        "domain": ".facebook.com",\r\n        "expirationDate": 1787735953.139714,\r\n        "hostOnly": false,\r\n        "httpOnly": true,\r\n        "name": "sb",\r\n        "path": "/",\r\n        "sameSite": "no_restriction",\r\n        "secure": true,\r\n        "session": false,\r\n        "storeId": "0",\r\n        "value": "C2l5ZnnEjJrWG6dAap2TnYN0",\r\n        "id": 8\r\n    },\r\n    {\r\n        "domain": ".facebook.com",\r\n        "expirationDate": 1754721095,\r\n        "hostOnly": false,\r\n        "httpOnly": false,\r\n        "name": "wd",\r\n        "path": "/",\r\n        "sameSite": "lax",\r\n        "secure": true,\r\n        "session": false,\r\n        "storeId": "0",\r\n        "value": "1705x733",\r\n        "id": 9\r\n    },\r\n    {\r\n        "domain": ".facebook.com",\r\n        "expirationDate": 1785652286.696646,\r\n        "hostOnly": false,\r\n        "httpOnly": true,\r\n        "name": "xs",\r\n        "path": "/",\r\n        "sameSite": "no_restriction",\r\n        "secure": true,\r\n        "session": false,\r\n        "storeId": "0",\r\n        "value": "41%3AjOGUXk9AVSpQmg%3A2%3A1753175950%3A-1%3A-1%3A%3AAcVuQ5s2oN_EIf9g5-p8YByFgI7N9n3qiZqToNnacg",\r\n        "id": 10\r\n    }\r\n    ]', '', ''),
(3, 'FQD332U', 'Jeremiah Thewriter - facebook', 'Facebook classic', '01-01-2020 07:13 PM', 'idle', '[\r\n{\r\n    "domain": ".facebook.com",\r\n    "hostOnly": false,\r\n    "httpOnly": true,\r\n    "name": "ar_debug",\r\n    "path": "/",\r\n    "sameSite": "no_restriction",\r\n    "secure": true,\r\n    "session": true,\r\n    "storeId": "0",\r\n    "value": "1",\r\n    "id": 1\r\n},\r\n{\r\n    "domain": ".facebook.com",\r\n    "expirationDate": 1785659235.496147,\r\n    "hostOnly": false,\r\n    "httpOnly": false,\r\n    "name": "c_user",\r\n    "path": "/",\r\n    "sameSite": "no_restriction",\r\n    "secure": true,\r\n    "session": false,\r\n    "storeId": "0",\r\n    "value": "100003134371797",\r\n    "id": 2\r\n},\r\n{\r\n    "domain": ".facebook.com",\r\n    "expirationDate": 1787735953.13957,\r\n    "hostOnly": false,\r\n    "httpOnly": true,\r\n    "name": "datr",\r\n    "path": "/",\r\n    "sameSite": "no_restriction",\r\n    "secure": true,\r\n    "session": false,\r\n    "storeId": "0",\r\n    "value": "jVd_aJEIEWe1PEfLDzjsI1Iw",\r\n    "id": 3\r\n},\r\n{\r\n    "domain": ".facebook.com",\r\n    "expirationDate": 1754729512,\r\n    "hostOnly": false,\r\n    "httpOnly": false,\r\n    "name": "dpr",\r\n    "path": "/",\r\n    "sameSite": "no_restriction",\r\n    "secure": true,\r\n    "session": false,\r\n    "storeId": "0",\r\n    "value": "0.800000011920929",\r\n    "id": 4\r\n},\r\n{\r\n    "domain": ".facebook.com",\r\n    "expirationDate": 1761899235.496284,\r\n    "hostOnly": false,\r\n    "httpOnly": true,\r\n    "name": "fr",\r\n    "path": "/",\r\n    "sameSite": "no_restriction",\r\n    "secure": true,\r\n    "session": false,\r\n    "storeId": "0",\r\n    "value": "1Lc4KRl6QKEpIOTD1.AWfWiirMm9h_94-4NNLxxOeYHmHHmcl9HPlQtyqPxow8-OA6pxM.Bojcvi..AAA.0.0.Bojcvi.AWcgfA6lZx1j43JolnPq-rlshQc",\r\n    "id": 5\r\n},\r\n{\r\n    "domain": ".facebook.com",\r\n    "hostOnly": false,\r\n    "httpOnly": false,\r\n    "name": "presence",\r\n    "path": "/",\r\n    "sameSite": "unspecified",\r\n    "secure": true,\r\n    "session": true,\r\n    "storeId": "0",\r\n    "value": "C%7B%22t3%22%3A%5B%5D%2C%22utc3%22%3A1754124712998%2C%22v%22%3A1%7D",\r\n    "id": 6\r\n},\r\n{\r\n    "domain": ".facebook.com",\r\n    "expirationDate": 1788676807.719394,\r\n    "hostOnly": false,\r\n    "httpOnly": true,\r\n    "name": "ps_l",\r\n    "path": "/",\r\n    "sameSite": "lax",\r\n    "secure": true,\r\n    "session": false,\r\n    "storeId": "0",\r\n    "value": "1",\r\n    "id": 7\r\n},\r\n{\r\n    "domain": ".facebook.com",\r\n    "expirationDate": 1788676807.719543,\r\n    "hostOnly": false,\r\n    "httpOnly": true,\r\n    "name": "ps_n",\r\n    "path": "/",\r\n    "sameSite": "no_restriction",\r\n    "secure": true,\r\n    "session": false,\r\n    "storeId": "0",\r\n    "value": "1",\r\n    "id": 8\r\n},\r\n{\r\n    "domain": ".facebook.com",\r\n    "expirationDate": 1787735953.139714,\r\n    "hostOnly": false,\r\n    "httpOnly": true,\r\n    "name": "sb",\r\n    "path": "/",\r\n    "sameSite": "no_restriction",\r\n    "secure": true,\r\n    "session": false,\r\n    "storeId": "0",\r\n    "value": "C2l5ZnnEjJrWG6dAap2TnYN0",\r\n    "id": 9\r\n},\r\n{\r\n    "domain": ".facebook.com",\r\n    "expirationDate": 1754729512,\r\n    "hostOnly": false,\r\n    "httpOnly": false,\r\n    "name": "wd",\r\n    "path": "/",\r\n    "sameSite": "lax",\r\n    "secure": true,\r\n    "session": false,\r\n    "storeId": "0",\r\n    "value": "1705x733",\r\n    "id": 10\r\n},\r\n{\r\n    "domain": ".facebook.com",\r\n    "expirationDate": 1785659235.496345,\r\n    "hostOnly": false,\r\n    "httpOnly": true,\r\n    "name": "xs",\r\n    "path": "/",\r\n    "sameSite": "no_restriction",\r\n    "secure": true,\r\n    "session": false,\r\n    "storeId": "0",\r\n    "value": "41%3AjOGUXk9AVSpQmg%3A2%3A1753175950%3A-1%3A-1%3A%3AAcVV9LfqFPgPDkcxqeBXKGssVyLzV83YU6mmmrjhfw",\r\n    "id": 11\r\n}\r\n]', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `advert_agents`
--
ALTER TABLE `advert_agents`
  ADD PRIMARY KEY (`primkey`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `advert_agents`
--
ALTER TABLE `advert_agents`
  MODIFY `primkey` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
