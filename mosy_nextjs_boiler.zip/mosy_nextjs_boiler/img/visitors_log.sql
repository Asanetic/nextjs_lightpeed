-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2026 at 05:57 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cora`
--

-- --------------------------------------------------------

--
-- Table structure for table `visitors_log`
--

CREATE TABLE IF NOT EXISTS `visitors_log` (
  `primkey` int(255) NOT NULL,
  `record_id` varchar(500) NOT NULL,
  `visitdate` datetime NOT NULL,
  `asset` varchar(500) NOT NULL,
  `visitor_code` varchar(500) NOT NULL,
  `pagevisited` varchar(500) NOT NULL,
  `taskid` varchar(500) NOT NULL,
  `market_id` varchar(500) NOT NULL,
  `camp_id` varchar(500) NOT NULL,
  `sourcename` varchar(500) NOT NULL,
  `device` varchar(500) NOT NULL,
  `sourceurl` varchar(500) NOT NULL,
  `visitedurl` varchar(500) NOT NULL,
  `script_data` longtext NOT NULL,
  `url_data` longtext NOT NULL,
  `hive_site_id` varchar(500) NOT NULL,
  `hive_site_name` varchar(500) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `visitors_log`
--

INSERT INTO `visitors_log` (`primkey`, `record_id`, `visitdate`, `asset`, `visitor_code`, `pagevisited`, `taskid`, `market_id`, `camp_id`, `sourcename`, `device`, `sourceurl`, `visitedurl`, `script_data`, `url_data`, `hive_site_id`, `hive_site_name`) VALUES
(1, '2DRNJ5NNES', '2025-08-03 07:36:55', 'Ember Pro', 'Q36HDA0K0L', 'Iams :: App Login', 'N/A', 'N/A', 'N/A', 'localhost', 'Win32', '', 'http://localhost/iams/login', '{"coraasset":"Ember Pro"}', '{"title":"Iams :: App Login","url":"http://localhost/iams/login","referer":"http://localhost/iams/login","host":"localhost","visitorId":"Bethina_Zehe_1754190991596","timestamp":"2025-08-03T04:36:54.524Z","scriptData":{"coraasset":"Ember Pro"},"urlData":{},"userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0","deviceMemory":8,"platform":"Win32","language":"en-US"}', '', ''),
(2, '0JUVS0WETH', '2025-08-03 07:41:03', 'Ember Pro', 'Bethina_Zehe_1754190991596', 'Iams :: App Login', 'N/A', 'N/A', 'N/A', 'localhost', 'Win32', 'http://localhost/iams/resetpassword', 'http://localhost/iams/login', '{"coraasset":"Ember Pro"}', '{"title":"Iams :: App Login","url":"http://localhost/iams/login","referer":"http://localhost/iams/resetpassword","host":"localhost","visitorId":"Bethina_Zehe_1754190991596","timestamp":"2025-08-03T04:41:01.864Z","scriptData":{"coraasset":"Ember Pro"},"urlData":{},"userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0","deviceMemory":8,"platform":"Win32","language":"en-US"}', '', ''),
(3, 'A2W1SK38AH', '2025-08-03 07:43:02', 'Cora', 'Bethina_Zehe_1754190991596', 'Visitors Log', 'N/A', 'N/A', 'N/A', 'localhost', 'Win32', 'http://localhost:3000/corav2/visitors_log/list', 'http://localhost:3000/corav2/visitors_log/list', '{"coraasset":"Cora"}', '{"title":"Visitors Log","url":"http://localhost:3000/corav2/visitors_log/list","referer":"http://localhost:3000/corav2/visitors_log/list","host":"localhost","visitorId":"Bethina_Zehe_1754190991596","timestamp":"2025-08-03T04:43:00.285Z","scriptData":{"coraasset":"Cora"},"urlData":{},"userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0","deviceMemory":8,"platform":"Win32","language":"en-US"}', '', ''),
(4, 'LBKASCAJ94', '2025-08-03 07:43:07', 'Cora', 'Bethina_Zehe_1754190991596', 'Visitors Log', 'N/A', 'N/A', 'N/A', 'localhost', 'Win32', 'http://localhost:3000/corav2/visitors_log/list', 'http://localhost:3000/corav2/visitors_log/list', '{"coraasset":"Cora"}', '{"title":"Visitors Log","url":"http://localhost:3000/corav2/visitors_log/list","referer":"http://localhost:3000/corav2/visitors_log/list","host":"localhost","visitorId":"Bethina_Zehe_1754190991596","timestamp":"2025-08-03T04:43:07.471Z","scriptData":{"coraasset":"Cora"},"urlData":{},"userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0","deviceMemory":8,"platform":"Win32","language":"en-US"}', '', ''),
(5, 'BMJOXH1CPJ', '2025-08-03 07:43:48', 'Ember Pro', 'Bethina_Zehe_1754190991596', 'Iams :: App Login', '43kdkfldk', '3434', 'N/A', 'localhost', 'Win32', '', 'http://localhost/iams/login?ma=3434&tid=43kdkfldk', '{"coraasset":"Ember Pro"}', '{"title":"Iams :: App Login","url":"http://localhost/iams/login?ma=3434&tid=43kdkfldk","referer":"","host":"localhost","visitorId":"Bethina_Zehe_1754190991596","timestamp":"2025-08-03T04:43:47.853Z","scriptData":{"coraasset":"Ember Pro"},"urlData":{"ma":"3434","tid":"43kdkfldk"},"userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0","deviceMemory":8,"platform":"Win32","language":"en-US"}', '', ''),
(6, 'Y9DC0EMUZR', '2025-08-03 07:43:53', 'Cora', 'Bethina_Zehe_1754190991596', 'Visitors Log', 'N/A', 'N/A', 'N/A', 'localhost', 'Win32', 'http://localhost:3000/corav2/visitors_log/list', 'http://localhost:3000/corav2/visitors_log/list', '{"coraasset":"Cora"}', '{"title":"Visitors Log","url":"http://localhost:3000/corav2/visitors_log/list","referer":"http://localhost:3000/corav2/visitors_log/list","host":"localhost","visitorId":"Bethina_Zehe_1754190991596","timestamp":"2025-08-03T04:43:52.598Z","scriptData":{"coraasset":"Cora"},"urlData":{},"userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0","deviceMemory":8,"platform":"Win32","language":"en-US"}', '', ''),
(7, 'M5QFJVPBTQ', '2025-08-03 07:46:50', 'Cora', 'Bethina_Zehe_1754190991596', 'Visitors Log', 'N/A', 'N/A', 'N/A', 'localhost', 'Win32', 'http://localhost:3000/corav2/visitors_log/list', 'http://localhost:3000/corav2/visitors_log/list', '{"coraasset":"Cora"}', '{"title":"Visitors Log","url":"http://localhost:3000/corav2/visitors_log/list","referer":"http://localhost:3000/corav2/visitors_log/list","host":"localhost","visitorId":"Bethina_Zehe_1754190991596","timestamp":"2025-08-03T04:46:48.201Z","scriptData":{"coraasset":"Cora"},"urlData":{},"userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0","deviceMemory":8,"platform":"Win32","language":"en-US"}', '', ''),
(8, '4CQT8BX9CV', '2025-08-03 07:46:58', 'Cora', 'Bethina_Zehe_1754190991596', 'Post activity', 'N/A', 'N/A', 'N/A', 'localhost', 'Win32', 'http://localhost:3000/corav2/visitors_log/list', 'http://localhost:3000/corav2/advert_tasktray/list', '{"coraasset":"Cora"}', '{"title":"Post activity","url":"http://localhost:3000/corav2/advert_tasktray/list","referer":"http://localhost:3000/corav2/visitors_log/list","host":"localhost","visitorId":"Bethina_Zehe_1754190991596","timestamp":"2025-08-03T04:46:57.885Z","scriptData":{"coraasset":"Cora"},"urlData":{},"userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0","deviceMemory":8,"platform":"Win32","language":"en-US"}', '', ''),
(9, 'GGUGH89PRQ', '2025-08-03 07:47:28', 'Cora', 'Bethina_Zehe_1754190991596', 'Post activity', 'N/A', 'N/A', 'N/A', 'localhost', 'Win32', 'http://localhost:3000/corav2/visitors_log/list', 'http://localhost:3000/corav2/advert_tasktray/list', '{"coraasset":"Cora"}', '{"title":"Post activity","url":"http://localhost:3000/corav2/advert_tasktray/list","referer":"http://localhost:3000/corav2/visitors_log/list","host":"localhost","visitorId":"Bethina_Zehe_1754190991596","timestamp":"2025-08-03T04:47:28.258Z","scriptData":{"coraasset":"Cora"},"urlData":{},"userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0","deviceMemory":8,"platform":"Win32","language":"en-US"}', '', ''),
(10, 'V6B1AMRLZ4', '2025-08-03 07:47:33', 'Cora', 'Bethina_Zehe_1754190991596', 'Visitors Log', 'N/A', 'N/A', 'N/A', 'localhost', 'Win32', 'http://localhost:3000/corav2/advert_tasktray/list', 'http://localhost:3000/corav2/visitors_log/list', '{"coraasset":"Cora"}', '{"title":"Visitors Log","url":"http://localhost:3000/corav2/visitors_log/list","referer":"http://localhost:3000/corav2/advert_tasktray/list","host":"localhost","visitorId":"Bethina_Zehe_1754190991596","timestamp":"2025-08-03T04:47:32.853Z","scriptData":{"coraasset":"Cora"},"urlData":{},"userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0","deviceMemory":8,"platform":"Win32","language":"en-US"}', '', ''),
(11, 'P0KJYMFK3F', '2025-08-03 07:47:59', 'Cora', 'Bethina_Zehe_1754190991596', 'Post activity', 'N/A', 'N/A', 'N/A', 'localhost', 'Win32', 'http://localhost:3000/corav2/visitors_log/list', 'http://localhost:3000/corav2/advert_tasktray/list', '{"coraasset":"Cora"}', '{"title":"Post activity","url":"http://localhost:3000/corav2/advert_tasktray/list","referer":"http://localhost:3000/corav2/visitors_log/list","host":"localhost","visitorId":"Bethina_Zehe_1754190991596","timestamp":"2025-08-03T04:47:59.607Z","scriptData":{"coraasset":"Cora"},"urlData":{},"userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0","deviceMemory":8,"platform":"Win32","language":"en-US"}', '', ''),
(12, '9NLRKBE2H0', '2025-08-03 07:51:55', 'Cora', 'Bethina_Zehe_1754190991596', 'Visitors Log', 'N/A', 'N/A', 'N/A', 'localhost', 'Win32', 'http://localhost:3000/corav2/advert_tasktray/profile?advert_tasktray_uptoken=MTE5', 'http://localhost:3000/corav2/visitors_log/list', '{"coraasset":"Cora"}', '{"title":"Visitors Log","url":"http://localhost:3000/corav2/visitors_log/list","referer":"http://localhost:3000/corav2/advert_tasktray/profile?advert_tasktray_uptoken=MTE5","host":"localhost","visitorId":"Bethina_Zehe_1754190991596","timestamp":"2025-08-03T04:51:51.696Z","scriptData":{"coraasset":"Cora"},"urlData":{},"userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0","deviceMemory":8,"platform":"Win32","language":"en-US"}', '', ''),
(13, '617MG68XAZ', '2025-08-03 09:02:51', 'Cora', 'Trixi_Sanders_1754200966301', 'Visitors Log', 'N/A', 'N/A', 'N/A', 'localhost', 'Win32', 'http://localhost:3000/corav2/visitors_log/list', 'http://localhost:3000/corav2/visitors_log/list', '{"coraasset":"Cora"}', '{"title":"Visitors Log","url":"http://localhost:3000/corav2/visitors_log/list","referer":"http://localhost:3000/corav2/visitors_log/list","host":"localhost","visitorId":"Trixi_Sanders_1754200966301","timestamp":"2025-08-03T06:02:47.021Z","scriptData":{"coraasset":"Cora"},"urlData":{},"userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0","deviceMemory":8,"platform":"Win32","language":"en-US"}', '', ''),
(14, 'K1KPNHYQQ2', '2025-08-03 09:02:56', 'Cora', 'Trixi_Sanders_1754200966301', 'Visitors Log', 'N/A', 'N/A', 'N/A', 'localhost', 'Win32', 'http://localhost:3000/corav2/visitors_log/list', 'http://localhost:3000/corav2/visitors_log/list', '{"coraasset":"Cora"}', '{"title":"Visitors Log","url":"http://localhost:3000/corav2/visitors_log/list","referer":"http://localhost:3000/corav2/visitors_log/list","host":"localhost","visitorId":"Trixi_Sanders_1754200966301","timestamp":"2025-08-03T06:02:55.916Z","scriptData":{"coraasset":"Cora"},"urlData":{},"userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0","deviceMemory":8,"platform":"Win32","language":"en-US"}', '', ''),
(15, 'AYFTF16IRR', '2025-08-03 09:03:36', 'Cora', 'Trixi_Sanders_1754200966301', 'Visitors Log', 'N/A', 'N/A', 'N/A', 'localhost', 'Win32', 'http://localhost:3000/corav2/visitors_log/list?qvisitors_log_page=1', 'http://localhost:3000/corav2/visitors_log/list?qvisitors_log_page=1', '{"coraasset":"Cora"}', '{"title":"Visitors Log","url":"http://localhost:3000/corav2/visitors_log/list?qvisitors_log_page=1","referer":"http://localhost:3000/corav2/visitors_log/list?qvisitors_log_page=1","host":"localhost","visitorId":"Trixi_Sanders_1754200966301","timestamp":"2025-08-03T06:03:36.267Z","scriptData":{"coraasset":"Cora"},"urlData":{"qvisitors_log_page":"1"},"userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0","deviceMemory":8,"platform":"Win32","language":"en-US"}', '', ''),
(16, 'QLASXUERUQ', '2025-08-03 09:04:27', 'Cora', 'Trixi_Sanders_1754200966301', 'Visitors Log', 'N/A', 'N/A', 'N/A', 'localhost', 'Win32', 'http://localhost:3000/corav2/visitors_log/list?qvisitors_log_page=1&qvisitors_log=emVoZQ%3D%3D', 'http://localhost:3000/corav2/visitors_log/list?qvisitors_log_page=1&qvisitors_log=emVoZQ%3D%3D', '{"coraasset":"Cora"}', '{"title":"Visitors Log","url":"http://localhost:3000/corav2/visitors_log/list?qvisitors_log_page=1&qvisitors_log=emVoZQ%3D%3D","referer":"http://localhost:3000/corav2/visitors_log/list?qvisitors_log_page=1&qvisitors_log=emVoZQ%3D%3D","host":"localhost","visitorId":"Trixi_Sanders_1754200966301","timestamp":"2025-08-03T06:04:27.413Z","scriptData":{"coraasset":"Cora"},"urlData":{"qvisitors_log_page":"1","qvisitors_log":"emVoZQ=="},"userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0","deviceMemory":8,"platform":"Win32","language":"en-US"}', '', ''),
(17, 'PS39SCCXWT', '2025-08-03 11:47:46', 'Cora', 'Trixi_Sanders_1754200966301', 'Campaigns', 'N/A', 'N/A', 'N/A', 'localhost', 'Win32', 'http://localhost:3000/auth/splash', 'http://localhost:3000/corav2/campaigns/list', '{"coraasset":"Cora"}', '{"title":"Campaigns","url":"http://localhost:3000/corav2/campaigns/list","referer":"http://localhost:3000/auth/splash","host":"localhost","visitorId":"Trixi_Sanders_1754200966301","timestamp":"2025-08-03T08:47:41.159Z","scriptData":{"coraasset":"Cora"},"urlData":{},"userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0","deviceMemory":8,"platform":"Win32","language":"en-US"}', '', ''),
(18, 'KGJF0CKLTD', '2025-08-03 11:48:32', 'Cora', 'Trixi_Sanders_1754200966301', 'Post activity', 'N/A', 'N/A', 'N/A', 'localhost', 'Win32', 'http://localhost:3000/corav2/campaigns/profile?campaigns_uptoken=Mjc3', 'http://localhost:3000/corav2/advert_tasktray/list', '{"coraasset":"Cora"}', '{"title":"Post activity","url":"http://localhost:3000/corav2/advert_tasktray/list","referer":"http://localhost:3000/corav2/campaigns/profile?campaigns_uptoken=Mjc3","host":"localhost","visitorId":"Trixi_Sanders_1754200966301","timestamp":"2025-08-03T08:48:31.603Z","scriptData":{"coraasset":"Cora"},"urlData":{},"userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0","deviceMemory":8,"platform":"Win32","language":"en-US"}', '', ''),
(19, '43LLBRTMYY', '2025-08-03 11:48:41', 'Cora', 'Trixi_Sanders_1754200966301', 'Visitors Log', 'N/A', 'N/A', 'N/A', 'localhost', 'Win32', 'http://localhost:3000/corav2/advert_tasktray/list', 'http://localhost:3000/corav2/visitors_log/list', '{"coraasset":"Cora"}', '{"title":"Visitors Log","url":"http://localhost:3000/corav2/visitors_log/list","referer":"http://localhost:3000/corav2/advert_tasktray/list","host":"localhost","visitorId":"Trixi_Sanders_1754200966301","timestamp":"2025-08-03T08:48:40.650Z","scriptData":{"coraasset":"Cora"},"urlData":{},"userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0","deviceMemory":8,"platform":"Win32","language":"en-US"}', '', ''),
(20, 'JEPEJX23MZ', '2025-08-03 11:49:47', 'Cora', 'Trixi_Sanders_1754200966301', 'Visitors Log', 'N/A', 'N/A', 'N/A', 'localhost', 'Win32', 'http://localhost:3000/corav2/visitors_log/list?qvisitors_log=NjE2MTEwMTUzMDc0Mw%3D%3D', 'http://localhost:3000/corav2/visitors_log/list?qvisitors_log=NjE2MTEwMTUzMDc0Mw%3D%3D', '{"coraasset":"Cora"}', '{"title":"Visitors Log","url":"http://localhost:3000/corav2/visitors_log/list?qvisitors_log=NjE2MTEwMTUzMDc0Mw%3D%3D","referer":"http://localhost:3000/corav2/visitors_log/list?qvisitors_log=NjE2MTEwMTUzMDc0Mw%3D%3D","host":"localhost","visitorId":"Trixi_Sanders_1754200966301","timestamp":"2025-08-03T08:49:46.767Z","scriptData":{"coraasset":"Cora"},"urlData":{"qvisitors_log":"NjE2MTEwMTUzMDc0Mw=="},"userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 OPR/120.0.0.0","deviceMemory":8,"platform":"Win32","language":"en-US"}', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `visitors_log`
--
ALTER TABLE `visitors_log`
  ADD PRIMARY KEY (`primkey`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `visitors_log`
--
ALTER TABLE `visitors_log`
  MODIFY `primkey` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
