
// data_control/postFormData.js
export async function mosyPostFormData({ formId, url, method = 'POST', isMultipart = true }) {
  const form = document.getElementById(formId);
  if (!form) throw new Error(`Form with ID "${formId}" not found.`);

  const formData = new FormData(form);
  let body;
  let headers = {};

  // Check if there's any file input OR force multipart manually
  const containsFile = [...form.elements].some(
    (el) => el.type === 'file' && el.files.length > 0
  );

  const useMultipart = containsFile || isMultipart;

  if (useMultipart) {
    // Browser handles content-type header automatically with boundary
    body = formData;
  } else {
    const jsonData = {};
    formData.forEach((value, key) => {
      jsonData[key] = value;
    });
    body = JSON.stringify(jsonData);
    headers['Content-Type'] = 'application/json';
  }

  const res = await fetch(url, {
    method,
    headers,
    body,
  });

  const result = await res.json();

  if (!res.ok) {
    //throw new Error(result.message || 'Form submission failed');
    return res;
  }

  return result;
}




export async function mosyGetData({
  endpoint = '', // default endpoint
  params = {},                    // optional query params
  onError = (err) => console.error('MosyFetchError:', err),
}) {
  try {
    // Ensure params are URL-encoded correctly
    const query = new URLSearchParams(params).toString();
    const encodedUrlQuery = encodeURIComponent(query);

    const url = query ? `${endpoint}?${query}` : endpoint;

    console.log('Request URL:', url); // Log the final URL for debugging

    const res = await fetch(url);

    if (!res.ok) {
      //throw new Error(`Fetch failed with status ${res.status}`);
      return res;
    }

    const json = await res.json();

    if (json.status !== 'success') {
      //throw new Error(json.message || 'Unknown API error');
      return json
    }

    return json; // Contains data, page_count etc.
  } catch (err) {
    onError(err);
    return {
      status: 'error',
      message: err.message,
      data: [],
    };
  }
}


export function mosyHydrateFormData(responseObj, tblCallback = "") {
  console.log('Sent data to hydrate:', JSON.stringify(responseObj, null, 2));

  try {
    const dataObj = responseObj?.data?.[0];

    if (!dataObj) {
      console.warn("No data to hydrate.");
      return;
    }

    Object.entries(dataObj).forEach(([key, val]) => {
      const safeVal = val ?? ''; // avoid nulls

      mosy_push_data(`txt_${key}`, safeVal);
      mosy_push_data(`txt_${key}_disp`, safeVal);
      mosy_push_data(`txt_${key}_${tblCallback}_disp`, safeVal);
      mosy_push_data(`div_txt_${key}`, safeVal);
      mosy_push_data(`src_${key}`, safeVal);
      mosy_push_data(`href_${key}`, safeVal);
      mosy_push_data(`sel_${key}`, safeVal);
      mosy_push_data_class(`mosy_data_${key}`, safeVal);
    });
  } catch (error) {
    console.error("Hydration failed:", error);
  }
}




function mosy_push_data(id, value) {
  const el = document.getElementById(id);
  if (el) {
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT') {
      el.value = value;
    } else if (el.tagName === 'IMG') {
      el.src = value;
    } else if (el.tagName === 'A') {
      el.href = value;
    } else {
      el.innerText = value;
    }
  }
}

function mosy_push_data_class(className, value) {
  const elements = document.querySelectorAll(`.${className}`);
  elements.forEach((el) => {
    el.innerText = value;
  });
}

export function dayTime() {
  const hour = new Date().getHours();
  if (hour < 12) return 'Morning';
  if (hour < 18) return 'Afternoon';
  return 'Evening';
}

// ------------------------- begin generateRandomStr -------- //

export function magicRandomStr(length) {
  const characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  let randomString = '';
  const charactersLength = characters.length;

  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * charactersLength);
    randomString += characters[randomIndex];
  }

  return randomString;
}

// ------------------------- end generateRandomStr -------- //


// lib/utils/magic_basename.js
export function magicBasename(input = null) {
  let path = '';

  // If input is provided
  if (input) {
    if (input.includes('http')) {
      try {
        path = new URL(input).pathname;
      } catch {
        path = input;
      }
    } else {
      path = input;
    }
  }

  // If in browser (client-side), auto-detect from location
  else if (typeof window !== 'undefined' && window.location) {
    path = window.location.pathname;
  }

  const segments = path.split('/').filter(Boolean);
  return segments.pop() || '';
}


export function magicTrimText(text, length, stripIf = length) {
  try {
    const plainText = text.replace(/<[^>]+>/g, ''); // Strip HTML tags

    if (plainText.length > stripIf) {
      return plainText.substring(0, length) + '...';
    }

    return plainText;
  } catch (error) {
    //console.error('Error in magicTrimText:', error);
    return ''; // Return empty string or fallback text if needed
  }
}

export function mosySetCookie(name, value, days = 7) {
  const expires = new Date(Date.now() + days * 864e5).toUTCString();
  document.cookie = `${name}=${encodeURIComponent(value)}; expires=${expires}; path=/`;
}


export function mosyGetCookie(name) {
  if (typeof document === "undefined") return null;

  const value = document.cookie
    .split('; ')
    .find((row) => row.startsWith(name + '='))
    ?.split('=')[1];

  return value ? decodeURIComponent(value) : null;
}



export function mosyDeleteCookie(name) {
  document.cookie = `${name}=; Max-Age=0; path=/`;
}


export function mosyToday() {
  const now = new Date();
  return now.toISOString().split('T')[0]; // "YYYY-MM-DD"
}

export function mosyRightNow() {
  const now = new Date();
  const pad = (num) => String(num).padStart(2, '0');

  const year = now.getFullYear();
  const month = pad(now.getMonth() + 1);
  const day = pad(now.getDate());
  const hours = pad(now.getHours());
  const minutes = pad(now.getMinutes());
  const seconds = pad(now.getSeconds());

  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}


export function mosySetLSData(key, value) {
  if (typeof window !== "undefined") {
    localStorage.setItem(key, JSON.stringify(value));
  }
}

export function mosyGetLSData(key, fallback = null) {
  if (typeof window !== "undefined") {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : fallback;
  }
  return fallback;
}

export function mosyDeleteLSData(key) {
  if (typeof window !== "undefined") {
    localStorage.removeItem(key);
  }
}


export function mosyBtoa(str) {
  try {
    if (!str) return ""; // Handle null, undefined, or empty string
    if (typeof window !== "undefined") {
      return window.btoa(str);
    } else {
      return Buffer.from(str, 'utf-8').toString('base64');
    }
  } catch (err) {
    console.error("btoa failed:", err);
    return "";
  }
}

export function mosyAtob(encodedStr) {
  try {
    if (!encodedStr) return "";
    if (typeof window !== "undefined") {
      return window.atob(encodedStr);
    } else {
      return Buffer.from(encodedStr, 'base64').toString('utf-8');
    }
  } catch (err) {
    console.error("atob failed:", err);
    return "";
  }
}

