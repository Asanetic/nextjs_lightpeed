import {MosyCard, closeMosyCard } from '@/app/components/MosyCard';         

export function MosyAlertCard({
  icon = "bell",
  iconColor = "text-danger",
  message = "Are you sure?",
  yesLabel = "Yes",
  noLabel = "Cancel",
  onYes,
  onNo,
}) {
  function handleYes() {
    if (typeof onYes === "function") {
      onYes();
    }
    closeMosyCard(); // dismiss regardless
  }

  function handleNo() {
    if (typeof onNo === "function") {
      onNo();
    }
    closeMosyCard(); // dismiss regardless
  }

  return MosyCard(
    <div className="row col-md-12 justify-content-center">
      <div className="fancy-gradient-spinner" title="Warning">
        <i className={`fa fa-${icon} large_icon ${iconColor}`}></i>
      </div>
    </div>,
    <div className="text-center">
      <p className="mt-3">{message}</p>
      <div className="row col-md-12 justify-content-center mt-4 border-top border_set pt-3">
        <button
          className="btn btn-outline-primary ml-lg-4 col-lg-4 col-5"
          onClick={handleYes}
        >
          {yesLabel}
        </button>

        <div className="col-2"></div>

        <button
          className="btn btn-outline-primary col-lg-4 col-5"
          onClick={handleNo}
        >
          {noLabel}
        </button>
      </div>
    </div>
  );
}



export function MosyNotify({message = "Done!", icon="info-circle" , iconColor="text-info", duration = 5000}) {
  MosyCard(
    <div className="row col-md-12 justify-content-center">
      <div className="fancy-gradient-spinner" title="Warning">
        <i className={`fa fa-${icon} large_icon ${iconColor}`}></i>
      </div>
      <div className="text-center col-md-12 p-2">
      <p className="mt-3">{message}</p>
    </div>      
    </div> ,
    <div></div>, // no buttons
    true // not dismissable by click
  );

  setTimeout(() => {
    const container = document.getElementById("alert_box");
    if (container) container.innerHTML = ""; // close manually
  }, duration);
}


export function MosyConfirm({
    icon = "warning",
    iconColor = "text-danger",
    message = "Are you sure?",
    yesLabel = "Yes",
    noLabel = "Cancel",
    onYes = () => {},
    onNo = () => {}
  }) {
    MosyCard(
      <div className="text-center">
        <i className={`fa fa-${icon} ${iconColor} display-4`}></i>
        <p className="mt-3">{message}</p>
      </div>,
  
      <div className="text-center mt-4">
        <button className="btn btn-danger mx-2" onClick={() => { onYes(); closeMosyCard(); }}>
          {yesLabel}
        </button>
        <button className="btn btn-secondary mx-2" onClick={() => { onNo(); closeMosyCard(); }}>
          {noLabel}
        </button>
      </div>
    );
  }