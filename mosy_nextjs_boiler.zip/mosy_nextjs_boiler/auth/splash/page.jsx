
import mosyThemeConfigs from '../../appConfigs/mosy_theme';
import saAuthConfigs from '../features_config/saAuthConfigs'; 
import { mosyGetLSData } from '../../MosyUtils/hiveUtils';

import SplashScreen from './ui_control/SplashScreen';


export async function generateMetadata() {
  const appName = mosyThemeConfigs.mosyAppName || 'Mosy';
  
  return {
    title: `Loading :: ${appName}`,
    description: `${appName}`,
  };
}


export default function SplashScreenPage() {
  const firstName ="Jeremy";
  const appLogo = mosyThemeConfigs.mosyAppLogo;
  const appName = mosyThemeConfigs.mosyAppName;
  const afterSplashPage = saAuthConfigs.afterSplashPage;

  
  return (
    <SplashScreen
      firstName={firstName}
      appLogo={appLogo}
      appName={appName}
      afterSplashPage={afterSplashPage}
    />
  );
}
