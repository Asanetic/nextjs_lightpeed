
import mosyThemeConfigs from '../../appConfigs/mosy_theme';
import saAuthConfigs from '../features_config/saAuthConfigs'; 


import LoginForm from './ui_control/LoginForm';


export async function generateMetadata() {
  const appName = mosyThemeConfigs.mosyAppName || 'Mosy';
  
  return {
    title: `Login :: ${appName}`,
    description: `${appName}`,
  };
}


export default function AuthPage() {
  const loginBgImg =saAuthConfigs.loginBgImage;
  const appLogo = mosyThemeConfigs.mosyAppLogo;
  const appName = mosyThemeConfigs.mosyAppName;
  const showResetLink =saAuthConfigs.showResetLink;
  const changePasswordUrl = saAuthConfigs.changePasswordUrl;
  const showCreateAccount = saAuthConfigs.showCreateAccount;
  const registerUrl = saAuthConfigs.registerUrl;

  return (
    <LoginForm
      loginBgImg={loginBgImg}
      appLogo={appLogo}
      appName={appName}
      showResetLink={showResetLink}
      changePasswordUrl={changePasswordUrl}
      showCreateAccount={showCreateAccount}
      registerUrl={registerUrl}
    />
  );
}
