/** @type {import('next').NextConfig} */
// const nextConfig = {
//     basePath: '/dairy',      // tells Next.js this app lives under /dairy
//     assetPrefix: '/dairy',   // optional: ensures static assets load correctly
//     reactStrictMode: true
//   };
  
//   module.exports = nextConfig;
  
  