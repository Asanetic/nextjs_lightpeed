// app/layout.js

import appConfigs from './appConfigs/mosy_theme'; // Theme config
import './css/designer.css';
import MosyUiTheme from './css/mosy_ui.js';
import './css/fonts.css';
import './assets/css/font-awesome.min.css';
import './assets/css/feathericon.min.css';
import './assets/plugins/morris/morris.css';
import './assets/css/style.css';

export const metadata = {
  icons: {
    icon: '/logo.png',  // You can also use '/icon.png'
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link
          href="https://fonts.googleapis.com/css?family=Poppins:400,300"
          rel="stylesheet"
        />    
        <MosyUiTheme />

      </head>
      <body>{children}</body>
    </html>
  );
}
