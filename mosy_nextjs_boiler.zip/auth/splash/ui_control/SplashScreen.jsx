'use client'; // Only needed if using interactivity (e.g., hooks)

import React from 'react';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';


export default function SplashScreen(props) {
  const { firstName, appName, appLogo , afterSplashPage} = props;

  // Optional: simulate the `daytime()` PHP function
  function getDaytimeGreeting() {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  }

    
 const router = useRouter();

  useEffect(() => {
    const timer = setTimeout(() => {
      router.push(afterSplashPage); // ⬅️ Destination URL
    }, 3000); // 3000ms = 3 seconds

    return () => clearTimeout(timer); // Clean up if component unmounts early
  }, [router]);
  
  
  
  return (
    <main role="main" className="container-fluid skin_plasma" style={{ minHeight: '100vh' }}>
      <div className="row justify-content-center pl-1 pr-1 pt-lg-5">
        <h3 className="col-md-12 text-center pt-5 mt-5 padding_row">
          {getDaytimeGreeting()} {firstName?.split(' ')[0] || 'User'}
        </h3>
        <h5 className="col-md-12 text-center pt-4">
          Welcome to {appName}
        </h5>
        <h3 className="col-md-12 text-center">
          <img
            src={appLogo}
            className="pt-5 mt-lg-5 blink"
            style={{ width: '200px', height: 'auto' }}
            alt="App Logo"
          />
        </h3>
        <h3 className="col-md-12 text-center">Loading...</h3>
      </div>
    </main>
  );
}
