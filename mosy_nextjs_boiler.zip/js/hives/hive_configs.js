

  // Declare base URLs
  var mainBaseUrl = onlineBaseUrl;

  // Check if the hostname is "localhost" or "127.0.0.1"
  if (window.location.hostname === 'localhost') {
    mainBaseUrl = localBaseUrl;
  }

  // Routes object
  const hiveRoutes = {
    iptv: `${mainBaseUrl}/be/hiveapi.php`,
    smartsend: `${mainBaseUrl}/be/hiveapi.php`,
    superauth:`${mainBaseUrl}/be/hiveapi.php`,
    auth:`${mainBaseUrl}/be/hiveapi.php`,
    authapi:`${mainBaseUrl}/be/authapi.php`    
  };

  // Media roots object
  const mediaRoots = {
    iptv: `${mainBaseUrl}/be/`,
    auth: `${mainBaseUrl}/be/`,
  };

  const rootUrl = hiveRoutes.iptv;
  const mediaRoot = `${mainBaseUrl}/be`;
  
  var ajax_url = rootUrl;

  