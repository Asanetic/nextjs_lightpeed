
function mosy_list_render_(json_data, cols_, template_ui)
{
  // Regular expression to match {{}} placeholders
    var matches = template_ui.match(/{{(.*?)}}/g);

    // Array to store extracted words
    var extractedWords = "";

    // Loop through matches and extract the words inside {{}}
    matches.forEach(function(match) {
        // Remove {{ and }} from the matched string
        var extracted = match.substring(2, match.length - 2);
        // Push extracted word to the array
        extractedWords +=('{{'+extracted+'}}|');
    });

  var template_values = extractedWords
  var modified_template_values = template_values.slice(0, -1);
  
  var parse_serv_json=JSON.parse(json_data);
   
  var str_node = "";
    
  var re = new RegExp(modified_template_values, 'gi');

  for(datanode of parse_serv_json.data)
    {
      str_node+= template_ui.replace(re, function (node) {

        var datanode_val =  datanode[node.replace(/[{{}}]/g, "")];;

        return datanode_val;
      }); 
    }
  
  return str_node;
  
}

function mosy_ui_data_nodes(json_server_response, tbl_callback="") 
{
    
    ///alert(json_server_response);
    
    var json_decoded_str=JSON.parse(json_server_response).data[0];
    
    ///console.log("  initialize response -- "+json_decoded_str);
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) 
      {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("txt_"+keys[i]+"_"+tbl_callback+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          mosy_push_data_class("mosy_data_"+keys[i], val);
          
          // use val
      }
        
    }
    
function  mosy_paginate_api(server_resp, pagination_label, push_to, response_fun, _txt_payload,req_url="iptv")
{    
  var paginate_count=JSON.parse(server_resp);
 
  mosy_paginate_ui(paginate_count.page_count, push_to, _txt_payload, 1, req_url="iptv")
   
}


function mosy_paginate_ui(totalPages, push_to, payload_source, currentPage=1, req_url="iptv")
{
    ///alert("af -- "+currentPage+push_to)
    ///let currentPage = 1; // Current page number
    const maxPaginationButtons = 7; // Maximum number of pagination buttons to display
    const halfMaxPaginationButtons = Math.floor(maxPaginationButtons / 2); // Half of maximum number of pagination buttons
    
    // Calculate total number of pages
    ////const totalPages = Math.ceil(totalRecords / recordsPerPage);
  
      let linkHTML = `
          <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center">        
        `;
      // Generate "Previous" link
      if (currentPage > 1) {
        linkHTML += `<li class="page-item"><a class="page-link cpointer "   onclick="mosy_navigate_pagination(${currentPage - 1},'${push_to}', '${totalPages}', '${payload_source}', '${req_url}')"> << </a></li>`;
      } else {
        linkHTML += `<li class="page-item disabled"><a class="page-link cpointer "  > << </a></li>`;
      }

      // Generate "First" link
      if (currentPage > 1) {
        linkHTML += `<li class="page-item"><a class="page-link cpointer "   onclick="mosy_navigate_pagination(1,'${push_to}', '${totalPages}', '${payload_source}', '${req_url}')">First</a></li>`;
      } else {
        linkHTML += `<li class="page-item disabled"><a class="page-link cpointer "  >First</a></li>`;
      }      
      // Generate numbered links
      let startPage = 1;
      let endPage = totalPages;
      if (totalPages > maxPaginationButtons) {
        if (currentPage <= halfMaxPaginationButtons) {
          endPage = maxPaginationButtons;
        } else if (currentPage >= totalPages - halfMaxPaginationButtons) {
          startPage = totalPages - maxPaginationButtons + 1;
        } else {
          startPage = currentPage - halfMaxPaginationButtons;
          endPage = currentPage + halfMaxPaginationButtons;
        }
        if (startPage > 1) {
          linkHTML += `<li class="page-item"><a class="page-link cpointer "   onclick="mosy_navigate_pagination(${startPage - 1},'${push_to}', '${totalPages}', '${payload_source}', '${req_url}')">...</a></li>`;
        }
        for (let i = startPage; i <= endPage; i++) {
          if (i === currentPage) {
            linkHTML += `<li class="page-item active"><a class="page-link cpointer "  >${i}</a></li>`;
          } else {
            linkHTML += `<li class="page-item"><a class="page-link cpointer "   onclick="mosy_navigate_pagination(${i},'${push_to}', '${totalPages}', '${payload_source}', '${req_url}')">${i}</a></li>`;
          }
        }
        if (endPage < totalPages) {
          linkHTML += `<li class="page-item"><a class="page-link cpointer "   onclick="mosy_navigate_pagination(${endPage + 1},'${push_to}', '${totalPages}', '${payload_source}', '${req_url}')">...</a></li>`;
        }
      } else {
        for (let i = startPage; i <= endPage; i++) {
          if (i === currentPage) {
            linkHTML += `<li class="page-item active"><a class="page-link cpointer "  >${i}</a></li>`;
          } else {
            linkHTML += `<li class="page-item"><a class="page-link cpointer "   onclick="mosy_navigate_pagination(${i},'${push_to}', '${totalPages}', '${payload_source}', '${req_url}')">${i}</a></li>`;
          }
        }
      }

      // Generate "Last" link
      if (currentPage < totalPages) {
        linkHTML += `<li class="page-item"><a class="page-link cpointer "   onclick="mosy_navigate_pagination(${totalPages},'${push_to}', '${totalPages}', '${payload_source}', '${req_url}')">Last</a></li>`;
      } else {
        linkHTML += `<li class="page-item disabled"><a class="page-link cpointer "  >Last</a></li>`;
      }


      // Generate "Next" link
      if (currentPage < totalPages) {
        linkHTML += `<li class="page-item"><a class="page-link cpointer "   onclick="mosy_navigate_pagination(${currentPage + 1},'${push_to}', '${totalPages}', '${payload_source}', '${req_url}')"> >> </a></li>`;
      } else {
        linkHTML += `<li class="page-item disabled"><a class="page-link cpointer "  > >> </a></li>`;
      }
      linkHTML +=`</ul>
        </nav>`;

     push_html(push_to, linkHTML)

      return linkHTML;
    
}

function mosy_navigate_pagination(page, push_to, total_pages, payload_source, response_fun, req_url="iptv") 
{
   currentPage = page+1;
   
   ///alert(response_fun)
   
   var parse_serv_json=JSON.parse(get_newval(payload_source));

   var pagination_label = parse_serv_json.pagination_label;
      
   ////alert(payload_source+" -- "+parse_serv_json._payload)
   
   
   var paginate_payload = (parse_serv_json._payload).replace("l:"+pagination_label+":"+mosy_limit, "l:"+pagination_label+":"+mosy_limit+":"+page+"")


   var removed_regen_pagination =delete (parse_serv_json.response_attr)._payload_str;
   
   var response_function =(JSON.stringify(parse_serv_json.response_attr))
   
  ///alert(paginate_payload +" -- "+pagination_label)
  
  ////alert(response_function)
  
   ///push_newval(payload_source, paginate_payload)
   
   mosyajax_get(paginate_payload, response_function, req_url);
  
  mosy_paginate_ui(total_pages, push_to, payload_source, page)
  
}


//===============End Mosy queries-============
function mosy_msdn_event(event) {
  const target = event.target;
  const mosy_msdnElement = target.closest('.mosy_msdn');

  if (mosy_msdnElement) {
    const arguments = mosy_msdnElement.getAttribute('data-mosy_msdn');
    eval(arguments);
    event.stopPropagation(); // stop the event from propagating further up the tree
  }
}

// Add an onclick event listener to the parent element using event delegation
document.body.addEventListener('click', mosy_msdn_event);

// Define a function to handle the click event
function mosy_tup_event(event) {
  
  const target = event.target;
  if (target.classList.contains('mosy_tup')) {
    const arguments = target.getAttribute('data-mosy_tup');
    eval(arguments);    
    event.stopPropagation(); // stop the event from propagating further up the tree
  }
  
}

// Add an onkeyup event listener to the parent element using event delegation
document.body.addEventListener('keyup', mosy_tup_event);

var mosyajax_sql_url=ajax_url;
   //Ajax Manager
function mosyflex_sel(tbl, colstr, filter_col , cols, node_function_name, callback_function_string, ui_tag, pagination="", req_url="")
{
//alert(filter_col);
///alert(pagination);
//alert(req_url);
    
    var route_to = hiveRoutes[req_url];
    
    if(req_url=="")
    {
     route_to=ajax_url;
    }
    
    

    var clean_ui1=ui_tag.replace(/</g, "{{<}}");
    var clean_ui2=clean_ui1.replace(/>/g, "{{>}}");
    var clean_ui3=clean_ui2.replace(/onclick/g, "{{on click}}");
    var clean_ui4=clean_ui3.replace(/onkeyup/g, "{{on keyup}}");
    var clean_ui5=clean_ui4.replace(/onchange/g, "{{on change}}");
    var clean_ui=btoa(clean_ui5);
    
  	var pagination_token=1;
    var pagination_name=pagination;
    
    if(pagination.indexOf(":") >= 0)
  	{
      pagination_token_expl=pagination.split(":");
      pagination_token=pagination_token_expl[1];
      pagination_name=pagination_token_expl[0];
    }
    
  
    var json_params_str={"mosyajax_sql_data":btoa(filter_col), "colstr":btoa(colstr), "cols":btoa(cols), "node_function_name":node_function_name, "tbl":btoa(tbl), "ui_tag":clean_ui,"pagination":pagination_name};
   
  	//alert(clean_ui);
  
  //alert(pagination_name);
  //alert(pagination_token);
  
    if(pagination_token>1)
    {
		mosy_ajax_post(route_to+"?"+pagination_name+"="+btoa(pagination_token), json_params_str, callback_function_string, "");
    }else{
		mosy_ajax_post(route_to, json_params_str, callback_function_string, "");

    }
}


function mosy_next_page(elem_id)
{
  if(get_newval(elem_id)=="")
  {
  	push_newval(elem_id,0)
  }
  var next_token_no=parseInt(get_newval(elem_id))+1;
  
  push_newval(elem_id, next_token_no);
  
  return next_token_no;
}

function mosy_prev_page(elem_id)
{
  if(get_newval(elem_id)=="")
  {
  	push_newval(elem_id,0)
  }
  var next_token_no=parseInt(get_newval(elem_id))-1;
  
  if(next_token_no<=0)
  {
  next_token_no=1;
  }
  
  push_newval(elem_id, next_token_no);
  
  return next_token_no;
}

function push_result(server_resp, additional_callbacks)
{
  //alert(server_resp);
  
  var str_to_display=server_resp+'<div class="col-md-12 p-0 text-right"><span class="badge cpointer" style="font-size:10px;"><i class="fa fa-times-circle"></i> Close</span></div>';
  
  if(server_resp.toString().trim()=='')
  {
  	var str_to_display='<div class="row justify-content-center p-2 mb-3 text-center col-md-12 no_data_tray"> <div class=" text-wrap mt-5"><i class="fa fa-search"></i> Sorry. We didn`t find results matching this request.<hr></div> <div class="col-md-6 text-dark text-center cpointer  p-1 rounded mb-3"><i class="fa fa-star"></i> Lets try a new search</div> </div>';
  }
  
  
  if (document.getElementById(additional_callbacks) !==null) {
        
  document.getElementById(additional_callbacks).style.display="block";
  document.getElementById(additional_callbacks).innerHTML=str_to_display;
        
    }else{
          
    document.getElementById("result").innerHTML=server_resp;

    };
}



function push_grid_result(server_resp, additional_callbacks)
{
  //alert(server_resp);
  
  var str_to_display=server_resp;
  
  var tbl_col_str="";
  var tbl_colspan ="";
  var elem_id=additional_callbacks;

  var empty_state_str="";
  
  if(additional_callbacks.indexOf(":") >= 0)
  {
     tbl_col_str=additional_callbacks.split(":");
     
     tbl_colspan=tbl_col_str[1];
     
     elem_id=tbl_col_str[0];

	if(typeof tbl_col_str[2] !== 'undefined') 
    {
     var empty_state_str = tbl_col_str[2];
    }

  }
///alert(additional_callbacks);
  if(server_resp.toString().trim()=='')
  {
  	if(tbl_colspan!="")
    {
      	var str_to_display='<tr class=" no_data_tray_grid" > <td colspan="'+tbl_colspan+'" style="text-align:center;"><div class=" text-wrap  mt-5"><i class="fa fa-search"></i> Sorry. We didn`t find results matching this request.<hr></div> <div class=" text-dark text-center cpointer  p-1 rounded mb-3"><i class="fa fa-star"></i> Lets try a new search</div></td> </tr>';
    if(empty_state_str!="")
    {
    var str_to_display =window[empty_state_str];
    
    }
    }else{
        
  	var str_to_display='<div class="row justify-content-center p-2 mb-3 text-center col-md-12 no_data_tray_grid" > <div class=" text-wrap  mt-5 "><i class="fa fa-search"></i> Sorry. We didn`t find results matching this request.<hr></div> <div class="text-dark text-center cpointer  p-1 rounded mb-3"><i class="fa fa-star"></i> Lets try a new search</div> </div>';
    
    if(empty_state_str!="")
    {
    var str_to_display =window[empty_state_str];
    
    }
    }
  }
  
  
  if (document.getElementById(elem_id) !==null) {
        
  ///document.getElementById(elem_id).style.display="block";
  document.getElementById(elem_id).innerHTML=str_to_display;
        
    }else{
          
    document.getElementById("result").innerHTML=server_resp;

    };
}

function mosy_empty_state(top_msg="", btm_msg="", tbl_colspan="")
{

    var str_to_display="";

  	if(tbl_colspan!="")
    {
      	var str_to_display='<tr class=" no_data_tray_grid " > <td colspan="'+tbl_colspan+'" style="text-align:center;">'+top_msg+'<hr><div class="col-md-12 text-dark text-center cpointer  p-1 rounded mb-3"> '+btm_msg+'</div></td> </tr>';
 
    }else{
        
  	 str_to_display='<div class="row justify-content-center p-2 mb-3 text-center col-md-12 no_data_tray_grid" > <div class=" text-wrap col-md-12">'+top_msg+'<hr></div> <div class="col-md-12 text-dark text-center cpointer  p-1 rounded mb-3"> '+btm_msg+'</div> </div>';
    
 
    }


///alert(str_to_display);

  return str_to_display;

}

// Function to set a data-* attribute
function set_dataval(id, key, value) {
  let el = document.getElementById(id);
  if (!el) {
    console.error(`Element with ID '${id}' not found.`);
    return;
  }
  el.dataset[key] = value;
}

// Function to get a data-* attribute
function get_dataval(id, key) {
  let el = document.getElementById(id);
  if (!el) {
    console.error(`Element with ID '${id}' not found.`);
    return null;
  }
  return el.dataset[key] || null;
}


function push_val(arrkeys, arrvalues)
{
    var r = {},i;
    
    for (let i = 0; i < arrkeys.length; i++) {
        r[arrkeys[i]] = arrvalues[i];
      document.getElementById(arrvalues[i]).value=[arrkeys[i]];
    }

}

    function qddata(server_resp,callbacks)
    {
    //alert(server_resp);
    var retjson = JSON.parse(server_resp)[0];
    
        ///alert(retjson.name);


    return retjson;
    
    
    }
function mosy_ajax_post(post_url, json_params, callback_function_string, additional_callbacks)
{

	/////alert(post_url);

	var fcall_back_function = callback_function_string;
    
	var fadditional_callbacks = additional_callbacks;
    
      try {
        
        const jsonObject = JSON.parse(callback_function_string);
        

         fcall_back_function = jsonObject.cbfun;

         fadditional_callbacks = callback_function_string;
            
        console.log("Valid JSON");
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        console.log("Invalid JSON:"+callback_function_string);
        
        if(callback_function_string.indexOf(":") >= 0)
        {         
             split_call_back=callback_function_string.split(/:(.*)/s);

             fcall_back_function = split_call_back[0];

             fadditional_callbacks = split_call_back[1];

        }        
        
      }
    
    if (document.getElementById(fadditional_callbacks) !==null) {
      ////  document.getElementById(fadditional_callbacks).style.display="block";
    	///document.getElementById(fadditional_callbacks).innerHTML='<i class="fa fa-spinner fa-spin"></i> Processing request... '+document.getElementById(fadditional_callbacks).innerHTML;
        
    }
    
       if (document.getElementById("ajax_spinner") !==null) 
       {
            
          document.getElementById("ajax_spinner").style.display="block";
          document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-spinner fa-spin"></i> Processing request... ';

       }else{
       	mosy_snack_wgt("Processing request...", "top", "ajax_snack", "200px", "ajax_snack_id", "#000",  "#fff", "");
    
    	mosytoggle_class("ajax_snack_id", "show");
        
       }
       
       
  	var formData = ((json_params)); //Array 
  
      $.ajax({ 
      url: post_url,
      type: "POST",
      data:formData,

      success: function (data) 
      {
        //alert(data);
       if (document.getElementById("ajax_spinner") !==null) 
       {
       
         var result_response_='<i class="fa fa-info-circle"></i> Request Processed Succesfully.';
		
        	if(data=='')
            {
            
        		var result_response_='<i class="fa fa-info-circle"></i> No data .';
            
            }
            
          document.getElementById("ajax_spinner").style.display="block";
          document.getElementById("ajax_spinner").innerHTML=result_response_;

       } 
       
       push_html("ajax_snack", "");                                          

        window[fcall_back_function](data, fadditional_callbacks);

      }

  })
  
}  


   //Ajax Manager

function mosyajax_create_data(tbl, tbl_cols, tbl_vals, callback_function_string)
{
  ///alert(tbl_cols+" - "+tbl_vals);
  
    var json_params_str={"mosyajax_create":"ok", "tbl_cols":tbl_cols, "tbl_vals":tbl_vals, "tbl":tbl};
    
  	mosy_ajax_post(mosyajax_sql_url, json_params_str, callback_function_string, '');

}

   //Ajax Exe
function mosyajax_update(tbl, update_str, where_str, callback_function_string)
{
  //alert(update_str);
  
    var json_params_str={"mosyajax_update":"ok", "update_str":update_str, "where_str":where_str, "tbl":tbl};
    
  	mosy_ajax_post(mosyajax_sql_url, json_params_str, callback_function_string, '');

}

function mosyajax_drop(tbl, where_str, callback_function_string)
{
  //alert(where_str);
  
    var json_params_str={"mosyajax_drop":"ok", "where_str":where_str, "tbl":tbl};
    
  	mosy_ajax_post(mosyajax_sql_url, json_params_str, callback_function_string, '');

}


function mosyajax_get(getstr, callback_function_string,req_url="")
{
    var route_to = hiveRoutes[req_url];
    
    if(req_url=="")
    {
     route_to=ajax_url;
    }

	var fcall_back_function = callback_function_string;
    
	var fadditional_callbacks = "";

      try {
        
        const jsonObject = JSON.parse(callback_function_string);
        

         fcall_back_function = jsonObject.cbfun;

         fadditional_callbacks = callback_function_string;
            
        console.log("Valid JSON");
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        console.log("Invalid JSON:"+callback_function_string);
        
        if(callback_function_string.indexOf(":") >= 0)
        {
             split_call_back = callback_function_string.split(":");

             fcall_back_function = split_call_back[0];

             fadditional_callbacks = split_call_back[1];

        }        
        
      }
    
       if (document.getElementById("ajax_spinner") !==null) 
       {
            
          document.getElementById("ajax_spinner").style.display="block";
          document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-spinner fa-spin"></i> Processing request... ';

       }else{
       	mosy_snack_wgt("Processing request...", "top", "ajax_snack", "200px", "ajax_snack_id", "#000",  "#fff", "");
    
    	mosytoggle_class("ajax_snack_id", "show");
        
       }
       

    $.ajax({
      url: route_to+"?"+getstr,
      type: 'GET',
      success: function(res) {
 
       if (document.getElementById("ajax_spinner") !==null) 
       {
       
         var result_response_='<i class="fa fa-info-circle"></i> Request Processed Succesfully.';
		
        	if(data=='')
            {
            
        		var result_response_='<i class="fa fa-info-circle"></i> No data .';
            
            }
            
          document.getElementById("ajax_spinner").style.display="block";
          document.getElementById("ajax_spinner").innerHTML=result_response_;

       } 
       
       push_html("ajax_snack", "");                                       

            //alert(res);
        window[fcall_back_function](res, fadditional_callbacks);

          }
      });
}


function mosy_validate_required(required_inp=null, show_dial='yes')
{
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+"</b><br>";
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, "False")=="False")
      {
      
       var required_state="1";
      
      }else{
      
        var required_state="0";
        if(show_dial=='yes')
        {

          magic_message(validate_msg, 'dialog_box');

        }
      }
  
  return required_state ;
}

function mosy_form_data(form_id,  save_action, callback_function_string, additional_callbacks, required_inp="",req_url="")
{

    var route_to = hiveRoutes[req_url];
    
    if(req_url=="")
    {
     route_to=ajax_url;
    }
    
	var fcall_back_function = callback_function_string;
    
	var fadditional_callbacks = additional_callbacks;
    
    if(callback_function_string.indexOf(":") >= 0)
    {
		var split_call_back = callback_function_string.split(":");
        
		var fcall_back_function = split_call_back[0];
        
        var fadditional_callbacks = split_call_back[1];
    
    }
    
    
	var formData = new FormData(document.getElementById(form_id));
  
    if (document.getElementById("ajax_spinner") !==null) {
        
    	document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-spinner fa-spin"></i> Processing request... ';
        
    }
    
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
   ///alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
    {

	formData.append(save_action, "ok");
	formData.append('mosyrequest_type', "ajax");
        $.ajax({
            type: "POST",
            url: route_to,
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            success: function(data){
                  if (document.getElementById("ajax_spinner") !==null) {
        
                      document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-check-circle"></i> Request Processed Succesfully. <span class="badge badge-primary btn_neo"><i class="fa fa-thumbs-up"></i> OK </span>';

                  }
              ///alert(data);
        		window[fcall_back_function](data, fadditional_callbacks);
            },
	    complete: function(){
			//alert("Data uploaded successfully.");
	    },
	    error: function (jqXHR, textStatus, errorThrown) {
			alert(errorThrown);
	    } 
        });
      // Display the key/value pairs
      for (var pair of formData.entries()) {
          ///console.log(pair[0]+ ", " + pair[1]); 
      }
        	  
     }else{
        magic_message(validate_msg, 'dialog_box');
      }
      
      
}

function blackhole(data)
{

}

function show_password(input_name) 
{
  var x = document.getElementById(input_name);
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}


function get_newval(elemid)
{
    if (document.getElementById(elemid) !==null) {

	  return document.getElementById(elemid).value;
    }else{
  
  return "";
  }
}

function mosy_response(server_resp, callbacks)
{

	alert("server_resp"+server_resp+" -- Callbacks "+callbacks);

}

function get_html(elemid)
{
    if (document.getElementById(elemid) !==null) {

  return document.getElementById(elemid).innerHTML;
  }else{
  
  return "";
  }
}

function get_src(elemid)
{
  if (document.getElementById(elemid) !==null) {

  return document.getElementById(elemid).src;
  }else{
  
  return "";
  }
}

function get_href(elemid)
{
  if (document.getElementById(elemid) !==null) {

  return document.getElementById(elemid).href;
  }else{
  
  return "";
  }
}


function push_ddown(server_items, selelem)
{

	$('#'+selelem+' option:not(:first)').remove();

	document.getElementById(selelem).innerHTML=document.getElementById(selelem).innerHTML+server_items;

}
//========= formart to num =================

function tonum(req_number, decplc=0)
{

///alert(req_number);
if (Number.isNaN(Number(req_number)))
{
  req_number=0;
}

var n = parseFloat(req_number).toFixed(decplc)
var withCommas = Number(n).toLocaleString('en');

if(withCommas=="NaN")
{
 withCommas = 0 
}
return withCommas;
}

//========= formart to num =================

function mosy_qstr(string, query_str)
{
    
   if(string.indexOf(query_str)==-1)
    {
      
      var q_str_state="False";
      
    }else{
    
	  var q_str_state="True";
     
	}
    
  return q_str_state;
    
}
function mosy_refresh(new_location)
{

var new_location_str=window.location.href;

  window.location=new_location_str.replace("table_alert", "tbl_alert_old");

}

function mosy_srefresh(server_resp, new_location)
{

  window.location=new_location;

}
////////////////// ===================  js action listener ================  

  var _js_msdn=document.querySelectorAll('js_msdn');
  
  _js_msdn.forEach(el => el.addEventListener('click', event => {
  
  var _mosy_jsmsdn_event_trgt= event.currentTarget;

  
	 _mosy_jsmsdn_jsaction="";
	 _mosy_jsmsdn_arg="";
     
  if (!_mosy_jsmsdn_event_trgt.hasAttribute("data-mosy_js")) 
  {
    // data attribute doesnt exist
  }else{
  
	 _mosy_jsmsdn_jsaction=_mosy_jsmsdn_event_trgt.getAttribute("data-mosy_js");
	 _mosy_jsmsdn_arg=_mosy_jsmsdn_event_trgt.getAttribute("data-_mosy_jsmsdn_arg");
     
  }

     window[_mosy_jsmsdn_jsaction](_mosy_jsmsdn_arg);

  
}));
  
  
  
////////////////// ==================  js action listener ================  



function pop_filter_tray (data_src, card_title, where_str_req,cols,returnfun)
{
  magic_screen(pop_data_filter_card, "alert_box");
        
  var where_str =" and "+(where_str_req);
  var where_str_inp =" and "+magic_clean_str(where_str_req);
  
  if(where_str_req=="")
  {
    var where_str="";
    var where_str_inp ="";
  }
  
  var load_data_set ="load_"+data_src;
  var gft_data_str="gft_"+data_src;
  ///alert(where_str);
  window[load_data_set]("", ajaxw+" "+window[gft_data_str]("")+where_str, cols, returnfun, "push_result:result","card");
  
  //alert(cols);
  var textbox ='<input type="text" class="form-control" onkeyup="'+load_data_set+'(this.value, \''+ajaxw+' \'+'+gft_data_str+'(this.value)+\''+where_str_inp+'\', \''+magic_clean_str(cols)+'\', \''+returnfun+'\', \'push_result:result\',\'card\')" placeholder="Type your search here"/>';
        
  document.getElementById('card_title').innerHTML=card_title;
  document.getElementById('dope_text').innerHTML=textbox;

        
}


function mosytoggle_elem(elemid, new_val)
{
  if(new_val=='')
  {
  if(document.getElementById(elemid).style.display!='none')
  {
    document.getElementById(elemid).style.display='none';
  }else{
    document.getElementById(elemid).style.display='block';
  }
  }else{
    document.getElementById(elemid).style.display=new_val;
  }
}

function tray_uptoken(datakey,callbacks)
{
  
  window.location=callbacks[0]+'?'+callbacks[1]+'_uptoken='+btoa(datakey[0]);
}

var pop_data_filter_card=`
    <h5><i class="fa fa-search mr-2"></i><span id="card_title"></span></h5>
	<hr>
  <div class="row justify-content-center m-0 p-0 col-md-12">
  	<div id="dope_text" class="col-md-12"></div>
	<div id="result" class="col-md-12" style="max-height:300px; overflow-y:auto;" onclick="this.style.display='none'"></div>
    
  	<div id="r" class="col-md-12 row justify-content-center m-0 p-0 mt-3">
    	<a href="" class="badge border border_set p-2 rounded text-primary col-md-5 mr-lg-3" id="pop_tray_location"> 
        	View All <i class="fa fa-arrow-right"></i> 
        </a>
    	<a href="" class="badge border border_set p-2 rounded text-primary col-md-5" id="new_pop_tray_location"> 
        	<i class="fa fa-plus" id="newclass"></i> 
        	<span id="new_record_label"> Add new </span> 
        </a>
    </div>
  </div>`;
  
function push_link(new_link,anchor_el)
{

	//alert(new_link);
	document.getElementById(anchor_el).href=new_link;

}


function push_html(elemid, new_val="")
{
    if (document.getElementById(elemid) !==null) {

	  document.getElementById(elemid).innerHTML=(new_val);
      
      }
}

function nl_to_br(str)
{

	return str.replace(/(?:\r\n|\r|\n)/g, "<br>");

}

function br_to_nl(str)
{

	return str.replace(/(<br>)/g, "\n");

}

function push_newval(elemid, new_val="")
{
    if (document.getElementById(elemid) !==null) {

  		document.getElementById(elemid).value=(new_val);
  
  }
}

function push_src(elemid, new_val="")
{
	  if (document.getElementById(elemid) !==null) 
      {

	  		document.getElementById(elemid).src=new_val;
      
      }
}

function mosytoggle_class(elemid, new_class)
{
  if(document.getElementById(elemid).classList.contains(new_class))
  {
    document.getElementById(elemid).classList.remove(new_class);
  }else{
    document.getElementById(elemid).classList.add(new_class);
  }
  
}

function mosytoggle_addclass(elemid, new_class)
{
  if(document.getElementById(elemid).classList.contains(new_class))
  {
    //document.getElementById(elemid).classList.remove(new_class);
  }else{
    document.getElementById(elemid).classList.add(new_class);
  }
  
}

function mosytoggle_remclass(elemid, new_class)
{
  if(document.getElementById(elemid).classList.contains(new_class))
  {
    document.getElementById(elemid).classList.remove(new_class);
  }
  
}


function mosyhide_elem(elemid, new_class="")
{
    var curr_class="none";
    if(new_class!="")
    {
    curr_class=new_class;
    }
    	
   if (document.getElementById(elemid) !==null) 
   {
   	document.getElementById(elemid).style.display=curr_class;
   }
}

function mosyshow_elem(elemid, new_class="")
{
    var curr_class="block";
    if(new_class!="")
    {
    curr_class=new_class;
    }
   if (document.getElementById(elemid) !==null) 
   {
   	document.getElementById(elemid).style.display=curr_class;
   }
}

function mosy_get_param(name){
   if(name=(new RegExp('[?&]'+encodeURIComponent(name)+'=([^&]*)')).exec(location.search))
      return decodeURIComponent(name[1]);
}




function mosy_push_data_class(class_name,data)
{    
	var elem_state ="false";
    ///alert(class_name);
    
    if (document.getElementsByClassName(class_name)[0] !==null) 
    {
      elem_state="true";

     var slides = document.getElementsByClassName(class_name);
     for (var i = 0; i < slides.length; i++) 
     {
	  var elemid = document.getElementsByClassName(class_name)[i].id;
      

	 console.log(elemid+" state "+ elem_state);
      var elem_type=(document.getElementById(elemid).nodeName).toLowerCase();

      if(elem_type=='span')
      {
        push_html(elemid, data);
      }else if(elem_type=='select')
      {
        ///alert("select found "+elemid+" vals"+get_html(elemid));
      var remove_dup_item=get_html(elemid).replace( "<option>"+data+"</option>","")
       push_html(elemid, "<option>"+data+"</option>"+remove_dup_item);
        

      }else if(elem_type=='img')
      {
        push_src(elemid, data);
      }else if(elem_type=='a')
      {
        push_link(elemid, data);
      }else{
      push_newval(elemid, data);
      push_html(elemid, data);
      }
  
  }
  
  console.log(elemid+" state "+ elem_state);
 }  
}

function mosy_push_data(elemid,data)
{
	var elem_state ="false";
    if (document.getElementById(elemid) !==null) 
    {
      elem_state="true";
      

      var elem_type=(document.getElementById(elemid).nodeName).toLowerCase();

      if(elem_type=='span')
      {
        push_html(elemid, data);
      }else if(elem_type=='select')
      {
        ///alert("select found "+elemid+" vals"+get_html(elemid));
      var remove_dup_item=get_html(elemid).replace( "<option>"+data+"</option>","")
       push_html(elemid, "<option>"+data+"</option>"+remove_dup_item);
        

      }else if(elem_type=='img')
      {
        push_src(elemid, data);
      }else if(elem_type=='a')
      {
        push_link(elemid, data);
      }else{
      push_newval(elemid, data);
      push_html(elemid, data);
      }
  
  }
  
  ///console.log(elemid+" state "+ elem_state);
  
}

function check_elem(elemid)
{
    if (document.getElementById(elemid) ===null) 
    {
    alert("element_"+elemid+" Not available");
    }
}

function push_shtml(server_res, callback)
{
  
  magic_message(callback, "dialog_box");
  
}



function mosy_push_serv_resp(_server_resp, elemid_str)
{

///alert(_server_resp);

	var elem_state ="false";
    var elemid=elemid_str;
  
    var data = _server_resp;
              
    ////console.log(elemid+" state "+ elem_state+" serep "+_server_resp);

    if (document.getElementById(elemid) !==null) 
    {
      elem_state="true";
      push_html(elemid, data);      
      push_newval(elemid, data);
      var elem_type=(document.getElementById(elemid).nodeName).toLowerCase();

      if(elem_type=='span')
      {
        push_html(elemid, data);
      }
       if(elem_type=='select')
      {
        push_html(elemid, data);
      }

      if(elem_type=='img')
      {
        push_src(elemid, data);
      }
      if(elem_type=='a')
      {
        push_link(elemid, data);
      }
  
  }
  
  ///console.log(elemid+" state "+ elem_state);
  return _server_resp;
}


function mosy_push_num_ddata(_server_resp, elemid_str)
{
	//alert(_server_resp);
    
	var elem_state ="false";
    var elemid=",,";    
    var json_decoded_str=JSON.parse(_server_resp)[0];
        
    var data_str=elemid_str;
    
    var data = json_decoded_str[data_str];

    if(elemid_str.indexOf("|") >= 0)
    {
		var elemid_arr = elemid_str.split("|");
        
		 elemid = (elemid_arr[0]);
        
          data_str = elemid_arr[1];
          
          console.log(elemid+" state "+ data_str+" serep "+_server_resp);

         data = tonum(json_decoded_str[data_str]);
        
    }
    
    if (document.getElementById(elemid) !==null) 
    {
      elem_state="true";
            
      push_html(elemid, data);
      push_newval(elemid, data);
      var elem_type=(document.getElementById(elemid).nodeName).toLowerCase();

      if(elem_type=='span')
      {
        push_html(elemid, data);
      }
       if(elem_type=='select')
      {
        push_html(elemid, data);
      }

      if(elem_type=='img')
      {
        push_src(elemid, data);
      }
      if(elem_type=='a')
      {
        push_link(elemid, data);
      }
  
  }
  
  ///console.log(elemid+" state "+ elem_state);
  return json_decoded_str;
}

function mosy_push_ddata(_server_resp, elemid_str)
{

///alert(_server_resp);

	var elem_state ="false";
    var elemid=",,";    
    var json_decoded_str=JSON.parse(_server_resp)[0];
        
    var data_str=elemid_str;
    

    if(elemid_str.indexOf("|") >= 0)
    {
		var elemid_arr = elemid_str.split("|");
        
		 elemid = elemid_arr[0];
        
          data_str = elemid_arr[1];
          

         var data = json_decoded_str[data_str];
        
    }else{

		var data = json_decoded_str[data_str];

    }
              
    console.log(elemid+" state "+ data_str+" serep "+_server_resp);

    if (document.getElementById(elemid) !==null) 
    {
      elem_state="true";
      push_html(elemid, data);      
      push_newval(elemid, data);
      var elem_type=(document.getElementById(elemid).nodeName).toLowerCase();

      if(elem_type=='span')
      {
        push_html(elemid, data);
      }
       if(elem_type=='select')
      {
        push_html(elemid, data);
      }

      if(elem_type=='img')
      {
        push_src(elemid, data);
      }
      if(elem_type=='a')
      {
        push_link(elemid, data);
      }
  
  }
  
  ///console.log(elemid+" state "+ elem_state);
  return json_decoded_str;
}

function dope_token(token_url="", token_key="")
{
window.history.replaceState(null, null, "?"+token_url+"="+token_key+"");
}

function mosyrename_elem(elemid, newname)
{
    if (document.getElementById(elemid) !==null) 
    {
      document.getElementById(elemid).id=newname;
      document.getElementById(newname).setAttribute("name",newname);
    }
}
///////////////  slide show 
function mosy_slide_wgt(image_arr_n_captions, img_style, img_class, extra_attr, slide_indicators_yes_no)
{
  
const rem_array = image_arr_n_captions.slice(0, 0).concat(image_arr_n_captions.slice(0+1, image_arr_n_captions.length));
  
var curr_slide_id =magic_random_str(10);
    
var img_string =  image_arr_n_captions[0];
var caption_str = ""
var caption_str_div="";
var datakey = "";
  
if(image_arr_n_captions[0].includes(":"))
{
 img_string =  image_arr_n_captions[0].substring(0, image_arr_n_captions[0].indexOf(':')); 
 datakey_1 = image_arr_n_captions[0].substring(image_arr_n_captions[0].indexOf(':')+1); 
 datakey = datakey_1.substring(0, datakey_1.indexOf(':'));
 datakey_2 = datakey_1.substring(datakey_1.indexOf(':')+1);
 caption_str = datakey_2.substring(datakey_2.indexOf(':'));
 caption_str_div=`<div class="col-md-12 text-center  pb-4"> ${caption_str} </div>`;
}
  ///alert("dkey1 -- "+datakey_2);
 var slide_node="";
 var slidecounter="";
 var i=0;
  
 if(slide_indicators_yes_no=='yes')
 {
   slidecounter=`<li data-target="#slide_s${curr_slide_id}" data-slide-to="0" class="active"></li>`;
 }
 for(img_arr of rem_array)
 {
   i++;
   
	if(slide_indicators_yes_no=='yes'){
 slidecounter+=`
        <li data-target="#slide_s${curr_slide_id}" data-slide-to="${i}" class="active"></li>
   `;  
    }
   
   var loop_img_string =  img_arr;
   var loop_caption_str = "";
   var loop_caption_str_div="";
   var loop_datakey="";
   
   if(img_arr.includes(":")){
 	loop_img_string =  img_arr.substring(0, img_arr.indexOf(':')); 
 	loop_datakey_1 = img_arr.substring(img_arr.indexOf(':')+1); 
 	loop_datakey = loop_datakey_1.substring(0, loop_datakey_1.indexOf(':'));
 	loop_datakey_2 = loop_datakey_1.substring(loop_datakey_1.indexOf(':')+1);
 	loop_caption_str = loop_datakey_2.substring(loop_datakey_2.indexOf(':'));
 	loop_caption_str_div=`<div class="col-md-12 text-center  pb-4"> ${loop_caption_str} </div>`;
   }
   
   slide_node+=`   
            <!-- carousel item -->
            <div class="carousel-item">
             <div class="row pt-3 justify-content-center">
     			${loop_caption_str_div}
               <div  class="col-md-12 pr-0 w-100">
               <img src="${loop_img_string}" style="${img_style}" class="${img_class}" ${extra_attr} data-idkey="${loop_datakey}"/>
               </div>
             </div>
           </div>
           <!-- carousel item -->`;
   
 }
  
var slide_tray=`
      <!--------------- Start carousel ---------->
      <div id="slide_s${curr_slide_id}" class="carousel slide w-100" data-ride="carousel" data-interval="2000">
        <ol class="carousel-indicators mt-2">
  		${slidecounter}
        </ol>
        <!-- carousel inner -->
          <div class="carousel-inner">
            <!-- carousel item -->
            <div class="carousel-item active">
             <div class="row pt-3 justify-content-center">
          	   ${caption_str_div}
               <div  class="col-md-12 pr-0 w-100">
               <img src="${img_string}" style="${img_style}" class="${img_class}" ${extra_attr} data-idkey="${datakey}"/>
               </div>
             </div>
           </div>
           <!-- carousel item -->
		   ${slide_node}
            <!-- carousel inner -->
            <a class="carousel-control-prev" href="#slide_s${curr_slide_id}" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            </a>
            <a class="carousel-control-next" href="#slide_s${curr_slide_id}" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
            </a> 
          </div>
             
      </div>
      <!--------------- End carousel ---------->
        `;
  
return [slide_tray, curr_slide_id];  
}
///////////////  slide show 

//////////////  image alert 
function mosy_img_pop(img_src,img_style, img_class,  extra_attr, slide_show_yes_no)
{
  var img_tray=
    `
    <img src="${img_src}" style="${img_style}" class="${img_class}"/>
    
    `;
  
  if(slide_show_yes_no=='yes')
  {
    
    var pop_tray_carousel = mosy_slide_wgt(img_src, img_style, img_class, extra_attr)[0];
    
    magic_screen(pop_tray_carousel, 'alert_box');
    
  }else{
  	magic_screen(img_tray, 'alert_box');
  }
  
}  

//////////////  image alert \

function mosy_snack_wgt(content, curr_position, push_to, snack_pos, snackid, color, bg, onclick_fun)
{
              
var snack_cont=`
<style>
/* The snackbar - position it at the bottom and in the middle of the screen */
#${snackid} {
  visibility: hidden; /* Hidden by default. Visible on click */
  min-width: 250px; /* Set a default minimum width */
  margin-left: -125px; /* Divide value of min-width by 2 */
  background:${bg}; /* Black background color */
  color: ${color}; /* White text color */
  text-align: center; /* Centered text */
  border-radius: 2px; /* Rounded borders */
  padding: 16px; /* Padding */
  position: fixed; /* Sit on top of the screen */
  z-index: 9999; /* Add a z-index if needed */
  left: 50%; /* Center the snackbar */
  ${curr_position}: ${snack_pos}; /* 30px from the bottom */
}

/* Show the snackbar when clicking on a button (class added with JavaScript) */
#${snackid}.show {
  visibility: visible; /* Show the snackbar */
  /* Add animation: Take 0.5 seconds to fade in and out the snackbar.
  However, delay the fade out process for 2.5 seconds */
  -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
  animation: fadein 0.5s, fadeout 0.5s 2.5s;
}

/* Animations to fade the snackbar in and out */
@-webkit-keyframes fadein {
  from {${curr_position}: 0; opacity: 0;}
  to {${curr_position}: ${snack_pos}; opacity: 1;}
}

@keyframes fadein {
  from {${curr_position}: 0; opacity: 0;}
  to {${curr_position}: ${snack_pos}; opacity: 1;}
}

@-webkit-keyframes fadeout {
  from {${curr_position}: ${snack_pos}; opacity: 1;}
  to {${curr_position}: 0; opacity: 0;}
}

@keyframes fadeout {
  from {${curr_position}: ${snack_pos}; opacity: 1;}
  to {${curr_position}: 0; opacity: 0;}
}
</style>
  
  <div id="${snackid}" onclick="${onclick_fun};push_html('${push_to}', '')">${content}</div>

  `;


push_html(push_to, snack_cont);


} 

function new_location(new_location_str)
{
window.location=new_location_str;
}

function mosy_reload()
{
   document.location.reload()

} 

function glass_modal()
{
       document.getElementsByClassName("msg_modal-content")[0].style.setProperty("background-color", "transparent", "important");;
       document.getElementsByClassName("msg_modal-content")[0].style.setProperty("border-top", "0px solid", "important");;
       document.getElementsByClassName("msg_modal-content")[0].style.setProperty("border", "0px solid", "important");;
}

function mosy_card(card_title="", card_content, attach_To)
{
	var mosy_card_title="";
    if(card_title!="")
    {
    var mosy_card_title=`
                          <!-- Start  Title ribbon-->
                      <h5 class="col-md-12 row p-2 justify-content-center p-0 m-0 ">
                        <div class="col-md-2 bg-dark mb-3 mb-lg-0 mt-lg-3" style="height: 1px"></div>
                        <div class="col-md-8 text-center"><b> ${card_title}</b></div>
                        <div class="col-md-2 bg-dark mt-3" style="height: 1px"></div>
                      </h5>
                      <!-- End Title ribbon--> 
    `;
    }
    var link_pop=`
    <div class="row justify-content-center m-0 p-0 col-md-12">
						${mosy_card_title}
                      <div class="row justify-content-center m-0 p-0 col-md-12 mt-3 mb-3">
                        ${card_content}
                      </div>
      </div>
    </div>

    `;

    if(attach_To=='' || attach_To==undefined)
    {
    magic_screen(link_pop, 'alert_box');
    }else{
      push_html(attach_To, link_pop);
    }

    return link_pop;
 
}

  
function filter_by_date(card_title,filter_link,filter_col,and_query='',trailing_space="")
{

//alert(card_title+"-fl-"+filter_link+"- colstr -"+filter_col+"- and q -"+and_query+"- trsp  -"+trailing_space+"- inptype-"+input_type);
 var def_date = mosy_ymd();

var pop_filter_date=`
    <h5>Filter by <span id="filter_title"> ${card_title} </span></h5>
  <div class="row justify-content-center m-0 p-0 col-md-12">
	<div class="form-group col-md-6">
		<label >Start Date</label>
		<input class="form-control" id="txt_start_date" name="" value="${def_date}" placeholder="Your Name" type="date">
	</div>
  	<div class="form-group col-md-6">
		<label >End Date</label>
		<input class="form-control" id="txt_end_date"  name="" value="${def_date}" placeholder="Your Name" type="date">
	</div>
    <input type="hidden" id="txt_mosy_filter_q" value="${filter_col}" />
    <input type="hidden" id="txt_mosy_and_query" value="${and_query}" />
  <div class="col-md-7 cpointer btn_neoo2 btn-primary text-center" onclick=" go_to_date('${filter_link}', get_newval('txt_start_date'), get_newval('txt_end_date'), get_newval('txt_mosy_filter_q'), get_newval('txt_mosy_and_query'), '${trailing_space}', '')"><i class="fa fa-arrow-right"></i> Proceed </div>
  </div>
  `;
  
  mosy_card('', pop_filter_date);
  
  return pop_filter_date;
  
}

function filter_by_month(card_title,filter_link,filter_col,and_query='',trailing_space="")
{

//alert(card_title+"-fl-"+filter_link+"- colstr -"+filter_col+"- and q -"+and_query+"- trsp  -"+trailing_space+"- inptype-"+input_type);
 var def_date = mosy_ymd();

var pop_filter_date=`
    <h5>Filter by <span id="filter_title"> ${card_title} </span></h5>
  <div class="row justify-content-center m-0 p-0 col-md-12">
	<div class="form-group col-md-6">
		<label >Select Month</label>
		<input class="form-control" id="txt_start_filter_month__" name="" value="${def_date}" placeholder="Select Month" type="month">
	</div>
    <input type="hidden" id="txt_mosy_filter_q" value="${filter_col}" />
    <input type="hidden" id="txt_mosy_and_query" value="${and_query}" />
  <div class="col-md-7 cpointer btn_neoo2 btn-primary text-center" onclick=" go_to_month('${filter_link}', get_newval('txt_start_filter_month__'), get_newval('txt_mosy_filter_q'), get_newval('txt_mosy_and_query'), '${trailing_space}', '')"><i class="fa fa-arrow-right"></i> Proceed </div>
  </div>
  `;
  
  mosy_card('', pop_filter_date);
  
  return pop_filter_date;
  
}


function go_to_month(filter_link, start_date, filter_col, and_query, trailing_space, input_type="month")
{
  
  if(input_type=="datetime")
  {
  var filter_location=filter_link+"="+btoa(trailing_space+""+filter_col+" ='" +start_date+"' "+and_query+" ");  
  }else{
    var filter_location=filter_link+"="+btoa(trailing_space+"DATE_FORMAT("+filter_col+", '%Y-%m') ='" +start_date+"' "+and_query+" ")+"&mosy_start_month__="+btoa(start_date);  

  }
  
  ///alert(filter_location);
  ///console.log(filter_location);
  
  if(start_date!=""){
   window.location=filter_location;
  }else{
  mosy_validate_required(["txt_start_filter_month__:Month Required"])
  }
  
}

/////=========  mosy filter date 

  
function filter_by_datetime(card_title,filter_link,filter_col,and_query='',trailing_space="",def_inp_date_="")
{

/////alert(card_title+"-fl-"+filter_link+"- colstr -"+filter_col+"- and q -"+and_query+"- trsp  -"+trailing_space+"- def date -"+def_inp_date_);

var pop_filter_date=`
    <h5>Filter by <span id="filter_title"> ${card_title} </span></h5>
  <div class="row justify-content-center m-0 p-0 col-md-12">
	<div class="form-group col-md-6">
		<label >Start Date</label>
		<input class="form-control" id="txt_start_date" name="" value="${def_inp_date_}" placeholder="Your Name" type="datetime-local">
	</div>
  	<div class="form-group col-md-6">
		<label >End Date</label>
		<input class="form-control" id="txt_end_date"  name="" value="${def_inp_date_}" placeholder="Your Name" type="datetime-local">
	</div>
    <input type="hidden" id="txt_mosy_filter_q" value="${filter_col}" />
    <input type="hidden" id="txt_mosy_and_query" value="${and_query}" />
  <div class="col-md-7 cpointer btn_neoo2 btn-primary text-center" onclick=" go_to_date('${filter_link}', get_newval('txt_start_date'), get_newval('txt_end_date'), get_newval('txt_mosy_filter_q'), get_newval('txt_mosy_and_query'), '${trailing_space}', 'datetime')"><i class="fa fa-arrow-right"></i> Proceed </div>
  </div>
  `;
  
  mosy_card('', pop_filter_date);
  
  return pop_filter_date;
  
}
//==========================================

/*
function go_to_date(filter_link, start_date, end_date, filter_col, and_query, trailing_space, input_type="date")
{
  
  if(input_type=="datetime")
  {
  var filter_location=filter_link+"="+btoa(trailing_space+""+filter_col+" >='" +start_date+"' AND "+filter_col+"<='" +end_date+ "' "+and_query+" ");  
  }else{
    var filter_location=filter_link+"="+btoa(trailing_space+"DATE_FORMAT("+filter_col+", '%Y-%m-%d') >='" +start_date+"' AND DATE_FORMAT("+filter_col+", '%Y-%m-%d') <='" +end_date+ "' "+and_query+" ")+"&mosy_start_date="+btoa(start_date)+"&mosy_end_date="+btoa(end_date);  

  }
  
  ///alert(filter_location);
  ///console.log(filter_location);
  window.location=filter_location;
  
}
*/ 

function go_to_date(filter_link, start_date, end_date, filter_col, and_query, trailing_space, input_type="date")
{
  
  var filter_str=(trailing_space+""+filter_col+" >='" +start_date+"' AND "+filter_col+"<='" +end_date+ "' "+and_query+" ")
  const encoder = new TextEncoder("UTF-8");
  const byteArray = encoder.encode(filter_str);

  // Encode byte array to Base64
  //const base64String = btoa(String.fromCharCode(...byteArray));
  const base64String = encodeURIComponent(btoa(filter_str));
  
  if(input_type=="datetime")
  {
  var filter_location=filter_link+"="+base64String;  
  }else{
    var filter_location=filter_link+"="+base64String+"&mosy_start_date="+btoa(start_date)+"&mosy_end_date="+btoa(end_date);  

  }
  
  ///alert(filter_location);
  ///console.log(filter_location);
  window.location=filter_location;
  
}


function mosy_ymd(date='', time='') 
{

 if(date=="")
 {
  var today = new Date();
 }else{
  var today = date;
 }
 
 var curr_date = new Date().toISOString().slice(0, 10);
 
 var curr_time_date = curr_date+" "+today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
 
 if(time!="")
 {
  return curr_time_date;
 }else{
 return curr_date;
 }
}


function mosy_modal(modal_content, attach_To="alert_box", parent_id="")
{

  if(attach_To=="")
  {
  	attach_To="alert_box"
  }
  var mosy_modal_tray =`
  <div class="col-md-12 mosy_modal rounded_big p-0 m-0 bg-white shadow  border border_set ">
    <div class="col-md-12 pt-2 text-right"><span class="cpointer "  onclick="push_html('${attach_To}','')"><i class="fa fa-times-circle"></i></span></div>
    <div class="row justify-content-center m-0 p-0 col-md-12" id="${parent_id}">
    	${modal_content}
    </div>
  </div>`;

  ///alert(mosy_modal_tray);

  push_html(attach_To, mosy_modal_tray);

  return mosy_modal_tray;

}


  function mosy_print_elem(print_div,doc_title="", header_layout="",print_footer="")
  {
   var curr_doc_title___= magic_random_str(10)+"_curr_doc_title"
   
   var document_print_out_title_=`
       	<div class="col-md-12 p-3 mb-4 rounded shadow-sm  border bg-white ">                                	                                
                   <div class="form-group text-center">
                    <label class="m-0 p-0 label_text " >Add document title</label>
                    <input class="m-0 form-control" id="${curr_doc_title___}" name="${curr_doc_title___}" value="${doc_title}" placeholder="add the title you would like to appear in the document" type="text">
                </div>
                <div class="col-md-12 p-0 text-right  ">
             <div class="col-md-12 description_text pb-2" > 
                <em>To download as a PDF file select "PDF as your printer" on the print options</em>
              </div>
                 <button type="button" class="cpointer shadow btn btn-primary mb-3 pr-5 pl-5 mosy_msdn" data-mosy_msdn="mosy_finish_print_elem(\'${print_div}\', get_newval(\'${curr_doc_title___}\'), \'${header_layout}\',\'${print_footer}\')"> <i class="fa fa-print"></i> Print </button>
                </div>
        </div>
    `
    mosy_card("", document_print_out_title_)
  }

  function mosy_finish_print_elem(print_div,doc_title="", header_layout="",print_footer="") 
  {
  
    var dropdownContents = document.querySelectorAll(".table_cell_dropdown-content");

    // Loop through each dropdown content element
    dropdownContents.forEach(function(element) {
        // Modify properties of each element as needed
        element.style.display = "none";

    });
  
        if (typeof mosy_print_header_layout !== "undefined" && header_layout=="") {
           header_layout=mosy_print_header_layout
         }
  		var print_title=`
        <h3 class="col-md-12 p-3">${doc_title}</h3>
        `;
        //Get the HTML of div
        var divElements = header_layout+print_title+document.getElementById(print_div).innerHTML+print_footer;
        //Get the HTML of whole page
        var oldPage = document.body.innerHTML;
        //Reset the pages HTML with divs HTML only
        document.body.innerHTML = 
          `<html><head><title></title>
          <style>
            body{
            background-color:#fff!important;
            font-family:"Helvetica";
            font-size:18px;
            font-weight:500;
            }
            .table thead th 
            {
              white-space: nowrap;
              padding: 1px;
              vertical-align: top;
              font-size: 14px;
            }
            .table tbody td 
            {
              white-space: nowrap;
              padding: 1px;
              vertical-align: top;
              font-size: 14px;
            }
            a{
            color:#000;
            }  
			.table_cell_dropdown:hover .table_cell_dropdown-content{display:none}
            tr:hover .table_cell_dropdown-content{display:none}              
           </style>
          </head>
         <body>` + 
          divElements + "</body>";
        //Print Page
        window.print();
        //Restore orignal HTML
        document.body.innerHTML = oldPage;
        mosy_reload();

    }


function mosy_decode_json(json_server_resp, arr_node)
{
  var decode_resp=JSON.parse(json_server_resp);
    
  if(arr_node.indexOf("|") >= 0)
  {
   
   		var elemid_arr = arr_node.split("|");
        
		var elemid = (elemid_arr[1]);
        
        var data_str = elemid_arr[0]; 
    
        mosy_push_data(elemid, decode_resp[data_str]);
        
        var ret_data = decode_resp[data_str];
  }else{
    
	var ret_data = decode_resp[arr_node];
    
  }
  
  return ret_data ;
  ////alert(decode_resp[arr_node]);
}


function mosy_push_sdata(_server_resp, elemid_str)
{

///alert(_server_resp);

	var elem_state ="false";
    var elemid=elemid_str;    

    var data= _server_resp;
  
    if (document.getElementById(elemid) !==null) 
    {
      elem_state="true";
      push_html(elemid, data);      
      push_newval(elemid, data);
      var elem_type=(document.getElementById(elemid).nodeName).toLowerCase();

      if(elem_type=='span')
      {
        push_html(elemid, data);
      }
       if(elem_type=='select')
      {
        push_html(elemid, data);
      }

      if(elem_type=='img')
      {
        push_src(elemid, data);
      }
      if(elem_type=='a')
      {
        push_link(elemid, data);
      }
  
  }
  
  ///console.log(elemid+" state "+ elem_state);
  ////return json_decoded_str;
}

function mosy_pop_window(market_location)
{
  window.open(atob(market_location), "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,width=1300,height=900");
    
}

function mosy_ajax_list(parent_id, label, qfunction, loop_id,height_class="max_height_70vh")
{
    var html_qloc= `
    <div class="row justify-content-center m-0 p-0 col-md-12 ">
    <input type="text" placeholder="${label}"  class="form-control mb-2" id="txt_q_${loop_id}" name="txt_q_${loop_id}" onkeyup="window['${qfunction}'](this.value)"/>
    </div>
    <div class="row justify-content-center m-0 p-0 col-md-12 ${height_class}" id="${loop_id}" style=""></div>`;
  
   mosy_card("", html_qloc,parent_id);
  
   window[qfunction]("")  
}



function mosy_countdown(push_to, count_to="17")
{
    var timeLeft = count_to;
  
    var timerId = setInterval(countdown, 1000);
    
    function countdown() 
    {
      if (timeLeft == -1) {
        
        clearTimeout(timerId);
        
      } else {
        push_html(push_to, timeLeft);
        timeLeft--;
      }
    }
  
  return timerId;

}


function mosy_delete_get_pram(param)
{
    // Get the URLSearchParams object from the current URL
  const urlParams = new URLSearchParams(window.location.search);

  // Check if the param parameter exists in the URL
  if (urlParams.has(param)) {
    // Delete the param parameter
    urlParams.delete(param);

    // Update the URL without the deleted parameter
    window.history.replaceState({}, "", `${location.pathname}?${urlParams}`);
  }
  
}

function mosy_update_get_param(param, newval)
{
  
      // Get the URLSearchParams object from the current URL
    const urlParams = new URLSearchParams(window.location.search);

    // Check if the "param" parameter exists in the URL
    if (urlParams.has(param)) {
      // Get the value of the param parameter
      const paramValue = urlParams.get(param);

      // Update the param parameter with a new value
      urlParams.set(param, newval);

      // Update the URL with the new parameter value
    } else {
      // Append the param parameter with a new value
      urlParams.append(param,newval);
    }

  window.history.replaceState({}, "", `${location.pathname}?${urlParams}`);

  
}


function mosy_required_form_inputs_required(form_id)
{
  var elements = document.getElementById(form_id).elements;
  var input_arr=[];
  
  for (var i = 0, element; element = elements[i++];) {

    if(element.hasAttribute('required'))
    {
      //do your stuff
      input_arr.push(element.id);
      
      console.log(" elent "+element.id)
    }
  }
  
 return mosy_validate_required(input_arr);

}


function mosy_required_form_inputs(elemid)
{
const divElement = document.getElementById(elemid);
const formElements = divElement.querySelectorAll("*");

var input_arr=[];

formElements.forEach((element) => {
  // Do something with each form element

    if(element.hasAttribute('required'))
    {
      //do your stuff
      input_arr.push(element.id);
      
      console.log(" elent "+element.id)
    }

});

 return mosy_validate_required(input_arr);

}


   const hive_post = document.querySelectorAll(".hive_post");
        hive_post.forEach(hive_post_elem => {
          hive_post_elem.addEventListener("click", event => {            
              const target = event.target;            
              var hive_trigger_node = target.getAttribute('data-hive_post');
              var hive_recall_node = target.getAttribute('data-hive_recall');
              var hive_required_node = target.getAttribute('data-hive_required');
              var hive_added_calldata = target.getAttribute('data-hive_added_calldata');
              var hive_route__ = target.getAttribute('data-hive_route');
              var hive_required_node_arr = "";            
                
            
              if (hive_required_node) {
              
                hive_required_node_arr = hive_required_node.split(',');            
                
              }
            
                // Check if any data attribute is missing, and skip the logic if so
              if (!hive_trigger_node) {
                hive_trigger_node=""
              }
            
              if (!hive_required_node) {
                hive_required_node_arr=""
              }            
            
              if (!hive_recall_node) {
                hive_recall_node=""
              }
            
              if (!hive_route__) {
                hive_route__=""
              }
            
              if (!hive_added_calldata) {
                hive_added_calldata=""
              }            
            
       		  mosy_form_data("mosy_form", hive_trigger_node, hive_recall_node, hive_added_calldata, hive_required_node_arr, hive_route__);

            })
          
          });


   const hive_get_ = document.querySelectorAll(".hive_get_tup");
        hive_get_.forEach(hive_get_elem_ => {
          hive_get_elem_.addEventListener("keyup", event => {            
            
              const target = event.target;            
              var hive_trigger_node = target.getAttribute('data-hive_get');
              var hive_recall_node = target.getAttribute('data-hive_recall');

              var hive_route__ = target.getAttribute('data-hive_route');
            
                // Check if any data attribute is missing, and skip the logic if so
              if (!hive_trigger_node) {
                hive_trigger_node=""
              }
            
              if (!hive_recall_node) {
                hive_recall_node=""
              }
            
              if (!hive_route__) {
                hive_route__=""
              }
          
            
              mosyajax_get(hive_trigger_node, hive_recall_node,hive_route__)

            })
          
          });


   const hive_get = document.querySelectorAll(".hive_get");
        hive_get.forEach(hive_get_elem => {
          hive_get_elem.addEventListener("click", event => {            
            
              const target = event.target;            
              var hive_trigger_node = target.getAttribute('data-hive_get');
              var hive_recall_node = target.getAttribute('data-hive_recall');

              var hive_route__ = target.getAttribute('data-hive_route');
            
                // Check if any data attribute is missing, and skip the logic if so
              if (!hive_trigger_node) {
                hive_trigger_node=""
              }
            
              if (!hive_recall_node) {
                hive_recall_node=""
              }
            
              if (!hive_route__) {
                hive_route__=""
              }
          
            
              mosyajax_get(hive_trigger_node, hive_recall_node,hive_route__)

            })
          
          });

// Add a click event listener to a parent element that contains dynamically created elements
document.addEventListener('click', function(event) {
  // Check if the clicked element has the class 'hive_dcall'
  if (event.target.classList.contains('hive_dcall')) {
    // Get the clicked element
    var hive_element = event.target;

    // Get the function name and arguments from data attributes
    var hive_functionName = hive_element.getAttribute('data-hive_dcall_fun');
    var hive_argsString = hive_element.getAttribute('data-hive_dcall_arg');
    var hive_args = hive_argsString ? hive_argsString.split(',') : [];

    // Check if the function exists before calling it
    if (typeof window[hive_functionName] === 'function') {
      // Call the function with arguments
      window[hive_functionName](...hive_args);
    } else {
      console.error('Function ' + hive_functionName + ' not found');
    }
  }
});


// Add a click event listener to a parent element that contains dynamically created elements
document.addEventListener('keyup', function(event) {
  // Check if the clicked element has the class 'hive_dcall'
  if (event.target.classList.contains('hive_dcall_tup')) {
    // Get the clicked element
    var hive_element = event.target;

    // Get the function name and arguments from data attributes
    var hive_functionName = hive_element.getAttribute('data-hive_dcall_fun');
    var hive_argsString = hive_element.getAttribute('data-hive_dcall_arg');
    var hive_args = hive_argsString ? hive_argsString.split(',') : [];

    // Check if the function exists before calling it
    if (typeof window[hive_functionName] === 'function') {
      // Call the function with arguments
      window[hive_functionName](...hive_args);
    } else {
      console.error('Function ' + hive_functionName + ' not found');
    }
  }
});


  
//======================

function loop_hive_template_(template_name="user_long_card", data_nodes, action_="")
{      
    const ui_template_ ={ user_long_card : `
        <!-- Start side bar image card list -->
        <div data-mosy_msdn="${action_}" class="bg-white text-primary rounded_meduim pt-2 pb-2 mb-1 justify-content-center col-md-12 shadow-sm border border-light cpointer mosy_msdn">
        <div class="row justify-content-center col-md-12">
            <div class="col-md-2 pt-3 text-center " id="">
                <img src="{{photo_node}}" class="useravatar_small shadow-sm" onerror="this.src='img/logo.png'"/>
            </div>
            <div class="col-10 text-left p-0" style="font-size:14px">
                <div class="p-1"><span class="h5">{{node1}}</span></div>
                <div class="p-1"><span>{{node2}}</span></div>
                <div class="text-info p-1"><em>{{node3}}</em></div>
            </div>
         </div>
        </div>
        <!-- End side bar image card list -->
    `,

    long_content_card: `
        <!-- Start side bar image card list -->
        <div data-mosy_msdn="${action_}" class="bg-white text-primary rounded_meduim pt-2 pb-2 mb-1 justify-content-center col-md-12 shadow-sm border border-light cpointer mosy_msdn">       
            <div class="col-12 text-left p-0" style="font-size:14px">
                <div class="p-1"><span class="h5">{{node1}}</span></div>
                <div class="p-1"><span>{{node2}}</span></div>
                <div class="text-info p-1"><em>{{node3}}</em></div>
            </div>
        </div>                                        
        <div class="col-md-12 p-0" id=""></div>
        <!-- End side bar image card list -->
    `,

    blog_card__ : `
        <!-- Start side bar image card list -->
        <div data-mosy_msdn="${action_}" class="bg-white text-primary rounded p-0 mb-3 mr-lg-3 justify-content-center col-md-3 border shadow-sm" cpointer mosy_msdn>
            <div class="col-md-12 p-0 text-center " id="">
                <div class="" style="position: relative; width: 100%; height: 200px; overflow: hidden;">
                    <div class="" style="position: absolute; width: 100%; height: 100%; background-image: url('{{photo_node}}'); filter: blur(8px);"></div>
                    <div class="" style="position: absolute; width: 100%; height: 100%;">
                        <img src="{{photo_node}}" style="width: 100%; height: 100%; object-fit: contain;" onerror="this.src='img/logo.png'">
                    </div>
                </div>                       
            </div>
            <div class="col-12 text-left p-3 border-top mb-3" style="">
                <div class="p-1"><span class="h5 ">{{node1}}</span></div>
                <div class="p-1 text-muted"><span>{{node2}}</span></div>
                <div class="text-info p-1"><em>{{node3}}</em></div>                       
            </div>                                      
            <div class="col-md-12 p-0 text-right pt-3" style="position:absolute; bottom:20px; right:15px; ">
                <span class="cpointer badge text-info">  View more <i class="fa fa-arrow-right"></i> </span>
            </div> 
        </div>
        <!-- End side bar image card list -->
    `,

    blog_card__no_blur : `
        <!-- Start side bar image card list -->
        <div data-mosy_msdn="${action_}" class="bg-white text-primary rounded p-0 mb-3 mr-lg-3 justify-content-center col-md-3 border shadow-sm cpointer mosy_msdn">
            <div class="col-md-12 p-0 text-center " id="">
                <div class="" style="position: relative; width: 100%; height: 200px; overflow: hidden;">
                    <div class="" style="position: absolute; width: 100%; height: 100%;"></div>
                    <div class="p-2 text-center" style="position: absolute; width: 100%; height: 100%;">
                        <img src="{{photo_node}}" style="width: 100%; height: 100%; object-fit: contain;" onerror="this.src='img/logo.png'">
                    </div>
                </div>                       
            </div>
            <div class="col-12 text-left p-3 border-top mb-3" style="">
                <div class="p-1"><span class="h5 ">{{node1}}</span></div>
                <div class="p-1 text-muted"><span>{{node2}}</span></div>
                <div class="text-info p-1"><em>{{node3}}</em></div>                       
            </div>                                      
            <div class="col-md-12 p-0 text-right pt-3" style="position:absolute; bottom:20px; right:15px; ">
                <span class="cpointer badge text-info">  View more <i class="fa fa-arrow-right"></i> </span>
            </div> 
        </div>
        <!-- End side bar image card list -->
    `,

    user_list_card : `
        <!-- Start side bar image card list -->
        <div  data-mosy_msdn="${action_}" class="bg-white text-primary rounded p-0 mb-3 mr-lg-3 justify-content-center col-md-2 border shadow cpointer mosy_msdn">
            <div class="col-md-12 p-4 text-center " id="">
                <img src="{{photo_node}}" class="shadow-sm" style="width: 100px; height: 100px; border-radius:50%;" onerror="this.src='img/logo.png'">
            </div>
            <div class="col-12 text-left p-3 border-top " style="">
                <div class="p-1"><span class="h6 ">{{node1}}</span></div>
                <div class="p-1 text-muted"><span>{{node2}}</span></div>
                <div class="text-info p-0 col-md-12 mb-0" style="word-wrap:break-word"><span class="badge text-secondary"> <i class="fa fa-envelope"></i> {{node3}}</span></div>
                <div class="text-info p-0 col-md-12 " style="word-wrap:break-word"><span class="badge text-secondary"><i class="fa fa-phone"></i>  {{node4}}</span></div>
            </div>
        </div>
        <!-- End side bar image card list -->
    `,

    timeline_card : `
        <!--- POST TIMELINE  card with image  --->
        <div data-mosy_msdn="${action_}" class="row rounded_medium  col-md-12 pb-3 mb-0  justify-content-left p-0 m-0 text-dark cpointer mosy_msdn">
            <!-- User image -->
            <div class="col-2 col-lg-1 text-left m-0 p-0">
                <div style="z-index:5; position:absolute; top:30%;" class="useravatar_small border  ctn_set"><i class="fa fa-envelope medium_icon ml-2 mt-2"></i></div>
                <div  class="m-2 ml-4 pb-0 pt-0 col-md-12 border-left border_set" style="position:absolute; bottom:0px; top:0%; z-index:1"><div class="p-0"></div></div>
            </div>
            <div class="col-10 col-lg-10 border shadow rounded_big p-4 ">
                <div class="p-2">
                    <b>{{node3}}</b>
                    <span class="text-muted badge pt-2 float-right">{{node1}}</span>
                </div><!-- /.username -->
                <div class="col-md-12 pt-lg-0 pt-1  p-0">{{node2}}</div>
            </div>
            <!-- /.comment-text -->
        </div>
        <!--- POST TIMELINE  card witg image --->
    `,     
                         
	column_search_list :`
             <div data-mosy_msdn="${action_}" class="mosy_msdn row m-0 p-0 col-md-12">
              <div class="col-md-12 text-left border-bottom cpointer p-2"><span class="">{{node1}}</span></div>  
             </div>
    `                         
  }
    
       //additional 

      var template = ui_template_[template_name];
    
      if(template_name.indexOf(":") >= 0)
      {
         var template_name_extraction=template_name.split(":");

         template=window[template_name_extraction[0]];

     }
  
     if(template_name=="table")
     {
       template=prepare_tbl_template(data_nodes,action_)
     }
     
    //additional      

    // Replace placeholders in the template with values from the data array
    for (var key in data_nodes) 
    {
        var placeholder = key;
        var replacement = data_nodes[key];
        template = template.replace(new RegExp(placeholder, 'g'), replacement);
    }

    return template;
  
}
  
  function plug_element(elementId, doping_node, position="afterend") 
  {
      var existingElement = document.getElementById(elementId);

      // Check if the existing element exists
      if (existingElement) {
        // Insert the new HTML after the existing element
        existingElement.insertAdjacentHTML(position, doping_node);
      } else {
        console.error('Element with ID ' + elementId + ' not found.');
      }
  }
  
   function mosy_inject_input_text(el, newText) {
   
       var cursorPos = $("#"+el+"").prop("selectionStart");
       var v = $("#"+el+"").val();
       var textBefore = v.substring(0,  cursorPos);
       var textAfter  = v.substring(cursorPos, v.length);
   
       $("#"+el+"").val(textBefore + newText + textAfter);
   }  
   
    // Function to remove an existing element by ID
    function unplug_element(elementId) {
      var existingElement = document.getElementById(elementId);
      // Check if the existing element exists
      if (existingElement) {
        existingElement.parentNode.removeChild(existingElement);
        console.log("elemet exisit")
      }else{

        console.log("element id "+elementId+" does not exisit")

      }
    }
  
    function checkelem(elemid)
    {
        if (document.getElementById(elemid) !==null) {

          return true;

          }else{
            return false
          }

    }

    function hive_elem_val(value="", exe_type="get_newval")
    {
      if(checkelem(value))
      {

        return window[exe_type](value)

      }else{
        return value
      }
    }
  
function hive_dsearch_ui(tbl_n_tray, qstr="", hive_data_template="", new_data_isle="",  new_pagination_isle="")
{      
      if(tbl_n_tray.indexOf(":") >= 0)
      {
         var table_n_tray_name_extraction=tbl_n_tray.split(":");
         var tbl=table_n_tray_name_extraction[0];
         var tray_template = table_n_tray_name_extraction[1];
         var add_pagination_isle = false;
         
         if(table_n_tray_name_extraction[2]!=undefined)
         {
          add_pagination_isle=true;    
         }

     }else{
      var tbl = tbl_n_tray
      var tray_template ="ps_dtray"
	  var add_pagination_isle = false;

     } 
     if(hive_data_template==""){
       hive_data_template='new_hive_'+tbl+'_data_template'
     }
    
	 if(new_data_isle=="")
     {
       new_data_isle='hive_'+tbl+'_data_isle'
     }
    
	 if(new_pagination_isle=="")
     {
      new_pagination_isle='hive_'+tbl+'_pagination_isle'
     }
                     
      if(tray_template=="cs_dtray"){
      var template_row= `
      <div class="m-0 p-3 col-md-12 row bg-white justify-content-center border shadow mosy_msdn" data-mosy_msdn="mosyhide_elem('${new_data_isle}')" style="max-height:200px; overflow-y:auto; position:absolute; width:100%; z-index:9999; padding-right:10px" id="${new_data_isle}">
      	<div class="col-md-12 text-center h5 "><i class="fa fa-spinner fa-spin"></i> Loading ...</div>
  	  </div>`;
      }else{
      var template_row= `
      <div class="m-0 p-3 col-md-12 row bg-white justify-content-center" style="overflow-y:auto; max-height:70vh;" id="${new_data_isle}">
      	<div class="col-md-12 text-center h4 "><i class="fa fa-spinner fa-spin"></i> Loading ...</div>
  	  </div>`;
      }
     
      var navigation_isle =`     
      <div class="row justify-content-center m-0 p-0 col-md-12" id="${new_pagination_isle}"></div> `      


      unplug_element(new_data_isle)
      unplug_element(new_pagination_isle)
      plug_element(qstr, template_row)
      
      if(add_pagination_isle=="true")
      {
       plug_element(new_data_isle, navigation_isle)
      }
  
}

 function hive_mosy_dsearch(tbl_n_tray, qstr="", hive_data_template="", new_data_isle="",  and_query="", tbl_pcol="", new_pagination_isle="",  pagination_prefix="",req_url="iptv")
  {
  
           ///console.log("tbl_n_tray "+tbl_n_tray)

      if(tbl_n_tray.indexOf(":") >= 0)
      {
         var table_n_tray_name_extraction=tbl_n_tray.split(":");
         var tbl=table_n_tray_name_extraction[0];
         var tray_template = table_n_tray_name_extraction[1];
         var add_pagination_isle = false;
         
         if(table_n_tray_name_extraction[2]!=undefined)
         {
          add_pagination_isle=true;    
         }

     }else{
      var tbl = tbl_n_tray
      var tray_template ="ps_dtray"
	  var add_pagination_isle = false;

     } 
     if(hive_data_template==""){
       hive_data_template='new_hive_'+tbl+'_data_template'
     }
    
	 if(new_data_isle=="")
     {
       new_data_isle='hive_'+tbl+'_data_isle'
     }
    
	 if(new_pagination_isle=="")
     {
      new_pagination_isle='hive_'+tbl+'_pagination_isle'
     }
	 
     if(pagination_prefix=="")
     {
       pagination_prefix='hive_'+tbl+'_pagination_prefix'
     }

               
      var  dynafun = '{"cbfun":"process__dsql_json_data","tbl":"'+tbl+'","_data_isle":"'+new_data_isle+'","_pagination_isle":"'+new_pagination_isle+'","_data_template":"'+hive_data_template+'","_payload_str":"req","_pagination_prefix":"'+pagination_prefix+'","req_url":"'+req_url+'"}';
      
      if(tray_template=="cs_dtray"){
      var template_row= `
      <div class="m-0 p-3 col-md-12 row bg-white justify-content-center border shadow mosy_msdn" data-mosy_msdn="mosyhide_elem('${new_data_isle}')" style="max-height:200px; overflow-y:auto; position:absolute; width:100%; z-index:9999; padding-right:10px" id="${new_data_isle}">
      	<div class="col-md-12 text-center h5 "><i class="fa fa-spinner fa-spin"></i> Loading ...</div>
  	  </div>`;
      }else{
      var template_row= `
      <div class="m-0 p-3 col-md-12 row bg-white justify-content-center" style="overflow-y:auto; max-height:70vh;" id="${new_data_isle}">
      	<div class="col-md-12 text-center h4 "><i class="fa fa-spinner fa-spin"></i> Loading ...</div>
  	  </div>`;
      }
     
      console.log(" tray_template  "+tray_template)

      var navigation_isle =`     
      <div class="row justify-content-center m-0 p-0 col-md-12" id="${new_pagination_isle}"></div> `      


      unplug_element(new_data_isle)
      unplug_element(new_pagination_isle)
      plug_element(qstr, template_row)
      
      if(add_pagination_isle=="true")
      {
       plug_element(new_data_isle, navigation_isle)
      }
      
      var dynamic_data_js_function="mosy_"+tbl+"_json_data_list"
      
      var tbl_n_pcol =tbl
      if(tbl_pcol!="")
      {
	
    	tbl_n_pcol=tbl+":"+tbl_pcol

      }
      
       
       if (and_query.includes(":")) {
        let parts = and_query.split(":");
        and_query=  atob(parts[1].trim()); // Use the second part after the colon, removing extra spaces
       }
       
      //var dataret =  window[dynamic_data_js_function](hive_elem_val(qstr), dynafun)  
      mosy__dsql_json_data_list(tbl_n_pcol, hive_elem_val(qstr), dynafun, and_query)
      
      //console.log(" ===  "+dataret)

    }

  function create_new_location(location, key)
  {
    new_location(location+btoa(key))
  }
  



function push_arrval(array_key_val)
{
  
  console.log(array_key_val)
  for(input_val of array_key_val)
  {
    var splitkey_val = input_val.split(":")
    var input_id = splitkey_val[0]
    var input_val = splitkey_val[1]
    
    console.log(input_id+" -- "+input_val)
      
    push_newval(input_id, input_val)
    push_html(input_id, input_val)
    push_src(input_id, input_val)
      
      
  }
}
                                                 
  
function create_mosy_filter(colval_arr, link_page_n_tbl)
{

  var link_params=""
  var filter_str_node =""
    
  for(colval_node of colval_arr)
  {
    
    var splitkey_val = colval_node.split(":")
    var col_name = splitkey_val[0]
    var col_val = splitkey_val[1]
    var val_type = splitkey_val[2]
      
    if(val_type!="?")
    {
      col_val=get_newval(col_val)
    }
      
     filter_str_node+=col_name+"='"+col_val+"' and "  
     console.log(colval_arr+"\n"+filter_str_node+" >><< ")
  }
  
  var clean_filter_node = filter_str_node.replace(/\s+and\s*$/, '');
  
  var link_page_n_tbl_split=link_page_n_tbl.split(":")
  var tbl_name= link_page_n_tbl_split[0]
  var link_page  =link_page_n_tbl_split[1]
  
  var link_params = "?"+tbl_name+"_mosyfilter="+btoa(clean_filter_node)  
  
  new_location(link_page+link_params)
    
}



 function mosy_live_search(tbl_n_plug_id, node_colname="{{primkey}}", action_fun="", and_query="", loop_temp="column_search_list", function_cols="",pagination="", _pagination_prefix_="",colstr="*", req_url="iptv")
 {

  var split_tbl_n_plug_id=tbl_n_plug_id.split(":")
  var tbl = split_tbl_n_plug_id[0]
  var input_box =split_tbl_n_plug_id[1]
  var query_type =split_tbl_n_plug_id[2]
  var node_colname_type =split_tbl_n_plug_id[3]
    
  var qstr = query_type
    
  if(query_type="?")
  {
    qstr=get_newval(input_box)
  }
  
  if(node_colname_type=="?")
  {
    node_colname="{{"+node_colname+"}}"
  }
    

  var split_action_fun_=action_fun.split(":")
  var isle_id__=magic_random_str(10)
    
  if(split_action_fun_[0]=="token")
  {
    var token_tbl_=split_action_fun_[1]
    var filter_key=split_action_fun_[2]
      
    if(filter_key=="?")
    {
      filter_key="primkey"
    }
    
    if(token_tbl_=="?")
    {
      token_tbl_=tbl
    }
      
    action_fun = "new_location('"+token_tbl_+"_profile?"+token_tbl_+"_uptoken='+btoa(\'{{"+filter_key+"}}\')+'')"
  }
  
  if(split_action_fun_[0]=="mf")
  {
    var filter__location_=split_action_fun_[1]
    var token_tbl_=split_action_fun_[2]
    var _mosyfilter_keys =split_action_fun_[3]
    let clean_filters = _mosyfilter_keys.replace(/{{/g, "\\'{{").replace(/}}/g, "}}\\'");
  
    action_fun = "new_location('"+filter__location_+"?"+token_tbl_+"_mosyfilter='+btoa(\'"+clean_filters+"\')+\'')"
  }
  
  
  
  var component_id=tbl 

  console.log("loop_tempname == "+loop_temp)
  var mosy_live_search_temp = component_id+"_mosy_live_search_temp"
  //additional 
  if(loop_temp=="table")
  {
   var template=loop_hive_template_(loop_temp, component_id+","+node_colname, action_fun+";unplug_element("+mosy_live_search_temp+")")
  }else{
  if(split_tbl_n_plug_id[4]!=undefined)
  {
     if(split_tbl_n_plug_id[4]=="ft")
     {
      var template = loop_hive_template_(loop_temp,{"{{node1}}":""+node_colname+""},action_fun+";unplug_element("+mosy_live_search_temp+")")
     }else{
      var template = loop_hive_template_(loop_temp,{"{{node1}}":""+node_colname+""},action_fun)
       
     }
  }else{
      var template = loop_hive_template_(loop_temp,{"{{node1}}":""+node_colname+""},action_fun)
    
  }
 }
  //additional 
  //additional 
  var data_container_style=''
    
  if(split_tbl_n_plug_id[4]!=undefined)
  {
     if(split_tbl_n_plug_id[4]=="ft")
     {
      data_container_style='style="max-height:200px; overflow-y:auto; position:absolute; width:100%; z-index:9999; padding-right:10px" onclick="this.style.display=\'none\'"'
     }
    
  }  
  
  var isle_n_template=`
     <div class="col-md-12 p-0 m-0 bg-white" id="${mosy_live_search_temp}"  ${data_container_style}>
      <div class="col-md-12 p-0 m-0  row justify-content-center" id="${component_id}_data_isle"></div> 
      <template id="${component_id}_data_template"></template>
      </div>
  ` 
     
   
  //additional   
  if(loop_temp=="table")
  {
    var full_table_grid=prepare_tbl_template(component_id+","+node_colname, action_fun)
      
    isle_n_template=`
     <div class="col-md-12 p-0 m-0 bg-white" id="${mosy_live_search_temp}"  ${data_container_style}>
      ${full_table_grid}
     </div>`
       
  }
                                                   
  unplug_element(mosy_live_search_temp)
  plug_element(input_box, isle_n_template)
  
  if(loop_temp!="table"){
   
    push_html(""+component_id+"_data_template", template)  
      
  }

  var tbl_col_span=""
  if(loop_temp=="table")
  {

    var array_cols = node_colname.split(",")
      
    tbl_col_span=":"+(array_cols.length)

  }
  
 //additional 

  var response_fun='{"cbfun":"process__dsql_json_data","tbl":"'+tbl+'","_data_isle":"'+component_id+'_data_isle'+tbl_col_span+'","_pagination_isle":"'+component_id+'_pagination_isle","_data_template":"'+component_id+'_data_template","_payload_str":"req","_pagination_prefix":"'+_pagination_prefix_+'","req_url":"'+req_url+'"}';
        
  mosy__dsql_json_data_list(tbl, qstr, response_fun, and_query, function_cols, pagination, _pagination_prefix_, colstr, req_url)
   
 }

   //additional 
      function prepare_tbl_template(csv_cols, action_fun="")
      {             
       
          console.log(" csv_cols == "+csv_cols)
          var array_cols = csv_cols.split(",")
            
          var tbl_header ="";
          var tbl_row ="";
          var template_id_=array_cols[0];
          var arr_count=0;
        
          for(td_col of array_cols)
          {
              
          if(arr_count!=0){
          var td_ui_col_name = td_col.replace("_"," ")
          var td_col_name=td_col
            
          if(td_col.indexOf(":") >= 0)
          {

            var td_col_split= td_col.split(":")
            var td_ui_col_name=td_col_split[1]
            var td_col_name=td_col_split[0]

          }
            
            
          tbl_header+=`
            <th scope="col">${td_ui_col_name}</th>
            `
          if(td_col_name=="_edit_")
          {
            tbl_row+=`<td scope="col" title="Edit"><i class="fa fa-pencil"></i></td>`
          }else{
          tbl_row+=`<td scope="col">{{${td_col_name}}}</td>`
            
          }            
            }
            arr_count++
            
          }       
          
          
         var tbl_template=`<!-- Start Table -->          
          <div class="table-responsive data-tables" style="padding-bottom: 150px;">
          <table class="table table-hover text-left">
            <thead class="text-uppercase bg-white sticky_scroll">
              <tr>
              ${tbl_header}
              </tr>
            </thead>
              <tbody id="${template_id_}_data_isle">
              </tbody>
          </table>
            <template id="${template_id_}_data_template">
               <tr class="cpointer mosy_msdn" data-mosy_msdn="${action_fun}">
                ${tbl_row}
               </tr>     
            </template>
               
          </div>
          <!-- End Table -->
          `             
          
        return tbl_template
                 
      }
  //additional
  
  function mosy_live_modal(modal_title, tbl_name, display_col, action_fun, and_query="")
 {
  
  var input_temp_id = magic_random_str(12)
  
   var mosy_live_modal_template=`
   
               <div class="form-group col-md-12">
                    <input class="m-0 form-control mosy_tup mosy_msdn" data-mosy_msdn="mosyauto_dropdown('${input_temp_id}')" data-mosy_tup="mosy_live_search('${tbl_name}:${input_temp_id}:?','${display_col}','${action_fun}', '${and_query}')"  id="${input_temp_id}" name="" value="" placeholder="${modal_title}" type="text">   
                    </div>
   `
   mosy_card(modal_title,mosy_live_modal_template)
 }
    
function mosy_livecu(action_name, callback_action='mosy_reload', required_inp='', additional_callbacks='', req_url='')
{
     
  mosy_form_data('mosy_form',  action_name, callback_action, additional_callbacks, required_inp,req_url)
             

}
 
   
function excelNavigate($) {
  $.fn.enableCellNavigation = function () {
    var arrow = {
      left: 37,
      up: 38,
      right: 39,
      down: 40
    };

    return this.each(function () {
      var $table = $(this);

      $table.find('input').keydown(function (e) {
        if ($.inArray(e.which, [arrow.left, arrow.up, arrow.right, arrow.down]) < 0) {
          return;
        }

        var $input = $(e.target);
        var $td = $input.closest('td');
        var moveTo = null;

        switch (e.which) {
          case arrow.left:
            if ($input[0].selectionStart == 0) {
              moveTo = $td.prev('td:has(input,textarea)');
            }
            break;
          case arrow.right:
            if ($input[0].selectionEnd == $input.val().length) {
              moveTo = $td.next('td:has(input,textarea)');
            }
            break;
          case arrow.up:
          case arrow.down:
            var $tr = $td.closest('tr');
            var pos = $td[0].cellIndex;
            var moveToRow = null;

            if (e.which == arrow.down) {
              moveToRow = $tr.next('tr');
            } else if (e.which == arrow.up) {
              moveToRow = $tr.prev('tr');
            }

            if (moveToRow.length) {
              moveTo = $(moveToRow[0].cells[pos]);
            }
            break;
        }

        if (moveTo && moveTo.length) {
          e.preventDefault();
          moveTo.find('input,textarea,td').each(function (i, input) {
            $(input).focus().select();
          });
        }
      });
    });
  };
}



//==================================

function create_mosy_profile(inputs_str, form_title="", crud_btns_="c:u:d", inject_to='' , additional_profile_btns_="")
{

  var split_inputs_str_=inputs_str.split(",")
    
  var form_group=""
    
  for (input_ of split_inputs_str_)
  {
    var split_input_attr_=input_.split(":")
      
    var input_id=split_input_attr_[0]
    var split_input_required=input_id.split("|")
    var required_attr=""
      
    if(split_input_required[1]!=undefined)
    {
      input_id=split_input_required[0]
      required_attr=split_input_required[1]
    }
    
    var cell_size ="col-md-4"
    
    if(split_input_attr_[3]!==undefined)
    {
      if(split_input_attr_[3]!="?"){
      
        cell_size=split_input_attr_[3]
        
      }
      
    }
    
    //add_lable_buttons
    var additions_label_btns_="";
    
    if(split_input_attr_[5]!=undefined)
    {
      
      var additions_label_btns_split=split_input_attr_[5].split("|")
      var label_btn_id_=additions_label_btns_split[0]
      var label_btn_name=additions_label_btns_split[1]
      var label_btn_icon=additions_label_btns_split[2]
      var label_btn_function=additions_label_btns_split[3]
         
      additions_label_btns_=`<span class="cpointer badge mosy_msdn ml-2 cpointer " data-mosy_msdn="${label_btn_function}"> <em> <i class="fa fa-${label_btn_icon}"></i> ${label_btn_name} </em></span>`

        
    
     }
    
    console.log(split_inputs_str_+ input_)
      
    var parts = input_id.split('_');
      
    // Extract all parts after the first one
    var remainingParts = parts.slice(1);

    // Capitalize each part and join them with spaces
    var col_name__ = remainingParts.map(function(part) {
        return part.charAt(0)+ part.slice(1);
    }).join('_');
    
    
    var label = remainingParts.map(function(part) {
        return part.charAt(0).toUpperCase() + part.slice(1);
    }).join(' ');
    
    if(split_input_attr_[1]!==undefined)
    {
    
      if(split_input_attr_[1]!="?")
      {
       label=split_input_attr_[1]
      }
    }
    
    var input_type="text"      
    if(split_input_attr_[2]!==undefined)
    {
      
     if(split_input_attr_[2]!="?"){
      input_type=split_input_attr_[2]
     }
      
    }
    
    var def_value__= ""
    if(input_type=="date")
    {
    
      def_value__=mosy_current_date() 
      
    }
    
    if(input_type=="datetime-local")
    {
    
      def_value__=mosy_current_datetime() 
      
    }    
    
    var input_component =`
        <label class="m-0 p-0 label_text " >${label}  ${additions_label_btns_}</label>                          
      <input class="m-0 form-control mosy_data_class_null mosy_data_class_${col_name__}" ${required_attr} id="${input_id}" name="${input_id}" value="${def_value__}" placeholder="${label}" type="${input_type}">`
      
    if(input_type=="password")
    {
      input_component+=`<input type="checkbox" onclick="show_password('${input_id}')"> <span class=""><em>Show Password</em></span>`
    }
    
    if(input_type=="textarea")
    {

      if(split_input_attr_[3]===undefined)
      {
        cell_size="col-md-12"
      }
      
      input_component=`
        <label class="m-0 p-0 label_text " >${label}  ${additions_label_btns_}</label>                            
        <textarea class="form-control m-0  mosy_data_class_${col_name__}"  ${required_attr} style="min-height:150px"  placeholder="${label}"></textarea>`
    }
    
    if(input_type=="sdd")
    {

      var dd_array=split_input_attr_[4].split("|")
      var dd_str=`<option  value="">${label}  ${additions_label_btns_}</option>`
        
      for(dd_node of dd_array)
      {
        dd_str+=`<option  value="${dd_node}">${dd_node}</option>`
      }
      
      input_component=`
        <label class="m-0 p-0 label_text " >${label}</label>                            
        <select class="form-control  mosy_data_class_${col_name__}"  ${required_attr} id="${input_id}" name="${input_id}">
           ${dd_str}
        </select>
        `
    }    
    
    if(input_type=="ddd")
    {

      var dd_str=`<option  value="">${label}  ${additions_label_btns_} </option>`
     
      var dd_toggle__=`
        <label><span>${label}</span> 
              <span id="_toggle_on_${input_id}" onclick="document.getElementById('${input_id}').type='text';push_newval('${input_id}', '');document.getElementById('sel_${input_id}').style.display='none';this.style.display='none';document.getElementById('_toggle_off_${input_id}').style.display='inline-block';" class="cpointer badge mosy_msdn"> <em> <i class="fa fa-plus"></i> Add new </em></span>
              
              <span style="display:none" id="_toggle_off_${input_id}" onclick="document.getElementById('${input_id}').type='hidden';document.getElementById('sel_${input_id}').style.display='block';this.style.display='none';document.getElementById('_toggle_on_${input_id}').style.display='inline-block';if(document.getElementById('${input_id}').value=='') document.getElementById('${input_id}').value=document.getElementById('sel_${input_id}').value" class="cpointer badge mosy_msdn"> <em> <i class="fa fa-list"></i> Use Options</em></span>

              </label>`
        
      input_component=`
        ${dd_toggle__}
        <input type="hidden" name="${input_id}" id="${input_id}"  ${required_attr} class="form-control" placeholder="Type new ${label}" value="">
        <select class="form-control" id="sel_${input_id}"  ${required_attr} name="sel_${input_id}">
           ${dd_str}
        </select>
        `
    } 
    
    if(input_type=='dsb')
    {
      
      var dsb_attr_=split_input_attr_[4].split("|")
      var mother_table = dsb_attr_[0]
      var record_id_col=dsb_attr_[1]
      var item_name_col_=dsb_attr_[2]
      var item_id_txt_=dsb_attr_[3]

       input_component=`
			<div class="col-md-12 p-0 m-0 " id="">
              <label>${label} ${additions_label_btns_}</label>                                                         
               <input autocomplete="off" type="text" name="${input_id}" id="${input_id}"  ${required_attr} class="form-control hive_dcall_tup" data-hive_dcall_fun="hive_mosy_dsearch" data-hive_dcall_arg="${mother_table}:cs_dtray,${input_id},_${mother_table}_name_${col_name__}_cstemp,_${mother_table}_name_${col_name__}_data_isle" placeholder="Search ${label}" value="">
              <template id="_${mother_table}_name_${col_name__}_cstemp">                             
                <div data-mosy_msdn="push_newval('${item_id_txt_}','{{${record_id_col}}}');push_newval('${input_id}','{{${item_name_col_}}}');mosyhide_elem('_${mother_table}_name_${col_name__}_data_isle')" class="mosy_msdn row justify-content-center m-0 p-0 col-md-12">
                  <div class="col-md-12 border-bottom cpointer p-2"><span class=""> <b>${label}</b> : {{${item_name_col_}}}</span></div>  
                </div>
              </template>
              <input type="hidden" name="${item_id_txt_}"  ${required_attr} id="${item_id_txt_}" value="">
             </div>
         `
        
    }
    if(input_type=="hidden")
    {
      cell_size="d-none"
    }
    
    form_group+=`               
     <div class="form-group ${cell_size} text-left hive_data_cell">    
        ${input_component}
     </div>`
  
   }
  
  //primary_table_name
  var split_btn_attr_=crud_btns_.split(",")
  var profile_tbl =split_btn_attr_[0]
    
  ///add new btn
  var add_new_btn=split_btn_attr_[1]
  var split_btn_attr_add_new= add_new_btn.split(":")  
  var add_new_btn_ui=profile_tbl+"_new_entry"
  var skip_add_new_cols=""
    
  if(split_btn_attr_add_new[2]!=undefined)
  {
    skip_add_new_cols=split_btn_attr_add_new[2]    
  }
  
  
  var add_new_btn_fun="toggle_cruds_new('"+profile_tbl+"','"+inject_to+"', '"+skip_add_new_cols+"')"

  if(split_btn_attr_add_new[3]!=undefined)
  {
  
    add_new_btn_fun=split_btn_attr_add_new[3]
    
  }
  
  
  if(split_btn_attr_add_new[1]!=undefined)
  {  
    add_new_btn_ui=split_btn_attr_add_new[1]  
    if(split_btn_attr_add_new[1]=="?")
    {
      add_new_btn_ui=profile_tbl+"_new_entry"
    }
    
    if(split_btn_attr_add_new[1]=="sk")
    {
       add_new_btn_ui =""
    }      
    
  }
  
    
  var del_ui_btn=split_btn_attr_[2]
  var split_btn_attr_del_rec= del_ui_btn.split(":")  
  var  del_rec_btn_ui=profile_tbl+"_del_entry"
    
  var del_rec_btn_fun="mosy_drop_rec('"+profile_tbl+"', 'mosy_reload')"
    
  if(split_btn_attr_del_rec[2]!=undefined)
  {
  
    del_rec_btn_fun=split_btn_attr_del_rec[2]
    
  }
  
  if(split_btn_attr_del_rec[1]!=undefined)
  {
    del_rec_btn_ui=split_btn_attr_del_rec[1]
  
    if(split_btn_attr_del_rec[1]=="sk")
    {
       del_rec_btn_ui =""
    }   
    
  }    
  
  var ins_ui_btn=split_btn_attr_[3]
  var split_btn_attr_ins_rec= ins_ui_btn.split(":")  
  var ins_rec_btn_ui=profile_tbl+"_insert_btn"
    
  var ins_rec_btn_name=split_btn_attr_ins_rec[2]
  
  
  if(split_btn_attr_ins_rec[1]!=undefined)
  {
    ins_rec_btn_ui=split_btn_attr_ins_rec[1]
    if(split_btn_attr_ins_rec[1]=="?")
    {
   
      ins_rec_btn_ui=profile_tbl+"_insert_btn"      
      
    }
    
    if(split_btn_attr_del_rec[1]=="sk")
    {
       ins_rec_btn_ui =""

    }
  }
    
  var ins_rec_btn_action="mosy_slivecu('"+ins_rec_btn_ui+"','toggle_server_resp_cruds:"+profile_tbl+"', '"+inject_to+"');"

  if(split_btn_attr_ins_rec[3]!=undefined)
  {
    ins_rec_btn_action="mosy_slivecu('"+ins_rec_btn_ui+"','toggle_server_resp_cruds:"+profile_tbl+"','"+inject_to+"');"+split_btn_attr_ins_rec[3]+""
  }
  
  
  var updt_ui_btn=split_btn_attr_[4]
  var split_btn_attr_updt_rec= updt_ui_btn.split(":")  
  var updt_rec_btn_ui =profile_tbl+"_update_btn"
  var updt_rec_btn_name=split_btn_attr_updt_rec[2]
  var updt_rec_btn_action=split_btn_attr_updt_rec[3]
    
  if(split_btn_attr_updt_rec[1]!=undefined){

    updt_rec_btn_ui = split_btn_attr_updt_rec[1]
    if(split_btn_attr_updt_rec[1]=="?")
    {
       updt_rec_btn_ui =profile_tbl+"_update_btn"
    }
    if(split_btn_attr_updt_rec[1]=="sk")
    {
       updt_rec_btn_ui =""

    }
  }
  var btn_icon__ = `<i class="fa fa-arrow-right"></i> `
  var updt_btn_icon__ = `<i class="fa fa-save"></i> `
    
  if(updt_rec_btn_name==undefined || updt_rec_btn_name=="?")
  {
    updt_rec_btn_name="Update"
  }
  
  if(ins_rec_btn_name==undefined || ins_rec_btn_name=="?")
  {
  
    ins_rec_btn_name="Proceed"
    
  }
  

  var ins_btn_component_ =`
            <button class="cpointer btn btn-primary mb-3 mosy_msdn" data-mosy_msdn="${ins_rec_btn_action}" type="button" id="${ins_rec_btn_ui}" name="${ins_rec_btn_ui}">${ins_rec_btn_name} ${btn_icon__}  </button>

    `
  
  if(ins_rec_btn_ui=="sk")
  {
  
    ins_btn_component_=""
    
  }
    
  var uptoken_input = `<input type="hidden" id="${profile_tbl}_uptoken" name="${profile_tbl}_uptoken" value=""/>`
  
  if(checkelem(profile_tbl+"_uptoken"))
  {
  
    uptoken_input=""
  }
  
  
  var updt_rec_btn_action="mosy_slivecu('"+updt_rec_btn_ui+"','toggle_server_resp_cruds:"+profile_tbl+"','"+inject_to+"');"

  if(split_btn_attr_updt_rec[3]!=undefined)
  {
    updt_rec_btn_action="mosy_slivecu('"+updt_rec_btn_ui+"','toggle_server_resp_cruds:"+profile_tbl+"','"+inject_to+"');"+split_btn_attr_updt_rec[3]+""
  }
  
  
  var updt_btn_component_ =`
            <button class="cpointer btn btn-primary mb-3  mosy_msdn d-none " data-mosy_msdn="${updt_rec_btn_action}" type="button" id="${updt_rec_btn_ui}" name="${updt_rec_btn_ui}">${updt_btn_icon__}  ${updt_rec_btn_name} </button>

    `
  
  if(updt_rec_btn_ui=="sk")
  {
  
    updt_btn_component_=""
    
  }
  
  
  var btn_container__=`
     <div class="col-md-12 text-right">
      ${ins_btn_component_} ${updt_btn_component_}
     </div>
    `
    
  var addnew_ui_btn_=""
  var delete_ui_btn_=""
    
  if(del_rec_btn_ui!=""){  
  
    delete_ui_btn_=`
          <button type="button" class="medium_btn border-danger btn-white text-danger hive_list_nav_refresh ml-3 d-none mosy_msdn" data-mosy_msdn="${del_rec_btn_fun}"  id="${del_rec_btn_ui}" name="${del_rec_btn_ui}"><i class="fa fa-trash mr-1 "></i> Delete </button>      
    `
  }
  
  
  if(add_new_btn_ui!=""){  
  
    addnew_ui_btn_=`
      <button type="button" class="medium_btn border border_set btn-primary ml-3 hive_list_nav_new mosy_msdn d-none" data-mosy_msdn="${add_new_btn_fun}" id="${add_new_btn_ui}" name="${add_new_btn_ui}"><i class="fa fa-plus-circle"></i>  Add new </button>
    `
      
  }
   
  var additions_power_btns_=""
    
  if(additional_profile_btns_!=""){
    
    var split_power_btns__=additional_profile_btns_.split("|")
    for (power_btn_arr_node of split_power_btns__){
      
      var power_btn_attr__=power_btn_arr_node.split(":")
      var power_btn_name__=power_btn_attr__[1]
      var power_btn_id__=power_btn_attr__[0]
      var power_btn_icon__=power_btn_attr__[2]
      var power_btn_function__=power_btn_attr__[3]

        additions_power_btns_+=`        
         <!-- start power button  -->    	
           <button type="button" class="medium_btn border border_set btn-white text-dark hive_list_nav_refresh ml-3 mosy_msdn" id="${power_btn_id__}" data-mosy_msdn="${power_btn_function__}" > 
               <i class="fa fa-${power_btn_icon__}"></i> ${power_btn_name__}
            </button>          	                          					         
          <!-- End power button  -->`
     }
    
    }
        
  var delete_add_new_btn__=`    
     <div class="col-md-12 hive_list_nav_right_ribbon text-right " id=""> 
       ${additions_power_btns_}
       ${addnew_ui_btn_}
  
       ${delete_ui_btn_}
  
      <div class="col-md-12 pt-3 p-0" id=""></div>
    </div>    
    `
    
  var main_container__=`
    <div class="row justify-content-left m-0 p-0 col-md-12 pt-3">
      ${delete_add_new_btn__}
      ${form_group}
      ${btn_container__} 
      ${uptoken_input}
    </div>
    `
    
  mosy_card(form_title, main_container__, inject_to)

  
}


///console.log(ajax_url)

function create_mosy_list(tbl_n_hook, col_nodes, action_fun="", and_query="", template_type="table")
{

  var tbl = tbl_n_hook
    
  if(tbl_n_hook.indexOf(":") >= 0)
  {
  
    var table_n_tray_name_extraction=tbl_n_hook.split(":");
    
    var tbl=table_n_tray_name_extraction[0];
    
  }
  
  var action_str_="push_newval('"+tbl+"_uptoken', btoa('{{primkey}}'));mginitialize__dsql('"+tbl+"', '{{primkey}}');"
  
  if(action_fun!="")
  {
  
    action_str_=action_fun
    
  }   
  var split_crud_btn__=action_fun.split(":")
    
  if(split_crud_btn__[0]=="mosy_crud")
  {
     action_str_="toggle_row_cruds('"+tbl+"','{{primkey}}')"

  }
  

  
  mosy_live_search(tbl_n_hook, col_nodes, action_str_, and_query, template_type)
  
  //mosy_live_search(tbl_n_plug_id, node_colname="{{primkey}}", action_fun="", and_query="", loop_temp="column_search_list", function_cols="",pagination="", _pagination_prefix_="",colstr="*", req_url="assemblyui")

  
}


function mosy_drop_rec(tbl_name, callback_fun="mosy_response")
{
  
  toggle_cruds_new(tbl_name)
  mosy_snack_wgt('<i class="fa fa-spinner fa-spin"></i> Sending Request...', "top", 'snack_box', "200px", "table_alert_toast", '#000', '#fff', '')
  mosytoggle_class('table_alert_toast', 'show');
  
  magic_yes_no_alert('Delete record?', 'alert_box', 'mosyajax_get(\'conf_delete'+tbl_name+'&'+tbl_name+'_uptoken='+(get_newval(tbl_name+"_uptoken"))+'\', \''+callback_fun+'\')', 'mosy_reload()')
}

function toggle_row_cruds(tbl, tbl_key)
{
  toggle_cruds_update(tbl)
  push_newval(tbl+'_uptoken', btoa(tbl_key));
  mginitialize__dsql(tbl, tbl_key);
  mosy_update_get_param(tbl+'_uptoken', btoa(tbl_key))
  
  
}


function toggle_server_resp_cruds(tbl_key,tbl)
{
  
  mosy_snack_wgt('<i class="fa fa-check-circle"></i> Request processed successfully.', "top", 'snack_box', "200px", "table_alert_toast", '#000', '#fff', '')
  mosytoggle_class('table_alert_toast', 'show');
  
      setInterval(function () 
      {

        push_html('snack_box')
        //function code here      

      }, 3000);
  
  
  push_newval(tbl+'_uptoken', btoa(tbl_key));
  mginitialize__dsql(tbl, tbl_key);

  mosytoggle_addclass(tbl+"_insert_btn", "d-none")
  mosytoggle_remclass(tbl+"_update_btn", "d-none")
  mosytoggle_remclass(tbl+"_new_entry",  "d-none")
  mosytoggle_remclass(tbl+"_del_entry",  "d-none")   
    
  mosy_update_get_param(tbl+"_uptoken", btoa(tbl_key))  
}

function toggle_cruds_update(tbl)
{
  
  mosytoggle_addclass(tbl+"_insert_btn", "d-none")
    
  mosytoggle_remclass(tbl+"_update_btn", "d-none")
  mosytoggle_remclass(tbl+"_new_entry",  "d-none")
  mosytoggle_remclass(tbl+"_del_entry",  "d-none")  

    
}

function toggle_cruds_new(tbl, parent_container="", skip_cols="")
{
  if(parent_container!=""){mosy_clearInputs(parent_container,skip_cols);}
  
  mosytoggle_remclass(tbl+"_insert_btn", "d-none")
    
  mosytoggle_addclass(tbl+"_update_btn", "d-none")
  mosytoggle_addclass(tbl+"_new_entry",  "d-none")
  mosytoggle_addclass(tbl+"_del_entry",  "d-none")  

    
}


function mosy_slivecu(action_name, callback_action='mosy_response', inputs_form_container='', additional_callbacks='', req_url='iptv')
{
  
  
  var required_valid="1"
    
  if(inputs_form_container!=""){
   required_valid = mosy_required_form_inputs(inputs_form_container)
    
    }
  
  if(required_valid=="1"){
  
  mosy_snack_wgt('<i class="fa fa-spinner fa-spin"></i> Sending Request...', "top", 'snack_box', "200px", "table_alert_toast", '#000', '#fff', '')
  mosytoggle_class('table_alert_toast', 'show');
    
    mosy_form_data('mosy_form',  action_name, callback_action, additional_callbacks, '',req_url)
      
  }         

}


function mosy_clearInputs(containerId, skip_cols="") {
    var container = document.getElementById(containerId);
    var inputs = container.querySelectorAll('input, textarea, select');
    
    var skipIds = skip_cols.split('|').map(function(id) {
        return id.trim();
    });
    
    inputs.forEach(function(input) {
        if (skipIds.includes(input.id)) {
            return; // Skip clearing this input's value
        }
        input.value = '';
    });
}

function mosy_current_date() {
  const today = new Date();
  const year = today.getFullYear();
  let month = today.getMonth() + 1;
  let day = today.getDate();

  // Add leading zero if month/day is a single digit
  month = month < 10 ? '0' + month : month;
  day = day < 10 ? '0' + day : day;

  return year + '-' + month + '-' + day;
}

function mosy_current_datetime() {
  const today = new Date();
  const year = today.getFullYear();
  let month = today.getMonth() + 1;
  let day = today.getDate();
  let hours = today.getHours();
  let minutes = today.getMinutes();
  let seconds = today.getSeconds();

  // Add leading zero if month/day/hours/minutes/seconds is a single digit
  month = month < 10 ? '0' + month : month;
  day = day < 10 ? '0' + day : day;
  hours = hours < 10 ? '0' + hours : hours;
  minutes = minutes < 10 ? '0' + minutes : minutes;
  seconds = seconds < 10 ? '0' + seconds : seconds;

  return year + '-' + month + '-' + day + 'T' + hours + ':' + minutes + ':' + seconds;
}


function mosy_update_get_param(param_name, param_value) {
  // Get the current URL
  let currentUrl = window.location.href;

  // Extract existing parameters from the URL
  const urlParams = new URLSearchParams(window.location.search);

  // Check if the parameter already exists in the URL
  if (urlParams.has(param_name)) {
    // Update the parameter value
    urlParams.set(param_name, param_value);
  } else {
    // Add the new parameter
    urlParams.append(param_name, param_value);
  }

  // Construct the new URL with updated parameters
  const newUrl = currentUrl.split('?')[0] + '?' + urlParams.toString();

  // Update the address bar
  window.history.replaceState({}, document.title, newUrl);
  
}



    function mosy_print_excel(tblname, tbl_title) {
        const table = document.getElementById(tblname);
        
        // Remove the first column from the table
        const rows = table.getElementsByTagName('tr');
        for (let i = 0; i < rows.length; i++) {
            rows[i].deleteCell(0);
        }

    	$("#"+tblname+"").table2excel({
    		//exclude: ".no-export",
    		filename: tbl_title+".xls",
    		fileext: ".xls",
    		exclude_links: true,
    		exclude_inputs: true
    	});
      
       
       location.reload();

        
    }
    
function mosyauto_dropdown(elementId, key="ArrowDown") {
  // Select the input element
  var inputElement = document.getElementById(elementId);

  // Add a click event listener to the input element
  inputElement.addEventListener('click', function() {
    // Create a new KeyboardEvent
    var event = new KeyboardEvent('keyup', {
      bubbles: true,
      cancelable: true,
      key: key || 'a', // Default key is 'a' if not provided
    });

    // Dispatch the event on the input element
    inputElement.dispatchEvent(event);
  });
}


function magic_strip_str(text, maxLength = 50) {
    try {

        if (text.length > maxLength) {
            return text.substring(0, maxLength) + "...";  // Adding ellipsis to indicate trimming
        }
        return text;
    } catch (error) {
        console.error("Error in magic_strip_str:", error.message);
        return "";  // Return an empty string or a default value
    }
}




