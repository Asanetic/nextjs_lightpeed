
<script type="text/javascript">var iptv_primary_domain = "<?php echo $hive_routes["iptv"]; ?>"</script>      
<script src="js/hives/jsmagicbits.js"></script>
<script src="js/hives/hive_node_control.js?v=4243"></script>
