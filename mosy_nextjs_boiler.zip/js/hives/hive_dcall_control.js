
    
    function  gft__dsql(q_dsql_str, tbl="")
    {
        var _dsql_var_to_replace = "{{q"+tbl+"}}";
        var new__dsql_regex = new RegExp(_dsql_var_to_replace, "g");
        var data_nodes_clean__dsql_filter_str = window["wh_gft_"+tbl+"_str"].replace(new__dsql_regex, magic_clean_str(q_dsql_str));

        return  data_nodes_clean__dsql_filter_str;
    }    
    
  function mosy__dsql_ui_node (_dsql_json_data, _dsql_load_to, _dsql_cols_, _dsql_template_ui)
  {
     ////alert(_dsql_template_ui);
     var _dsql_cols_fun_cols_str ="";
     
     if(typeof _dsql_cols_fun_cols !== "undefined")
      {
        _dsql_cols_fun_cols_str=_dsql_cols_fun_cols;
        
        ///alert(_dsql_cols_fun_cols)
      } 
      
     var _dsql_ui__ = mosy_list_render_(_dsql_json_data, _dsql_cols_fun_cols_str+_dsql_cols_, _dsql_template_ui) 

     ////push_html(_dsql_load_to, _dsql_ui__)  

     push_grid_result(_dsql_ui__, _dsql_load_to)
  }
  
 
 ///////
 
 var _dsql_auto_function= '{"cbfun":"process__dsql_json_data","_data_isle":"_dsql_data_isle","_pagination_isle":"_dsql_pagination_isle","_data_template":"hive__dsql_data_template","_payload_str":"req","_pagination_prefix":"__pgnt__dsql","req_url":"iptv"}';

 
 
 ///============ auto renders 
 
 
function mosy__dsql_json_data_list(new_tbl, qstr="", response_fun="", and_query="", function_cols="", pagination="", _pagination_prefix_="", colstr="*", req_url="iptv")
{
 
   var tblkey ="primkey";
   var tbl = new_tbl;
   
   if(tbl.indexOf(":") >= 0)
   {
     var split_tbl_=tbl.split(":")
     tbl = split_tbl_[0]
     tblkey = split_tbl_[1];
   }

  /*if(qstr!="")
  {
   mosy_update_get_param("_dsql", btoa(qstr))
  }else{
    mosy_delete_get_pram("_dsql")
  }
  
  if(mosy_get_param("_dsql")!==undefined)
  {
    qstr=atob(mosy_get_param("_dsql"))
  }
  */ 
  var and_query_str=and_query;
  
  /*if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }*/
  
  if(pagination==="")
  {
    pagination="l:"+tbl+"_page_no:"+mosy_limit;
  }
  
  if(_pagination_prefix_==="")
  {
    _pagination_prefix_=""+tbl+"_pagination_prefix_input";
  }
  
  ///hive__dsql_data_template

  console.log("mosy__dsql_json_data_list == "+new_tbl+" tbl key "+tblkey)
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process__dsql_json_data","tbl":"'+tbl+'","_data_isle":"'+tbl+'_data_isle","_pagination_isle":"'+tbl+'_pagination_isle","_data_template":"'+tbl+'_data_template","_payload_str":"req","_pagination_prefix":"'+_pagination_prefix_+'","req_url":"'+req_url+'"}';
            
  }
  
  return mosyrender__dsql_(tbl, response_fun," where "+gft__dsql(qstr, tbl)+" "+and_query_str+"  order by "+tblkey+" desc ",function_cols,colstr,pagination, _pagination_prefix_,req_url)
  
}


  
  function autoprocess__dsql_json_data(_dsql_server_resp, tbl)
  {  
    mosy__dsql_ui_node(_dsql_server_resp, "_dsql_data_isle", _dsql_data_nodes, window["hive_"+tbl+"_data_template"],"", "l:"+tbl+"_page_no:15")
    mosy_paginate_api(_dsql_server_resp, ""+tbl+"_page_no", ""+tbl+"_pagination_isle", "15")
  }
  
  function process__dsql_json_data(_dsql_server_resp, _dsql_callback="")
  {  
      var _dsql_data_isle="_dsql_data_isle";
      var _dsql_data_node_template="hive__dsql_data_template";
      var _dsql_pagination_isle="_dsql_pagination_isle";
      var _dsql_payload_str="";
      var _dsql__pagination_prefix_str="__pgnt__dsql";
      var _dsql__tbl_src="__tbl_src_dsql";
      
       ///alert(_dsql_callback)
       ///alert(_dsql_server_resp)
       ///console.log(_dsql_server_resp)
              
      try {
        
           const _dsql_jsonObject = JSON.parse(_dsql_callback);
        
           _dsql_data_isle=_dsql_jsonObject._data_isle;
           _dsql_data_node_template=_dsql_jsonObject._data_template;
           _dsql_pagination_isle=_dsql_jsonObject._pagination_isle;
           _dsql_payload_str=_dsql_jsonObject._payload_str;
           _dsql__pagination_prefix_str=_dsql_jsonObject._pagination_prefix;
           _dsql__req_url=_dsql_jsonObject.req_url;
           _dsql__tbl_src=_dsql_jsonObject.tbl;
           
           ///console.log("paginate == : valid JSON"+_dsql_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+_dsql_callback);
        
         if(_dsql_callback.indexOf(",") >= 0)
         {
              _dsql_data_handler_ui =_dsql_callback.split(",");                                 

              if(_dsql_data_handler_ui[0]!=undefined){ _dsql_data_isle=_dsql_data_handler_ui[0];}

              if(_dsql_data_handler_ui[1]!=undefined){ _dsql_data_node_template =_dsql_data_handler_ui[1];}

              if(_dsql_data_handler_ui[2]!=undefined){ _dsql_pagination_isle=_dsql_data_handler_ui[2]};

              if(_dsql_data_handler_ui[3]!=undefined){ _dsql_payload_str=btoa(_dsql_data_handler_ui[3])};
              
              if(_dsql_data_handler_ui[4]!=undefined){ _dsql__pagination_prefix_str=btoa(_dsql_data_handler_ui[4])};

			  if(_dsql_data_handler_ui[5]!=undefined){ _dsql__req_url=_dsql_data_handler_ui[5]};                            
              
			  if(_dsql_data_handler_ui[6]!=undefined){ _dsql__tbl_src=_dsql_data_handler_ui[5]};                            
              
         }       
        
      }

       ///alert(" dtisle == "+_dsql_data_isle)
       
            mosy__dsql_ui_node(_dsql_server_resp, _dsql_data_isle, window["wh_"+_dsql__tbl_src+"_data_nodes"], get_html(_dsql_data_node_template),"", "l:"+_dsql__tbl_src+"_page_no:"+mosy_limit)                       
            
             if(_dsql_payload_str==="req")
             {
                
                mosy_paginate_api(_dsql_server_resp, ""+_dsql__tbl_src+"_page_no", _dsql_pagination_isle, "process__dsql_json_data", _dsql__pagination_prefix_str,_dsql__req_url)

             }
           
  }
    

function mosyrender__dsql_(tbl, response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt__dsql", req_url="iptv")
{
   
  if(pagination==="")
  {
    pagination="l:"+tbl+"_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var __dsql_payload="mosyget_&skipurldecode&tbl="+tbl+"&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(__dsql_payload+curl_url)
  
  var __dsql_pagination_json = '{"_payload":"'+__dsql_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const __dsql_payload_input = document.createElement("input");
                __dsql_payload_input.setAttribute('type', 'hidden');
                __dsql_payload_input.setAttribute('name',_txt_payload);
                __dsql_payload_input.setAttribute('id', _txt_payload);

                // Add the __dsql_payload_input element to the DOM
                document.body.appendChild(__dsql_payload_input);
                
      }
      
    var route_to = hiveRoutes[req_url];
    
    if(req_url=="")
    {
     route_to=ajax_url;
    }
      
  push_newval(_txt_payload, __dsql_pagination_json)
  mosyajax_get(__dsql_payload, response_fun, req_url);
  
  return __dsql_payload;
  
}


function mginitialize__dsql(new_tbl,reqkey, response_fun="", function_cols="", req_url="")
{
  
     var tblkey ="primkey";
     var tbl = new_tbl;

     if(tbl.indexOf(":") >= 0)
     {
       var split_tbl_=tbl.split(":")
       tbl = split_tbl_[0]
       tblkey = split_tbl_[1];
     }
   
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var __dsql_payload="mosyget_&skipurldecode&tbl="+tbl+"&colstr="+btoa("*")+"&where_str="+btoa(" where "+tblkey+" ='"+reqkey+"' ")+"&pagination=l&function_cols="+function_cols;
   
    var route_to = hiveRoutes[req_url];
    
    if(req_url=="")
    {
     route_to=ajax_url;
    }
      
     mosyajax_get(__dsql_payload, response_fun, req_url);


}


  

//==================================================                      simplified mosy_list call                          ============================*******************

//render data
function mosysql_render_list_(json_data, template_ui_name, default_trim="70")
{
  
  var template_ui =get_html(template_ui_name)
    
  // Regular expression to match {{}} placeholders
    var matches = template_ui.match(/{{(.*?)}}/g);

    // Array to store extracted words
    var extractedWords = "";

    // Loop through matches and extract the words inside {{}}
    matches.forEach(function(match) {
        // Remove {{ and }} from the matched string
        var extracted = match.substring(2, match.length - 2);
        // Push extracted word to the array
        extractedWords +=("{{"+extracted+"}}|");
    });

  //compute sum rows
      // Create a temporary div element
    var tempDiv = document.createElement('table');
    
    // Set the innerHTML of the temporary div to the template string
    tempDiv.innerHTML = template_ui;
          
    // Check if the temporary div contains an element with ID "sum_cols"
    var hasSumRows = tempDiv.querySelector('#sum_cols') !== null;
        
  if(hasSumRows)
  {
    //sum cols array 
    var sum_cols_csv=get_html('sum_cols')
    var split_col_csv_ = sum_cols_csv.split(",")      
      
    console.log("sum_cols_csv "+sum_cols_csv+" split_col_csv_ "+split_col_csv_)
      
    for(sum_node of split_col_csv_)
    {
       window["js_"+sum_node] =0;
      
      console.log("sum_node ++ "+sum_node+" "+window["js_"+sum_node])
    }
    
  }  

  // Check if the temporary div contains an element with ID "img_cols"

  var hasImgCols =  tempDiv.querySelector('#img_cols') !== null;
     
  var template_values = extractedWords
  var modified_template_values = template_values.slice(0, -1);
  
  var parse_serv_json=JSON.parse(json_data);
   
  var str_node = "";    
  var re = new RegExp(modified_template_values, "gi");


  for(datanode of parse_serv_json.data)
  {   
    
        if(hasSumRows)
        {

          for(sum_node of split_col_csv_)
          {
            window["js_" + sum_node] = Number(window["js_" + sum_node]) + Number(datanode[sum_node]);
          }
          
        }    
    
      str_node+= template_ui.replace(re, function (node) {

        var tbl_col_name = node.replace(/[{{}}]/g, "")
        var datanode_val =  magic_strip_str(datanode[tbl_col_name], default_trim);               
        if(hasImgCols)
        {
                           
         var img_cols_csv=get_html('img_cols')
         var split_img_col_csv_ = img_cols_csv.split(",")  
           
         console.log("imgggg_node ++ "+tbl_col_name+" ++ "+split_img_col_csv_)
           
         if(split_img_col_csv_.includes(tbl_col_name))
         {
            datanode_val = datanode[tbl_col_name]

            //new image implementation
            if(datanode_val=="")
            {
              datanode_val="img/logo.png"
            }
          
          }  
        }
        
        
        if(hasSumRows)
        {
          
          if(split_col_csv_.includes(tbl_col_name))
          {
            datanode_val=tonum(datanode[tbl_col_name])
          }

        }
        

        return datanode_val;
      }); 
  }
     
  var sum_node_final_res=[]
  if(hasSumRows)
  {

    for(sum_node of split_col_csv_)
    {
      
      sum_node_final_res.push({ [sum_node]: window["js_" + sum_node] });
            
    }
  }
  

    // Loop through each object in sum_node_final_res
    for (var i = 0; i < sum_node_final_res.length; i++) {
        // Access the current object
        var obj = sum_node_final_res[i];

        // Iterate over each key-value pair in the current object
        for (var key in obj) {
            if (obj.hasOwnProperty(key)) {
                // Log the key and its corresponding value
              
                push_html('js_sum_'+key, tonum(obj[key]) )
            }
        }
    }

  
  return str_node;
  
}

 //process data 
  function mosysql_process_jsondata(_dsql_server_resp, _dsql_callback="")
  {
      var _dsql_data_isle="_dsql_data_isle";
      var _dsql_data_node_template="hive__dsql_data_template";
      var _dsql_pagination_isle="_dsql_pagination_isle";
      var _dsql_payload_str="";
      var _dsql__pagination_prefix_str="__pgnt__dsql";
      var _dsql__tbl_src="__tbl_src_dsql";
      
       ///alert(_dsql_callback)
       ///alert(_dsql_server_resp)
       ///console.log(_dsql_server_resp)
              
      try {
        
           const _dsql_jsonObject = JSON.parse(_dsql_callback);
        
           _dsql_data_isle=_dsql_jsonObject._data_isle;
           _dsql_data_node_template=_dsql_jsonObject._data_template;
           _dsql_pagination_isle=_dsql_jsonObject._pagination_isle;
           _dsql_payload_str=_dsql_jsonObject._payload_str;
           _dsql__pagination_prefix_str=_dsql_jsonObject._pagination_prefix;
           _dsql__req_url=_dsql_jsonObject.req_url;
           _dsql__tbl_src=_dsql_jsonObject.tbl;
           
           ///console.log("paginate == : valid JSON"+_dsql_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+_dsql_callback);
        
         if(_dsql_callback.indexOf(",") >= 0)
         {
              _dsql_data_handler_ui =_dsql_callback.split(",");                                 

              if(_dsql_data_handler_ui[0]!=undefined){ _dsql_data_isle=_dsql_data_handler_ui[0];}

              if(_dsql_data_handler_ui[1]!=undefined){ _dsql_data_node_template =_dsql_data_handler_ui[1];}

              if(_dsql_data_handler_ui[2]!=undefined){ _dsql_pagination_isle=_dsql_data_handler_ui[2]};

              if(_dsql_data_handler_ui[3]!=undefined){ _dsql_payload_str=btoa(_dsql_data_handler_ui[3])};
              
              if(_dsql_data_handler_ui[4]!=undefined){ _dsql__pagination_prefix_str=btoa(_dsql_data_handler_ui[4])};

			  if(_dsql_data_handler_ui[5]!=undefined){ _dsql__req_url=_dsql_data_handler_ui[5]};                            
              
			  if(_dsql_data_handler_ui[6]!=undefined){ _dsql__tbl_src=_dsql_data_handler_ui[5]};                            
              
         }       
        
      }

       ///alert(" dtisle == "+_dsql_data_isle)
                   
            var processed_template = mosysql_render_list_(_dsql_server_resp, _dsql_data_node_template)
              
            push_grid_result(processed_template, _dsql_data_isle)
              
            if(_dsql_payload_str==="req")
            {
                
               mosy_paginate_api(_dsql_server_resp, ""+_dsql__tbl_src+"_page_no", _dsql_pagination_isle, "mosysql_process_jsondata", _dsql__pagination_prefix_str,_dsql__req_url)

            }
           
  
  }


//fetch data 
function mosysql_jsondata(tbl, where_str="", response_fun="", function_cols="", colstr="*", pagination="", _txt_payload="__pgnt__dsql", req_url="gridmaster")
{
   
  if(pagination==="")
  {
    pagination="l:"+tbl+"_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var __dsql_payload="mosyget_&skipurldecode&tbl="+tbl+"&colstr="+btoa(colstr)+"&where_str="+(where_str)+"&pagination="+pagination+"&function_cols="+(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(__dsql_payload+curl_url)
  
  if(response_fun=="")
  {
      response_fun='{"cbfun":"mosysql_process_jsondata","tbl":"'+tbl+'","_data_isle":"'+tbl+'_data_isle","_pagination_isle":"'+tbl+'_pagination_isle","_data_template":"'+tbl+'_data_template","_payload_str":"req","_pagination_prefix":"'+_pagination_prefix_+'","req_url":"'+req_url+'"}';
            
  }
  
  var __dsql_pagination_json = '{"_payload":"'+__dsql_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const __dsql_payload_input = document.createElement("input");
                __dsql_payload_input.setAttribute('type', 'hidden');
                __dsql_payload_input.setAttribute('name',_txt_payload);
                __dsql_payload_input.setAttribute('id', _txt_payload);

                // Add the __dsql_payload_input element to the DOM
                document.body.appendChild(__dsql_payload_input);
                
      }
      
    var route_to = hiveRoutes[req_url];
    
    if(req_url=="")
    {
     route_to=ajax_url;
    }
      
  push_newval(_txt_payload, __dsql_pagination_json)
  mosyajax_get(__dsql_payload, response_fun, req_url);
  
  return __dsql_payload;
  
}

//==================================================                      simplified mosy_list call                          ============================*******************



 

