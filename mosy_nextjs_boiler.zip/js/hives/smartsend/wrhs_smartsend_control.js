
   
   
     /***************************************** global data warehouse for account_urls ***********************************/
   var wh_account_urls_list_cols ="primkey:primkey,record_id:record_id,url_name:url_name,url:url,description:description,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start account_urls search columns 
   
   var wh_gft_account_urls_str="(primkey LIKE '%{{qaccount_urls}}%' OR  record_id LIKE '%{{qaccount_urls}}%' OR  url_name LIKE '%{{qaccount_urls}}%' OR  url LIKE '%{{qaccount_urls}}%' OR  description LIKE '%{{qaccount_urls}}%' OR  hive_site_id LIKE '%{{qaccount_urls}}%' OR  hive_site_name LIKE '%{{qaccount_urls}}%')";
   
   
   ///account_urls data_nodes 
  var wh_account_urls_data_nodes ="{{row_count}}|{{primkey}}|{{record_id}}|{{url_name}}|{{url}}|{{description}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for app_users ***********************************/
   var wh_app_users_list_cols ="primkey:primkey,user_id:user_id,fullnames:fullnames,email_address:email_address,mobile_number:mobile_number,login_password:login_password,signupdate:signupdate,account_no:account_no,profile_photo:profile_photo,gender:gender,last_seen:last_seen,site_id:site_id,about:about,company_email:company_email,company_name:company_name,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start app_users search columns 
   
   var wh_gft_app_users_str="(primkey LIKE '%{{qapp_users}}%' OR  user_id LIKE '%{{qapp_users}}%' OR  fullnames LIKE '%{{qapp_users}}%' OR  email_address LIKE '%{{qapp_users}}%' OR  mobile_number LIKE '%{{qapp_users}}%' OR  login_password LIKE '%{{qapp_users}}%' OR  signupdate LIKE '%{{qapp_users}}%' OR  account_no LIKE '%{{qapp_users}}%' OR  profile_photo LIKE '%{{qapp_users}}%' OR  gender LIKE '%{{qapp_users}}%' OR  last_seen LIKE '%{{qapp_users}}%' OR  site_id LIKE '%{{qapp_users}}%' OR  about LIKE '%{{qapp_users}}%' OR  company_email LIKE '%{{qapp_users}}%' OR  company_name LIKE '%{{qapp_users}}%' OR  hive_site_id LIKE '%{{qapp_users}}%' OR  hive_site_name LIKE '%{{qapp_users}}%')";
   
   
   ///app_users data_nodes 
  var wh_app_users_data_nodes ="{{row_count}}|{{primkey}}|{{user_id}}|{{fullnames}}|{{email_address}}|{{mobile_number}}|{{login_password}}|{{signupdate}}|{{account_no}}|{{profile_photo}}|{{gender}}|{{last_seen}}|{{site_id}}|{{about}}|{{company_email}}|{{company_name}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for billing_log ***********************************/
   var wh_billing_log_list_cols ="primkey:primkey,trx_key:trx_key,transaction_ref:transaction_ref,trx_type:trx_type,trx_time:trx_time,amount:amount,trx_source:trx_source,ref_id:ref_id,site_id:site_id,message:message,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start billing_log search columns 
   
   var wh_gft_billing_log_str="(primkey LIKE '%{{qbilling_log}}%' OR  trx_key LIKE '%{{qbilling_log}}%' OR  transaction_ref LIKE '%{{qbilling_log}}%' OR  trx_type LIKE '%{{qbilling_log}}%' OR  trx_time LIKE '%{{qbilling_log}}%' OR  amount LIKE '%{{qbilling_log}}%' OR  trx_source LIKE '%{{qbilling_log}}%' OR  ref_id LIKE '%{{qbilling_log}}%' OR  site_id LIKE '%{{qbilling_log}}%' OR  message LIKE '%{{qbilling_log}}%' OR  hive_site_id LIKE '%{{qbilling_log}}%' OR  hive_site_name LIKE '%{{qbilling_log}}%')";
   
   
   ///billing_log data_nodes 
  var wh_billing_log_data_nodes ="{{row_count}}|{{primkey}}|{{trx_key}}|{{transaction_ref}}|{{trx_type}}|{{trx_time}}|{{amount}}|{{trx_source}}|{{ref_id}}|{{site_id}}|{{message}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for clients ***********************************/
   var wh_clients_list_cols ="primkey:primkey,user_id:user_id,name:name,email:email,tel:tel,login_password:login_password,ref_id:ref_id,regdate:regdate,user_no:user_no,user_pic:user_pic,user_gender:user_gender,last_seen:last_seen,city:city,town:town,client_type:client_type,about:about,active_state:active_state,expiry_date:expiry_date,service_id:service_id,service_name:service_name,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start clients search columns 
   
   var wh_gft_clients_str="(primkey LIKE '%{{qclients}}%' OR  user_id LIKE '%{{qclients}}%' OR  name LIKE '%{{qclients}}%' OR  email LIKE '%{{qclients}}%' OR  tel LIKE '%{{qclients}}%' OR  login_password LIKE '%{{qclients}}%' OR  ref_id LIKE '%{{qclients}}%' OR  regdate LIKE '%{{qclients}}%' OR  user_no LIKE '%{{qclients}}%' OR  user_pic LIKE '%{{qclients}}%' OR  user_gender LIKE '%{{qclients}}%' OR  last_seen LIKE '%{{qclients}}%' OR  city LIKE '%{{qclients}}%' OR  town LIKE '%{{qclients}}%' OR  client_type LIKE '%{{qclients}}%' OR  about LIKE '%{{qclients}}%' OR  active_state LIKE '%{{qclients}}%' OR  expiry_date LIKE '%{{qclients}}%' OR  service_id LIKE '%{{qclients}}%' OR  service_name LIKE '%{{qclients}}%' OR  hive_site_id LIKE '%{{qclients}}%' OR  hive_site_name LIKE '%{{qclients}}%')";
   
   
   ///clients data_nodes 
  var wh_clients_data_nodes ="{{row_count}}|{{primkey}}|{{user_id}}|{{name}}|{{email}}|{{tel}}|{{login_password}}|{{ref_id}}|{{regdate}}|{{user_no}}|{{user_pic}}|{{user_gender}}|{{last_seen}}|{{city}}|{{town}}|{{client_type}}|{{about}}|{{active_state}}|{{expiry_date}}|{{service_id}}|{{service_name}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for message_templates ***********************************/
   var wh_message_templates_list_cols ="primkey:primkey,record_id:record_id,template_name:template_name,message_template:message_template,template_code:template_code";
        
   ///start message_templates search columns 
   
   var wh_gft_message_templates_str="(primkey LIKE '%{{qmessage_templates}}%' OR  record_id LIKE '%{{qmessage_templates}}%' OR  template_name LIKE '%{{qmessage_templates}}%' OR  message_template LIKE '%{{qmessage_templates}}%' OR  template_code LIKE '%{{qmessage_templates}}%')";
   
   
   ///message_templates data_nodes 
  var wh_message_templates_data_nodes ="{{row_count}}|{{primkey}}|{{record_id}}|{{template_name}}|{{message_template}}|{{template_code}}"
   
   
   
   
     /***************************************** global data warehouse for messaging ***********************************/
   var wh_messaging_list_cols ="primkey:primkey,messageid:messageid,receiver_contacts:receiver_contacts,reciver_names:reciver_names,message_type:message_type,site_id:site_id,group_name:group_name,message_date:message_date,sent_state:sent_state,msg_read_state:msg_read_state,subject:subject,message_label:message_label,about:about,sms_cost:sms_cost,page_count:page_count,hive_site_id:hive_site_id,hive_site_name:hive_site_name,custom_dictionary:custom_dictionary,message_signature:message_signature";
        
   ///start messaging search columns 
   
   var wh_gft_messaging_str="(primkey LIKE '%{{qmessaging}}%' OR  messageid LIKE '%{{qmessaging}}%' OR  receiver_contacts LIKE '%{{qmessaging}}%' OR  reciver_names LIKE '%{{qmessaging}}%' OR  message_type LIKE '%{{qmessaging}}%' OR  site_id LIKE '%{{qmessaging}}%' OR  group_name LIKE '%{{qmessaging}}%' OR  message_date LIKE '%{{qmessaging}}%' OR  sent_state LIKE '%{{qmessaging}}%' OR  msg_read_state LIKE '%{{qmessaging}}%' OR  subject LIKE '%{{qmessaging}}%' OR  message_label LIKE '%{{qmessaging}}%' OR  about LIKE '%{{qmessaging}}%' OR  sms_cost LIKE '%{{qmessaging}}%' OR  page_count LIKE '%{{qmessaging}}%' OR  hive_site_id LIKE '%{{qmessaging}}%' OR  hive_site_name LIKE '%{{qmessaging}}%' OR  custom_dictionary LIKE '%{{qmessaging}}%' OR  message_signature LIKE '%{{qmessaging}}%')";
   
   
   ///messaging data_nodes 
  var wh_messaging_data_nodes ="{{row_count}}|{{primkey}}|{{messageid}}|{{receiver_contacts}}|{{reciver_names}}|{{message_type}}|{{site_id}}|{{group_name}}|{{message_date}}|{{sent_state}}|{{msg_read_state}}|{{subject}}|{{message_label}}|{{about}}|{{sms_cost}}|{{page_count}}|{{hive_site_id}}|{{hive_site_name}}|{{custom_dictionary}}|{{message_signature}}"
   
   
   
   
     /***************************************** global data warehouse for mosy_sql_roll_back ***********************************/
   var wh_mosy_sql_roll_back_list_cols ="primkey:primkey,roll_bk_key:roll_bk_key,table_name:table_name,roll_type:roll_type,where_str:where_str,roll_timestamp:roll_timestamp,value_entries:value_entries,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start mosy_sql_roll_back search columns 
   
   var wh_gft_mosy_sql_roll_back_str="(primkey LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_bk_key LIKE '%{{qmosy_sql_roll_back}}%' OR  table_name LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_type LIKE '%{{qmosy_sql_roll_back}}%' OR  where_str LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_timestamp LIKE '%{{qmosy_sql_roll_back}}%' OR  value_entries LIKE '%{{qmosy_sql_roll_back}}%' OR  hive_site_id LIKE '%{{qmosy_sql_roll_back}}%' OR  hive_site_name LIKE '%{{qmosy_sql_roll_back}}%')";
   
   
   ///mosy_sql_roll_back data_nodes 
  var wh_mosy_sql_roll_back_data_nodes ="{{row_count}}|{{primkey}}|{{roll_bk_key}}|{{table_name}}|{{roll_type}}|{{where_str}}|{{roll_timestamp}}|{{value_entries}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for mosycomms_array ***********************************/
   var wh_mosycomms_array_list_cols ="primkey:primkey,messageid:messageid,receiver_contacts:receiver_contacts,reciver_names:reciver_names,message_type:message_type,site_id:site_id,group_name:group_name,message_date:message_date,sent_state:sent_state,msg_read_state:msg_read_state,subject:subject,message_label:message_label,message:message,delvery_receipt:delvery_receipt,mosycomms_dictionary:mosycomms_dictionary,sms_cost:sms_cost,page_count:page_count,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start mosycomms_array search columns 
   
   var wh_gft_mosycomms_array_str="(primkey LIKE '%{{qmosycomms_array}}%' OR  messageid LIKE '%{{qmosycomms_array}}%' OR  receiver_contacts LIKE '%{{qmosycomms_array}}%' OR  reciver_names LIKE '%{{qmosycomms_array}}%' OR  message_type LIKE '%{{qmosycomms_array}}%' OR  site_id LIKE '%{{qmosycomms_array}}%' OR  group_name LIKE '%{{qmosycomms_array}}%' OR  message_date LIKE '%{{qmosycomms_array}}%' OR  sent_state LIKE '%{{qmosycomms_array}}%' OR  msg_read_state LIKE '%{{qmosycomms_array}}%' OR  subject LIKE '%{{qmosycomms_array}}%' OR  message_label LIKE '%{{qmosycomms_array}}%' OR  message LIKE '%{{qmosycomms_array}}%' OR  delvery_receipt LIKE '%{{qmosycomms_array}}%' OR  mosycomms_dictionary LIKE '%{{qmosycomms_array}}%' OR  sms_cost LIKE '%{{qmosycomms_array}}%' OR  page_count LIKE '%{{qmosycomms_array}}%' OR  hive_site_id LIKE '%{{qmosycomms_array}}%' OR  hive_site_name LIKE '%{{qmosycomms_array}}%')";
   
   
   ///mosycomms_array data_nodes 
  var wh_mosycomms_array_data_nodes ="{{row_count}}|{{primkey}}|{{messageid}}|{{receiver_contacts}}|{{reciver_names}}|{{message_type}}|{{site_id}}|{{group_name}}|{{message_date}}|{{sent_state}}|{{msg_read_state}}|{{subject}}|{{message_label}}|{{message}}|{{delvery_receipt}}|{{mosycomms_dictionary}}|{{sms_cost}}|{{page_count}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for mosycomms_settings ***********************************/
   var wh_mosycomms_settings_list_cols ="primkey:primkey,record_id:record_id,company_name:company_name,company_email:company_email,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start mosycomms_settings search columns 
   
   var wh_gft_mosycomms_settings_str="(primkey LIKE '%{{qmosycomms_settings}}%' OR  record_id LIKE '%{{qmosycomms_settings}}%' OR  company_name LIKE '%{{qmosycomms_settings}}%' OR  company_email LIKE '%{{qmosycomms_settings}}%' OR  hive_site_id LIKE '%{{qmosycomms_settings}}%' OR  hive_site_name LIKE '%{{qmosycomms_settings}}%')";
   
   
   ///mosycomms_settings data_nodes 
  var wh_mosycomms_settings_data_nodes ="{{row_count}}|{{primkey}}|{{record_id}}|{{company_name}}|{{company_email}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for page_manifest_ ***********************************/
   var wh_page_manifest__list_cols ="primkey:primkey,manikey:manikey,page_group:page_group,site_id:site_id,page_url:page_url,hive_site_id:hive_site_id,hive_site_name:hive_site_name,project_id:project_id,project_name:project_name";
        
   ///start page_manifest_ search columns 
   
   var wh_gft_page_manifest__str="(primkey LIKE '%{{qpage_manifest_}}%' OR  manikey LIKE '%{{qpage_manifest_}}%' OR  page_group LIKE '%{{qpage_manifest_}}%' OR  site_id LIKE '%{{qpage_manifest_}}%' OR  page_url LIKE '%{{qpage_manifest_}}%' OR  hive_site_id LIKE '%{{qpage_manifest_}}%' OR  hive_site_name LIKE '%{{qpage_manifest_}}%' OR  project_id LIKE '%{{qpage_manifest_}}%' OR  project_name LIKE '%{{qpage_manifest_}}%')";
   
   
   ///page_manifest_ data_nodes 
  var wh_page_manifest__data_nodes ="{{row_count}}|{{primkey}}|{{manikey}}|{{page_group}}|{{site_id}}|{{page_url}}|{{hive_site_id}}|{{hive_site_name}}|{{project_id}}|{{project_name}}"
   
   
   
   
     /***************************************** global data warehouse for phonebook ***********************************/
   var wh_phonebook_list_cols ="primkey:primkey,contact_id:contact_id,name:name,email:email,tel:tel,profile_photo:profile_photo,username:username,site_id:site_id,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start phonebook search columns 
   
   var wh_gft_phonebook_str="(primkey LIKE '%{{qphonebook}}%' OR  contact_id LIKE '%{{qphonebook}}%' OR  name LIKE '%{{qphonebook}}%' OR  email LIKE '%{{qphonebook}}%' OR  tel LIKE '%{{qphonebook}}%' OR  profile_photo LIKE '%{{qphonebook}}%' OR  username LIKE '%{{qphonebook}}%' OR  site_id LIKE '%{{qphonebook}}%' OR  hive_site_id LIKE '%{{qphonebook}}%' OR  hive_site_name LIKE '%{{qphonebook}}%')";
   
   
   ///phonebook data_nodes 
  var wh_phonebook_data_nodes ="{{row_count}}|{{primkey}}|{{contact_id}}|{{name}}|{{email}}|{{tel}}|{{profile_photo}}|{{username}}|{{site_id}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for send_list ***********************************/
   var wh_send_list_list_cols ="primkey:primkey,send_list_key:send_list_key,send_list_name:send_list_name,site_id:site_id,contact_id:contact_id,contact_names:contact_names,mobile:mobile,email:email,ref_no:ref_no,group_name:group_name,date_created:date_created,description:description,active_state:active_state,service_id:service_id,service_name:service_name,hive_site_id:hive_site_id,hive_site_name:hive_site_name,entry_context:entry_context";
        
   ///start send_list search columns 
   
   var wh_gft_send_list_str="(primkey LIKE '%{{qsend_list}}%' OR  send_list_key LIKE '%{{qsend_list}}%' OR  send_list_name LIKE '%{{qsend_list}}%' OR  site_id LIKE '%{{qsend_list}}%' OR  contact_id LIKE '%{{qsend_list}}%' OR  contact_names LIKE '%{{qsend_list}}%' OR  mobile LIKE '%{{qsend_list}}%' OR  email LIKE '%{{qsend_list}}%' OR  ref_no LIKE '%{{qsend_list}}%' OR  group_name LIKE '%{{qsend_list}}%' OR  date_created LIKE '%{{qsend_list}}%' OR  description LIKE '%{{qsend_list}}%' OR  active_state LIKE '%{{qsend_list}}%' OR  service_id LIKE '%{{qsend_list}}%' OR  service_name LIKE '%{{qsend_list}}%' OR  hive_site_id LIKE '%{{qsend_list}}%' OR  hive_site_name LIKE '%{{qsend_list}}%' OR  entry_context LIKE '%{{qsend_list}}%')";
   
   
   ///send_list data_nodes 
  var wh_send_list_data_nodes ="{{row_count}}|{{primkey}}|{{send_list_key}}|{{send_list_name}}|{{site_id}}|{{contact_id}}|{{contact_names}}|{{mobile}}|{{email}}|{{ref_no}}|{{group_name}}|{{date_created}}|{{description}}|{{active_state}}|{{service_id}}|{{service_name}}|{{hive_site_id}}|{{hive_site_name}}|{{entry_context}}"
   
   
   
   
     /***************************************** global data warehouse for system_role_bundles ***********************************/
   var wh_system_role_bundles_list_cols ="primkey:primkey,record_id:record_id,bundle_id:bundle_id,bundle_name:bundle_name,remark:remark,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start system_role_bundles search columns 
   
   var wh_gft_system_role_bundles_str="(primkey LIKE '%{{qsystem_role_bundles}}%' OR  record_id LIKE '%{{qsystem_role_bundles}}%' OR  bundle_id LIKE '%{{qsystem_role_bundles}}%' OR  bundle_name LIKE '%{{qsystem_role_bundles}}%' OR  remark LIKE '%{{qsystem_role_bundles}}%' OR  hive_site_id LIKE '%{{qsystem_role_bundles}}%' OR  hive_site_name LIKE '%{{qsystem_role_bundles}}%')";
   
   
   ///system_role_bundles data_nodes 
  var wh_system_role_bundles_data_nodes ="{{row_count}}|{{primkey}}|{{record_id}}|{{bundle_id}}|{{bundle_name}}|{{remark}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for system_users ***********************************/
   var wh_system_users_list_cols ="login_password:login_password,primkey:primkey,user_id:user_id,name:name,email:email,tel:tel,ref_id:ref_id,regdate:regdate,user_no:user_no,user_pic:user_pic,user_gender:user_gender,last_seen:last_seen,about:about,hive_site_id:hive_site_id,hive_site_name:hive_site_name,auth_token:auth_token,token_status:token_status,token_expiring_in:token_expiring_in,project_id:project_id,project_name:project_name";
        
   ///start system_users search columns 
   
   var wh_gft_system_users_str="(login_password LIKE '%{{qsystem_users}}%' OR  primkey LIKE '%{{qsystem_users}}%' OR  user_id LIKE '%{{qsystem_users}}%' OR  name LIKE '%{{qsystem_users}}%' OR  email LIKE '%{{qsystem_users}}%' OR  tel LIKE '%{{qsystem_users}}%' OR  ref_id LIKE '%{{qsystem_users}}%' OR  regdate LIKE '%{{qsystem_users}}%' OR  user_no LIKE '%{{qsystem_users}}%' OR  user_pic LIKE '%{{qsystem_users}}%' OR  user_gender LIKE '%{{qsystem_users}}%' OR  last_seen LIKE '%{{qsystem_users}}%' OR  about LIKE '%{{qsystem_users}}%' OR  hive_site_id LIKE '%{{qsystem_users}}%' OR  hive_site_name LIKE '%{{qsystem_users}}%' OR  auth_token LIKE '%{{qsystem_users}}%' OR  token_status LIKE '%{{qsystem_users}}%' OR  token_expiring_in LIKE '%{{qsystem_users}}%' OR  project_id LIKE '%{{qsystem_users}}%' OR  project_name LIKE '%{{qsystem_users}}%')";
   
   
   ///system_users data_nodes 
  var wh_system_users_data_nodes ="{{row_count}}|{{login_password}}|{{primkey}}|{{user_id}}|{{name}}|{{email}}|{{tel}}|{{ref_id}}|{{regdate}}|{{user_no}}|{{user_pic}}|{{user_gender}}|{{last_seen}}|{{about}}|{{hive_site_id}}|{{hive_site_name}}|{{auth_token}}|{{token_status}}|{{token_expiring_in}}|{{project_id}}|{{project_name}}"
   
   
   
   
     /***************************************** global data warehouse for user_bundle_role_functions ***********************************/
   var wh_user_bundle_role_functions_list_cols ="primkey:primkey,record_id:record_id,bundle_id:bundle_id,bundle_name:bundle_name,role_id:role_id,role_name:role_name,remark:remark,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start user_bundle_role_functions search columns 
   
   var wh_gft_user_bundle_role_functions_str="(primkey LIKE '%{{quser_bundle_role_functions}}%' OR  record_id LIKE '%{{quser_bundle_role_functions}}%' OR  bundle_id LIKE '%{{quser_bundle_role_functions}}%' OR  bundle_name LIKE '%{{quser_bundle_role_functions}}%' OR  role_id LIKE '%{{quser_bundle_role_functions}}%' OR  role_name LIKE '%{{quser_bundle_role_functions}}%' OR  remark LIKE '%{{quser_bundle_role_functions}}%' OR  hive_site_id LIKE '%{{quser_bundle_role_functions}}%' OR  hive_site_name LIKE '%{{quser_bundle_role_functions}}%')";
   
   
   ///user_bundle_role_functions data_nodes 
  var wh_user_bundle_role_functions_data_nodes ="{{row_count}}|{{primkey}}|{{record_id}}|{{bundle_id}}|{{bundle_name}}|{{role_id}}|{{role_name}}|{{remark}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for user_manifest_ ***********************************/
   var wh_user_manifest__list_cols ="primkey:primkey,admin_mkey:admin_mkey,user_id:user_id,user_name:user_name,role_id:role_id,site_id:site_id,role_name:role_name,hive_site_id:hive_site_id,hive_site_name:hive_site_name,project_id:project_id,project_name:project_name";
        
   ///start user_manifest_ search columns 
   
   var wh_gft_user_manifest__str="(primkey LIKE '%{{quser_manifest_}}%' OR  admin_mkey LIKE '%{{quser_manifest_}}%' OR  user_id LIKE '%{{quser_manifest_}}%' OR  user_name LIKE '%{{quser_manifest_}}%' OR  role_id LIKE '%{{quser_manifest_}}%' OR  site_id LIKE '%{{quser_manifest_}}%' OR  role_name LIKE '%{{quser_manifest_}}%' OR  hive_site_id LIKE '%{{quser_manifest_}}%' OR  hive_site_name LIKE '%{{quser_manifest_}}%' OR  project_id LIKE '%{{quser_manifest_}}%' OR  project_name LIKE '%{{quser_manifest_}}%')";
   
   
   ///user_manifest_ data_nodes 
  var wh_user_manifest__data_nodes ="{{row_count}}|{{primkey}}|{{admin_mkey}}|{{user_id}}|{{user_name}}|{{role_id}}|{{site_id}}|{{role_name}}|{{hive_site_id}}|{{hive_site_name}}|{{project_id}}|{{project_name}}"
   
   