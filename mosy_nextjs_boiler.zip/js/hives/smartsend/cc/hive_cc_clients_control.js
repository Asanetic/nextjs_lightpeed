
   const hive_clients_ins_btn = document.querySelectorAll(".hive_clients_ins_btn");
        hive_clients_ins_btn.forEach(clients_ins_btn => {
          clients_ins_btn.addEventListener("click", event => {
          
          mosy_clients_ins_fun()
          
          });
        });
        
        
   const hive_clients_updt_btn = document.querySelectorAll(".hive_clients_updt_btn");
        hive_clients_updt_btn.forEach(clients_updt_btn => {
          clients_updt_btn.addEventListener("click", event => {
          
          mosy_clients_updt_fun()
          
          });
        });

	  //// ================== cc view data nodes template =============
      ////var clients_data_template=get_html("clients_tbl_nodes");
	  //// ================== cc view data nodes template =============

      function loop_clients_ui_data(qstr="",callback="", andquery="", _clients_auto_function="")
      {      
        
        
         /// ==============clients custom js auto response function  ================
    var custom_clients_auto_function= '{"cbfun":"process_clients_json_data","_data_isle":"clients_data_isle:22","_pagination_isle":"clients_pagination_isle","_data_template":"hive_clients_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_clients"}';
    
/// ==============clients custom js auto response function  ================
   
    
      if(_clients_auto_function!="")
      {
      	custom_clients_auto_function = _clients_auto_function
      }
    	
    
       if(callback!="")
       {
         qstr="";
         magic_message(callback, "dialog_box")
       }
       
       mosy_clients_json_data_list(qstr, custom_clients_auto_function, andquery);
       
       var and_count ="";
       if(andquery!="")
       {
          and_count=" and "+andquery
       }
        
      }
      