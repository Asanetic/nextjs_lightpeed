
   const hive_billing_log_ins_btn = document.querySelectorAll(".hive_billing_log_ins_btn");
        hive_billing_log_ins_btn.forEach(billing_log_ins_btn => {
          billing_log_ins_btn.addEventListener("click", event => {
          
          mosy_billing_log_ins_fun()
          
          });
        });
        
        
   const hive_billing_log_updt_btn = document.querySelectorAll(".hive_billing_log_updt_btn");
        hive_billing_log_updt_btn.forEach(billing_log_updt_btn => {
          billing_log_updt_btn.addEventListener("click", event => {
          
          mosy_billing_log_updt_fun()
          
          });
        });

	  //// ================== cc view data nodes template =============
      ////var billing_log_data_template=get_html("billing_log_tbl_nodes");
	  //// ================== cc view data nodes template =============

      function loop_billing_log_ui_data(qstr="",callback="", andquery="", _billing_log_auto_function="")
      {      
        
        
         /// ==============billing_log custom js auto response function  ================
    var custom_billing_log_auto_function= '{"cbfun":"process_billing_log_json_data","_data_isle":"billing_log_data_isle:12","_pagination_isle":"billing_log_pagination_isle","_data_template":"hive_billing_log_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_billing_log"}';
    
/// ==============billing_log custom js auto response function  ================
   
    
      if(_billing_log_auto_function!="")
      {
      	custom_billing_log_auto_function = _billing_log_auto_function
      }
    	
    
       if(callback!="")
       {
         qstr="";
         magic_message(callback, "dialog_box")
       }
       
       mosy_billing_log_json_data_list(qstr, custom_billing_log_auto_function, andquery);
       
       var and_count ="";
       if(andquery!="")
       {
          and_count=" and "+andquery
       }
        
      }
      