//============================================================ ++++ start message_templates datahandler js =============================
   
    

    //Start get  message_templates Data ===============
    
      function get_message_templates(message_templates_colstr, message_templates_filter_col, message_templates_cols, message_templates_node_function_name, message_templates_callback_function_string, message_templates_ui_tag, message_templates_pagination, route_url_name="smartsend")
      {        
        var req_url=route_url_name;

        mosyflex_sel("message_templates", message_templates_colstr, message_templates_filter_col , message_templates_cols, message_templates_node_function_name, message_templates_callback_function_string, message_templates_ui_tag, message_templates_pagination,req_url);
        
      }
    //End get  message_templates Data ===============

    //Start insert  message_templates Data ===============

	function add_message_templates(message_templates_cols, message_templates_vals, message_templates_callback_function_string)
    {
		
        mosyajax_create_data("message_templates", message_templates_cols, message_templates_vals, message_templates_callback_function_string);
     }
     
    //End insert  message_templates Data ===============

    
    //Start update  message_templates Data ===============

    function update_message_templates(message_templates_update_str, message_templates_where_str, message_templates_callback_function_string){
    
		mosyajax_update("message_templates", message_templates_update_str, message_templates_where_str, message_templates_callback_function_string)
    
    }
    //end  update  message_templates Data ===============

	//Start drop  message_templates Data ===============
    function message_templates_drop(message_templates_where_str, message_templates_callback_function_string)
    {
        mosyajax_drop("message_templates", message_templates_where_str, message_templates_callback_function_string)

    }
	//End drop  message_templates Data ===============
    
    function initialize_message_templates(qstr="", message_templates_callback_function_string="",route_url_name="smartsend")
    {
    
    ///alert(qstr);
      var message_templates_token_query =qstr;
      if(qstr=="")
      {
       var message_templates_token_query_param="";
       var message_templates_js_uptoken=mosy_get_param("message_templates_uptoken");
       //alert(message_templates_js_uptoken);
       if(message_templates_js_uptoken!==undefined)
       {
       
        message_templates_token_query_param = atob(message_templates_js_uptoken);
       }
        message_templates_token_query = " where primkey='"+(message_templates_token_query_param)+"'";
        
           if (document.getElementById("message_templates_uptoken") !==null) {
           	if(document.getElementById("message_templates_uptoken").value!="")
            {
            
            var message_templates_atob_tbl_key =atob(document.getElementById("message_templates_uptoken").value);
            
                   
            message_templates_token_query = " where primkey='"+(message_templates_atob_tbl_key)+"'";

            }
           }
      }
      
      var message_templates_push_ui_data_to =message_templates_callback_function_string;
      if(message_templates_callback_function_string=="")
      {
      message_templates_push_ui_data_to = "add_message_templates_ui_data";
      }
                
      console.log(message_templates_token_query+" -- "+message_templates_js_uptoken);

	  //alert(message_templates_push_ui_data_to);

	 var req_url=route_url_name;

     get_message_templates("*", message_templates_token_query, "primkey", "blackhole", message_templates_push_ui_data_to, "", "", req_url);
     

    }
    
    function add_message_templates_ui_data(message_templates_server_resp) 
    {
    
    ///alert(message_templates_server_resp);
    
    var json_decoded_str=JSON.parse(message_templates_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          mosy_push_data_class("mosy_data_"+keys[i], val);
          
          // use val
      }
        
    }
    

    ///=============== load message_templates data on the fly ==============
    
	var gft_message_templates_str="(primkey LIKE '%{{qmessage_templates}}%' OR  record_id LIKE '%{{qmessage_templates}}%' OR  template_name LIKE '%{{qmessage_templates}}%' OR  message_template LIKE '%{{qmessage_templates}}%' OR  template_code LIKE '%{{qmessage_templates}}%')";
    
    function  gft_message_templates(qmessage_templates_str)
    {
        	var clean_message_templates_filter_str=gft_message_templates_str.replace(/{{qmessage_templates}}/g, magic_clean_str(qmessage_templates_str));
            
            return  clean_message_templates_filter_str;

    }
    
    function load_message_templates(message_templates_qstr, message_templates_where_str, message_templates_ret_cols, message_templates_user_function, message_templates_result_function, message_templates_data_tray, route_url_name="smartsend")
    {
    
    var fmessage_templates_result_function="push_result";
      
    if(message_templates_result_function!="")
    {
          var fmessage_templates_result_function=message_templates_result_function;

    }
    	var clean_message_templates_filter_str=gft_message_templates_str.replace(/{{qmessage_templates}}/g, magic_clean_str(message_templates_qstr));
        
        var fmessage_templates_where_str=" where "+clean_message_templates_filter_str;

    if(message_templates_where_str!="")
    {
          var fmessage_templates_where_str=" "+message_templates_where_str;

    }

	  var req_url=route_url_name;

      get_message_templates("*", fmessage_templates_where_str, message_templates_ret_cols, message_templates_user_function, fmessage_templates_result_function, message_templates_data_tray,"",req_url);

  }
    ///=============== load message_templates data on the fly ==============


 ///=quick load 
 
function qkload_message_templates(qstr, push_fun="", ui_card="", and_query="", additional_cols="", message_templates_pagination="",route_url_name="smartsend")
{


      message_templates_list_nodes_str=ui_card;
  
   
   var message_templates_qret_fun="push_grid_result:message_templates_tbl_list";
   
   if(push_fun!="")
   {
    message_templates_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }

   var req_url=route_url_name;

   get_message_templates("*", ajaxw+" ("+gft_message_templates(qstr)+") "+combined_query+"  order by primkey desc ", message_templates_list_cols+additional_cols_str, "",message_templates_qret_fun, "c=>"+message_templates_list_nodes_str, message_templates_pagination, req_url);
}


////////////// arithmetic function 


//count 

function count_message_templates(where_str, push_to, callback_function_string="", num_form="yes", route_url_name="smartsend")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }

   var req_url=route_url_name;

   get_message_templates("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "","",req_url);
   ///get_message_templates(message_templates_colstr, message_templates_filter_col, message_templates_cols, message_templates_node_function_name, message_templates_callback_function_string, message_templates_ui_tag, message_templates_pagination, route_url_name="smartsend") 

}


//qddata
function qmessage_templates_ddata(where_str, disp_col , push_to, callback_function_string="",route_url_name="smartsend")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }

   var req_url=route_url_name;

   get_message_templates("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "","",req_url);
   ///get_message_templates(message_templates_colstr, message_templates_filter_col, message_templates_cols, message_templates_node_function_name, message_templates_callback_function_string, message_templates_ui_tag, message_templates_pagination, route_url_name="smartsend")    

}



//sum 

function sum_message_templates(sum_col, where_str, push_to, callback_function_string="", num_form="yes",route_url_name="smartsend")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
           
    var req_url=route_url_name;

   get_message_templates("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "","",req_url);

}


///request handlers 

  
  function conf_del_message_templates_(message_templates_data_key, after_delete="blackhole",  cancel_function="blackhole()", push_to="alert_box")
  {


    magic_yes_no_alert('Delete record?', push_to, 'message_templates_rem_(\''+message_templates_data_key+'\', \''+after_delete+'\')', cancel_function)

  }


function mosy_message_templates_ins_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form",route_url_name="smartsend")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
    magic_message("Processing", "dialog_box")

    var req_url=route_url_name;

   message_templates_ins_(formid,"",response_fun,req_url)
 }
}

function mosy_message_templates_updt_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form", route_url_name="smartsend")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
   magic_message("Processing", "dialog_box")

   var req_url=route_url_name;

   message_templates_updt_(formid,"",response_fun,req_url)
 }
}

function message_templates_ins_(formid, required_inp=null, callback_function_string="",route_url_name="smartsend")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }

    var req_url=route_url_name;

    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "message_templates_insert_btn", callback_function_string_str, "", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function message_templates_updt_(formid, required_inp, callback_function_string="",route_url_name="smartsend")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);

     var req_url=route_url_name;
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "message_templates_update_btn", callback_function_string_str,"", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function message_templates_rem_(req_token, callback_function_string="",route_url_name="smartsend")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

 var req_url=route_url_name;
 
 mosyajax_get('conf_deletemessage_templates&message_templates_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str,req_url);

}


function grid_message_templates_updt_(updt_key,colstr,newcolval, callback_function_string="",route_url_name="smartsend")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 

 var req_url=route_url_name;

mosyajax_get("_grid_updt_="+btoa('message_templates')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str,req_url);

}
  //============================================================ ++++ End message_templates datahandler js =============================
   
   ///message_templates data_nodes 
  var message_templates_data_nodes ='{{row_count}}|{{primkey}}|{{record_id}}|{{template_name}}|{{message_template}}|{{template_code}}';



   var message_templates_list_cols ="primkey:primkey,record_id:record_id,template_name:template_name,message_template:message_template,template_code:template_code";

;
        
   ///start message_templates search columns 
   
   var data_nodes_gft_message_templates_str="(primkey LIKE '%{{qmessage_templates}}%' OR  record_id LIKE '%{{qmessage_templates}}%' OR  template_name LIKE '%{{qmessage_templates}}%' OR  message_template LIKE '%{{qmessage_templates}}%' OR  template_code LIKE '%{{qmessage_templates}}%')";
    
    function  data_nodes_gft_message_templates(qmessage_templates_str)
    {
        	var data_nodes_clean_message_templates_filter_str=data_nodes_gft_message_templates_str.replace(/{{qmessage_templates}}/g, magic_clean_str(qmessage_templates_str));
            
            return  data_nodes_clean_message_templates_filter_str;

    }
       ///end message_templates search columns 

  function mosy_message_templates_ui_node (message_templates_json_data, message_templates_load_to, message_templates_cols_, message_templates_template_ui)
  {
     ////alert(message_templates_template_ui);
     var message_templates_cols_fun_cols_str ="";
     
     if(typeof message_templates_cols_fun_cols !== "undefined")
      {
        message_templates_cols_fun_cols_str=message_templates_cols_fun_cols;
        
        ///alert(message_templates_cols_fun_cols)
      } 
      
     var message_templates_ui__ = mosy_list_render_(message_templates_json_data, message_templates_cols_fun_cols_str+message_templates_cols_, message_templates_template_ui) 

     ////push_html(message_templates_load_to, message_templates_ui__)  

     push_grid_result(message_templates_ui__, message_templates_load_to)
  }
  
 
 ///////
 
 var message_templates_auto_function= '{"cbfun":"process_message_templates_json_data","_data_isle":"message_templates_data_isle","_pagination_isle":"message_templates_pagination_isle","_data_template":"hive_message_templates_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_message_templates","req_url":"smartsend"}';

 
 
 ///============ auto renders 
 
 
function mosy_message_templates_json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", message_templates_pagination_prefix_="__pgnt_message_templates", colstr="*", req_url="smartsend")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("message_templates", btoa(qstr))
  }else{
    mosy_delete_get_pram("message_templates")
  }
  
  if(mosy_get_param("message_templates")!==undefined)
  {
    qstr=atob(mosy_get_param("message_templates"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:message_templates_page_no:"+mosy_limit;
  }
  
  ///hive_message_templates_data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_message_templates_json_data","_data_isle":"message_templates_data_isle","_pagination_isle":"message_templates_pagination_isle","_data_template":"hive_message_templates_data_template","_payload_str":"req","_pagination_prefix":"'+message_templates_pagination_prefix_+'","req_url":"'+req_url+'"}';
            
  }
  
  return mosyrender_message_templates_(response_fun," where "+gft_message_templates(qstr)+" "+and_query_str+"  order by primkey desc ",function_cols,colstr,pagination, message_templates_pagination_prefix_,req_url)
  
}


  
  function autoprocess_message_templates_json_data(message_templates_server_resp)
  {  
    mosy_message_templates_ui_node(message_templates_server_resp, "message_templates_data_isle", message_templates_data_nodes, get_html(hive_message_templates_data_template),"", "l:message_templates_page_no:15")
    mosy_paginate_api(message_templates_server_resp, "message_templates_page_no", "message_templates_pagination_isle", "15")
  }
  
  function process_message_templates_json_data(message_templates_server_resp, message_templates_callback="")
  {  
      var message_templates_data_isle="message_templates_data_isle";
      var message_templates_data_node_template="hive_message_templates_data_template";
      var message_templates_pagination_isle="message_templates_pagination_isle";
      var message_templates_payload_str="";
      var message_templates__pagination_prefix_str="__pgnt_message_templates";
      
       ///alert(message_templates_callback)
       ///alert(message_templates_server_resp)
       ///console.log(message_templates_server_resp)
              
      try {
        
           const message_templates_jsonObject = JSON.parse(message_templates_callback);
        
           message_templates_data_isle=message_templates_jsonObject._data_isle;
           message_templates_data_node_template=message_templates_jsonObject._data_template;
           message_templates_pagination_isle=message_templates_jsonObject._pagination_isle;
           message_templates_payload_str=message_templates_jsonObject._payload_str;
           message_templates__pagination_prefix_str=message_templates_jsonObject._pagination_prefix;
           message_templates__req_url=message_templates_jsonObject.req_url;

           ///console.log("paginate == : valid JSON"+message_templates_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+message_templates_callback);
        
         if(message_templates_callback.indexOf(",") >= 0)
         {
              message_templates_data_handler_ui =message_templates_callback.split(",");                                 

              if(message_templates_data_handler_ui[0]!=undefined){ message_templates_data_isle=message_templates_data_handler_ui[0];}

              if(message_templates_data_handler_ui[1]!=undefined){message_templates_data_node_template =message_templates_data_handler_ui[1];}

              if(message_templates_data_handler_ui[2]!=undefined){ message_templates_pagination_isle=message_templates_data_handler_ui[2]};

              if(message_templates_data_handler_ui[3]!=undefined){ message_templates_payload_str=btoa(message_templates_data_handler_ui[3])};
              
              if(message_templates_data_handler_ui[4]!=undefined){ message_templates__pagination_prefix_str=btoa(message_templates_data_handler_ui[4])};

			  if(message_templates_data_handler_ui[5]!=undefined){ message_templates__req_url=message_templates_data_handler_ui[5]};                            
              
         }       
        
      }

       ///alert(" dtisle == "+message_templates_data_isle)
       
            mosy_message_templates_ui_node(message_templates_server_resp, message_templates_data_isle, message_templates_data_nodes, get_html(message_templates_data_node_template),"", "l:message_templates_page_no:"+mosy_limit)                       
            
             if(message_templates_payload_str==="req")
             {
                
                mosy_paginate_api(message_templates_server_resp, "message_templates_page_no", message_templates_pagination_isle, "process_message_templates_json_data", message_templates__pagination_prefix_str,message_templates__req_url)

             }
           
  }
    

function mosyrender_message_templates_(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_message_templates", req_url="smartsend")
{
   
  if(pagination==="")
  {
    pagination="l:message_templates_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _message_templates_payload="mosyget_&tbl=message_templates&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_message_templates_payload+curl_url)
  
  var _message_templates_pagination_json = '{"_payload":"'+_message_templates_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _message_templates_payload_input = document.createElement("input");
                _message_templates_payload_input.setAttribute('type', 'hidden');
                _message_templates_payload_input.setAttribute('name',_txt_payload);
                _message_templates_payload_input.setAttribute('id', _txt_payload);

                // Add the _message_templates_payload_input element to the DOM
                document.body.appendChild(_message_templates_payload_input);
                
      }
      
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
  push_newval(_txt_payload, _message_templates_pagination_json)
  mosyajax_get(_message_templates_payload, response_fun, req_url);
  
  return _message_templates_payload;
  
}


function mginitialize_message_templates(reqkey, response_fun="",req_url="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _message_templates_payload="mosyget_&tbl=message_templates&colstr="+btoa("*")+"&where_str="+btoa(" where primkey ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
     mosyajax_get(_message_templates_payload, response_fun, req_url);


}

 

