//============================================================ ++++ start account_urls datahandler js =============================
   
    

    //Start get  account_urls Data ===============
    
      function get_account_urls(account_urls_colstr, account_urls_filter_col, account_urls_cols, account_urls_node_function_name, account_urls_callback_function_string, account_urls_ui_tag, account_urls_pagination, route_url_name="smartsend")
      {        
        var req_url=route_url_name;

        mosyflex_sel("account_urls", account_urls_colstr, account_urls_filter_col , account_urls_cols, account_urls_node_function_name, account_urls_callback_function_string, account_urls_ui_tag, account_urls_pagination,req_url);
        
      }
    //End get  account_urls Data ===============

    //Start insert  account_urls Data ===============

	function add_account_urls(account_urls_cols, account_urls_vals, account_urls_callback_function_string)
    {
		
        mosyajax_create_data("account_urls", account_urls_cols, account_urls_vals, account_urls_callback_function_string);
     }
     
    //End insert  account_urls Data ===============

    
    //Start update  account_urls Data ===============

    function update_account_urls(account_urls_update_str, account_urls_where_str, account_urls_callback_function_string){
    
		mosyajax_update("account_urls", account_urls_update_str, account_urls_where_str, account_urls_callback_function_string)
    
    }
    //end  update  account_urls Data ===============

	//Start drop  account_urls Data ===============
    function account_urls_drop(account_urls_where_str, account_urls_callback_function_string)
    {
        mosyajax_drop("account_urls", account_urls_where_str, account_urls_callback_function_string)

    }
	//End drop  account_urls Data ===============
    
    function initialize_account_urls(qstr="", account_urls_callback_function_string="",route_url_name="smartsend")
    {
    
    ///alert(qstr);
      var account_urls_token_query =qstr;
      if(qstr=="")
      {
       var account_urls_token_query_param="";
       var account_urls_js_uptoken=mosy_get_param("account_urls_uptoken");
       //alert(account_urls_js_uptoken);
       if(account_urls_js_uptoken!==undefined)
       {
       
        account_urls_token_query_param = atob(account_urls_js_uptoken);
       }
        account_urls_token_query = " where primkey='"+(account_urls_token_query_param)+"'";
        
           if (document.getElementById("account_urls_uptoken") !==null) {
           	if(document.getElementById("account_urls_uptoken").value!="")
            {
            
            var account_urls_atob_tbl_key =atob(document.getElementById("account_urls_uptoken").value);
            
                   
            account_urls_token_query = " where primkey='"+(account_urls_atob_tbl_key)+"'";

            }
           }
      }
      
      var account_urls_push_ui_data_to =account_urls_callback_function_string;
      if(account_urls_callback_function_string=="")
      {
      account_urls_push_ui_data_to = "add_account_urls_ui_data";
      }
                
      console.log(account_urls_token_query+" -- "+account_urls_js_uptoken);

	  //alert(account_urls_push_ui_data_to);

	 var req_url=route_url_name;

     get_account_urls("*", account_urls_token_query, "primkey", "blackhole", account_urls_push_ui_data_to, "", "", req_url);
     

    }
    
    function add_account_urls_ui_data(account_urls_server_resp) 
    {
    
    ///alert(account_urls_server_resp);
    
    var json_decoded_str=JSON.parse(account_urls_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          mosy_push_data_class("mosy_data_"+keys[i], val);
          
          // use val
      }
        
    }
    

    ///=============== load account_urls data on the fly ==============
    
	var gft_account_urls_str="(primkey LIKE '%{{qaccount_urls}}%' OR  record_id LIKE '%{{qaccount_urls}}%' OR  url_name LIKE '%{{qaccount_urls}}%' OR  url LIKE '%{{qaccount_urls}}%' OR  description LIKE '%{{qaccount_urls}}%' OR  hive_site_id LIKE '%{{qaccount_urls}}%' OR  hive_site_name LIKE '%{{qaccount_urls}}%')";
    
    function  gft_account_urls(qaccount_urls_str)
    {
        	var clean_account_urls_filter_str=gft_account_urls_str.replace(/{{qaccount_urls}}/g, magic_clean_str(qaccount_urls_str));
            
            return  clean_account_urls_filter_str;

    }
    
    function load_account_urls(account_urls_qstr, account_urls_where_str, account_urls_ret_cols, account_urls_user_function, account_urls_result_function, account_urls_data_tray, route_url_name="smartsend")
    {
    
    var faccount_urls_result_function="push_result";
      
    if(account_urls_result_function!="")
    {
          var faccount_urls_result_function=account_urls_result_function;

    }
    	var clean_account_urls_filter_str=gft_account_urls_str.replace(/{{qaccount_urls}}/g, magic_clean_str(account_urls_qstr));
        
        var faccount_urls_where_str=" where "+clean_account_urls_filter_str;

    if(account_urls_where_str!="")
    {
          var faccount_urls_where_str=" "+account_urls_where_str;

    }

	  var req_url=route_url_name;

      get_account_urls("*", faccount_urls_where_str, account_urls_ret_cols, account_urls_user_function, faccount_urls_result_function, account_urls_data_tray,"",req_url);

  }
    ///=============== load account_urls data on the fly ==============


 ///=quick load 
 
function qkload_account_urls(qstr, push_fun="", ui_card="", and_query="", additional_cols="", account_urls_pagination="",route_url_name="smartsend")
{


      account_urls_list_nodes_str=ui_card;
  
   
   var account_urls_qret_fun="push_grid_result:account_urls_tbl_list";
   
   if(push_fun!="")
   {
    account_urls_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }

   var req_url=route_url_name;

   get_account_urls("*", ajaxw+" ("+gft_account_urls(qstr)+") "+combined_query+"  order by primkey desc ", account_urls_list_cols+additional_cols_str, "",account_urls_qret_fun, "c=>"+account_urls_list_nodes_str, account_urls_pagination, req_url);
}


////////////// arithmetic function 


//count 

function count_account_urls(where_str, push_to, callback_function_string="", num_form="yes", route_url_name="smartsend")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }

   var req_url=route_url_name;

   get_account_urls("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "","",req_url);
   ///get_account_urls(account_urls_colstr, account_urls_filter_col, account_urls_cols, account_urls_node_function_name, account_urls_callback_function_string, account_urls_ui_tag, account_urls_pagination, route_url_name="smartsend") 

}


//qddata
function qaccount_urls_ddata(where_str, disp_col , push_to, callback_function_string="",route_url_name="smartsend")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }

   var req_url=route_url_name;

   get_account_urls("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "","",req_url);
   ///get_account_urls(account_urls_colstr, account_urls_filter_col, account_urls_cols, account_urls_node_function_name, account_urls_callback_function_string, account_urls_ui_tag, account_urls_pagination, route_url_name="smartsend")    

}



//sum 

function sum_account_urls(sum_col, where_str, push_to, callback_function_string="", num_form="yes",route_url_name="smartsend")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
           
    var req_url=route_url_name;

   get_account_urls("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "","",req_url);

}


///request handlers 

  
  function conf_del_account_urls_(account_urls_data_key, after_delete="blackhole",  cancel_function="blackhole()", push_to="alert_box")
  {


    magic_yes_no_alert('Delete record?', push_to, 'account_urls_rem_(\''+account_urls_data_key+'\', \''+after_delete+'\')', cancel_function)

  }


function mosy_account_urls_ins_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form",route_url_name="smartsend")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
    magic_message("Processing", "dialog_box")

    var req_url=route_url_name;

   account_urls_ins_(formid,"",response_fun,req_url)
 }
}

function mosy_account_urls_updt_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form", route_url_name="smartsend")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
   magic_message("Processing", "dialog_box")

   var req_url=route_url_name;

   account_urls_updt_(formid,"",response_fun,req_url)
 }
}

function account_urls_ins_(formid, required_inp=null, callback_function_string="",route_url_name="smartsend")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }

    var req_url=route_url_name;

    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "account_urls_insert_btn", callback_function_string_str, "", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function account_urls_updt_(formid, required_inp, callback_function_string="",route_url_name="smartsend")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);

     var req_url=route_url_name;
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "account_urls_update_btn", callback_function_string_str,"", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function account_urls_rem_(req_token, callback_function_string="",route_url_name="smartsend")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

 var req_url=route_url_name;
 
 mosyajax_get('conf_deleteaccount_urls&account_urls_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str,req_url);

}


function grid_account_urls_updt_(updt_key,colstr,newcolval, callback_function_string="",route_url_name="smartsend")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 

 var req_url=route_url_name;

mosyajax_get("_grid_updt_="+btoa('account_urls')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str,req_url);

}
  //============================================================ ++++ End account_urls datahandler js =============================
   
   ///account_urls data_nodes 
  var account_urls_data_nodes ='{{row_count}}|{{primkey}}|{{record_id}}|{{url_name}}|{{url}}|{{description}}|{{hive_site_id}}|{{hive_site_name}}';



   var account_urls_list_cols ="primkey:primkey,record_id:record_id,url_name:url_name,url:url,description:description,hive_site_id:hive_site_id,hive_site_name:hive_site_name";

;
        
   ///start account_urls search columns 
   
   var data_nodes_gft_account_urls_str="(primkey LIKE '%{{qaccount_urls}}%' OR  record_id LIKE '%{{qaccount_urls}}%' OR  url_name LIKE '%{{qaccount_urls}}%' OR  url LIKE '%{{qaccount_urls}}%' OR  description LIKE '%{{qaccount_urls}}%' OR  hive_site_id LIKE '%{{qaccount_urls}}%' OR  hive_site_name LIKE '%{{qaccount_urls}}%')";
    
    function  data_nodes_gft_account_urls(qaccount_urls_str)
    {
        	var data_nodes_clean_account_urls_filter_str=data_nodes_gft_account_urls_str.replace(/{{qaccount_urls}}/g, magic_clean_str(qaccount_urls_str));
            
            return  data_nodes_clean_account_urls_filter_str;

    }
       ///end account_urls search columns 

  function mosy_account_urls_ui_node (account_urls_json_data, account_urls_load_to, account_urls_cols_, account_urls_template_ui)
  {
     ////alert(account_urls_template_ui);
     var account_urls_cols_fun_cols_str ="";
     
     if(typeof account_urls_cols_fun_cols !== "undefined")
      {
        account_urls_cols_fun_cols_str=account_urls_cols_fun_cols;
        
        ///alert(account_urls_cols_fun_cols)
      } 
      
     var account_urls_ui__ = mosy_list_render_(account_urls_json_data, account_urls_cols_fun_cols_str+account_urls_cols_, account_urls_template_ui) 

     ////push_html(account_urls_load_to, account_urls_ui__)  

     push_grid_result(account_urls_ui__, account_urls_load_to)
  }
  
 
 ///////
 
 var account_urls_auto_function= '{"cbfun":"process_account_urls_json_data","_data_isle":"account_urls_data_isle","_pagination_isle":"account_urls_pagination_isle","_data_template":"hive_account_urls_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_account_urls","req_url":"smartsend"}';

 
 
 ///============ auto renders 
 
 
function mosy_account_urls_json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", account_urls_pagination_prefix_="__pgnt_account_urls", colstr="*", req_url="smartsend")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("account_urls", btoa(qstr))
  }else{
    mosy_delete_get_pram("account_urls")
  }
  
  if(mosy_get_param("account_urls")!==undefined)
  {
    qstr=atob(mosy_get_param("account_urls"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:account_urls_page_no:"+mosy_limit;
  }
  
  ///hive_account_urls_data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_account_urls_json_data","_data_isle":"account_urls_data_isle","_pagination_isle":"account_urls_pagination_isle","_data_template":"hive_account_urls_data_template","_payload_str":"req","_pagination_prefix":"'+account_urls_pagination_prefix_+'","req_url":"'+req_url+'"}';
            
  }
  
  return mosyrender_account_urls_(response_fun," where "+gft_account_urls(qstr)+" "+and_query_str+"  order by primkey desc ",function_cols,colstr,pagination, account_urls_pagination_prefix_,req_url)
  
}


  
  function autoprocess_account_urls_json_data(account_urls_server_resp)
  {  
    mosy_account_urls_ui_node(account_urls_server_resp, "account_urls_data_isle", account_urls_data_nodes, get_html(hive_account_urls_data_template),"", "l:account_urls_page_no:15")
    mosy_paginate_api(account_urls_server_resp, "account_urls_page_no", "account_urls_pagination_isle", "15")
  }
  
  function process_account_urls_json_data(account_urls_server_resp, account_urls_callback="")
  {  
      var account_urls_data_isle="account_urls_data_isle";
      var account_urls_data_node_template="hive_account_urls_data_template";
      var account_urls_pagination_isle="account_urls_pagination_isle";
      var account_urls_payload_str="";
      var account_urls__pagination_prefix_str="__pgnt_account_urls";
      
       ///alert(account_urls_callback)
       ///alert(account_urls_server_resp)
       ///console.log(account_urls_server_resp)
              
      try {
        
           const account_urls_jsonObject = JSON.parse(account_urls_callback);
        
           account_urls_data_isle=account_urls_jsonObject._data_isle;
           account_urls_data_node_template=account_urls_jsonObject._data_template;
           account_urls_pagination_isle=account_urls_jsonObject._pagination_isle;
           account_urls_payload_str=account_urls_jsonObject._payload_str;
           account_urls__pagination_prefix_str=account_urls_jsonObject._pagination_prefix;
           account_urls__req_url=account_urls_jsonObject.req_url;

           ///console.log("paginate == : valid JSON"+account_urls_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+account_urls_callback);
        
         if(account_urls_callback.indexOf(",") >= 0)
         {
              account_urls_data_handler_ui =account_urls_callback.split(",");                                 

              if(account_urls_data_handler_ui[0]!=undefined){ account_urls_data_isle=account_urls_data_handler_ui[0];}

              if(account_urls_data_handler_ui[1]!=undefined){account_urls_data_node_template =account_urls_data_handler_ui[1];}

              if(account_urls_data_handler_ui[2]!=undefined){ account_urls_pagination_isle=account_urls_data_handler_ui[2]};

              if(account_urls_data_handler_ui[3]!=undefined){ account_urls_payload_str=btoa(account_urls_data_handler_ui[3])};
              
              if(account_urls_data_handler_ui[4]!=undefined){ account_urls__pagination_prefix_str=btoa(account_urls_data_handler_ui[4])};

			  if(account_urls_data_handler_ui[5]!=undefined){ account_urls__req_url=account_urls_data_handler_ui[5]};                            
              
         }       
        
      }

       ///alert(" dtisle == "+account_urls_data_isle)
       
            mosy_account_urls_ui_node(account_urls_server_resp, account_urls_data_isle, account_urls_data_nodes, get_html(account_urls_data_node_template),"", "l:account_urls_page_no:"+mosy_limit)                       
            
             if(account_urls_payload_str==="req")
             {
                
                mosy_paginate_api(account_urls_server_resp, "account_urls_page_no", account_urls_pagination_isle, "process_account_urls_json_data", account_urls__pagination_prefix_str,account_urls__req_url)

             }
           
  }
    

function mosyrender_account_urls_(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_account_urls", req_url="smartsend")
{
   
  if(pagination==="")
  {
    pagination="l:account_urls_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _account_urls_payload="mosyget_&tbl=account_urls&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_account_urls_payload+curl_url)
  
  var _account_urls_pagination_json = '{"_payload":"'+_account_urls_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _account_urls_payload_input = document.createElement("input");
                _account_urls_payload_input.setAttribute('type', 'hidden');
                _account_urls_payload_input.setAttribute('name',_txt_payload);
                _account_urls_payload_input.setAttribute('id', _txt_payload);

                // Add the _account_urls_payload_input element to the DOM
                document.body.appendChild(_account_urls_payload_input);
                
      }
      
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
  push_newval(_txt_payload, _account_urls_pagination_json)
  mosyajax_get(_account_urls_payload, response_fun, req_url);
  
  return _account_urls_payload;
  
}


function mginitialize_account_urls(reqkey, response_fun="",req_url="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _account_urls_payload="mosyget_&tbl=account_urls&colstr="+btoa("*")+"&where_str="+btoa(" where primkey ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
     mosyajax_get(_account_urls_payload, response_fun, req_url);


}

 

