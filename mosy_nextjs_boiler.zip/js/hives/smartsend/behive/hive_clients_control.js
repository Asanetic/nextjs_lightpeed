//============================================================ ++++ start clients datahandler js =============================
   
    

    //Start get  clients Data ===============
    
      function get_clients(clients_colstr, clients_filter_col, clients_cols, clients_node_function_name, clients_callback_function_string, clients_ui_tag, clients_pagination, route_url_name="smartsend")
      {        
        var req_url=route_url_name;

        mosyflex_sel("clients", clients_colstr, clients_filter_col , clients_cols, clients_node_function_name, clients_callback_function_string, clients_ui_tag, clients_pagination,req_url);
        
      }
    //End get  clients Data ===============

    //Start insert  clients Data ===============

	function add_clients(clients_cols, clients_vals, clients_callback_function_string)
    {
		
        mosyajax_create_data("clients", clients_cols, clients_vals, clients_callback_function_string);
     }
     
    //End insert  clients Data ===============

    
    //Start update  clients Data ===============

    function update_clients(clients_update_str, clients_where_str, clients_callback_function_string){
    
		mosyajax_update("clients", clients_update_str, clients_where_str, clients_callback_function_string)
    
    }
    //end  update  clients Data ===============

	//Start drop  clients Data ===============
    function clients_drop(clients_where_str, clients_callback_function_string)
    {
        mosyajax_drop("clients", clients_where_str, clients_callback_function_string)

    }
	//End drop  clients Data ===============
    
    function initialize_clients(qstr="", clients_callback_function_string="",route_url_name="smartsend")
    {
    
    ///alert(qstr);
      var clients_token_query =qstr;
      if(qstr=="")
      {
       var clients_token_query_param="";
       var clients_js_uptoken=mosy_get_param("clients_uptoken");
       //alert(clients_js_uptoken);
       if(clients_js_uptoken!==undefined)
       {
       
        clients_token_query_param = atob(clients_js_uptoken);
       }
        clients_token_query = " where primkey='"+(clients_token_query_param)+"'";
        
           if (document.getElementById("clients_uptoken") !==null) {
           	if(document.getElementById("clients_uptoken").value!="")
            {
            
            var clients_atob_tbl_key =atob(document.getElementById("clients_uptoken").value);
            
                   
            clients_token_query = " where primkey='"+(clients_atob_tbl_key)+"'";

            }
           }
      }
      
      var clients_push_ui_data_to =clients_callback_function_string;
      if(clients_callback_function_string=="")
      {
      clients_push_ui_data_to = "add_clients_ui_data";
      }
                
      console.log(clients_token_query+" -- "+clients_js_uptoken);

	  //alert(clients_push_ui_data_to);

	 var req_url=route_url_name;

     get_clients("*", clients_token_query, "primkey", "blackhole", clients_push_ui_data_to, "", "", req_url);
     

    }
    
    function add_clients_ui_data(clients_server_resp) 
    {
    
    ///alert(clients_server_resp);
    
    var json_decoded_str=JSON.parse(clients_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          mosy_push_data_class("mosy_data_"+keys[i], val);
          
          // use val
      }
        
    }
    

    ///=============== load clients data on the fly ==============
    
	var gft_clients_str="(primkey LIKE '%{{qclients}}%' OR  user_id LIKE '%{{qclients}}%' OR  name LIKE '%{{qclients}}%' OR  email LIKE '%{{qclients}}%' OR  tel LIKE '%{{qclients}}%' OR  login_password LIKE '%{{qclients}}%' OR  ref_id LIKE '%{{qclients}}%' OR  regdate LIKE '%{{qclients}}%' OR  user_no LIKE '%{{qclients}}%' OR  user_pic LIKE '%{{qclients}}%' OR  user_gender LIKE '%{{qclients}}%' OR  last_seen LIKE '%{{qclients}}%' OR  city LIKE '%{{qclients}}%' OR  town LIKE '%{{qclients}}%' OR  client_type LIKE '%{{qclients}}%' OR  about LIKE '%{{qclients}}%' OR  active_state LIKE '%{{qclients}}%' OR  expiry_date LIKE '%{{qclients}}%' OR  service_id LIKE '%{{qclients}}%' OR  service_name LIKE '%{{qclients}}%' OR  hive_site_id LIKE '%{{qclients}}%' OR  hive_site_name LIKE '%{{qclients}}%')";
    
    function  gft_clients(qclients_str)
    {
        	var clean_clients_filter_str=gft_clients_str.replace(/{{qclients}}/g, magic_clean_str(qclients_str));
            
            return  clean_clients_filter_str;

    }
    
    function load_clients(clients_qstr, clients_where_str, clients_ret_cols, clients_user_function, clients_result_function, clients_data_tray, route_url_name="smartsend")
    {
    
    var fclients_result_function="push_result";
      
    if(clients_result_function!="")
    {
          var fclients_result_function=clients_result_function;

    }
    	var clean_clients_filter_str=gft_clients_str.replace(/{{qclients}}/g, magic_clean_str(clients_qstr));
        
        var fclients_where_str=" where "+clean_clients_filter_str;

    if(clients_where_str!="")
    {
          var fclients_where_str=" "+clients_where_str;

    }

	  var req_url=route_url_name;

      get_clients("*", fclients_where_str, clients_ret_cols, clients_user_function, fclients_result_function, clients_data_tray,"",req_url);

  }
    ///=============== load clients data on the fly ==============


 ///=quick load 
 
function qkload_clients(qstr, push_fun="", ui_card="", and_query="", additional_cols="", clients_pagination="",route_url_name="smartsend")
{


      clients_list_nodes_str=ui_card;
  
   
   var clients_qret_fun="push_grid_result:clients_tbl_list";
   
   if(push_fun!="")
   {
    clients_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }

   var req_url=route_url_name;

   get_clients("*", ajaxw+" ("+gft_clients(qstr)+") "+combined_query+"  order by primkey desc ", clients_list_cols+additional_cols_str, "",clients_qret_fun, "c=>"+clients_list_nodes_str, clients_pagination, req_url);
}


////////////// arithmetic function 


//count 

function count_clients(where_str, push_to, callback_function_string="", num_form="yes", route_url_name="smartsend")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }

   var req_url=route_url_name;

   get_clients("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "","",req_url);
   ///get_clients(clients_colstr, clients_filter_col, clients_cols, clients_node_function_name, clients_callback_function_string, clients_ui_tag, clients_pagination, route_url_name="smartsend") 

}


//qddata
function qclients_ddata(where_str, disp_col , push_to, callback_function_string="",route_url_name="smartsend")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }

   var req_url=route_url_name;

   get_clients("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "","",req_url);
   ///get_clients(clients_colstr, clients_filter_col, clients_cols, clients_node_function_name, clients_callback_function_string, clients_ui_tag, clients_pagination, route_url_name="smartsend")    

}



//sum 

function sum_clients(sum_col, where_str, push_to, callback_function_string="", num_form="yes",route_url_name="smartsend")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
           
    var req_url=route_url_name;

   get_clients("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "","",req_url);

}


///request handlers 

  
  function conf_del_clients_(clients_data_key, after_delete="blackhole",  cancel_function="blackhole()", push_to="alert_box")
  {


    magic_yes_no_alert('Delete record?', push_to, 'clients_rem_(\''+clients_data_key+'\', \''+after_delete+'\')', cancel_function)

  }


function mosy_clients_ins_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form",route_url_name="smartsend")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
    magic_message("Processing", "dialog_box")

    var req_url=route_url_name;

   clients_ins_(formid,"",response_fun,req_url)
 }
}

function mosy_clients_updt_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form", route_url_name="smartsend")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
   magic_message("Processing", "dialog_box")

   var req_url=route_url_name;

   clients_updt_(formid,"",response_fun,req_url)
 }
}

function clients_ins_(formid, required_inp=null, callback_function_string="",route_url_name="smartsend")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }

    var req_url=route_url_name;

    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "clients_insert_btn", callback_function_string_str, "", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function clients_updt_(formid, required_inp, callback_function_string="",route_url_name="smartsend")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);

     var req_url=route_url_name;
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "clients_update_btn", callback_function_string_str,"", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function clients_rem_(req_token, callback_function_string="",route_url_name="smartsend")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

 var req_url=route_url_name;
 
 mosyajax_get('conf_deleteclients&clients_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str,req_url);

}


function grid_clients_updt_(updt_key,colstr,newcolval, callback_function_string="",route_url_name="smartsend")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 

 var req_url=route_url_name;

mosyajax_get("_grid_updt_="+btoa('clients')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str,req_url);

}
  //============================================================ ++++ End clients datahandler js =============================
   
   ///clients data_nodes 
  var clients_data_nodes ='{{row_count}}|{{primkey}}|{{user_id}}|{{name}}|{{email}}|{{tel}}|{{login_password}}|{{ref_id}}|{{regdate}}|{{user_no}}|{{user_pic}}|{{user_gender}}|{{last_seen}}|{{city}}|{{town}}|{{client_type}}|{{about}}|{{active_state}}|{{expiry_date}}|{{service_id}}|{{service_name}}|{{hive_site_id}}|{{hive_site_name}}';



   var clients_list_cols ="primkey:primkey,user_id:user_id,name:name,email:email,tel:tel,login_password:login_password,ref_id:ref_id,regdate:regdate,user_no:user_no,user_pic:user_pic,user_gender:user_gender,last_seen:last_seen,city:city,town:town,client_type:client_type,about:about,active_state:active_state,expiry_date:expiry_date,service_id:service_id,service_name:service_name,hive_site_id:hive_site_id,hive_site_name:hive_site_name";

;
        
   ///start clients search columns 
   
   var data_nodes_gft_clients_str="(primkey LIKE '%{{qclients}}%' OR  user_id LIKE '%{{qclients}}%' OR  name LIKE '%{{qclients}}%' OR  email LIKE '%{{qclients}}%' OR  tel LIKE '%{{qclients}}%' OR  login_password LIKE '%{{qclients}}%' OR  ref_id LIKE '%{{qclients}}%' OR  regdate LIKE '%{{qclients}}%' OR  user_no LIKE '%{{qclients}}%' OR  user_pic LIKE '%{{qclients}}%' OR  user_gender LIKE '%{{qclients}}%' OR  last_seen LIKE '%{{qclients}}%' OR  city LIKE '%{{qclients}}%' OR  town LIKE '%{{qclients}}%' OR  client_type LIKE '%{{qclients}}%' OR  about LIKE '%{{qclients}}%' OR  active_state LIKE '%{{qclients}}%' OR  expiry_date LIKE '%{{qclients}}%' OR  service_id LIKE '%{{qclients}}%' OR  service_name LIKE '%{{qclients}}%' OR  hive_site_id LIKE '%{{qclients}}%' OR  hive_site_name LIKE '%{{qclients}}%')";
    
    function  data_nodes_gft_clients(qclients_str)
    {
        	var data_nodes_clean_clients_filter_str=data_nodes_gft_clients_str.replace(/{{qclients}}/g, magic_clean_str(qclients_str));
            
            return  data_nodes_clean_clients_filter_str;

    }
       ///end clients search columns 

  function mosy_clients_ui_node (clients_json_data, clients_load_to, clients_cols_, clients_template_ui)
  {
     ////alert(clients_template_ui);
     var clients_cols_fun_cols_str ="";
     
     if(typeof clients_cols_fun_cols !== "undefined")
      {
        clients_cols_fun_cols_str=clients_cols_fun_cols;
        
        ///alert(clients_cols_fun_cols)
      } 
      
     var clients_ui__ = mosy_list_render_(clients_json_data, clients_cols_fun_cols_str+clients_cols_, clients_template_ui) 

     ////push_html(clients_load_to, clients_ui__)  

     push_grid_result(clients_ui__, clients_load_to)
  }
  
 
 ///////
 
 var clients_auto_function= '{"cbfun":"process_clients_json_data","_data_isle":"clients_data_isle","_pagination_isle":"clients_pagination_isle","_data_template":"hive_clients_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_clients","req_url":"smartsend"}';

 
 
 ///============ auto renders 
 
 
function mosy_clients_json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", clients_pagination_prefix_="__pgnt_clients", colstr="*", req_url="smartsend")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("clients", btoa(qstr))
  }else{
    mosy_delete_get_pram("clients")
  }
  
  if(mosy_get_param("clients")!==undefined)
  {
    qstr=atob(mosy_get_param("clients"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:clients_page_no:"+mosy_limit;
  }
  
  ///hive_clients_data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_clients_json_data","_data_isle":"clients_data_isle","_pagination_isle":"clients_pagination_isle","_data_template":"hive_clients_data_template","_payload_str":"req","_pagination_prefix":"'+clients_pagination_prefix_+'","req_url":"'+req_url+'"}';
            
  }
  
  return mosyrender_clients_(response_fun," where "+gft_clients(qstr)+" "+and_query_str+"  order by primkey desc ",function_cols,colstr,pagination, clients_pagination_prefix_,req_url)
  
}


  
  function autoprocess_clients_json_data(clients_server_resp)
  {  
    mosy_clients_ui_node(clients_server_resp, "clients_data_isle", clients_data_nodes, get_html(hive_clients_data_template),"", "l:clients_page_no:15")
    mosy_paginate_api(clients_server_resp, "clients_page_no", "clients_pagination_isle", "15")
  }
  
  function process_clients_json_data(clients_server_resp, clients_callback="")
  {  
      var clients_data_isle="clients_data_isle";
      var clients_data_node_template="hive_clients_data_template";
      var clients_pagination_isle="clients_pagination_isle";
      var clients_payload_str="";
      var clients__pagination_prefix_str="__pgnt_clients";
      
       ///alert(clients_callback)
       ///alert(clients_server_resp)
       ///console.log(clients_server_resp)
              
      try {
        
           const clients_jsonObject = JSON.parse(clients_callback);
        
           clients_data_isle=clients_jsonObject._data_isle;
           clients_data_node_template=clients_jsonObject._data_template;
           clients_pagination_isle=clients_jsonObject._pagination_isle;
           clients_payload_str=clients_jsonObject._payload_str;
           clients__pagination_prefix_str=clients_jsonObject._pagination_prefix;
           clients__req_url=clients_jsonObject.req_url;

           ///console.log("paginate == : valid JSON"+clients_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+clients_callback);
        
         if(clients_callback.indexOf(",") >= 0)
         {
              clients_data_handler_ui =clients_callback.split(",");                                 

              if(clients_data_handler_ui[0]!=undefined){ clients_data_isle=clients_data_handler_ui[0];}

              if(clients_data_handler_ui[1]!=undefined){clients_data_node_template =clients_data_handler_ui[1];}

              if(clients_data_handler_ui[2]!=undefined){ clients_pagination_isle=clients_data_handler_ui[2]};

              if(clients_data_handler_ui[3]!=undefined){ clients_payload_str=btoa(clients_data_handler_ui[3])};
              
              if(clients_data_handler_ui[4]!=undefined){ clients__pagination_prefix_str=btoa(clients_data_handler_ui[4])};

			  if(clients_data_handler_ui[5]!=undefined){ clients__req_url=clients_data_handler_ui[5]};                            
              
         }       
        
      }

       ///alert(" dtisle == "+clients_data_isle)
       
            mosy_clients_ui_node(clients_server_resp, clients_data_isle, clients_data_nodes, get_html(clients_data_node_template),"", "l:clients_page_no:"+mosy_limit)                       
            
             if(clients_payload_str==="req")
             {
                
                mosy_paginate_api(clients_server_resp, "clients_page_no", clients_pagination_isle, "process_clients_json_data", clients__pagination_prefix_str,clients__req_url)

             }
           
  }
    

function mosyrender_clients_(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_clients", req_url="smartsend")
{
   
  if(pagination==="")
  {
    pagination="l:clients_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _clients_payload="mosyget_&tbl=clients&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_clients_payload+curl_url)
  
  var _clients_pagination_json = '{"_payload":"'+_clients_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _clients_payload_input = document.createElement("input");
                _clients_payload_input.setAttribute('type', 'hidden');
                _clients_payload_input.setAttribute('name',_txt_payload);
                _clients_payload_input.setAttribute('id', _txt_payload);

                // Add the _clients_payload_input element to the DOM
                document.body.appendChild(_clients_payload_input);
                
      }
      
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
  push_newval(_txt_payload, _clients_pagination_json)
  mosyajax_get(_clients_payload, response_fun, req_url);
  
  return _clients_payload;
  
}


function mginitialize_clients(reqkey, response_fun="",req_url="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _clients_payload="mosyget_&tbl=clients&colstr="+btoa("*")+"&where_str="+btoa(" where primkey ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
     mosyajax_get(_clients_payload, response_fun, req_url);


}

 

