//============================================================ ++++ start messaging datahandler js =============================
   
    

    //Start get  messaging Data ===============
    
      function get_messaging(messaging_colstr, messaging_filter_col, messaging_cols, messaging_node_function_name, messaging_callback_function_string, messaging_ui_tag, messaging_pagination, route_url_name="smartsend")
      {        
        var req_url=route_url_name;

        mosyflex_sel("messaging", messaging_colstr, messaging_filter_col , messaging_cols, messaging_node_function_name, messaging_callback_function_string, messaging_ui_tag, messaging_pagination,req_url);
        
      }
    //End get  messaging Data ===============

    //Start insert  messaging Data ===============

	function add_messaging(messaging_cols, messaging_vals, messaging_callback_function_string)
    {
		
        mosyajax_create_data("messaging", messaging_cols, messaging_vals, messaging_callback_function_string);
     }
     
    //End insert  messaging Data ===============

    
    //Start update  messaging Data ===============

    function update_messaging(messaging_update_str, messaging_where_str, messaging_callback_function_string){
    
		mosyajax_update("messaging", messaging_update_str, messaging_where_str, messaging_callback_function_string)
    
    }
    //end  update  messaging Data ===============

	//Start drop  messaging Data ===============
    function messaging_drop(messaging_where_str, messaging_callback_function_string)
    {
        mosyajax_drop("messaging", messaging_where_str, messaging_callback_function_string)

    }
	//End drop  messaging Data ===============
    
    function initialize_messaging(qstr="", messaging_callback_function_string="",route_url_name="smartsend")
    {
    
    ///alert(qstr);
      var messaging_token_query =qstr;
      if(qstr=="")
      {
       var messaging_token_query_param="";
       var messaging_js_uptoken=mosy_get_param("messaging_uptoken");
       //alert(messaging_js_uptoken);
       if(messaging_js_uptoken!==undefined)
       {
       
        messaging_token_query_param = atob(messaging_js_uptoken);
       }
        messaging_token_query = " where primkey='"+(messaging_token_query_param)+"'";
        
           if (document.getElementById("messaging_uptoken") !==null) {
           	if(document.getElementById("messaging_uptoken").value!="")
            {
            
            var messaging_atob_tbl_key =atob(document.getElementById("messaging_uptoken").value);
            
                   
            messaging_token_query = " where primkey='"+(messaging_atob_tbl_key)+"'";

            }
           }
      }
      
      var messaging_push_ui_data_to =messaging_callback_function_string;
      if(messaging_callback_function_string=="")
      {
      messaging_push_ui_data_to = "add_messaging_ui_data";
      }
                
      console.log(messaging_token_query+" -- "+messaging_js_uptoken);

	  //alert(messaging_push_ui_data_to);

	 var req_url=route_url_name;

     get_messaging("*", messaging_token_query, "primkey", "blackhole", messaging_push_ui_data_to, "", "", req_url);
     

    }
    
    function add_messaging_ui_data(messaging_server_resp) 
    {
    
    ///alert(messaging_server_resp);
    
    var json_decoded_str=JSON.parse(messaging_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          mosy_push_data_class("mosy_data_"+keys[i], val);
          
          // use val
      }
        
    }
    

    ///=============== load messaging data on the fly ==============
    
	var gft_messaging_str="(primkey LIKE '%{{qmessaging}}%' OR  messageid LIKE '%{{qmessaging}}%' OR  receiver_contacts LIKE '%{{qmessaging}}%' OR  reciver_names LIKE '%{{qmessaging}}%' OR  message_type LIKE '%{{qmessaging}}%' OR  site_id LIKE '%{{qmessaging}}%' OR  group_name LIKE '%{{qmessaging}}%' OR  message_date LIKE '%{{qmessaging}}%' OR  sent_state LIKE '%{{qmessaging}}%' OR  msg_read_state LIKE '%{{qmessaging}}%' OR  subject LIKE '%{{qmessaging}}%' OR  message_label LIKE '%{{qmessaging}}%' OR  about LIKE '%{{qmessaging}}%' OR  sms_cost LIKE '%{{qmessaging}}%' OR  page_count LIKE '%{{qmessaging}}%' OR  hive_site_id LIKE '%{{qmessaging}}%' OR  hive_site_name LIKE '%{{qmessaging}}%' OR  custom_dictionary LIKE '%{{qmessaging}}%' OR  message_signature LIKE '%{{qmessaging}}%')";
    
    function  gft_messaging(qmessaging_str)
    {
        	var clean_messaging_filter_str=gft_messaging_str.replace(/{{qmessaging}}/g, magic_clean_str(qmessaging_str));
            
            return  clean_messaging_filter_str;

    }
    
    function load_messaging(messaging_qstr, messaging_where_str, messaging_ret_cols, messaging_user_function, messaging_result_function, messaging_data_tray, route_url_name="smartsend")
    {
    
    var fmessaging_result_function="push_result";
      
    if(messaging_result_function!="")
    {
          var fmessaging_result_function=messaging_result_function;

    }
    	var clean_messaging_filter_str=gft_messaging_str.replace(/{{qmessaging}}/g, magic_clean_str(messaging_qstr));
        
        var fmessaging_where_str=" where "+clean_messaging_filter_str;

    if(messaging_where_str!="")
    {
          var fmessaging_where_str=" "+messaging_where_str;

    }

	  var req_url=route_url_name;

      get_messaging("*", fmessaging_where_str, messaging_ret_cols, messaging_user_function, fmessaging_result_function, messaging_data_tray,"",req_url);

  }
    ///=============== load messaging data on the fly ==============


 ///=quick load 
 
function qkload_messaging(qstr, push_fun="", ui_card="", and_query="", additional_cols="", messaging_pagination="",route_url_name="smartsend")
{


      messaging_list_nodes_str=ui_card;
  
   
   var messaging_qret_fun="push_grid_result:messaging_tbl_list";
   
   if(push_fun!="")
   {
    messaging_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }

   var req_url=route_url_name;

   get_messaging("*", ajaxw+" ("+gft_messaging(qstr)+") "+combined_query+"  order by primkey desc ", messaging_list_cols+additional_cols_str, "",messaging_qret_fun, "c=>"+messaging_list_nodes_str, messaging_pagination, req_url);
}


////////////// arithmetic function 


//count 

function count_messaging(where_str, push_to, callback_function_string="", num_form="yes", route_url_name="smartsend")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }

   var req_url=route_url_name;

   get_messaging("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "","",req_url);
   ///get_messaging(messaging_colstr, messaging_filter_col, messaging_cols, messaging_node_function_name, messaging_callback_function_string, messaging_ui_tag, messaging_pagination, route_url_name="smartsend") 

}


//qddata
function qmessaging_ddata(where_str, disp_col , push_to, callback_function_string="",route_url_name="smartsend")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }

   var req_url=route_url_name;

   get_messaging("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "","",req_url);
   ///get_messaging(messaging_colstr, messaging_filter_col, messaging_cols, messaging_node_function_name, messaging_callback_function_string, messaging_ui_tag, messaging_pagination, route_url_name="smartsend")    

}



//sum 

function sum_messaging(sum_col, where_str, push_to, callback_function_string="", num_form="yes",route_url_name="smartsend")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
           
    var req_url=route_url_name;

   get_messaging("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "","",req_url);

}


///request handlers 

  
  function conf_del_messaging_(messaging_data_key, after_delete="blackhole",  cancel_function="blackhole()", push_to="alert_box")
  {


    magic_yes_no_alert('Delete record?', push_to, 'messaging_rem_(\''+messaging_data_key+'\', \''+after_delete+'\')', cancel_function)

  }


function mosy_messaging_ins_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form",route_url_name="smartsend")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
    magic_message("Processing", "dialog_box")

    var req_url=route_url_name;

   messaging_ins_(formid,"",response_fun,req_url)
 }
}

function mosy_messaging_updt_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form", route_url_name="smartsend")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
   magic_message("Processing", "dialog_box")

   var req_url=route_url_name;

   messaging_updt_(formid,"",response_fun,req_url)
 }
}

function messaging_ins_(formid, required_inp=null, callback_function_string="",route_url_name="smartsend")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }

    var req_url=route_url_name;

    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "messaging_insert_btn", callback_function_string_str, "", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function messaging_updt_(formid, required_inp, callback_function_string="",route_url_name="smartsend")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);

     var req_url=route_url_name;
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "messaging_update_btn", callback_function_string_str,"", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function messaging_rem_(req_token, callback_function_string="",route_url_name="smartsend")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

 var req_url=route_url_name;
 
 mosyajax_get('conf_deletemessaging&messaging_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str,req_url);

}


function grid_messaging_updt_(updt_key,colstr,newcolval, callback_function_string="",route_url_name="smartsend")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 

 var req_url=route_url_name;

mosyajax_get("_grid_updt_="+btoa('messaging')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str,req_url);

}
  //============================================================ ++++ End messaging datahandler js =============================
   
   ///messaging data_nodes 
  var messaging_data_nodes ='{{row_count}}|{{primkey}}|{{messageid}}|{{receiver_contacts}}|{{reciver_names}}|{{message_type}}|{{site_id}}|{{group_name}}|{{message_date}}|{{sent_state}}|{{msg_read_state}}|{{subject}}|{{message_label}}|{{about}}|{{sms_cost}}|{{page_count}}|{{hive_site_id}}|{{hive_site_name}}|{{custom_dictionary}}|{{message_signature}}';



   var messaging_list_cols ="primkey:primkey,messageid:messageid,receiver_contacts:receiver_contacts,reciver_names:reciver_names,message_type:message_type,site_id:site_id,group_name:group_name,message_date:message_date,sent_state:sent_state,msg_read_state:msg_read_state,subject:subject,message_label:message_label,about:about,sms_cost:sms_cost,page_count:page_count,hive_site_id:hive_site_id,hive_site_name:hive_site_name,custom_dictionary:custom_dictionary,message_signature:message_signature";

;
        
   ///start messaging search columns 
   
   var data_nodes_gft_messaging_str="(primkey LIKE '%{{qmessaging}}%' OR  messageid LIKE '%{{qmessaging}}%' OR  receiver_contacts LIKE '%{{qmessaging}}%' OR  reciver_names LIKE '%{{qmessaging}}%' OR  message_type LIKE '%{{qmessaging}}%' OR  site_id LIKE '%{{qmessaging}}%' OR  group_name LIKE '%{{qmessaging}}%' OR  message_date LIKE '%{{qmessaging}}%' OR  sent_state LIKE '%{{qmessaging}}%' OR  msg_read_state LIKE '%{{qmessaging}}%' OR  subject LIKE '%{{qmessaging}}%' OR  message_label LIKE '%{{qmessaging}}%' OR  about LIKE '%{{qmessaging}}%' OR  sms_cost LIKE '%{{qmessaging}}%' OR  page_count LIKE '%{{qmessaging}}%' OR  hive_site_id LIKE '%{{qmessaging}}%' OR  hive_site_name LIKE '%{{qmessaging}}%' OR  custom_dictionary LIKE '%{{qmessaging}}%' OR  message_signature LIKE '%{{qmessaging}}%')";
    
    function  data_nodes_gft_messaging(qmessaging_str)
    {
        	var data_nodes_clean_messaging_filter_str=data_nodes_gft_messaging_str.replace(/{{qmessaging}}/g, magic_clean_str(qmessaging_str));
            
            return  data_nodes_clean_messaging_filter_str;

    }
       ///end messaging search columns 

  function mosy_messaging_ui_node (messaging_json_data, messaging_load_to, messaging_cols_, messaging_template_ui)
  {
     ////alert(messaging_template_ui);
     var messaging_cols_fun_cols_str ="";
     
     if(typeof messaging_cols_fun_cols !== "undefined")
      {
        messaging_cols_fun_cols_str=messaging_cols_fun_cols;
        
        ///alert(messaging_cols_fun_cols)
      } 
      
     var messaging_ui__ = mosy_list_render_(messaging_json_data, messaging_cols_fun_cols_str+messaging_cols_, messaging_template_ui) 

     ////push_html(messaging_load_to, messaging_ui__)  

     push_grid_result(messaging_ui__, messaging_load_to)
  }
  
 
 ///////
 
 var messaging_auto_function= '{"cbfun":"process_messaging_json_data","_data_isle":"messaging_data_isle","_pagination_isle":"messaging_pagination_isle","_data_template":"hive_messaging_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_messaging","req_url":"smartsend"}';

 
 
 ///============ auto renders 
 
 
function mosy_messaging_json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", messaging_pagination_prefix_="__pgnt_messaging", colstr="*", req_url="smartsend")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("messaging", btoa(qstr))
  }else{
    mosy_delete_get_pram("messaging")
  }
  
  if(mosy_get_param("messaging")!==undefined)
  {
    qstr=atob(mosy_get_param("messaging"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:messaging_page_no:"+mosy_limit;
  }
  
  ///hive_messaging_data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_messaging_json_data","_data_isle":"messaging_data_isle","_pagination_isle":"messaging_pagination_isle","_data_template":"hive_messaging_data_template","_payload_str":"req","_pagination_prefix":"'+messaging_pagination_prefix_+'","req_url":"'+req_url+'"}';
            
  }
  
  return mosyrender_messaging_(response_fun," where "+gft_messaging(qstr)+" "+and_query_str+"  order by primkey desc ",function_cols,colstr,pagination, messaging_pagination_prefix_,req_url)
  
}


  
  function autoprocess_messaging_json_data(messaging_server_resp)
  {  
    mosy_messaging_ui_node(messaging_server_resp, "messaging_data_isle", messaging_data_nodes, get_html(hive_messaging_data_template),"", "l:messaging_page_no:15")
    mosy_paginate_api(messaging_server_resp, "messaging_page_no", "messaging_pagination_isle", "15")
  }
  
  function process_messaging_json_data(messaging_server_resp, messaging_callback="")
  {  
      var messaging_data_isle="messaging_data_isle";
      var messaging_data_node_template="hive_messaging_data_template";
      var messaging_pagination_isle="messaging_pagination_isle";
      var messaging_payload_str="";
      var messaging__pagination_prefix_str="__pgnt_messaging";
      
       ///alert(messaging_callback)
       ///alert(messaging_server_resp)
       ///console.log(messaging_server_resp)
              
      try {
        
           const messaging_jsonObject = JSON.parse(messaging_callback);
        
           messaging_data_isle=messaging_jsonObject._data_isle;
           messaging_data_node_template=messaging_jsonObject._data_template;
           messaging_pagination_isle=messaging_jsonObject._pagination_isle;
           messaging_payload_str=messaging_jsonObject._payload_str;
           messaging__pagination_prefix_str=messaging_jsonObject._pagination_prefix;
           messaging__req_url=messaging_jsonObject.req_url;

           ///console.log("paginate == : valid JSON"+messaging_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+messaging_callback);
        
         if(messaging_callback.indexOf(",") >= 0)
         {
              messaging_data_handler_ui =messaging_callback.split(",");                                 

              if(messaging_data_handler_ui[0]!=undefined){ messaging_data_isle=messaging_data_handler_ui[0];}

              if(messaging_data_handler_ui[1]!=undefined){messaging_data_node_template =messaging_data_handler_ui[1];}

              if(messaging_data_handler_ui[2]!=undefined){ messaging_pagination_isle=messaging_data_handler_ui[2]};

              if(messaging_data_handler_ui[3]!=undefined){ messaging_payload_str=btoa(messaging_data_handler_ui[3])};
              
              if(messaging_data_handler_ui[4]!=undefined){ messaging__pagination_prefix_str=btoa(messaging_data_handler_ui[4])};

			  if(messaging_data_handler_ui[5]!=undefined){ messaging__req_url=messaging_data_handler_ui[5]};                            
              
         }       
        
      }

       ///alert(" dtisle == "+messaging_data_isle)
       
            mosy_messaging_ui_node(messaging_server_resp, messaging_data_isle, messaging_data_nodes, get_html(messaging_data_node_template),"", "l:messaging_page_no:"+mosy_limit)                       
            
             if(messaging_payload_str==="req")
             {
                
                mosy_paginate_api(messaging_server_resp, "messaging_page_no", messaging_pagination_isle, "process_messaging_json_data", messaging__pagination_prefix_str,messaging__req_url)

             }
           
  }
    

function mosyrender_messaging_(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_messaging", req_url="smartsend")
{
   
  if(pagination==="")
  {
    pagination="l:messaging_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _messaging_payload="mosyget_&tbl=messaging&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_messaging_payload+curl_url)
  
  var _messaging_pagination_json = '{"_payload":"'+_messaging_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _messaging_payload_input = document.createElement("input");
                _messaging_payload_input.setAttribute('type', 'hidden');
                _messaging_payload_input.setAttribute('name',_txt_payload);
                _messaging_payload_input.setAttribute('id', _txt_payload);

                // Add the _messaging_payload_input element to the DOM
                document.body.appendChild(_messaging_payload_input);
                
      }
      
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
  push_newval(_txt_payload, _messaging_pagination_json)
  mosyajax_get(_messaging_payload, response_fun, req_url);
  
  return _messaging_payload;
  
}


function mginitialize_messaging(reqkey, response_fun="",req_url="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _messaging_payload="mosyget_&tbl=messaging&colstr="+btoa("*")+"&where_str="+btoa(" where primkey ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
     mosyajax_get(_messaging_payload, response_fun, req_url);


}

 

