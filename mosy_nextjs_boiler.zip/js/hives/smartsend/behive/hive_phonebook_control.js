//============================================================ ++++ start phonebook datahandler js =============================
   
    

    //Start get  phonebook Data ===============
    
      function get_phonebook(phonebook_colstr, phonebook_filter_col, phonebook_cols, phonebook_node_function_name, phonebook_callback_function_string, phonebook_ui_tag, phonebook_pagination, route_url_name="smartsend")
      {        
        var req_url=route_url_name;

        mosyflex_sel("phonebook", phonebook_colstr, phonebook_filter_col , phonebook_cols, phonebook_node_function_name, phonebook_callback_function_string, phonebook_ui_tag, phonebook_pagination,req_url);
        
      }
    //End get  phonebook Data ===============

    //Start insert  phonebook Data ===============

	function add_phonebook(phonebook_cols, phonebook_vals, phonebook_callback_function_string)
    {
		
        mosyajax_create_data("phonebook", phonebook_cols, phonebook_vals, phonebook_callback_function_string);
     }
     
    //End insert  phonebook Data ===============

    
    //Start update  phonebook Data ===============

    function update_phonebook(phonebook_update_str, phonebook_where_str, phonebook_callback_function_string){
    
		mosyajax_update("phonebook", phonebook_update_str, phonebook_where_str, phonebook_callback_function_string)
    
    }
    //end  update  phonebook Data ===============

	//Start drop  phonebook Data ===============
    function phonebook_drop(phonebook_where_str, phonebook_callback_function_string)
    {
        mosyajax_drop("phonebook", phonebook_where_str, phonebook_callback_function_string)

    }
	//End drop  phonebook Data ===============
    
    function initialize_phonebook(qstr="", phonebook_callback_function_string="",route_url_name="smartsend")
    {
    
    ///alert(qstr);
      var phonebook_token_query =qstr;
      if(qstr=="")
      {
       var phonebook_token_query_param="";
       var phonebook_js_uptoken=mosy_get_param("phonebook_uptoken");
       //alert(phonebook_js_uptoken);
       if(phonebook_js_uptoken!==undefined)
       {
       
        phonebook_token_query_param = atob(phonebook_js_uptoken);
       }
        phonebook_token_query = " where primkey='"+(phonebook_token_query_param)+"'";
        
           if (document.getElementById("phonebook_uptoken") !==null) {
           	if(document.getElementById("phonebook_uptoken").value!="")
            {
            
            var phonebook_atob_tbl_key =atob(document.getElementById("phonebook_uptoken").value);
            
                   
            phonebook_token_query = " where primkey='"+(phonebook_atob_tbl_key)+"'";

            }
           }
      }
      
      var phonebook_push_ui_data_to =phonebook_callback_function_string;
      if(phonebook_callback_function_string=="")
      {
      phonebook_push_ui_data_to = "add_phonebook_ui_data";
      }
                
      console.log(phonebook_token_query+" -- "+phonebook_js_uptoken);

	  //alert(phonebook_push_ui_data_to);

	 var req_url=route_url_name;

     get_phonebook("*", phonebook_token_query, "primkey", "blackhole", phonebook_push_ui_data_to, "", "", req_url);
     

    }
    
    function add_phonebook_ui_data(phonebook_server_resp) 
    {
    
    ///alert(phonebook_server_resp);
    
    var json_decoded_str=JSON.parse(phonebook_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          mosy_push_data_class("mosy_data_"+keys[i], val);
          
          // use val
      }
        
    }
    

    ///=============== load phonebook data on the fly ==============
    
	var gft_phonebook_str="(primkey LIKE '%{{qphonebook}}%' OR  contact_id LIKE '%{{qphonebook}}%' OR  name LIKE '%{{qphonebook}}%' OR  email LIKE '%{{qphonebook}}%' OR  tel LIKE '%{{qphonebook}}%' OR  profile_photo LIKE '%{{qphonebook}}%' OR  username LIKE '%{{qphonebook}}%' OR  site_id LIKE '%{{qphonebook}}%' OR  hive_site_id LIKE '%{{qphonebook}}%' OR  hive_site_name LIKE '%{{qphonebook}}%')";
    
    function  gft_phonebook(qphonebook_str)
    {
        	var clean_phonebook_filter_str=gft_phonebook_str.replace(/{{qphonebook}}/g, magic_clean_str(qphonebook_str));
            
            return  clean_phonebook_filter_str;

    }
    
    function load_phonebook(phonebook_qstr, phonebook_where_str, phonebook_ret_cols, phonebook_user_function, phonebook_result_function, phonebook_data_tray, route_url_name="smartsend")
    {
    
    var fphonebook_result_function="push_result";
      
    if(phonebook_result_function!="")
    {
          var fphonebook_result_function=phonebook_result_function;

    }
    	var clean_phonebook_filter_str=gft_phonebook_str.replace(/{{qphonebook}}/g, magic_clean_str(phonebook_qstr));
        
        var fphonebook_where_str=" where "+clean_phonebook_filter_str;

    if(phonebook_where_str!="")
    {
          var fphonebook_where_str=" "+phonebook_where_str;

    }

	  var req_url=route_url_name;

      get_phonebook("*", fphonebook_where_str, phonebook_ret_cols, phonebook_user_function, fphonebook_result_function, phonebook_data_tray,"",req_url);

  }
    ///=============== load phonebook data on the fly ==============


 ///=quick load 
 
function qkload_phonebook(qstr, push_fun="", ui_card="", and_query="", additional_cols="", phonebook_pagination="",route_url_name="smartsend")
{


      phonebook_list_nodes_str=ui_card;
  
   
   var phonebook_qret_fun="push_grid_result:phonebook_tbl_list";
   
   if(push_fun!="")
   {
    phonebook_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }

   var req_url=route_url_name;

   get_phonebook("*", ajaxw+" ("+gft_phonebook(qstr)+") "+combined_query+"  order by primkey desc ", phonebook_list_cols+additional_cols_str, "",phonebook_qret_fun, "c=>"+phonebook_list_nodes_str, phonebook_pagination, req_url);
}


////////////// arithmetic function 


//count 

function count_phonebook(where_str, push_to, callback_function_string="", num_form="yes", route_url_name="smartsend")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }

   var req_url=route_url_name;

   get_phonebook("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "","",req_url);
   ///get_phonebook(phonebook_colstr, phonebook_filter_col, phonebook_cols, phonebook_node_function_name, phonebook_callback_function_string, phonebook_ui_tag, phonebook_pagination, route_url_name="smartsend") 

}


//qddata
function qphonebook_ddata(where_str, disp_col , push_to, callback_function_string="",route_url_name="smartsend")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }

   var req_url=route_url_name;

   get_phonebook("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "","",req_url);
   ///get_phonebook(phonebook_colstr, phonebook_filter_col, phonebook_cols, phonebook_node_function_name, phonebook_callback_function_string, phonebook_ui_tag, phonebook_pagination, route_url_name="smartsend")    

}



//sum 

function sum_phonebook(sum_col, where_str, push_to, callback_function_string="", num_form="yes",route_url_name="smartsend")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
           
    var req_url=route_url_name;

   get_phonebook("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "","",req_url);

}


///request handlers 

  
  function conf_del_phonebook_(phonebook_data_key, after_delete="blackhole",  cancel_function="blackhole()", push_to="alert_box")
  {


    magic_yes_no_alert('Delete record?', push_to, 'phonebook_rem_(\''+phonebook_data_key+'\', \''+after_delete+'\')', cancel_function)

  }


function mosy_phonebook_ins_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form",route_url_name="smartsend")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
    magic_message("Processing", "dialog_box")

    var req_url=route_url_name;

   phonebook_ins_(formid,"",response_fun,req_url)
 }
}

function mosy_phonebook_updt_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form", route_url_name="smartsend")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
   magic_message("Processing", "dialog_box")

   var req_url=route_url_name;

   phonebook_updt_(formid,"",response_fun,req_url)
 }
}

function phonebook_ins_(formid, required_inp=null, callback_function_string="",route_url_name="smartsend")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }

    var req_url=route_url_name;

    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "phonebook_insert_btn", callback_function_string_str, "", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function phonebook_updt_(formid, required_inp, callback_function_string="",route_url_name="smartsend")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);

     var req_url=route_url_name;
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "phonebook_update_btn", callback_function_string_str,"", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function phonebook_rem_(req_token, callback_function_string="",route_url_name="smartsend")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

 var req_url=route_url_name;
 
 mosyajax_get('conf_deletephonebook&phonebook_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str,req_url);

}


function grid_phonebook_updt_(updt_key,colstr,newcolval, callback_function_string="",route_url_name="smartsend")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 

 var req_url=route_url_name;

mosyajax_get("_grid_updt_="+btoa('phonebook')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str,req_url);

}
  //============================================================ ++++ End phonebook datahandler js =============================
   
   ///phonebook data_nodes 
  var phonebook_data_nodes ='{{row_count}}|{{primkey}}|{{contact_id}}|{{name}}|{{email}}|{{tel}}|{{profile_photo}}|{{username}}|{{site_id}}|{{hive_site_id}}|{{hive_site_name}}';



   var phonebook_list_cols ="primkey:primkey,contact_id:contact_id,name:name,email:email,tel:tel,profile_photo:profile_photo,username:username,site_id:site_id,hive_site_id:hive_site_id,hive_site_name:hive_site_name";

;
        
   ///start phonebook search columns 
   
   var data_nodes_gft_phonebook_str="(primkey LIKE '%{{qphonebook}}%' OR  contact_id LIKE '%{{qphonebook}}%' OR  name LIKE '%{{qphonebook}}%' OR  email LIKE '%{{qphonebook}}%' OR  tel LIKE '%{{qphonebook}}%' OR  profile_photo LIKE '%{{qphonebook}}%' OR  username LIKE '%{{qphonebook}}%' OR  site_id LIKE '%{{qphonebook}}%' OR  hive_site_id LIKE '%{{qphonebook}}%' OR  hive_site_name LIKE '%{{qphonebook}}%')";
    
    function  data_nodes_gft_phonebook(qphonebook_str)
    {
        	var data_nodes_clean_phonebook_filter_str=data_nodes_gft_phonebook_str.replace(/{{qphonebook}}/g, magic_clean_str(qphonebook_str));
            
            return  data_nodes_clean_phonebook_filter_str;

    }
       ///end phonebook search columns 

  function mosy_phonebook_ui_node (phonebook_json_data, phonebook_load_to, phonebook_cols_, phonebook_template_ui)
  {
     ////alert(phonebook_template_ui);
     var phonebook_cols_fun_cols_str ="";
     
     if(typeof phonebook_cols_fun_cols !== "undefined")
      {
        phonebook_cols_fun_cols_str=phonebook_cols_fun_cols;
        
        ///alert(phonebook_cols_fun_cols)
      } 
      
     var phonebook_ui__ = mosy_list_render_(phonebook_json_data, phonebook_cols_fun_cols_str+phonebook_cols_, phonebook_template_ui) 

     ////push_html(phonebook_load_to, phonebook_ui__)  

     push_grid_result(phonebook_ui__, phonebook_load_to)
  }
  
 
 ///////
 
 var phonebook_auto_function= '{"cbfun":"process_phonebook_json_data","_data_isle":"phonebook_data_isle","_pagination_isle":"phonebook_pagination_isle","_data_template":"hive_phonebook_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_phonebook","req_url":"smartsend"}';

 
 
 ///============ auto renders 
 
 
function mosy_phonebook_json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", phonebook_pagination_prefix_="__pgnt_phonebook", colstr="*", req_url="smartsend")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("phonebook", btoa(qstr))
  }else{
    mosy_delete_get_pram("phonebook")
  }
  
  if(mosy_get_param("phonebook")!==undefined)
  {
    qstr=atob(mosy_get_param("phonebook"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:phonebook_page_no:"+mosy_limit;
  }
  
  ///hive_phonebook_data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_phonebook_json_data","_data_isle":"phonebook_data_isle","_pagination_isle":"phonebook_pagination_isle","_data_template":"hive_phonebook_data_template","_payload_str":"req","_pagination_prefix":"'+phonebook_pagination_prefix_+'","req_url":"'+req_url+'"}';
            
  }
  
  return mosyrender_phonebook_(response_fun," where "+gft_phonebook(qstr)+" "+and_query_str+"  order by primkey desc ",function_cols,colstr,pagination, phonebook_pagination_prefix_,req_url)
  
}


  
  function autoprocess_phonebook_json_data(phonebook_server_resp)
  {  
    mosy_phonebook_ui_node(phonebook_server_resp, "phonebook_data_isle", phonebook_data_nodes, get_html(hive_phonebook_data_template),"", "l:phonebook_page_no:15")
    mosy_paginate_api(phonebook_server_resp, "phonebook_page_no", "phonebook_pagination_isle", "15")
  }
  
  function process_phonebook_json_data(phonebook_server_resp, phonebook_callback="")
  {  
      var phonebook_data_isle="phonebook_data_isle";
      var phonebook_data_node_template="hive_phonebook_data_template";
      var phonebook_pagination_isle="phonebook_pagination_isle";
      var phonebook_payload_str="";
      var phonebook__pagination_prefix_str="__pgnt_phonebook";
      
       ///alert(phonebook_callback)
       ///alert(phonebook_server_resp)
       ///console.log(phonebook_server_resp)
              
      try {
        
           const phonebook_jsonObject = JSON.parse(phonebook_callback);
        
           phonebook_data_isle=phonebook_jsonObject._data_isle;
           phonebook_data_node_template=phonebook_jsonObject._data_template;
           phonebook_pagination_isle=phonebook_jsonObject._pagination_isle;
           phonebook_payload_str=phonebook_jsonObject._payload_str;
           phonebook__pagination_prefix_str=phonebook_jsonObject._pagination_prefix;
           phonebook__req_url=phonebook_jsonObject.req_url;

           ///console.log("paginate == : valid JSON"+phonebook_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+phonebook_callback);
        
         if(phonebook_callback.indexOf(",") >= 0)
         {
              phonebook_data_handler_ui =phonebook_callback.split(",");                                 

              if(phonebook_data_handler_ui[0]!=undefined){ phonebook_data_isle=phonebook_data_handler_ui[0];}

              if(phonebook_data_handler_ui[1]!=undefined){phonebook_data_node_template =phonebook_data_handler_ui[1];}

              if(phonebook_data_handler_ui[2]!=undefined){ phonebook_pagination_isle=phonebook_data_handler_ui[2]};

              if(phonebook_data_handler_ui[3]!=undefined){ phonebook_payload_str=btoa(phonebook_data_handler_ui[3])};
              
              if(phonebook_data_handler_ui[4]!=undefined){ phonebook__pagination_prefix_str=btoa(phonebook_data_handler_ui[4])};

			  if(phonebook_data_handler_ui[5]!=undefined){ phonebook__req_url=phonebook_data_handler_ui[5]};                            
              
         }       
        
      }

       ///alert(" dtisle == "+phonebook_data_isle)
       
            mosy_phonebook_ui_node(phonebook_server_resp, phonebook_data_isle, phonebook_data_nodes, get_html(phonebook_data_node_template),"", "l:phonebook_page_no:"+mosy_limit)                       
            
             if(phonebook_payload_str==="req")
             {
                
                mosy_paginate_api(phonebook_server_resp, "phonebook_page_no", phonebook_pagination_isle, "process_phonebook_json_data", phonebook__pagination_prefix_str,phonebook__req_url)

             }
           
  }
    

function mosyrender_phonebook_(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_phonebook", req_url="smartsend")
{
   
  if(pagination==="")
  {
    pagination="l:phonebook_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _phonebook_payload="mosyget_&tbl=phonebook&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_phonebook_payload+curl_url)
  
  var _phonebook_pagination_json = '{"_payload":"'+_phonebook_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _phonebook_payload_input = document.createElement("input");
                _phonebook_payload_input.setAttribute('type', 'hidden');
                _phonebook_payload_input.setAttribute('name',_txt_payload);
                _phonebook_payload_input.setAttribute('id', _txt_payload);

                // Add the _phonebook_payload_input element to the DOM
                document.body.appendChild(_phonebook_payload_input);
                
      }
      
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
  push_newval(_txt_payload, _phonebook_pagination_json)
  mosyajax_get(_phonebook_payload, response_fun, req_url);
  
  return _phonebook_payload;
  
}


function mginitialize_phonebook(reqkey, response_fun="",req_url="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _phonebook_payload="mosyget_&tbl=phonebook&colstr="+btoa("*")+"&where_str="+btoa(" where primkey ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
     mosyajax_get(_phonebook_payload, response_fun, req_url);


}

 

