//============================================================ ++++ start send_list datahandler js =============================
   
    

    //Start get  send_list Data ===============
    
      function get_send_list(send_list_colstr, send_list_filter_col, send_list_cols, send_list_node_function_name, send_list_callback_function_string, send_list_ui_tag, send_list_pagination, route_url_name="smartsend")
      {        
        var req_url=route_url_name;

        mosyflex_sel("send_list", send_list_colstr, send_list_filter_col , send_list_cols, send_list_node_function_name, send_list_callback_function_string, send_list_ui_tag, send_list_pagination,req_url);
        
      }
    //End get  send_list Data ===============

    //Start insert  send_list Data ===============

	function add_send_list(send_list_cols, send_list_vals, send_list_callback_function_string)
    {
		
        mosyajax_create_data("send_list", send_list_cols, send_list_vals, send_list_callback_function_string);
     }
     
    //End insert  send_list Data ===============

    
    //Start update  send_list Data ===============

    function update_send_list(send_list_update_str, send_list_where_str, send_list_callback_function_string){
    
		mosyajax_update("send_list", send_list_update_str, send_list_where_str, send_list_callback_function_string)
    
    }
    //end  update  send_list Data ===============

	//Start drop  send_list Data ===============
    function send_list_drop(send_list_where_str, send_list_callback_function_string)
    {
        mosyajax_drop("send_list", send_list_where_str, send_list_callback_function_string)

    }
	//End drop  send_list Data ===============
    
    function initialize_send_list(qstr="", send_list_callback_function_string="",route_url_name="smartsend")
    {
    
    ///alert(qstr);
      var send_list_token_query =qstr;
      if(qstr=="")
      {
       var send_list_token_query_param="";
       var send_list_js_uptoken=mosy_get_param("send_list_uptoken");
       //alert(send_list_js_uptoken);
       if(send_list_js_uptoken!==undefined)
       {
       
        send_list_token_query_param = atob(send_list_js_uptoken);
       }
        send_list_token_query = " where primkey='"+(send_list_token_query_param)+"'";
        
           if (document.getElementById("send_list_uptoken") !==null) {
           	if(document.getElementById("send_list_uptoken").value!="")
            {
            
            var send_list_atob_tbl_key =atob(document.getElementById("send_list_uptoken").value);
            
                   
            send_list_token_query = " where primkey='"+(send_list_atob_tbl_key)+"'";

            }
           }
      }
      
      var send_list_push_ui_data_to =send_list_callback_function_string;
      if(send_list_callback_function_string=="")
      {
      send_list_push_ui_data_to = "add_send_list_ui_data";
      }
                
      console.log(send_list_token_query+" -- "+send_list_js_uptoken);

	  //alert(send_list_push_ui_data_to);

	 var req_url=route_url_name;

     get_send_list("*", send_list_token_query, "primkey", "blackhole", send_list_push_ui_data_to, "", "", req_url);
     

    }
    
    function add_send_list_ui_data(send_list_server_resp) 
    {
    
    ///alert(send_list_server_resp);
    
    var json_decoded_str=JSON.parse(send_list_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          mosy_push_data_class("mosy_data_"+keys[i], val);
          
          // use val
      }
        
    }
    

    ///=============== load send_list data on the fly ==============
    
	var gft_send_list_str="(primkey LIKE '%{{qsend_list}}%' OR  send_list_key LIKE '%{{qsend_list}}%' OR  send_list_name LIKE '%{{qsend_list}}%' OR  site_id LIKE '%{{qsend_list}}%' OR  contact_id LIKE '%{{qsend_list}}%' OR  contact_names LIKE '%{{qsend_list}}%' OR  mobile LIKE '%{{qsend_list}}%' OR  email LIKE '%{{qsend_list}}%' OR  ref_no LIKE '%{{qsend_list}}%' OR  group_name LIKE '%{{qsend_list}}%' OR  date_created LIKE '%{{qsend_list}}%' OR  description LIKE '%{{qsend_list}}%' OR  active_state LIKE '%{{qsend_list}}%' OR  service_id LIKE '%{{qsend_list}}%' OR  service_name LIKE '%{{qsend_list}}%' OR  hive_site_id LIKE '%{{qsend_list}}%' OR  hive_site_name LIKE '%{{qsend_list}}%' OR  entry_context LIKE '%{{qsend_list}}%')";
    
    function  gft_send_list(qsend_list_str)
    {
        	var clean_send_list_filter_str=gft_send_list_str.replace(/{{qsend_list}}/g, magic_clean_str(qsend_list_str));
            
            return  clean_send_list_filter_str;

    }
    
    function load_send_list(send_list_qstr, send_list_where_str, send_list_ret_cols, send_list_user_function, send_list_result_function, send_list_data_tray, route_url_name="smartsend")
    {
    
    var fsend_list_result_function="push_result";
      
    if(send_list_result_function!="")
    {
          var fsend_list_result_function=send_list_result_function;

    }
    	var clean_send_list_filter_str=gft_send_list_str.replace(/{{qsend_list}}/g, magic_clean_str(send_list_qstr));
        
        var fsend_list_where_str=" where "+clean_send_list_filter_str;

    if(send_list_where_str!="")
    {
          var fsend_list_where_str=" "+send_list_where_str;

    }

	  var req_url=route_url_name;

      get_send_list("*", fsend_list_where_str, send_list_ret_cols, send_list_user_function, fsend_list_result_function, send_list_data_tray,"",req_url);

  }
    ///=============== load send_list data on the fly ==============


 ///=quick load 
 
function qkload_send_list(qstr, push_fun="", ui_card="", and_query="", additional_cols="", send_list_pagination="",route_url_name="smartsend")
{


      send_list_list_nodes_str=ui_card;
  
   
   var send_list_qret_fun="push_grid_result:send_list_tbl_list";
   
   if(push_fun!="")
   {
    send_list_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }

   var req_url=route_url_name;

   get_send_list("*", ajaxw+" ("+gft_send_list(qstr)+") "+combined_query+"  order by primkey desc ", send_list_list_cols+additional_cols_str, "",send_list_qret_fun, "c=>"+send_list_list_nodes_str, send_list_pagination, req_url);
}


////////////// arithmetic function 


//count 

function count_send_list(where_str, push_to, callback_function_string="", num_form="yes", route_url_name="smartsend")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }

   var req_url=route_url_name;

   get_send_list("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "","",req_url);
   ///get_send_list(send_list_colstr, send_list_filter_col, send_list_cols, send_list_node_function_name, send_list_callback_function_string, send_list_ui_tag, send_list_pagination, route_url_name="smartsend") 

}


//qddata
function qsend_list_ddata(where_str, disp_col , push_to, callback_function_string="",route_url_name="smartsend")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }

   var req_url=route_url_name;

   get_send_list("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "","",req_url);
   ///get_send_list(send_list_colstr, send_list_filter_col, send_list_cols, send_list_node_function_name, send_list_callback_function_string, send_list_ui_tag, send_list_pagination, route_url_name="smartsend")    

}



//sum 

function sum_send_list(sum_col, where_str, push_to, callback_function_string="", num_form="yes",route_url_name="smartsend")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
           
    var req_url=route_url_name;

   get_send_list("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "","",req_url);

}


///request handlers 

  
  function conf_del_send_list_(send_list_data_key, after_delete="blackhole",  cancel_function="blackhole()", push_to="alert_box")
  {


    magic_yes_no_alert('Delete record?', push_to, 'send_list_rem_(\''+send_list_data_key+'\', \''+after_delete+'\')', cancel_function)

  }


function mosy_send_list_ins_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form",route_url_name="smartsend")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
    magic_message("Processing", "dialog_box")

    var req_url=route_url_name;

   send_list_ins_(formid,"",response_fun,req_url)
 }
}

function mosy_send_list_updt_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form", route_url_name="smartsend")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
   magic_message("Processing", "dialog_box")

   var req_url=route_url_name;

   send_list_updt_(formid,"",response_fun,req_url)
 }
}

function send_list_ins_(formid, required_inp=null, callback_function_string="",route_url_name="smartsend")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }

    var req_url=route_url_name;

    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "send_list_insert_btn", callback_function_string_str, "", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function send_list_updt_(formid, required_inp, callback_function_string="",route_url_name="smartsend")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);

     var req_url=route_url_name;
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "send_list_update_btn", callback_function_string_str,"", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function send_list_rem_(req_token, callback_function_string="",route_url_name="smartsend")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

 var req_url=route_url_name;
 
 mosyajax_get('conf_deletesend_list&send_list_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str,req_url);

}


function grid_send_list_updt_(updt_key,colstr,newcolval, callback_function_string="",route_url_name="smartsend")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 

 var req_url=route_url_name;

mosyajax_get("_grid_updt_="+btoa('send_list')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str,req_url);

}
  //============================================================ ++++ End send_list datahandler js =============================
   
   ///send_list data_nodes 
  var send_list_data_nodes ='{{row_count}}|{{primkey}}|{{send_list_key}}|{{send_list_name}}|{{site_id}}|{{contact_id}}|{{contact_names}}|{{mobile}}|{{email}}|{{ref_no}}|{{group_name}}|{{date_created}}|{{description}}|{{active_state}}|{{service_id}}|{{service_name}}|{{hive_site_id}}|{{hive_site_name}}|{{entry_context}}';



   var send_list_list_cols ="primkey:primkey,send_list_key:send_list_key,send_list_name:send_list_name,site_id:site_id,contact_id:contact_id,contact_names:contact_names,mobile:mobile,email:email,ref_no:ref_no,group_name:group_name,date_created:date_created,description:description,active_state:active_state,service_id:service_id,service_name:service_name,hive_site_id:hive_site_id,hive_site_name:hive_site_name,entry_context:entry_context";

;
        
   ///start send_list search columns 
   
   var data_nodes_gft_send_list_str="(primkey LIKE '%{{qsend_list}}%' OR  send_list_key LIKE '%{{qsend_list}}%' OR  send_list_name LIKE '%{{qsend_list}}%' OR  site_id LIKE '%{{qsend_list}}%' OR  contact_id LIKE '%{{qsend_list}}%' OR  contact_names LIKE '%{{qsend_list}}%' OR  mobile LIKE '%{{qsend_list}}%' OR  email LIKE '%{{qsend_list}}%' OR  ref_no LIKE '%{{qsend_list}}%' OR  group_name LIKE '%{{qsend_list}}%' OR  date_created LIKE '%{{qsend_list}}%' OR  description LIKE '%{{qsend_list}}%' OR  active_state LIKE '%{{qsend_list}}%' OR  service_id LIKE '%{{qsend_list}}%' OR  service_name LIKE '%{{qsend_list}}%' OR  hive_site_id LIKE '%{{qsend_list}}%' OR  hive_site_name LIKE '%{{qsend_list}}%' OR  entry_context LIKE '%{{qsend_list}}%')";
    
    function  data_nodes_gft_send_list(qsend_list_str)
    {
        	var data_nodes_clean_send_list_filter_str=data_nodes_gft_send_list_str.replace(/{{qsend_list}}/g, magic_clean_str(qsend_list_str));
            
            return  data_nodes_clean_send_list_filter_str;

    }
       ///end send_list search columns 

  function mosy_send_list_ui_node (send_list_json_data, send_list_load_to, send_list_cols_, send_list_template_ui)
  {
     ////alert(send_list_template_ui);
     var send_list_cols_fun_cols_str ="";
     
     if(typeof send_list_cols_fun_cols !== "undefined")
      {
        send_list_cols_fun_cols_str=send_list_cols_fun_cols;
        
        ///alert(send_list_cols_fun_cols)
      } 
      
     var send_list_ui__ = mosy_list_render_(send_list_json_data, send_list_cols_fun_cols_str+send_list_cols_, send_list_template_ui) 

     ////push_html(send_list_load_to, send_list_ui__)  

     push_grid_result(send_list_ui__, send_list_load_to)
  }
  
 
 ///////
 
 var send_list_auto_function= '{"cbfun":"process_send_list_json_data","_data_isle":"send_list_data_isle","_pagination_isle":"send_list_pagination_isle","_data_template":"hive_send_list_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_send_list","req_url":"smartsend"}';

 
 
 ///============ auto renders 
 
 
function mosy_send_list_json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", send_list_pagination_prefix_="__pgnt_send_list", colstr="*", req_url="smartsend")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("send_list", btoa(qstr))
  }else{
    mosy_delete_get_pram("send_list")
  }
  
  if(mosy_get_param("send_list")!==undefined)
  {
    qstr=atob(mosy_get_param("send_list"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:send_list_page_no:"+mosy_limit;
  }
  
  ///hive_send_list_data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_send_list_json_data","_data_isle":"send_list_data_isle","_pagination_isle":"send_list_pagination_isle","_data_template":"hive_send_list_data_template","_payload_str":"req","_pagination_prefix":"'+send_list_pagination_prefix_+'","req_url":"'+req_url+'"}';
            
  }
  
  return mosyrender_send_list_(response_fun," where "+gft_send_list(qstr)+" "+and_query_str+"  order by primkey desc ",function_cols,colstr,pagination, send_list_pagination_prefix_,req_url)
  
}


  
  function autoprocess_send_list_json_data(send_list_server_resp)
  {  
    mosy_send_list_ui_node(send_list_server_resp, "send_list_data_isle", send_list_data_nodes, get_html(hive_send_list_data_template),"", "l:send_list_page_no:15")
    mosy_paginate_api(send_list_server_resp, "send_list_page_no", "send_list_pagination_isle", "15")
  }
  
  function process_send_list_json_data(send_list_server_resp, send_list_callback="")
  {  
      var send_list_data_isle="send_list_data_isle";
      var send_list_data_node_template="hive_send_list_data_template";
      var send_list_pagination_isle="send_list_pagination_isle";
      var send_list_payload_str="";
      var send_list__pagination_prefix_str="__pgnt_send_list";
      
       ///alert(send_list_callback)
       ///alert(send_list_server_resp)
       ///console.log(send_list_server_resp)
              
      try {
        
           const send_list_jsonObject = JSON.parse(send_list_callback);
        
           send_list_data_isle=send_list_jsonObject._data_isle;
           send_list_data_node_template=send_list_jsonObject._data_template;
           send_list_pagination_isle=send_list_jsonObject._pagination_isle;
           send_list_payload_str=send_list_jsonObject._payload_str;
           send_list__pagination_prefix_str=send_list_jsonObject._pagination_prefix;
           send_list__req_url=send_list_jsonObject.req_url;

           ///console.log("paginate == : valid JSON"+send_list_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+send_list_callback);
        
         if(send_list_callback.indexOf(",") >= 0)
         {
              send_list_data_handler_ui =send_list_callback.split(",");                                 

              if(send_list_data_handler_ui[0]!=undefined){ send_list_data_isle=send_list_data_handler_ui[0];}

              if(send_list_data_handler_ui[1]!=undefined){send_list_data_node_template =send_list_data_handler_ui[1];}

              if(send_list_data_handler_ui[2]!=undefined){ send_list_pagination_isle=send_list_data_handler_ui[2]};

              if(send_list_data_handler_ui[3]!=undefined){ send_list_payload_str=btoa(send_list_data_handler_ui[3])};
              
              if(send_list_data_handler_ui[4]!=undefined){ send_list__pagination_prefix_str=btoa(send_list_data_handler_ui[4])};

			  if(send_list_data_handler_ui[5]!=undefined){ send_list__req_url=send_list_data_handler_ui[5]};                            
              
         }       
        
      }

       ///alert(" dtisle == "+send_list_data_isle)
       
            mosy_send_list_ui_node(send_list_server_resp, send_list_data_isle, send_list_data_nodes, get_html(send_list_data_node_template),"", "l:send_list_page_no:"+mosy_limit)                       
            
             if(send_list_payload_str==="req")
             {
                
                mosy_paginate_api(send_list_server_resp, "send_list_page_no", send_list_pagination_isle, "process_send_list_json_data", send_list__pagination_prefix_str,send_list__req_url)

             }
           
  }
    

function mosyrender_send_list_(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_send_list", req_url="smartsend")
{
   
  if(pagination==="")
  {
    pagination="l:send_list_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _send_list_payload="mosyget_&tbl=send_list&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_send_list_payload+curl_url)
  
  var _send_list_pagination_json = '{"_payload":"'+_send_list_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _send_list_payload_input = document.createElement("input");
                _send_list_payload_input.setAttribute('type', 'hidden');
                _send_list_payload_input.setAttribute('name',_txt_payload);
                _send_list_payload_input.setAttribute('id', _txt_payload);

                // Add the _send_list_payload_input element to the DOM
                document.body.appendChild(_send_list_payload_input);
                
      }
      
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
  push_newval(_txt_payload, _send_list_pagination_json)
  mosyajax_get(_send_list_payload, response_fun, req_url);
  
  return _send_list_payload;
  
}


function mginitialize_send_list(reqkey, response_fun="",req_url="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _send_list_payload="mosyget_&tbl=send_list&colstr="+btoa("*")+"&where_str="+btoa(" where primkey ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
     mosyajax_get(_send_list_payload, response_fun, req_url);


}

 

