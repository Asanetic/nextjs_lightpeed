
   const hive_app_users_ins_btn = document.querySelectorAll(".hive_app_users_ins_btn");
        hive_app_users_ins_btn.forEach(app_users_ins_btn => {
          app_users_ins_btn.addEventListener("click", event => {
          
          mosy_app_users_ins_fun()
          
          });
        });
        
        
   const hive_app_users_updt_btn = document.querySelectorAll(".hive_app_users_updt_btn");
        hive_app_users_updt_btn.forEach(app_users_updt_btn => {
          app_users_updt_btn.addEventListener("click", event => {
          
          mosy_app_users_updt_fun()
          
          });
        });

	  //// ================== cc view data nodes template =============
      ////var app_users_data_template=get_html("app_users_tbl_nodes");
	  //// ================== cc view data nodes template =============

      function loop_app_users_ui_data(qstr="",callback="", andquery="", _app_users_auto_function="")
      {      
        
        
         /// ==============app_users custom js auto response function  ================
    var custom_app_users_auto_function= '{"cbfun":"process_app_users_json_data","_data_isle":"app_users_data_isle:17","_pagination_isle":"app_users_pagination_isle","_data_template":"hive_app_users_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_app_users"}';
    
/// ==============app_users custom js auto response function  ================
   
    
      if(_app_users_auto_function!="")
      {
      	custom_app_users_auto_function = _app_users_auto_function
      }
    	
    
       if(callback!="")
       {
         qstr="";
         magic_message(callback, "dialog_box")
       }
       
       mosy_app_users_json_data_list(qstr, custom_app_users_auto_function, andquery);
       
       var and_count ="";
       if(andquery!="")
       {
          and_count=" and "+andquery
       }
        
      }
      

//== custom component app_users JS functions


