                        
                      var hive_app_users_data_template = 
                      `<!--- app_users data nodes -->
                        <div id="app_users_tbl_nodes">
                         <tr class="cpointer mosy_msdn " data-mosy_msdn="push_newval('app_users_uptoken',btoa('{{primkey}}'));mginitialize_app_users('{{primkey}}');">
                           <td scope="col" ><b class="">{{row_count}}</b></td>
                          							<td><img src="{{profile_photo}}" onerror="this.src=''"  style="width:50px; height:50px; border-radius:50%;"></td>

                          							<td>{{fullnames}}</td>
							<td>{{email_address}}</td>
							<td>{{mobile_number}}</td>
							<td>{{signupdate}}</td>
							<td>{{account_no}}</td>
							<td>{{gender}}</td>
							<td>{{last_seen}}</td>
							<td>{{site_id}}</td>
							<td>{{about}}</td>
							<td>{{company_email}}</td>
							<td>{{company_name}}</td>
							<td>{{hive_site_id}}</td>
							<td>{{hive_site_name}}</td>
    
                        </tr>
                        </div>`
                        
                     var hive_app_users_head_template = 
                      `<!--- app_users data head -->
                         <tr class="cpointer mosy_msdn ">
                           <td scope="col" ><b class="">#</b></td>
                           
                          							<th>PROFILE PHOTO</th>
    
                          							<th>FULLNAMES</th>
							<th>EMAIL ADDRESS</th>
							<th>MOBILE NUMBER</th>
							<th>SIGNUPDATE</th>
							<th>ACCOUNT NO</th>
							<th>GENDER</th>
							<th>LAST SEEN</th>
							<th>SITE ID</th>
							<th>ABOUT</th>
							<th>COMPANY EMAIL</th>
							<th>COMPANY NAME</th>
							<th>HIVE SITE ID</th>
							<th>HIVE SITE NAME</th>
    
                        </tr>`                                              
                        
              var hive_cv_app_users_search_input=` 
             <div class="col-md-12 m-0 p-0 ">
                     <input type="text" class="col-md-4 mb-2 ml-2 bg-transparent"  placeholder="Search app users " name="qtxt_app_users" id="qtxt_app_users" style="color:#000; border:none; border-bottom:1px solid #000;"/>
                     <button type="button" data-mosy_msdn="loop_app_users_ui_data(get_newval('qtxt_app_users'))" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2 mosy_msdn" name="qapp_users_btn" id="qapp_users_btn"><i class="fa fa-search"></i> Go </button>
                     <button type="button" class="badge badge-primary btn_neoo2 p-2 ml-2 mb-3 mosy_msdn " data-mosy_msdn="loop_app_users_ui_data()" ><i class="fa fa-refresh"></i> Refresh </button>                    
              </div>`;
