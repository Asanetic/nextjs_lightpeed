                        
                      var hive_message_templates_data_template = 
                      `<!--- message_templates data nodes -->
                        <div id="message_templates_tbl_nodes">
                         <tr class="cpointer mosy_msdn " data-mosy_msdn="push_newval('message_templates_uptoken',btoa('{{primkey}}'));mginitialize_message_templates('{{primkey}}');">
                           <td scope="col" ><b class="">{{row_count}}</b></td>
                          
                          							<td>{{template_name}}</td>
							<td>{{message_template}}</td>
							<td>{{template_code}}</td>
    
                        </tr>
                        </div>`
                        
                     var hive_message_templates_head_template = 
                      `<!--- message_templates data head -->
                         <tr class="cpointer mosy_msdn ">
                           <td scope="col" ><b class="">#</b></td>
                           
                              
                          							<th>TEMPLATE NAME</th>
							<th>MESSAGE TEMPLATE</th>
							<th>TEMPLATE CODE</th>
    
                        </tr>`                                              
                        
              var hive_cv_message_templates_search_input=` 
             <div class="col-md-12 m-0 p-0 ">
                     <input type="text" class="col-md-4 mb-2 ml-2 bg-transparent"  placeholder="Search message templates " name="qtxt_message_templates" id="qtxt_message_templates" style="color:#000; border:none; border-bottom:1px solid #000;"/>
                     <button type="button" data-mosy_msdn="loop_message_templates_ui_data(get_newval('qtxt_message_templates'))" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2 mosy_msdn" name="qmessage_templates_btn" id="qmessage_templates_btn"><i class="fa fa-search"></i> Go </button>
                     <button type="button" class="badge badge-primary btn_neoo2 p-2 ml-2 mb-3 mosy_msdn " data-mosy_msdn="loop_message_templates_ui_data()" ><i class="fa fa-refresh"></i> Refresh </button>                    
              </div>`;
