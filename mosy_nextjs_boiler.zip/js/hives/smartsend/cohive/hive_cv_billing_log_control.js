                        
                      var hive_billing_log_data_template = 
                      `<!--- billing_log data nodes -->
                        <div id="billing_log_tbl_nodes">
                         <tr class="cpointer mosy_msdn " data-mosy_msdn="push_newval('billing_log_uptoken',btoa('{{primkey}}'));mginitialize_billing_log('{{primkey}}');">
                           <td scope="col" ><b class="">{{row_count}}</b></td>
                          
                          							<td>{{transaction_ref}}</td>
							<td>{{trx_type}}</td>
							<td>{{trx_time}}</td>
							<td>{{amount}}</td>
							<td>{{trx_source}}</td>
							<td>{{ref_id}}</td>
							<td>{{site_id}}</td>
							<td>{{message}}</td>
							<td>{{hive_site_id}}</td>
							<td>{{hive_site_name}}</td>
    
                        </tr>
                        </div>`
                        
                     var hive_billing_log_head_template = 
                      `<!--- billing_log data head -->
                         <tr class="cpointer mosy_msdn ">
                           <td scope="col" ><b class="">#</b></td>
                           
                              
                          							<th>TRANSACTION REF</th>
							<th>TRX TYPE</th>
							<th>TRX TIME</th>
							<th>AMOUNT</th>
							<th>TRX SOURCE</th>
							<th>REF ID</th>
							<th>SITE ID</th>
							<th>MESSAGE</th>
							<th>HIVE SITE ID</th>
							<th>HIVE SITE NAME</th>
    
                        </tr>`                                              
                        
              var hive_cv_billing_log_search_input=` 
             <div class="col-md-12 m-0 p-0 ">
                     <input type="text" class="col-md-4 mb-2 ml-2 bg-transparent"  placeholder="Search billing log " name="qtxt_billing_log" id="qtxt_billing_log" style="color:#000; border:none; border-bottom:1px solid #000;"/>
                     <button type="button" data-mosy_msdn="loop_billing_log_ui_data(get_newval('qtxt_billing_log'))" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2 mosy_msdn" name="qbilling_log_btn" id="qbilling_log_btn"><i class="fa fa-search"></i> Go </button>
                     <button type="button" class="badge badge-primary btn_neoo2 p-2 ml-2 mb-3 mosy_msdn " data-mosy_msdn="loop_billing_log_ui_data()" ><i class="fa fa-refresh"></i> Refresh </button>                    
              </div>`;
