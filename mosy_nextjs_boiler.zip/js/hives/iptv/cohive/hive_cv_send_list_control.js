                        
                      var hive_send_list_data_template = 
                      `<!--- send_list data nodes -->
                        <div id="send_list_tbl_nodes">
                         <tr class="cpointer mosy_msdn " data-mosy_msdn="push_newval('send_list_uptoken',btoa('{{primkey}}'));mginitialize_send_list('{{primkey}}');">
                           <td scope="col" ><b class="">{{row_count}}</b></td>
                          
                          							<td>{{send_list_name}}</td>
							<td>{{site_id}}</td>
							<td>{{contact_id}}</td>
							<td>{{contact_names}}</td>
							<td>{{mobile}}</td>
							<td>{{email}}</td>
							<td>{{ref_no}}</td>
							<td>{{group_name}}</td>
							<td>{{date_created}}</td>
							<td>{{description}}</td>
							<td>{{active_state}}</td>
							<td>{{service_id}}</td>
							<td>{{service_name}}</td>
							<td>{{hive_site_id}}</td>
							<td>{{hive_site_name}}</td>
							<td>{{entry_context}}</td>
    
                        </tr>
                        </div>`
                        
                     var hive_send_list_head_template = 
                      `<!--- send_list data head -->
                         <tr class="cpointer mosy_msdn ">
                           <td scope="col" ><b class="">#</b></td>
                           
                              
                          							<th>SEND LIST NAME</th>
							<th>SITE ID</th>
							<th>CONTACT ID</th>
							<th>CONTACT NAMES</th>
							<th>MOBILE</th>
							<th>EMAIL</th>
							<th>REF NO</th>
							<th>GROUP NAME</th>
							<th>DATE CREATED</th>
							<th>DESCRIPTION</th>
							<th>ACTIVE STATE</th>
							<th>SERVICE ID</th>
							<th>SERVICE NAME</th>
							<th>HIVE SITE ID</th>
							<th>HIVE SITE NAME</th>
							<th>ENTRY CONTEXT</th>
    
                        </tr>`                                              
                        
              var hive_cv_send_list_search_input=` 
             <div class="col-md-12 m-0 p-0 ">
                     <input type="text" class="col-md-4 mb-2 ml-2 bg-transparent"  placeholder="Search send list " name="qtxt_send_list" id="qtxt_send_list" style="color:#000; border:none; border-bottom:1px solid #000;"/>
                     <button type="button" data-mosy_msdn="loop_send_list_ui_data(get_newval('qtxt_send_list'))" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2 mosy_msdn" name="qsend_list_btn" id="qsend_list_btn"><i class="fa fa-search"></i> Go </button>
                     <button type="button" class="badge badge-primary btn_neoo2 p-2 ml-2 mb-3 mosy_msdn " data-mosy_msdn="loop_send_list_ui_data()" ><i class="fa fa-refresh"></i> Refresh </button>                    
              </div>`;
