                        
                      var hive_transactions_data_template = 
                      `<!--- transactions data nodes -->
                        <div id="transactions_tbl_nodes">
                         <tr class="cpointer mosy_msdn " data-mosy_msdn="push_newval('transactions_uptoken',btoa('{{primkey}}'));mginitialize_transactions('{{primkey}}');">
                           <td scope="col" ><b class="">{{row_count}}</b></td>
                          
                          							<td>{{trx_id}}</td>
							<td>{{trx_date}}</td>
							<td>{{trx_month_year}}</td>
							<td>{{trx_remark}}</td>
							<td>{{amount}}</td>
							<td>{{trx_type}}</td>
							<td>{{business_id}}</td>
							<td>{{client_id}}</td>
							<td>{{admin_id}}</td>
							<td>{{TransactionType}}</td>
							<td>{{BusinessShortCode}}</td>
							<td>{{BillRefNumber}}</td>
							<td>{{InvoiceNumber}}</td>
							<td>{{OrgAccountBalance}}</td>
							<td>{{ThirdPartyTransID}}</td>
							<td>{{MSISDN}}</td>
							<td>{{FirstName}}</td>
							<td>{{MiddleName}}</td>
							<td>{{LastName}}</td>
							<td>{{trx_msg}}</td>
							<td>{{account_id}}</td>
							<td>{{used_status}}</td>
							<td>{{filter_date}}</td>
							<td>{{flw_id}}</td>
							<td>{{flag_state}}</td>
							<td>{{reconciled}}</td>
							<td>{{trx_timestamp}}</td>
							<td>{{hive_site_id}}</td>
							<td>{{hive_site_name}}</td>
    
                        </tr>
                        </div>`
                        
                     var hive_transactions_head_template = 
                      `<!--- transactions data head -->
                         <tr class="cpointer mosy_msdn ">
                           <td scope="col" ><b class="">#</b></td>
                           
                              
                          							<th>TRX ID</th>
							<th>TRX DATE</th>
							<th>TRX MONTH YEAR</th>
							<th>TRX REMARK</th>
							<th>AMOUNT</th>
							<th>TRX TYPE</th>
							<th>BUSINESS ID</th>
							<th>CLIENT ID</th>
							<th>ADMIN ID</th>
							<th>TRANSACTIONTYPE</th>
							<th>BUSINESSSHORTCODE</th>
							<th>BILLREFNUMBER</th>
							<th>INVOICENUMBER</th>
							<th>ORGACCOUNTBALANCE</th>
							<th>THIRDPARTYTRANSID</th>
							<th>MSISDN</th>
							<th>FIRSTNAME</th>
							<th>MIDDLENAME</th>
							<th>LASTNAME</th>
							<th>TRX MSG</th>
							<th>ACCOUNT ID</th>
							<th>USED STATUS</th>
							<th>FILTER DATE</th>
							<th>FLW ID</th>
							<th>FLAG STATE</th>
							<th>RECONCILED</th>
							<th>TRX TIMESTAMP</th>
							<th>HIVE SITE ID</th>
							<th>HIVE SITE NAME</th>
    
                        </tr>`                                              
                        
              var hive_cv_transactions_search_input=` 
             <div class="col-md-12 m-0 p-0 ">
                     <input type="text" class="col-md-4 mb-2 ml-2 bg-transparent"  placeholder="Search transactions " name="qtxt_transactions" id="qtxt_transactions" style="color:#000; border:none; border-bottom:1px solid #000;"/>
                     <button type="button" data-mosy_msdn="loop_transactions_ui_data(get_newval('qtxt_transactions'))" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2 mosy_msdn" name="qtransactions_btn" id="qtransactions_btn"><i class="fa fa-search"></i> Go </button>
                     <button type="button" class="badge badge-primary btn_neoo2 p-2 ml-2 mb-3 mosy_msdn " data-mosy_msdn="loop_transactions_ui_data()" ><i class="fa fa-refresh"></i> Refresh </button>                    
              </div>`;
