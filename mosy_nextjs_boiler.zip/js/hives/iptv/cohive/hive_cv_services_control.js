                        
                      var hive_services_data_template = 
                      `<!--- services data nodes -->
                        <div id="services_tbl_nodes">
                         <tr class="cpointer mosy_msdn " data-mosy_msdn="push_newval('services_uptoken',btoa('{{primkey}}'));mginitialize_services('{{primkey}}');">
                           <td scope="col" ><b class="">{{row_count}}</b></td>
                          
                          							<td>{{service_name}}</td>
							<td>{{service_code}}</td>
							<td>{{purchase_price}}</td>
							<td>{{selling_price}}</td>
							<td>{{service_type}}</td>
							<td>{{remark}}</td>
							<td>{{commission}}</td>
							<td>{{profit}}</td>
							<td>{{onboarding_commission}}</td>
							<td>{{onboarding_percentage}}</td>
							<td>{{renewal_percentage}}</td>
							<td>{{service_duration}}</td>
    
                        </tr>
                        </div>`
                        
                     var hive_services_head_template = 
                      `<!--- services data head -->
                         <tr class="cpointer mosy_msdn ">
                           <td scope="col" ><b class="">#</b></td>
                           
                              
                          							<th>SERVICE NAME</th>
							<th>SERVICE CODE</th>
							<th>PURCHASE PRICE</th>
							<th>SELLING PRICE</th>
							<th>SERVICE TYPE</th>
							<th>REMARK</th>
							<th>COMMISSION</th>
							<th>PROFIT</th>
							<th>ONBOARDING COMMISSION</th>
							<th>ONBOARDING PERCENTAGE</th>
							<th>RENEWAL PERCENTAGE</th>
							<th>SERVICE DURATION</th>
    
                        </tr>`                                              
                        
              var hive_cv_services_search_input=` 
             <div class="col-md-12 m-0 p-0 ">
                     <input type="text" class="col-md-4 mb-2 ml-2 bg-transparent"  placeholder="Search services " name="qtxt_services" id="qtxt_services" style="color:#000; border:none; border-bottom:1px solid #000;"/>
                     <button type="button" data-mosy_msdn="loop_services_ui_data(get_newval('qtxt_services'))" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2 mosy_msdn" name="qservices_btn" id="qservices_btn"><i class="fa fa-search"></i> Go </button>
                     <button type="button" class="badge badge-primary btn_neoo2 p-2 ml-2 mb-3 mosy_msdn " data-mosy_msdn="loop_services_ui_data()" ><i class="fa fa-refresh"></i> Refresh </button>                    
              </div>`;
