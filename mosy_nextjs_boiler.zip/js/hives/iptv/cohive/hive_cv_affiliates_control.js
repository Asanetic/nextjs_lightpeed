                        
                      var hive_affiliates_data_template = 
                      `<!--- affiliates data nodes -->
                        <div id="affiliates_tbl_nodes">
                         <tr class="cpointer mosy_msdn " data-mosy_msdn="push_newval('affiliates_uptoken',btoa('{{primkey}}'));mginitialize_affiliates('{{primkey}}');">
                           <td scope="col" ><b class="">{{row_count}}</b></td>
                          							<td><img src="{{photo}}" onerror="this.src=''"  style="width:50px; height:50px; border-radius:50%;"></td>

                          							<td>{{name}}</td>
							<td>{{tel}}</td>
							<td>{{email}}</td>
							<td>{{code}}</td>
							<td>{{password}}</td>
							<td>{{date_registered}}</td>
							<td>{{category}}</td>
							<td>{{remark}}</td>
    
                        </tr>
                        </div>`
                        
                     var hive_affiliates_head_template = 
                      `<!--- affiliates data head -->
                         <tr class="cpointer mosy_msdn ">
                           <td scope="col" ><b class="">#</b></td>
                           
                          							<th>PHOTO</th>
    
                          							<th>NAME</th>
							<th>TEL</th>
							<th>EMAIL</th>
							<th>CODE</th>
							<th>PASSWORD</th>
							<th>DATE REGISTERED</th>
							<th>CATEGORY</th>
							<th>REMARK</th>
    
                        </tr>`                                              
                        
              var hive_cv_affiliates_search_input=` 
             <div class="col-md-12 m-0 p-0 ">
                     <input type="text" class="col-md-4 mb-2 ml-2 bg-transparent"  placeholder="Search affiliates " name="qtxt_affiliates" id="qtxt_affiliates" style="color:#000; border:none; border-bottom:1px solid #000;"/>
                     <button type="button" data-mosy_msdn="loop_affiliates_ui_data(get_newval('qtxt_affiliates'))" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2 mosy_msdn" name="qaffiliates_btn" id="qaffiliates_btn"><i class="fa fa-search"></i> Go </button>
                     <button type="button" class="badge badge-primary btn_neoo2 p-2 ml-2 mb-3 mosy_msdn " data-mosy_msdn="loop_affiliates_ui_data()" ><i class="fa fa-refresh"></i> Refresh </button>                    
              </div>`;
