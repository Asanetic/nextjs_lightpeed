                        
                      var hive_affiliate_commissions_data_template = 
                      `<!--- affiliate_commissions data nodes -->
                        <div id="affiliate_commissions_tbl_nodes">
                         <tr class="cpointer mosy_msdn " data-mosy_msdn="push_newval('affiliate_commissions_uptoken',btoa('{{primkey}}'));mginitialize_affiliate_commissions('{{primkey}}');">
                           <td scope="col" ><b class="">{{row_count}}</b></td>
                          
                          							<td>{{affiliate}}</td>
							<td>{{amount}}</td>
							<td>{{date_earned}}</td>
							<td>{{client}}</td>
							<td>{{package}}</td>
							<td>{{commission_type}}</td>
    
                        </tr>
                        </div>`
                        
                     var hive_affiliate_commissions_head_template = 
                      `<!--- affiliate_commissions data head -->
                         <tr class="cpointer mosy_msdn ">
                           <td scope="col" ><b class="">#</b></td>
                           
                              
                          							<th>AFFILIATE</th>
							<th>AMOUNT</th>
							<th>DATE EARNED</th>
							<th>CLIENT</th>
							<th>PACKAGE</th>
							<th>COMMISSION TYPE</th>
    
                        </tr>`                                              
                        
              var hive_cv_affiliate_commissions_search_input=` 
             <div class="col-md-12 m-0 p-0 ">
                     <input type="text" class="col-md-4 mb-2 ml-2 bg-transparent"  placeholder="Search affiliate commissions " name="qtxt_affiliate_commissions" id="qtxt_affiliate_commissions" style="color:#000; border:none; border-bottom:1px solid #000;"/>
                     <button type="button" data-mosy_msdn="loop_affiliate_commissions_ui_data(get_newval('qtxt_affiliate_commissions'))" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2 mosy_msdn" name="qaffiliate_commissions_btn" id="qaffiliate_commissions_btn"><i class="fa fa-search"></i> Go </button>
                     <button type="button" class="badge badge-primary btn_neoo2 p-2 ml-2 mb-3 mosy_msdn " data-mosy_msdn="loop_affiliate_commissions_ui_data()" ><i class="fa fa-refresh"></i> Refresh </button>                    
              </div>`;
