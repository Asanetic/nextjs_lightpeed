                        
                      var hive_client_list_data_template = 
                      `<!--- client_list data nodes -->
                        <div id="client_list_tbl_nodes">
                         <tr class="cpointer mosy_msdn " data-mosy_msdn="push_newval('client_list_uptoken',btoa('{{primkey}}'));mginitialize_client_list('{{primkey}}');">
                           <td scope="col" ><b class="">{{row_count}}</b></td>
                          							<td><img src="{{user_pic}}" onerror="this.src=''"  style="width:50px; height:50px; border-radius:50%;"></td>

                          							<td>{{client_name}}</td>
							<td>{{date_registered}}</td>
							<td>{{tel}}</td>
							<td>{{email}}</td>
							<td>{{username}}</td>
							<td>{{device_type}}</td>
							<td>{{operating_system}}</td>
							<td>{{device_key}}</td>
							<td>{{macaddress}}</td>
							<td>{{reffered_by}}</td>
							<td>{{active_service}}</td>
							<td>{{expiring_on}}</td>
							<td>{{package_amount}}</td>
							<td>{{commission_amount}}</td>
							<td>{{account_status}}</td>
							<td>{{client_group}}</td>
							<td>{{city}}</td>
							<td>{{town}}</td>
							<td>{{trial_service_date}}</td>
							<td>{{remark}}</td>
							<td>{{onboarding_commission}}</td>
    
                        </tr>
                        </div>`
                        
                     var hive_client_list_head_template = 
                      `<!--- client_list data head -->
                         <tr class="cpointer mosy_msdn ">
                           <td scope="col" ><b class="">#</b></td>
                           
                          							<th>USER PIC</th>
    
                          							<th>CLIENT NAME</th>
							<th>DATE REGISTERED</th>
							<th>TEL</th>
							<th>EMAIL</th>
							<th>USERNAME</th>
							<th>DEVICE TYPE</th>
							<th>OPERATING SYSTEM</th>
							<th>DEVICE KEY</th>
							<th>MACADDRESS</th>
							<th>REFFERED BY</th>
							<th>ACTIVE SERVICE</th>
							<th>EXPIRING ON</th>
							<th>PACKAGE AMOUNT</th>
							<th>COMMISSION AMOUNT</th>
							<th>ACCOUNT STATUS</th>
							<th>CLIENT GROUP</th>
							<th>CITY</th>
							<th>TOWN</th>
							<th>TRIAL SERVICE DATE</th>
							<th>REMARK</th>
							<th>ONBOARDING COMMISSION</th>
    
                        </tr>`                                              
                        
              var hive_cv_client_list_search_input=` 
             <div class="col-md-12 m-0 p-0 ">
                     <input type="text" class="col-md-4 mb-2 ml-2 bg-transparent"  placeholder="Search client list " name="qtxt_client_list" id="qtxt_client_list" style="color:#000; border:none; border-bottom:1px solid #000;"/>
                     <button type="button" data-mosy_msdn="loop_client_list_ui_data(get_newval('qtxt_client_list'))" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2 mosy_msdn" name="qclient_list_btn" id="qclient_list_btn"><i class="fa fa-search"></i> Go </button>
                     <button type="button" class="badge badge-primary btn_neoo2 p-2 ml-2 mb-3 mosy_msdn " data-mosy_msdn="loop_client_list_ui_data()" ><i class="fa fa-refresh"></i> Refresh </button>                    
              </div>`;
