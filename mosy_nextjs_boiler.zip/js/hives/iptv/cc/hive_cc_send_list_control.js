
   const hive_send_list_ins_btn = document.querySelectorAll(".hive_send_list_ins_btn");
        hive_send_list_ins_btn.forEach(send_list_ins_btn => {
          send_list_ins_btn.addEventListener("click", event => {
          
          mosy_send_list_ins_fun()
          
          });
        });
        
        
   const hive_send_list_updt_btn = document.querySelectorAll(".hive_send_list_updt_btn");
        hive_send_list_updt_btn.forEach(send_list_updt_btn => {
          send_list_updt_btn.addEventListener("click", event => {
          
          mosy_send_list_updt_fun()
          
          });
        });

	  //// ================== cc view data nodes template =============
      ////var send_list_data_template=get_html("send_list_tbl_nodes");
	  //// ================== cc view data nodes template =============

      function loop_send_list_ui_data(qstr="",callback="", andquery="", _send_list_auto_function="")
      {      
        
        
         /// ==============send_list custom js auto response function  ================
    var custom_send_list_auto_function= '{"cbfun":"process_send_list_json_data","_data_isle":"send_list_data_isle:18","_pagination_isle":"send_list_pagination_isle","_data_template":"hive_send_list_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_send_list"}';
    
/// ==============send_list custom js auto response function  ================
   
    
      if(_send_list_auto_function!="")
      {
      	custom_send_list_auto_function = _send_list_auto_function
      }
    	
    
       if(callback!="")
       {
         qstr="";
         magic_message(callback, "dialog_box")
       }
       
       mosy_send_list_json_data_list(qstr, custom_send_list_auto_function, andquery);
       
       var and_count ="";
       if(andquery!="")
       {
          and_count=" and "+andquery
       }
        
      }
      