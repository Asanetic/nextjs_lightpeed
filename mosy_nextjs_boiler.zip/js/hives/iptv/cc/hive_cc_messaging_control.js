
   const hive_messaging_ins_btn = document.querySelectorAll(".hive_messaging_ins_btn");
        hive_messaging_ins_btn.forEach(messaging_ins_btn => {
          messaging_ins_btn.addEventListener("click", event => {
          
          mosy_messaging_ins_fun()
          
          });
        });
        
        
   const hive_messaging_updt_btn = document.querySelectorAll(".hive_messaging_updt_btn");
        hive_messaging_updt_btn.forEach(messaging_updt_btn => {
          messaging_updt_btn.addEventListener("click", event => {
          
          mosy_messaging_updt_fun()
          
          });
        });

	  //// ================== cc view data nodes template =============
      ////var messaging_data_template=get_html("messaging_tbl_nodes");
	  //// ================== cc view data nodes template =============

      function loop_messaging_ui_data(qstr="",callback="", andquery="", _messaging_auto_function="")
      {      
        
        
         /// ==============messaging custom js auto response function  ================
    var custom_messaging_auto_function= '{"cbfun":"process_messaging_json_data","_data_isle":"messaging_data_isle:19","_pagination_isle":"messaging_pagination_isle","_data_template":"hive_messaging_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_messaging"}';
    
/// ==============messaging custom js auto response function  ================
   
    
      if(_messaging_auto_function!="")
      {
      	custom_messaging_auto_function = _messaging_auto_function
      }
    	
    
       if(callback!="")
       {
         qstr="";
         magic_message(callback, "dialog_box")
       }
       
       mosy_messaging_json_data_list(qstr, custom_messaging_auto_function, andquery);
       
       var and_count ="";
       if(andquery!="")
       {
          and_count=" and "+andquery
       }
        
      }
      