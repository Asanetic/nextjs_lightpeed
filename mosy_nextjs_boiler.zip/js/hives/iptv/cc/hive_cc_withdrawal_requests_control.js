
   const hive_withdrawal_requests_ins_btn = document.querySelectorAll(".hive_withdrawal_requests_ins_btn");
        hive_withdrawal_requests_ins_btn.forEach(withdrawal_requests_ins_btn => {
          withdrawal_requests_ins_btn.addEventListener("click", event => {
          
          mosy_withdrawal_requests_ins_fun()
          
          });
        });
        
        
   const hive_withdrawal_requests_updt_btn = document.querySelectorAll(".hive_withdrawal_requests_updt_btn");
        hive_withdrawal_requests_updt_btn.forEach(withdrawal_requests_updt_btn => {
          withdrawal_requests_updt_btn.addEventListener("click", event => {
          
          mosy_withdrawal_requests_updt_fun()
          
          });
        });

	  //// ================== cc view data nodes template =============
      ////var withdrawal_requests_data_template=get_html("withdrawal_requests_tbl_nodes");
	  //// ================== cc view data nodes template =============

      function loop_withdrawal_requests_ui_data(qstr="",callback="", andquery="", _withdrawal_requests_auto_function="")
      {      
        
        
         /// ==============withdrawal_requests custom js auto response function  ================
    var custom_withdrawal_requests_auto_function= '{"cbfun":"process_withdrawal_requests_json_data","_data_isle":"withdrawal_requests_data_isle:10","_pagination_isle":"withdrawal_requests_pagination_isle","_data_template":"hive_withdrawal_requests_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_withdrawal_requests"}';
    
/// ==============withdrawal_requests custom js auto response function  ================
   
    
      if(_withdrawal_requests_auto_function!="")
      {
      	custom_withdrawal_requests_auto_function = _withdrawal_requests_auto_function
      }
    	
    
       if(callback!="")
       {
         qstr="";
         magic_message(callback, "dialog_box")
       }
       
       mosy_withdrawal_requests_json_data_list(qstr, custom_withdrawal_requests_auto_function, andquery);
       
       var and_count ="";
       if(andquery!="")
       {
          and_count=" and "+andquery
       }
        
      }
      