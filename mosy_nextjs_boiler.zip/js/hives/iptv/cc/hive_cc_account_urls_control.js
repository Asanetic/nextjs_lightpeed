
   const hive_account_urls_ins_btn = document.querySelectorAll(".hive_account_urls_ins_btn");
        hive_account_urls_ins_btn.forEach(account_urls_ins_btn => {
          account_urls_ins_btn.addEventListener("click", event => {
          
          mosy_account_urls_ins_fun()
          
          });
        });
        
        
   const hive_account_urls_updt_btn = document.querySelectorAll(".hive_account_urls_updt_btn");
        hive_account_urls_updt_btn.forEach(account_urls_updt_btn => {
          account_urls_updt_btn.addEventListener("click", event => {
          
          mosy_account_urls_updt_fun()
          
          });
        });

	  //// ================== cc view data nodes template =============
      ////var account_urls_data_template=get_html("account_urls_tbl_nodes");
	  //// ================== cc view data nodes template =============

      function loop_account_urls_ui_data(qstr="",callback="", andquery="", _account_urls_auto_function="")
      {      
        
        
         /// ==============account_urls custom js auto response function  ================
    var custom_account_urls_auto_function= '{"cbfun":"process_account_urls_json_data","_data_isle":"account_urls_data_isle:7","_pagination_isle":"account_urls_pagination_isle","_data_template":"hive_account_urls_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_account_urls"}';
    
/// ==============account_urls custom js auto response function  ================
   
    
      if(_account_urls_auto_function!="")
      {
      	custom_account_urls_auto_function = _account_urls_auto_function
      }
    	
    
       if(callback!="")
       {
         qstr="";
         magic_message(callback, "dialog_box")
       }
       
       mosy_account_urls_json_data_list(qstr, custom_account_urls_auto_function, andquery);
       
       var and_count ="";
       if(andquery!="")
       {
          and_count=" and "+andquery
       }
        
      }
      