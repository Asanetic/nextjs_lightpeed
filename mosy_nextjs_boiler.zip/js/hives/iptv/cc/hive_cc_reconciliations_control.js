
   const hive_reconciliations_ins_btn = document.querySelectorAll(".hive_reconciliations_ins_btn");
        hive_reconciliations_ins_btn.forEach(reconciliations_ins_btn => {
          reconciliations_ins_btn.addEventListener("click", event => {
          
          mosy_reconciliations_ins_fun()
          
          });
        });
        
        
   const hive_reconciliations_updt_btn = document.querySelectorAll(".hive_reconciliations_updt_btn");
        hive_reconciliations_updt_btn.forEach(reconciliations_updt_btn => {
          reconciliations_updt_btn.addEventListener("click", event => {
          
          mosy_reconciliations_updt_fun()
          
          });
        });

	  //// ================== cc view data nodes template =============
      ////var reconciliations_data_template=get_html("reconciliations_tbl_nodes");
	  //// ================== cc view data nodes template =============

      function loop_reconciliations_ui_data(qstr="",callback="", andquery="", _reconciliations_auto_function="")
      {      
        
        
         /// ==============reconciliations custom js auto response function  ================
    var custom_reconciliations_auto_function= '{"cbfun":"process_reconciliations_json_data","_data_isle":"reconciliations_data_isle:29","_pagination_isle":"reconciliations_pagination_isle","_data_template":"hive_reconciliations_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_reconciliations"}';
    
/// ==============reconciliations custom js auto response function  ================
   
    
      if(_reconciliations_auto_function!="")
      {
      	custom_reconciliations_auto_function = _reconciliations_auto_function
      }
    	
    
       if(callback!="")
       {
         qstr="";
         magic_message(callback, "dialog_box")
       }
       
       mosy_reconciliations_json_data_list(qstr, custom_reconciliations_auto_function, andquery);
       
       var and_count ="";
       if(andquery!="")
       {
          and_count=" and "+andquery
       }
        
      }
      