
   const hive_payment_confirmations_ins_btn = document.querySelectorAll(".hive_payment_confirmations_ins_btn");
        hive_payment_confirmations_ins_btn.forEach(payment_confirmations_ins_btn => {
          payment_confirmations_ins_btn.addEventListener("click", event => {
          
          mosy_payment_confirmations_ins_fun()
          
          });
        });
        
        
   const hive_payment_confirmations_updt_btn = document.querySelectorAll(".hive_payment_confirmations_updt_btn");
        hive_payment_confirmations_updt_btn.forEach(payment_confirmations_updt_btn => {
          payment_confirmations_updt_btn.addEventListener("click", event => {
          
          mosy_payment_confirmations_updt_fun()
          
          });
        });

	  //// ================== cc view data nodes template =============
      ////var payment_confirmations_data_template=get_html("payment_confirmations_tbl_nodes");
	  //// ================== cc view data nodes template =============

      function loop_payment_confirmations_ui_data(qstr="",callback="", andquery="", _payment_confirmations_auto_function="")
      {      
        
        
         /// ==============payment_confirmations custom js auto response function  ================
    var custom_payment_confirmations_auto_function= '{"cbfun":"process_payment_confirmations_json_data","_data_isle":"payment_confirmations_data_isle:20","_pagination_isle":"payment_confirmations_pagination_isle","_data_template":"hive_payment_confirmations_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_payment_confirmations"}';
    
/// ==============payment_confirmations custom js auto response function  ================
   
    
      if(_payment_confirmations_auto_function!="")
      {
      	custom_payment_confirmations_auto_function = _payment_confirmations_auto_function
      }
    	
    
       if(callback!="")
       {
         qstr="";
         magic_message(callback, "dialog_box")
       }
       
       mosy_payment_confirmations_json_data_list(qstr, custom_payment_confirmations_auto_function, andquery);
       
       var and_count ="";
       if(andquery!="")
       {
          and_count=" and "+andquery
       }
        
      }
      