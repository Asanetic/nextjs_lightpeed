
   const hive_affiliates_ins_btn = document.querySelectorAll(".hive_affiliates_ins_btn");
        hive_affiliates_ins_btn.forEach(affiliates_ins_btn => {
          affiliates_ins_btn.addEventListener("click", event => {
          
          mosy_affiliates_ins_fun()
          
          });
        });
        
        
   const hive_affiliates_updt_btn = document.querySelectorAll(".hive_affiliates_updt_btn");
        hive_affiliates_updt_btn.forEach(affiliates_updt_btn => {
          affiliates_updt_btn.addEventListener("click", event => {
          
          mosy_affiliates_updt_fun()
          
          });
        });

	  //// ================== cc view data nodes template =============
      ////var affiliates_data_template=get_html("affiliates_tbl_nodes");
	  //// ================== cc view data nodes template =============

      function loop_affiliates_ui_data(qstr="",callback="", andquery="", _affiliates_auto_function="")
      {      
        
        
         /// ==============affiliates custom js auto response function  ================
    var custom_affiliates_auto_function= '{"cbfun":"process_affiliates_json_data","_data_isle":"affiliates_data_isle:11","_pagination_isle":"affiliates_pagination_isle","_data_template":"hive_affiliates_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_affiliates"}';
    
/// ==============affiliates custom js auto response function  ================
   
    
      if(_affiliates_auto_function!="")
      {
      	custom_affiliates_auto_function = _affiliates_auto_function
      }
    	
    
       if(callback!="")
       {
         qstr="";
         magic_message(callback, "dialog_box")
       }
       
       mosy_affiliates_json_data_list(qstr, custom_affiliates_auto_function, andquery);
       
       var and_count ="";
       if(andquery!="")
       {
          and_count=" and "+andquery
       }
        
      }
      