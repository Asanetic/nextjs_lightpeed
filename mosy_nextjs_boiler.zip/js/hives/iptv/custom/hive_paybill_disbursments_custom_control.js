
   const hive_paybill_disbursments_ins_btn = document.querySelectorAll(".hive_paybill_disbursments_ins_btn");
        hive_paybill_disbursments_ins_btn.forEach(paybill_disbursments_ins_btn => {
          paybill_disbursments_ins_btn.addEventListener("click", event => {
          
          mosy_paybill_disbursments_ins_fun()
          
          });
        });
        
        
   const hive_paybill_disbursments_updt_btn = document.querySelectorAll(".hive_paybill_disbursments_updt_btn");
        hive_paybill_disbursments_updt_btn.forEach(paybill_disbursments_updt_btn => {
          paybill_disbursments_updt_btn.addEventListener("click", event => {
          
          mosy_paybill_disbursments_updt_fun()
          
          });
        });

	  //// ================== cc view data nodes template =============
      ////var paybill_disbursments_data_template=get_html("paybill_disbursments_tbl_nodes");
	  //// ================== cc view data nodes template =============

      function loop_paybill_disbursments_ui_data(qstr="",callback="", andquery="", _paybill_disbursments_auto_function="")
      {      
        
        
         /// ==============paybill_disbursments custom js auto response function  ================
    var custom_paybill_disbursments_auto_function= '{"cbfun":"process_paybill_disbursments_json_data","_data_isle":"paybill_disbursments_data_isle:31","_pagination_isle":"paybill_disbursments_pagination_isle","_data_template":"hive_paybill_disbursments_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_paybill_disbursments"}';
    
/// ==============paybill_disbursments custom js auto response function  ================
   
    
      if(_paybill_disbursments_auto_function!="")
      {
      	custom_paybill_disbursments_auto_function = _paybill_disbursments_auto_function
      }
    	
    
       if(callback!="")
       {
         qstr="";
         magic_message(callback, "dialog_box")
       }
       
       mosy_paybill_disbursments_json_data_list(qstr, custom_paybill_disbursments_auto_function, andquery);
       
       var and_count ="";
       if(andquery!="")
       {
          and_count=" and "+andquery
       }
        
      }
      

//== custom component paybill_disbursments JS functions


