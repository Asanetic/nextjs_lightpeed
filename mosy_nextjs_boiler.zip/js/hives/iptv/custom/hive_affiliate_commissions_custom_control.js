
   const hive_affiliate_commissions_ins_btn = document.querySelectorAll(".hive_affiliate_commissions_ins_btn");
        hive_affiliate_commissions_ins_btn.forEach(affiliate_commissions_ins_btn => {
          affiliate_commissions_ins_btn.addEventListener("click", event => {
          
          mosy_affiliate_commissions_ins_fun()
          
          });
        });
        
        
   const hive_affiliate_commissions_updt_btn = document.querySelectorAll(".hive_affiliate_commissions_updt_btn");
        hive_affiliate_commissions_updt_btn.forEach(affiliate_commissions_updt_btn => {
          affiliate_commissions_updt_btn.addEventListener("click", event => {
          
          mosy_affiliate_commissions_updt_fun()
          
          });
        });

	  //// ================== cc view data nodes template =============
      ////var affiliate_commissions_data_template=get_html("affiliate_commissions_tbl_nodes");
	  //// ================== cc view data nodes template =============

      function loop_affiliate_commissions_ui_data(qstr="",callback="", andquery="", _affiliate_commissions_auto_function="")
      {      
        
        
         /// ==============affiliate_commissions custom js auto response function  ================
    var custom_affiliate_commissions_auto_function= '{"cbfun":"process_affiliate_commissions_json_data","_data_isle":"affiliate_commissions_data_isle:9","_pagination_isle":"affiliate_commissions_pagination_isle","_data_template":"hive_affiliate_commissions_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_affiliate_commissions"}';
    
/// ==============affiliate_commissions custom js auto response function  ================
   
    
      if(_affiliate_commissions_auto_function!="")
      {
      	custom_affiliate_commissions_auto_function = _affiliate_commissions_auto_function
      }
    	
    
       if(callback!="")
       {
         qstr="";
         magic_message(callback, "dialog_box")
       }
       
       mosy_affiliate_commissions_json_data_list(qstr, custom_affiliate_commissions_auto_function, andquery);
       
       var and_count ="";
       if(andquery!="")
       {
          and_count=" and "+andquery
       }
        
      }
      

//== custom component affiliate_commissions JS functions


