
   const hive_phonebook_ins_btn = document.querySelectorAll(".hive_phonebook_ins_btn");
        hive_phonebook_ins_btn.forEach(phonebook_ins_btn => {
          phonebook_ins_btn.addEventListener("click", event => {
          
          mosy_phonebook_ins_fun()
          
          });
        });
        
        
   const hive_phonebook_updt_btn = document.querySelectorAll(".hive_phonebook_updt_btn");
        hive_phonebook_updt_btn.forEach(phonebook_updt_btn => {
          phonebook_updt_btn.addEventListener("click", event => {
          
          mosy_phonebook_updt_fun()
          
          });
        });

	  //// ================== cc view data nodes template =============
      ////var phonebook_data_template=get_html("phonebook_tbl_nodes");
	  //// ================== cc view data nodes template =============

      function loop_phonebook_ui_data(qstr="",callback="", andquery="", _phonebook_auto_function="")
      {      
        
        
         /// ==============phonebook custom js auto response function  ================
    var custom_phonebook_auto_function= '{"cbfun":"process_phonebook_json_data","_data_isle":"phonebook_data_isle:10","_pagination_isle":"phonebook_pagination_isle","_data_template":"hive_phonebook_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_phonebook"}';
    
/// ==============phonebook custom js auto response function  ================
   
    
      if(_phonebook_auto_function!="")
      {
      	custom_phonebook_auto_function = _phonebook_auto_function
      }
    	
    
       if(callback!="")
       {
         qstr="";
         magic_message(callback, "dialog_box")
       }
       
       mosy_phonebook_json_data_list(qstr, custom_phonebook_auto_function, andquery);
       
       var and_count ="";
       if(andquery!="")
       {
          and_count=" and "+andquery
       }
        
      }
      

//== custom component phonebook JS functions


