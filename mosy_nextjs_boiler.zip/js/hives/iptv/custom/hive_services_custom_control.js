
   const hive_services_ins_btn = document.querySelectorAll(".hive_services_ins_btn");
        hive_services_ins_btn.forEach(services_ins_btn => {
          services_ins_btn.addEventListener("click", event => {
          
          mosy_services_ins_fun()
          
          });
        });
        
        
   const hive_services_updt_btn = document.querySelectorAll(".hive_services_updt_btn");
        hive_services_updt_btn.forEach(services_updt_btn => {
          services_updt_btn.addEventListener("click", event => {
          
          mosy_services_updt_fun()
          
          });
        });

	  //// ================== cc view data nodes template =============
      ////var services_data_template=get_html("services_tbl_nodes");
	  //// ================== cc view data nodes template =============

      function loop_services_ui_data(qstr="",callback="", andquery="", _services_auto_function="")
      {      
        
        
         /// ==============services custom js auto response function  ================
    var custom_services_auto_function= '{"cbfun":"process_services_json_data","_data_isle":"services_data_isle:10","_pagination_isle":"services_pagination_isle","_data_template":"hive_services_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_services"}';
    
/// ==============services custom js auto response function  ================
   
    
      if(_services_auto_function!="")
      {
      	custom_services_auto_function = _services_auto_function
      }
    	
    
       if(callback!="")
       {
         qstr="";
         magic_message(callback, "dialog_box")
       }
       
       mosy_services_json_data_list(qstr, custom_services_auto_function, andquery);
       
       var and_count ="";
       if(andquery!="")
       {
          and_count=" and "+andquery
       }
        
      }
      

//== custom component services JS functions


