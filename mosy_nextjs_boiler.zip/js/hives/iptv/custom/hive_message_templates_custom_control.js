
   const hive_message_templates_ins_btn = document.querySelectorAll(".hive_message_templates_ins_btn");
        hive_message_templates_ins_btn.forEach(message_templates_ins_btn => {
          message_templates_ins_btn.addEventListener("click", event => {
          
          mosy_message_templates_ins_fun()
          
          });
        });
        
        
   const hive_message_templates_updt_btn = document.querySelectorAll(".hive_message_templates_updt_btn");
        hive_message_templates_updt_btn.forEach(message_templates_updt_btn => {
          message_templates_updt_btn.addEventListener("click", event => {
          
          mosy_message_templates_updt_fun()
          
          });
        });

	  //// ================== cc view data nodes template =============
      ////var message_templates_data_template=get_html("message_templates_tbl_nodes");
	  //// ================== cc view data nodes template =============

      function loop_message_templates_ui_data(qstr="",callback="", andquery="", _message_templates_auto_function="")
      {      
        
        
         /// ==============message_templates custom js auto response function  ================
    var custom_message_templates_auto_function= '{"cbfun":"process_message_templates_json_data","_data_isle":"message_templates_data_isle:6","_pagination_isle":"message_templates_pagination_isle","_data_template":"hive_message_templates_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_message_templates"}';
    
/// ==============message_templates custom js auto response function  ================
   
    
      if(_message_templates_auto_function!="")
      {
      	custom_message_templates_auto_function = _message_templates_auto_function
      }
    	
    
       if(callback!="")
       {
         qstr="";
         magic_message(callback, "dialog_box")
       }
       
       mosy_message_templates_json_data_list(qstr, custom_message_templates_auto_function, andquery);
       
       var and_count ="";
       if(andquery!="")
       {
          and_count=" and "+andquery
       }
        
      }
      

//== custom component message_templates JS functions


