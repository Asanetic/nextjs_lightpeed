
   const hive_client_list_ins_btn = document.querySelectorAll(".hive_client_list_ins_btn");
        hive_client_list_ins_btn.forEach(client_list_ins_btn => {
          client_list_ins_btn.addEventListener("click", event => {
          
          mosy_client_list_ins_fun()
          
          });
        });
        
        
   const hive_client_list_updt_btn = document.querySelectorAll(".hive_client_list_updt_btn");
        hive_client_list_updt_btn.forEach(client_list_updt_btn => {
          client_list_updt_btn.addEventListener("click", event => {
          
          mosy_client_list_updt_fun()
          
          });
        });

	  //// ================== cc view data nodes template =============
      ////var client_list_data_template=get_html("client_list_tbl_nodes");
	  //// ================== cc view data nodes template =============

      function loop_client_list_ui_data(qstr="",callback="", andquery="", _client_list_auto_function="")
      {      
        
        
         /// ==============client_list custom js auto response function  ================
    var custom_client_list_auto_function= '{"cbfun":"process_client_list_json_data","_data_isle":"client_list_data_isle:18","_pagination_isle":"client_list_pagination_isle","_data_template":"hive_client_list_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_client_list"}';
    
/// ==============client_list custom js auto response function  ================
   
    
      if(_client_list_auto_function!="")
      {
      	custom_client_list_auto_function = _client_list_auto_function
      }
    	
    
       if(callback!="")
       {
         qstr="";
         magic_message(callback, "dialog_box")
       }
       
       mosy_client_list_json_data_list(qstr, custom_client_list_auto_function, andquery);
       
       var and_count ="";
       if(andquery!="")
       {
          and_count=" and "+andquery
       }
        
      }
      

//== custom component client_list JS functions


