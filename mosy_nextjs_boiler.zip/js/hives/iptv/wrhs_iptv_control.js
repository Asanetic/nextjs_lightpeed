
   
   
     /***************************************** global data warehouse for account_urls ***********************************/
   var wh_account_urls_list_cols ="primkey:primkey,record_id:record_id,url_name:url_name,url:url,description:description,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start account_urls search columns 
   
   var wh_gft_account_urls_str="(primkey LIKE '%{{qaccount_urls}}%' OR  record_id LIKE '%{{qaccount_urls}}%' OR  url_name LIKE '%{{qaccount_urls}}%' OR  url LIKE '%{{qaccount_urls}}%' OR  description LIKE '%{{qaccount_urls}}%' OR  hive_site_id LIKE '%{{qaccount_urls}}%' OR  hive_site_name LIKE '%{{qaccount_urls}}%')";
   
   
   ///account_urls data_nodes 
  var wh_account_urls_data_nodes ="{{row_count}}|{{primkey}}|{{record_id}}|{{url_name}}|{{url}}|{{description}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for affiliate_commissions ***********************************/
   var wh_affiliate_commissions_list_cols ="primkey:primkey,record_id:record_id,affiliate:affiliate,amount:amount,date_earned:date_earned,client:client,package:package,commission_type:commission_type";
        
   ///start affiliate_commissions search columns 
   
   var wh_gft_affiliate_commissions_str="(primkey LIKE '%{{qaffiliate_commissions}}%' OR  record_id LIKE '%{{qaffiliate_commissions}}%' OR  affiliate LIKE '%{{qaffiliate_commissions}}%' OR  amount LIKE '%{{qaffiliate_commissions}}%' OR  date_earned LIKE '%{{qaffiliate_commissions}}%' OR  client LIKE '%{{qaffiliate_commissions}}%' OR  package LIKE '%{{qaffiliate_commissions}}%' OR  commission_type LIKE '%{{qaffiliate_commissions}}%')";
   
   
   ///affiliate_commissions data_nodes 
  var wh_affiliate_commissions_data_nodes ="{{row_count}}|{{primkey}}|{{record_id}}|{{affiliate}}|{{amount}}|{{date_earned}}|{{client}}|{{package}}|{{commission_type}}"
   
   
   
   
     /***************************************** global data warehouse for affiliates ***********************************/
   var wh_affiliates_list_cols ="primkey:primkey,record_id:record_id,name:name,tel:tel,email:email,code:code,password:password,photo:photo,date_registered:date_registered,category:category,remark:remark";
        
   ///start affiliates search columns 
   
   var wh_gft_affiliates_str="(primkey LIKE '%{{qaffiliates}}%' OR  record_id LIKE '%{{qaffiliates}}%' OR  name LIKE '%{{qaffiliates}}%' OR  tel LIKE '%{{qaffiliates}}%' OR  email LIKE '%{{qaffiliates}}%' OR  code LIKE '%{{qaffiliates}}%' OR  password LIKE '%{{qaffiliates}}%' OR  photo LIKE '%{{qaffiliates}}%' OR  date_registered LIKE '%{{qaffiliates}}%' OR  category LIKE '%{{qaffiliates}}%' OR  remark LIKE '%{{qaffiliates}}%')";
   
   
   ///affiliates data_nodes 
  var wh_affiliates_data_nodes ="{{row_count}}|{{primkey}}|{{record_id}}|{{name}}|{{tel}}|{{email}}|{{code}}|{{password}}|{{photo}}|{{date_registered}}|{{category}}|{{remark}}"
   
   
   
   
     /***************************************** global data warehouse for client_list ***********************************/
   var wh_client_list_list_cols ="primkey:primkey,record_id:record_id,client_name:client_name,date_registered:date_registered,tel:tel,email:email,username:username,device_type:device_type,operating_system:operating_system,device_key:device_key,macaddress:macaddress,reffered_by:reffered_by,active_service:active_service,expiring_on:expiring_on,package_amount:package_amount,commission_amount:commission_amount,account_status:account_status,client_group:client_group,user_pic:user_pic,city:city,town:town,trial_service_date:trial_service_date,remark:remark,onboarding_commission:onboarding_commission";
        
   ///start client_list search columns 
   
   var wh_gft_client_list_str="(primkey LIKE '%{{qclient_list}}%' OR  record_id LIKE '%{{qclient_list}}%' OR  client_name LIKE '%{{qclient_list}}%' OR  date_registered LIKE '%{{qclient_list}}%' OR  tel LIKE '%{{qclient_list}}%' OR  email LIKE '%{{qclient_list}}%' OR  username LIKE '%{{qclient_list}}%' OR  device_type LIKE '%{{qclient_list}}%' OR  operating_system LIKE '%{{qclient_list}}%' OR  device_key LIKE '%{{qclient_list}}%' OR  macaddress LIKE '%{{qclient_list}}%' OR  reffered_by LIKE '%{{qclient_list}}%' OR  active_service LIKE '%{{qclient_list}}%' OR  expiring_on LIKE '%{{qclient_list}}%' OR  package_amount LIKE '%{{qclient_list}}%' OR  commission_amount LIKE '%{{qclient_list}}%' OR  account_status LIKE '%{{qclient_list}}%' OR  client_group LIKE '%{{qclient_list}}%' OR  user_pic LIKE '%{{qclient_list}}%' OR  city LIKE '%{{qclient_list}}%' OR  town LIKE '%{{qclient_list}}%' OR  trial_service_date LIKE '%{{qclient_list}}%' OR  remark LIKE '%{{qclient_list}}%' OR  onboarding_commission LIKE '%{{qclient_list}}%')";
   
   
   ///client_list data_nodes 
  var wh_client_list_data_nodes ="{{row_count}}|{{primkey}}|{{record_id}}|{{client_name}}|{{date_registered}}|{{tel}}|{{email}}|{{username}}|{{device_type}}|{{operating_system}}|{{device_key}}|{{macaddress}}|{{reffered_by}}|{{active_service}}|{{expiring_on}}|{{package_amount}}|{{commission_amount}}|{{account_status}}|{{client_group}}|{{user_pic}}|{{city}}|{{town}}|{{trial_service_date}}|{{remark}}|{{onboarding_commission}}"
   
   
   
   
     /***************************************** global data warehouse for client_service_list ***********************************/
   var wh_client_service_list_list_cols ="primkey:primkey,record_id:record_id,service_name:service_name,client_name:client_name,date_added:date_added,expiry_date:expiry_date,amount:amount,status:status,remark:remark,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start client_service_list search columns 
   
   var wh_gft_client_service_list_str="(primkey LIKE '%{{qclient_service_list}}%' OR  record_id LIKE '%{{qclient_service_list}}%' OR  service_name LIKE '%{{qclient_service_list}}%' OR  client_name LIKE '%{{qclient_service_list}}%' OR  date_added LIKE '%{{qclient_service_list}}%' OR  expiry_date LIKE '%{{qclient_service_list}}%' OR  amount LIKE '%{{qclient_service_list}}%' OR  status LIKE '%{{qclient_service_list}}%' OR  remark LIKE '%{{qclient_service_list}}%' OR  hive_site_id LIKE '%{{qclient_service_list}}%' OR  hive_site_name LIKE '%{{qclient_service_list}}%')";
   
   
   ///client_service_list data_nodes 
  var wh_client_service_list_data_nodes ="{{row_count}}|{{primkey}}|{{record_id}}|{{service_name}}|{{client_name}}|{{date_added}}|{{expiry_date}}|{{amount}}|{{status}}|{{remark}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for message_templates ***********************************/
   var wh_message_templates_list_cols ="primkey:primkey,record_id:record_id,template_name:template_name,message_subject:message_subject,message_template:message_template,template_code:template_code";
        
   ///start message_templates search columns 
   
   var wh_gft_message_templates_str="(primkey LIKE '%{{qmessage_templates}}%' OR  record_id LIKE '%{{qmessage_templates}}%' OR  template_name LIKE '%{{qmessage_templates}}%' OR  message_subject LIKE '%{{qmessage_templates}}%' OR  message_template LIKE '%{{qmessage_templates}}%' OR  template_code LIKE '%{{qmessage_templates}}%')";
   
   
   ///message_templates data_nodes 
  var wh_message_templates_data_nodes ="{{row_count}}|{{primkey}}|{{record_id}}|{{template_name}}|{{message_subject}}|{{message_template}}|{{template_code}}"
   
   
   
   
     /***************************************** global data warehouse for messaging ***********************************/
   var wh_messaging_list_cols ="primkey:primkey,messageid:messageid,receiver_contacts:receiver_contacts,reciver_names:reciver_names,message_type:message_type,site_id:site_id,group_name:group_name,message_date:message_date,sent_state:sent_state,msg_read_state:msg_read_state,subject:subject,message_label:message_label,about:about,sms_cost:sms_cost,page_count:page_count,hive_site_id:hive_site_id,hive_site_name:hive_site_name,custom_dictionary:custom_dictionary,message_signature:message_signature";
        
   ///start messaging search columns 
   
   var wh_gft_messaging_str="(primkey LIKE '%{{qmessaging}}%' OR  messageid LIKE '%{{qmessaging}}%' OR  receiver_contacts LIKE '%{{qmessaging}}%' OR  reciver_names LIKE '%{{qmessaging}}%' OR  message_type LIKE '%{{qmessaging}}%' OR  site_id LIKE '%{{qmessaging}}%' OR  group_name LIKE '%{{qmessaging}}%' OR  message_date LIKE '%{{qmessaging}}%' OR  sent_state LIKE '%{{qmessaging}}%' OR  msg_read_state LIKE '%{{qmessaging}}%' OR  subject LIKE '%{{qmessaging}}%' OR  message_label LIKE '%{{qmessaging}}%' OR  about LIKE '%{{qmessaging}}%' OR  sms_cost LIKE '%{{qmessaging}}%' OR  page_count LIKE '%{{qmessaging}}%' OR  hive_site_id LIKE '%{{qmessaging}}%' OR  hive_site_name LIKE '%{{qmessaging}}%' OR  custom_dictionary LIKE '%{{qmessaging}}%' OR  message_signature LIKE '%{{qmessaging}}%')";
   
   
   ///messaging data_nodes 
  var wh_messaging_data_nodes ="{{row_count}}|{{primkey}}|{{messageid}}|{{receiver_contacts}}|{{reciver_names}}|{{message_type}}|{{site_id}}|{{group_name}}|{{message_date}}|{{sent_state}}|{{msg_read_state}}|{{subject}}|{{message_label}}|{{about}}|{{sms_cost}}|{{page_count}}|{{hive_site_id}}|{{hive_site_name}}|{{custom_dictionary}}|{{message_signature}}"
   
   
   
   
     /***************************************** global data warehouse for mosy_sql_roll_back ***********************************/
   var wh_mosy_sql_roll_back_list_cols ="primkey:primkey,roll_bk_key:roll_bk_key,table_name:table_name,roll_type:roll_type,where_str:where_str,roll_timestamp:roll_timestamp,value_entries:value_entries";
        
   ///start mosy_sql_roll_back search columns 
   
   var wh_gft_mosy_sql_roll_back_str="(primkey LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_bk_key LIKE '%{{qmosy_sql_roll_back}}%' OR  table_name LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_type LIKE '%{{qmosy_sql_roll_back}}%' OR  where_str LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_timestamp LIKE '%{{qmosy_sql_roll_back}}%' OR  value_entries LIKE '%{{qmosy_sql_roll_back}}%')";
   
   
   ///mosy_sql_roll_back data_nodes 
  var wh_mosy_sql_roll_back_data_nodes ="{{row_count}}|{{primkey}}|{{roll_bk_key}}|{{table_name}}|{{roll_type}}|{{where_str}}|{{roll_timestamp}}|{{value_entries}}"
   
   
   
   
     /***************************************** global data warehouse for mosycomms_array ***********************************/
   var wh_mosycomms_array_list_cols ="primkey:primkey,messageid:messageid,receiver_contacts:receiver_contacts,reciver_names:reciver_names,message_type:message_type,site_id:site_id,group_name:group_name,message_date:message_date,sent_state:sent_state,msg_read_state:msg_read_state,subject:subject,message_label:message_label,message:message,delvery_receipt:delvery_receipt,mosycomms_dictionary:mosycomms_dictionary,sms_cost:sms_cost,page_count:page_count,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start mosycomms_array search columns 
   
   var wh_gft_mosycomms_array_str="(primkey LIKE '%{{qmosycomms_array}}%' OR  messageid LIKE '%{{qmosycomms_array}}%' OR  receiver_contacts LIKE '%{{qmosycomms_array}}%' OR  reciver_names LIKE '%{{qmosycomms_array}}%' OR  message_type LIKE '%{{qmosycomms_array}}%' OR  site_id LIKE '%{{qmosycomms_array}}%' OR  group_name LIKE '%{{qmosycomms_array}}%' OR  message_date LIKE '%{{qmosycomms_array}}%' OR  sent_state LIKE '%{{qmosycomms_array}}%' OR  msg_read_state LIKE '%{{qmosycomms_array}}%' OR  subject LIKE '%{{qmosycomms_array}}%' OR  message_label LIKE '%{{qmosycomms_array}}%' OR  message LIKE '%{{qmosycomms_array}}%' OR  delvery_receipt LIKE '%{{qmosycomms_array}}%' OR  mosycomms_dictionary LIKE '%{{qmosycomms_array}}%' OR  sms_cost LIKE '%{{qmosycomms_array}}%' OR  page_count LIKE '%{{qmosycomms_array}}%' OR  hive_site_id LIKE '%{{qmosycomms_array}}%' OR  hive_site_name LIKE '%{{qmosycomms_array}}%')";
   
   
   ///mosycomms_array data_nodes 
  var wh_mosycomms_array_data_nodes ="{{row_count}}|{{primkey}}|{{messageid}}|{{receiver_contacts}}|{{reciver_names}}|{{message_type}}|{{site_id}}|{{group_name}}|{{message_date}}|{{sent_state}}|{{msg_read_state}}|{{subject}}|{{message_label}}|{{message}}|{{delvery_receipt}}|{{mosycomms_dictionary}}|{{sms_cost}}|{{page_count}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for mosycomms_settings ***********************************/
   var wh_mosycomms_settings_list_cols ="primkey:primkey,record_id:record_id,company_name:company_name,company_email:company_email,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start mosycomms_settings search columns 
   
   var wh_gft_mosycomms_settings_str="(primkey LIKE '%{{qmosycomms_settings}}%' OR  record_id LIKE '%{{qmosycomms_settings}}%' OR  company_name LIKE '%{{qmosycomms_settings}}%' OR  company_email LIKE '%{{qmosycomms_settings}}%' OR  hive_site_id LIKE '%{{qmosycomms_settings}}%' OR  hive_site_name LIKE '%{{qmosycomms_settings}}%')";
   
   
   ///mosycomms_settings data_nodes 
  var wh_mosycomms_settings_data_nodes ="{{row_count}}|{{primkey}}|{{record_id}}|{{company_name}}|{{company_email}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for page_manifest_ ***********************************/
   var wh_page_manifest__list_cols ="primkey:primkey,manikey:manikey,page_group:page_group,site_id:site_id,page_url:page_url,hive_site_id:hive_site_id,hive_site_name:hive_site_name,project_id:project_id,project_name:project_name";
        
   ///start page_manifest_ search columns 
   
   var wh_gft_page_manifest__str="(primkey LIKE '%{{qpage_manifest_}}%' OR  manikey LIKE '%{{qpage_manifest_}}%' OR  page_group LIKE '%{{qpage_manifest_}}%' OR  site_id LIKE '%{{qpage_manifest_}}%' OR  page_url LIKE '%{{qpage_manifest_}}%' OR  hive_site_id LIKE '%{{qpage_manifest_}}%' OR  hive_site_name LIKE '%{{qpage_manifest_}}%' OR  project_id LIKE '%{{qpage_manifest_}}%' OR  project_name LIKE '%{{qpage_manifest_}}%')";
   
   
   ///page_manifest_ data_nodes 
  var wh_page_manifest__data_nodes ="{{row_count}}|{{primkey}}|{{manikey}}|{{page_group}}|{{site_id}}|{{page_url}}|{{hive_site_id}}|{{hive_site_name}}|{{project_id}}|{{project_name}}"
   
   
   
   
     /***************************************** global data warehouse for paybill_disbursments ***********************************/
   var wh_paybill_disbursments_list_cols ="primkey:primkey,trxkey:trxkey,trx_id:trx_id,trx_date:trx_date,trx_month_year:trx_month_year,trx_remark:trx_remark,amount:amount,trx_type:trx_type,business_id:business_id,client_id:client_id,admin_id:admin_id,TransactionType:TransactionType,BusinessShortCode:BusinessShortCode,BillRefNumber:BillRefNumber,InvoiceNumber:InvoiceNumber,OrgAccountBalance:OrgAccountBalance,ThirdPartyTransID:ThirdPartyTransID,MSISDN:MSISDN,FirstName:FirstName,MiddleName:MiddleName,LastName:LastName,trx_msg:trx_msg,account_id:account_id,used_status:used_status,filter_date:filter_date,flw_id:flw_id,flag_state:flag_state,reconciled:reconciled,trx_timestamp:trx_timestamp,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start paybill_disbursments search columns 
   
   var wh_gft_paybill_disbursments_str="(primkey LIKE '%{{qpaybill_disbursments}}%' OR  trxkey LIKE '%{{qpaybill_disbursments}}%' OR  trx_id LIKE '%{{qpaybill_disbursments}}%' OR  trx_date LIKE '%{{qpaybill_disbursments}}%' OR  trx_month_year LIKE '%{{qpaybill_disbursments}}%' OR  trx_remark LIKE '%{{qpaybill_disbursments}}%' OR  amount LIKE '%{{qpaybill_disbursments}}%' OR  trx_type LIKE '%{{qpaybill_disbursments}}%' OR  business_id LIKE '%{{qpaybill_disbursments}}%' OR  client_id LIKE '%{{qpaybill_disbursments}}%' OR  admin_id LIKE '%{{qpaybill_disbursments}}%' OR  TransactionType LIKE '%{{qpaybill_disbursments}}%' OR  BusinessShortCode LIKE '%{{qpaybill_disbursments}}%' OR  BillRefNumber LIKE '%{{qpaybill_disbursments}}%' OR  InvoiceNumber LIKE '%{{qpaybill_disbursments}}%' OR  OrgAccountBalance LIKE '%{{qpaybill_disbursments}}%' OR  ThirdPartyTransID LIKE '%{{qpaybill_disbursments}}%' OR  MSISDN LIKE '%{{qpaybill_disbursments}}%' OR  FirstName LIKE '%{{qpaybill_disbursments}}%' OR  MiddleName LIKE '%{{qpaybill_disbursments}}%' OR  LastName LIKE '%{{qpaybill_disbursments}}%' OR  trx_msg LIKE '%{{qpaybill_disbursments}}%' OR  account_id LIKE '%{{qpaybill_disbursments}}%' OR  used_status LIKE '%{{qpaybill_disbursments}}%' OR  filter_date LIKE '%{{qpaybill_disbursments}}%' OR  flw_id LIKE '%{{qpaybill_disbursments}}%' OR  flag_state LIKE '%{{qpaybill_disbursments}}%' OR  reconciled LIKE '%{{qpaybill_disbursments}}%' OR  trx_timestamp LIKE '%{{qpaybill_disbursments}}%' OR  hive_site_id LIKE '%{{qpaybill_disbursments}}%' OR  hive_site_name LIKE '%{{qpaybill_disbursments}}%')";
   
   
   ///paybill_disbursments data_nodes 
  var wh_paybill_disbursments_data_nodes ="{{row_count}}|{{primkey}}|{{trxkey}}|{{trx_id}}|{{trx_date}}|{{trx_month_year}}|{{trx_remark}}|{{amount}}|{{trx_type}}|{{business_id}}|{{client_id}}|{{admin_id}}|{{TransactionType}}|{{BusinessShortCode}}|{{BillRefNumber}}|{{InvoiceNumber}}|{{OrgAccountBalance}}|{{ThirdPartyTransID}}|{{MSISDN}}|{{FirstName}}|{{MiddleName}}|{{LastName}}|{{trx_msg}}|{{account_id}}|{{used_status}}|{{filter_date}}|{{flw_id}}|{{flag_state}}|{{reconciled}}|{{trx_timestamp}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for payment_confirmations ***********************************/
   var wh_payment_confirmations_list_cols ="primkey:primkey,record_id:record_id,result_type:result_type,result_code:result_code,result_desc:result_desc,originator_conversation_id:originator_conversation_id,conversation_id:conversation_id,transaction_id:transaction_id,transaction_amount:transaction_amount,transaction_receipt:transaction_receipt,recipient_registered:recipient_registered,charges_paid_funds:charges_paid_funds,receiver_public_name:receiver_public_name,transaction_date_time:transaction_date_time,utility_funds:utility_funds,working_funds:working_funds,queue_timeout_url:queue_timeout_url,created_at:created_at,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start payment_confirmations search columns 
   
   var wh_gft_payment_confirmations_str="(primkey LIKE '%{{qpayment_confirmations}}%' OR  record_id LIKE '%{{qpayment_confirmations}}%' OR  result_type LIKE '%{{qpayment_confirmations}}%' OR  result_code LIKE '%{{qpayment_confirmations}}%' OR  result_desc LIKE '%{{qpayment_confirmations}}%' OR  originator_conversation_id LIKE '%{{qpayment_confirmations}}%' OR  conversation_id LIKE '%{{qpayment_confirmations}}%' OR  transaction_id LIKE '%{{qpayment_confirmations}}%' OR  transaction_amount LIKE '%{{qpayment_confirmations}}%' OR  transaction_receipt LIKE '%{{qpayment_confirmations}}%' OR  recipient_registered LIKE '%{{qpayment_confirmations}}%' OR  charges_paid_funds LIKE '%{{qpayment_confirmations}}%' OR  receiver_public_name LIKE '%{{qpayment_confirmations}}%' OR  transaction_date_time LIKE '%{{qpayment_confirmations}}%' OR  utility_funds LIKE '%{{qpayment_confirmations}}%' OR  working_funds LIKE '%{{qpayment_confirmations}}%' OR  queue_timeout_url LIKE '%{{qpayment_confirmations}}%' OR  created_at LIKE '%{{qpayment_confirmations}}%' OR  hive_site_id LIKE '%{{qpayment_confirmations}}%' OR  hive_site_name LIKE '%{{qpayment_confirmations}}%')";
   
   
   ///payment_confirmations data_nodes 
  var wh_payment_confirmations_data_nodes ="{{row_count}}|{{primkey}}|{{record_id}}|{{result_type}}|{{result_code}}|{{result_desc}}|{{originator_conversation_id}}|{{conversation_id}}|{{transaction_id}}|{{transaction_amount}}|{{transaction_receipt}}|{{recipient_registered}}|{{charges_paid_funds}}|{{receiver_public_name}}|{{transaction_date_time}}|{{utility_funds}}|{{working_funds}}|{{queue_timeout_url}}|{{created_at}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for phonebook ***********************************/
   var wh_phonebook_list_cols ="primkey:primkey,contact_id:contact_id,name:name,email:email,tel:tel,profile_photo:profile_photo,username:username,site_id:site_id,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start phonebook search columns 
   
   var wh_gft_phonebook_str="(primkey LIKE '%{{qphonebook}}%' OR  contact_id LIKE '%{{qphonebook}}%' OR  name LIKE '%{{qphonebook}}%' OR  email LIKE '%{{qphonebook}}%' OR  tel LIKE '%{{qphonebook}}%' OR  profile_photo LIKE '%{{qphonebook}}%' OR  username LIKE '%{{qphonebook}}%' OR  site_id LIKE '%{{qphonebook}}%' OR  hive_site_id LIKE '%{{qphonebook}}%' OR  hive_site_name LIKE '%{{qphonebook}}%')";
   
   
   ///phonebook data_nodes 
  var wh_phonebook_data_nodes ="{{row_count}}|{{primkey}}|{{contact_id}}|{{name}}|{{email}}|{{tel}}|{{profile_photo}}|{{username}}|{{site_id}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for reconciliations ***********************************/
   var wh_reconciliations_list_cols ="primkey:primkey,trxkey:trxkey,trx_id:trx_id,trx_date:trx_date,trx_month_year:trx_month_year,trx_remark:trx_remark,amount:amount,trx_type:trx_type,business_id:business_id,client_id:client_id,admin_id:admin_id,TransactionType:TransactionType,BusinessShortCode:BusinessShortCode,BillRefNumber:BillRefNumber,InvoiceNumber:InvoiceNumber,OrgAccountBalance:OrgAccountBalance,ThirdPartyTransID:ThirdPartyTransID,MSISDN:MSISDN,FirstName:FirstName,MiddleName:MiddleName,LastName:LastName,trx_msg:trx_msg,account_id:account_id,used_status:used_status,filter_date:filter_date,flag_state:flag_state,reconciled:reconciled,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start reconciliations search columns 
   
   var wh_gft_reconciliations_str="(primkey LIKE '%{{qreconciliations}}%' OR  trxkey LIKE '%{{qreconciliations}}%' OR  trx_id LIKE '%{{qreconciliations}}%' OR  trx_date LIKE '%{{qreconciliations}}%' OR  trx_month_year LIKE '%{{qreconciliations}}%' OR  trx_remark LIKE '%{{qreconciliations}}%' OR  amount LIKE '%{{qreconciliations}}%' OR  trx_type LIKE '%{{qreconciliations}}%' OR  business_id LIKE '%{{qreconciliations}}%' OR  client_id LIKE '%{{qreconciliations}}%' OR  admin_id LIKE '%{{qreconciliations}}%' OR  TransactionType LIKE '%{{qreconciliations}}%' OR  BusinessShortCode LIKE '%{{qreconciliations}}%' OR  BillRefNumber LIKE '%{{qreconciliations}}%' OR  InvoiceNumber LIKE '%{{qreconciliations}}%' OR  OrgAccountBalance LIKE '%{{qreconciliations}}%' OR  ThirdPartyTransID LIKE '%{{qreconciliations}}%' OR  MSISDN LIKE '%{{qreconciliations}}%' OR  FirstName LIKE '%{{qreconciliations}}%' OR  MiddleName LIKE '%{{qreconciliations}}%' OR  LastName LIKE '%{{qreconciliations}}%' OR  trx_msg LIKE '%{{qreconciliations}}%' OR  account_id LIKE '%{{qreconciliations}}%' OR  used_status LIKE '%{{qreconciliations}}%' OR  filter_date LIKE '%{{qreconciliations}}%' OR  flag_state LIKE '%{{qreconciliations}}%' OR  reconciled LIKE '%{{qreconciliations}}%' OR  hive_site_id LIKE '%{{qreconciliations}}%' OR  hive_site_name LIKE '%{{qreconciliations}}%')";
   
   
   ///reconciliations data_nodes 
  var wh_reconciliations_data_nodes ="{{row_count}}|{{primkey}}|{{trxkey}}|{{trx_id}}|{{trx_date}}|{{trx_month_year}}|{{trx_remark}}|{{amount}}|{{trx_type}}|{{business_id}}|{{client_id}}|{{admin_id}}|{{TransactionType}}|{{BusinessShortCode}}|{{BillRefNumber}}|{{InvoiceNumber}}|{{OrgAccountBalance}}|{{ThirdPartyTransID}}|{{MSISDN}}|{{FirstName}}|{{MiddleName}}|{{LastName}}|{{trx_msg}}|{{account_id}}|{{used_status}}|{{filter_date}}|{{flag_state}}|{{reconciled}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for send_list ***********************************/
   var wh_send_list_list_cols ="primkey:primkey,send_list_key:send_list_key,send_list_name:send_list_name,site_id:site_id,contact_id:contact_id,contact_names:contact_names,mobile:mobile,email:email,ref_no:ref_no,group_name:group_name,date_created:date_created,description:description,active_state:active_state,service_id:service_id,service_name:service_name,hive_site_id:hive_site_id,hive_site_name:hive_site_name,entry_context:entry_context";
        
   ///start send_list search columns 
   
   var wh_gft_send_list_str="(primkey LIKE '%{{qsend_list}}%' OR  send_list_key LIKE '%{{qsend_list}}%' OR  send_list_name LIKE '%{{qsend_list}}%' OR  site_id LIKE '%{{qsend_list}}%' OR  contact_id LIKE '%{{qsend_list}}%' OR  contact_names LIKE '%{{qsend_list}}%' OR  mobile LIKE '%{{qsend_list}}%' OR  email LIKE '%{{qsend_list}}%' OR  ref_no LIKE '%{{qsend_list}}%' OR  group_name LIKE '%{{qsend_list}}%' OR  date_created LIKE '%{{qsend_list}}%' OR  description LIKE '%{{qsend_list}}%' OR  active_state LIKE '%{{qsend_list}}%' OR  service_id LIKE '%{{qsend_list}}%' OR  service_name LIKE '%{{qsend_list}}%' OR  hive_site_id LIKE '%{{qsend_list}}%' OR  hive_site_name LIKE '%{{qsend_list}}%' OR  entry_context LIKE '%{{qsend_list}}%')";
   
   
   ///send_list data_nodes 
  var wh_send_list_data_nodes ="{{row_count}}|{{primkey}}|{{send_list_key}}|{{send_list_name}}|{{site_id}}|{{contact_id}}|{{contact_names}}|{{mobile}}|{{email}}|{{ref_no}}|{{group_name}}|{{date_created}}|{{description}}|{{active_state}}|{{service_id}}|{{service_name}}|{{hive_site_id}}|{{hive_site_name}}|{{entry_context}}"
   
   
   
   
     /***************************************** global data warehouse for services ***********************************/
   var wh_services_list_cols ="primkey:primkey,record_id:record_id,service_name:service_name,service_code:service_code,purchase_price:purchase_price,selling_price:selling_price,service_type:service_type,remark:remark,commission:commission,profit:profit,onboarding_commission:onboarding_commission,onboarding_percentage:onboarding_percentage,renewal_percentage:renewal_percentage,service_duration:service_duration";
        
   ///start services search columns 
   
   var wh_gft_services_str="(primkey LIKE '%{{qservices}}%' OR  record_id LIKE '%{{qservices}}%' OR  service_name LIKE '%{{qservices}}%' OR  service_code LIKE '%{{qservices}}%' OR  purchase_price LIKE '%{{qservices}}%' OR  selling_price LIKE '%{{qservices}}%' OR  service_type LIKE '%{{qservices}}%' OR  remark LIKE '%{{qservices}}%' OR  commission LIKE '%{{qservices}}%' OR  profit LIKE '%{{qservices}}%' OR  onboarding_commission LIKE '%{{qservices}}%' OR  onboarding_percentage LIKE '%{{qservices}}%' OR  renewal_percentage LIKE '%{{qservices}}%' OR  service_duration LIKE '%{{qservices}}%')";
   
   
   ///services data_nodes 
  var wh_services_data_nodes ="{{row_count}}|{{primkey}}|{{record_id}}|{{service_name}}|{{service_code}}|{{purchase_price}}|{{selling_price}}|{{service_type}}|{{remark}}|{{commission}}|{{profit}}|{{onboarding_commission}}|{{onboarding_percentage}}|{{renewal_percentage}}|{{service_duration}}"
   
   
   
   
     /***************************************** global data warehouse for system_role_bundles ***********************************/
   var wh_system_role_bundles_list_cols ="primkey:primkey,record_id:record_id,bundle_id:bundle_id,bundle_name:bundle_name,remark:remark,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start system_role_bundles search columns 
   
   var wh_gft_system_role_bundles_str="(primkey LIKE '%{{qsystem_role_bundles}}%' OR  record_id LIKE '%{{qsystem_role_bundles}}%' OR  bundle_id LIKE '%{{qsystem_role_bundles}}%' OR  bundle_name LIKE '%{{qsystem_role_bundles}}%' OR  remark LIKE '%{{qsystem_role_bundles}}%' OR  hive_site_id LIKE '%{{qsystem_role_bundles}}%' OR  hive_site_name LIKE '%{{qsystem_role_bundles}}%')";
   
   
   ///system_role_bundles data_nodes 
  var wh_system_role_bundles_data_nodes ="{{row_count}}|{{primkey}}|{{record_id}}|{{bundle_id}}|{{bundle_name}}|{{remark}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for system_users ***********************************/
   var wh_system_users_list_cols ="login_password:login_password,primkey:primkey,user_id:user_id,name:name,email:email,tel:tel,ref_id:ref_id,regdate:regdate,user_no:user_no,user_pic:user_pic,user_gender:user_gender,last_seen:last_seen,about:about,hive_site_id:hive_site_id,hive_site_name:hive_site_name,auth_token:auth_token,token_status:token_status,token_expiring_in:token_expiring_in,project_id:project_id,project_name:project_name";
        
   ///start system_users search columns 
   
   var wh_gft_system_users_str="(login_password LIKE '%{{qsystem_users}}%' OR  primkey LIKE '%{{qsystem_users}}%' OR  user_id LIKE '%{{qsystem_users}}%' OR  name LIKE '%{{qsystem_users}}%' OR  email LIKE '%{{qsystem_users}}%' OR  tel LIKE '%{{qsystem_users}}%' OR  ref_id LIKE '%{{qsystem_users}}%' OR  regdate LIKE '%{{qsystem_users}}%' OR  user_no LIKE '%{{qsystem_users}}%' OR  user_pic LIKE '%{{qsystem_users}}%' OR  user_gender LIKE '%{{qsystem_users}}%' OR  last_seen LIKE '%{{qsystem_users}}%' OR  about LIKE '%{{qsystem_users}}%' OR  hive_site_id LIKE '%{{qsystem_users}}%' OR  hive_site_name LIKE '%{{qsystem_users}}%' OR  auth_token LIKE '%{{qsystem_users}}%' OR  token_status LIKE '%{{qsystem_users}}%' OR  token_expiring_in LIKE '%{{qsystem_users}}%' OR  project_id LIKE '%{{qsystem_users}}%' OR  project_name LIKE '%{{qsystem_users}}%')";
   
   
   ///system_users data_nodes 
  var wh_system_users_data_nodes ="{{row_count}}|{{login_password}}|{{primkey}}|{{user_id}}|{{name}}|{{email}}|{{tel}}|{{ref_id}}|{{regdate}}|{{user_no}}|{{user_pic}}|{{user_gender}}|{{last_seen}}|{{about}}|{{hive_site_id}}|{{hive_site_name}}|{{auth_token}}|{{token_status}}|{{token_expiring_in}}|{{project_id}}|{{project_name}}"
   
   
   
   
     /***************************************** global data warehouse for transactions ***********************************/
   var wh_transactions_list_cols ="primkey:primkey,trxkey:trxkey,trx_id:trx_id,trx_date:trx_date,trx_month_year:trx_month_year,trx_remark:trx_remark,amount:amount,trx_type:trx_type,business_id:business_id,client_id:client_id,admin_id:admin_id,TransactionType:TransactionType,BusinessShortCode:BusinessShortCode,BillRefNumber:BillRefNumber,InvoiceNumber:InvoiceNumber,OrgAccountBalance:OrgAccountBalance,ThirdPartyTransID:ThirdPartyTransID,MSISDN:MSISDN,FirstName:FirstName,MiddleName:MiddleName,LastName:LastName,trx_msg:trx_msg,account_id:account_id,used_status:used_status,filter_date:filter_date,flw_id:flw_id,flag_state:flag_state,reconciled:reconciled,trx_timestamp:trx_timestamp,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start transactions search columns 
   
   var wh_gft_transactions_str="(primkey LIKE '%{{qtransactions}}%' OR  trxkey LIKE '%{{qtransactions}}%' OR  trx_id LIKE '%{{qtransactions}}%' OR  trx_date LIKE '%{{qtransactions}}%' OR  trx_month_year LIKE '%{{qtransactions}}%' OR  trx_remark LIKE '%{{qtransactions}}%' OR  amount LIKE '%{{qtransactions}}%' OR  trx_type LIKE '%{{qtransactions}}%' OR  business_id LIKE '%{{qtransactions}}%' OR  client_id LIKE '%{{qtransactions}}%' OR  admin_id LIKE '%{{qtransactions}}%' OR  TransactionType LIKE '%{{qtransactions}}%' OR  BusinessShortCode LIKE '%{{qtransactions}}%' OR  BillRefNumber LIKE '%{{qtransactions}}%' OR  InvoiceNumber LIKE '%{{qtransactions}}%' OR  OrgAccountBalance LIKE '%{{qtransactions}}%' OR  ThirdPartyTransID LIKE '%{{qtransactions}}%' OR  MSISDN LIKE '%{{qtransactions}}%' OR  FirstName LIKE '%{{qtransactions}}%' OR  MiddleName LIKE '%{{qtransactions}}%' OR  LastName LIKE '%{{qtransactions}}%' OR  trx_msg LIKE '%{{qtransactions}}%' OR  account_id LIKE '%{{qtransactions}}%' OR  used_status LIKE '%{{qtransactions}}%' OR  filter_date LIKE '%{{qtransactions}}%' OR  flw_id LIKE '%{{qtransactions}}%' OR  flag_state LIKE '%{{qtransactions}}%' OR  reconciled LIKE '%{{qtransactions}}%' OR  trx_timestamp LIKE '%{{qtransactions}}%' OR  hive_site_id LIKE '%{{qtransactions}}%' OR  hive_site_name LIKE '%{{qtransactions}}%')";
   
   
   ///transactions data_nodes 
  var wh_transactions_data_nodes ="{{row_count}}|{{primkey}}|{{trxkey}}|{{trx_id}}|{{trx_date}}|{{trx_month_year}}|{{trx_remark}}|{{amount}}|{{trx_type}}|{{business_id}}|{{client_id}}|{{admin_id}}|{{TransactionType}}|{{BusinessShortCode}}|{{BillRefNumber}}|{{InvoiceNumber}}|{{OrgAccountBalance}}|{{ThirdPartyTransID}}|{{MSISDN}}|{{FirstName}}|{{MiddleName}}|{{LastName}}|{{trx_msg}}|{{account_id}}|{{used_status}}|{{filter_date}}|{{flw_id}}|{{flag_state}}|{{reconciled}}|{{trx_timestamp}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for user_bundle_role_functions ***********************************/
   var wh_user_bundle_role_functions_list_cols ="primkey:primkey,record_id:record_id,bundle_id:bundle_id,bundle_name:bundle_name,role_id:role_id,role_name:role_name,remark:remark,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start user_bundle_role_functions search columns 
   
   var wh_gft_user_bundle_role_functions_str="(primkey LIKE '%{{quser_bundle_role_functions}}%' OR  record_id LIKE '%{{quser_bundle_role_functions}}%' OR  bundle_id LIKE '%{{quser_bundle_role_functions}}%' OR  bundle_name LIKE '%{{quser_bundle_role_functions}}%' OR  role_id LIKE '%{{quser_bundle_role_functions}}%' OR  role_name LIKE '%{{quser_bundle_role_functions}}%' OR  remark LIKE '%{{quser_bundle_role_functions}}%' OR  hive_site_id LIKE '%{{quser_bundle_role_functions}}%' OR  hive_site_name LIKE '%{{quser_bundle_role_functions}}%')";
   
   
   ///user_bundle_role_functions data_nodes 
  var wh_user_bundle_role_functions_data_nodes ="{{row_count}}|{{primkey}}|{{record_id}}|{{bundle_id}}|{{bundle_name}}|{{role_id}}|{{role_name}}|{{remark}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for user_manifest_ ***********************************/
   var wh_user_manifest__list_cols ="primkey:primkey,admin_mkey:admin_mkey,user_id:user_id,user_name:user_name,role_id:role_id,site_id:site_id,role_name:role_name,hive_site_id:hive_site_id,hive_site_name:hive_site_name,project_id:project_id,project_name:project_name";
        
   ///start user_manifest_ search columns 
   
   var wh_gft_user_manifest__str="(primkey LIKE '%{{quser_manifest_}}%' OR  admin_mkey LIKE '%{{quser_manifest_}}%' OR  user_id LIKE '%{{quser_manifest_}}%' OR  user_name LIKE '%{{quser_manifest_}}%' OR  role_id LIKE '%{{quser_manifest_}}%' OR  site_id LIKE '%{{quser_manifest_}}%' OR  role_name LIKE '%{{quser_manifest_}}%' OR  hive_site_id LIKE '%{{quser_manifest_}}%' OR  hive_site_name LIKE '%{{quser_manifest_}}%' OR  project_id LIKE '%{{quser_manifest_}}%' OR  project_name LIKE '%{{quser_manifest_}}%')";
   
   
   ///user_manifest_ data_nodes 
  var wh_user_manifest__data_nodes ="{{row_count}}|{{primkey}}|{{admin_mkey}}|{{user_id}}|{{user_name}}|{{role_id}}|{{site_id}}|{{role_name}}|{{hive_site_id}}|{{hive_site_name}}|{{project_id}}|{{project_name}}"
   
   
   
   
     /***************************************** global data warehouse for withdrawal_requests ***********************************/
   var wh_withdrawal_requests_list_cols ="primkey:primkey,record_id:record_id,affiliate:affiliate,amount:amount,date_requested:date_requested,approval_status:approval_status,amount_sent:amount_sent,payment_ref:payment_ref,date_sent:date_sent,remark:remark";
        
   ///start withdrawal_requests search columns 
   
   var wh_gft_withdrawal_requests_str="(primkey LIKE '%{{qwithdrawal_requests}}%' OR  record_id LIKE '%{{qwithdrawal_requests}}%' OR  affiliate LIKE '%{{qwithdrawal_requests}}%' OR  amount LIKE '%{{qwithdrawal_requests}}%' OR  date_requested LIKE '%{{qwithdrawal_requests}}%' OR  approval_status LIKE '%{{qwithdrawal_requests}}%' OR  amount_sent LIKE '%{{qwithdrawal_requests}}%' OR  payment_ref LIKE '%{{qwithdrawal_requests}}%' OR  date_sent LIKE '%{{qwithdrawal_requests}}%' OR  remark LIKE '%{{qwithdrawal_requests}}%')";
   
   
   ///withdrawal_requests data_nodes 
  var wh_withdrawal_requests_data_nodes ="{{row_count}}|{{primkey}}|{{record_id}}|{{affiliate}}|{{amount}}|{{date_requested}}|{{approval_status}}|{{amount_sent}}|{{payment_ref}}|{{date_sent}}|{{remark}}"
   
   