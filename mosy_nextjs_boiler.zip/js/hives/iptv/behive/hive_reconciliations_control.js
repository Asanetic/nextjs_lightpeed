//============================================================ ++++ start reconciliations datahandler js =============================
   
    

    //Start get  reconciliations Data ===============
    
      function get_reconciliations(reconciliations_colstr, reconciliations_filter_col, reconciliations_cols, reconciliations_node_function_name, reconciliations_callback_function_string, reconciliations_ui_tag, reconciliations_pagination, route_url_name="iptv")
      {        
        var req_url=route_url_name;

        mosyflex_sel("reconciliations", reconciliations_colstr, reconciliations_filter_col , reconciliations_cols, reconciliations_node_function_name, reconciliations_callback_function_string, reconciliations_ui_tag, reconciliations_pagination,req_url);
        
      }
    //End get  reconciliations Data ===============

    //Start insert  reconciliations Data ===============

	function add_reconciliations(reconciliations_cols, reconciliations_vals, reconciliations_callback_function_string)
    {
		
        mosyajax_create_data("reconciliations", reconciliations_cols, reconciliations_vals, reconciliations_callback_function_string);
     }
     
    //End insert  reconciliations Data ===============

    
    //Start update  reconciliations Data ===============

    function update_reconciliations(reconciliations_update_str, reconciliations_where_str, reconciliations_callback_function_string){
    
		mosyajax_update("reconciliations", reconciliations_update_str, reconciliations_where_str, reconciliations_callback_function_string)
    
    }
    //end  update  reconciliations Data ===============

	//Start drop  reconciliations Data ===============
    function reconciliations_drop(reconciliations_where_str, reconciliations_callback_function_string)
    {
        mosyajax_drop("reconciliations", reconciliations_where_str, reconciliations_callback_function_string)

    }
	//End drop  reconciliations Data ===============
    
    function initialize_reconciliations(qstr="", reconciliations_callback_function_string="",route_url_name="iptv")
    {
    
    ///alert(qstr);
      var reconciliations_token_query =qstr;
      if(qstr=="")
      {
       var reconciliations_token_query_param="";
       var reconciliations_js_uptoken=mosy_get_param("reconciliations_uptoken");
       //alert(reconciliations_js_uptoken);
       if(reconciliations_js_uptoken!==undefined)
       {
       
        reconciliations_token_query_param = atob(reconciliations_js_uptoken);
       }
        reconciliations_token_query = " where primkey='"+(reconciliations_token_query_param)+"'";
        
           if (document.getElementById("reconciliations_uptoken") !==null) {
           	if(document.getElementById("reconciliations_uptoken").value!="")
            {
            
            var reconciliations_atob_tbl_key =atob(document.getElementById("reconciliations_uptoken").value);
            
                   
            reconciliations_token_query = " where primkey='"+(reconciliations_atob_tbl_key)+"'";

            }
           }
      }
      
      var reconciliations_push_ui_data_to =reconciliations_callback_function_string;
      if(reconciliations_callback_function_string=="")
      {
      reconciliations_push_ui_data_to = "add_reconciliations_ui_data";
      }
                
      console.log(reconciliations_token_query+" -- "+reconciliations_js_uptoken);

	  //alert(reconciliations_push_ui_data_to);

	 var req_url=route_url_name;

     get_reconciliations("*", reconciliations_token_query, "primkey", "blackhole", reconciliations_push_ui_data_to, "", "", req_url);
     

    }
    
    function add_reconciliations_ui_data(reconciliations_server_resp) 
    {
    
    ///alert(reconciliations_server_resp);
    
    var json_decoded_str=JSON.parse(reconciliations_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          mosy_push_data_class("mosy_data_"+keys[i], val);
          
          // use val
      }
        
    }
    

    ///=============== load reconciliations data on the fly ==============
    
	var gft_reconciliations_str="(primkey LIKE '%{{qreconciliations}}%' OR  trxkey LIKE '%{{qreconciliations}}%' OR  trx_id LIKE '%{{qreconciliations}}%' OR  trx_date LIKE '%{{qreconciliations}}%' OR  trx_month_year LIKE '%{{qreconciliations}}%' OR  trx_remark LIKE '%{{qreconciliations}}%' OR  amount LIKE '%{{qreconciliations}}%' OR  trx_type LIKE '%{{qreconciliations}}%' OR  business_id LIKE '%{{qreconciliations}}%' OR  client_id LIKE '%{{qreconciliations}}%' OR  admin_id LIKE '%{{qreconciliations}}%' OR  TransactionType LIKE '%{{qreconciliations}}%' OR  BusinessShortCode LIKE '%{{qreconciliations}}%' OR  BillRefNumber LIKE '%{{qreconciliations}}%' OR  InvoiceNumber LIKE '%{{qreconciliations}}%' OR  OrgAccountBalance LIKE '%{{qreconciliations}}%' OR  ThirdPartyTransID LIKE '%{{qreconciliations}}%' OR  MSISDN LIKE '%{{qreconciliations}}%' OR  FirstName LIKE '%{{qreconciliations}}%' OR  MiddleName LIKE '%{{qreconciliations}}%' OR  LastName LIKE '%{{qreconciliations}}%' OR  trx_msg LIKE '%{{qreconciliations}}%' OR  account_id LIKE '%{{qreconciliations}}%' OR  used_status LIKE '%{{qreconciliations}}%' OR  filter_date LIKE '%{{qreconciliations}}%' OR  flag_state LIKE '%{{qreconciliations}}%' OR  reconciled LIKE '%{{qreconciliations}}%' OR  hive_site_id LIKE '%{{qreconciliations}}%' OR  hive_site_name LIKE '%{{qreconciliations}}%')";
    
    function  gft_reconciliations(qreconciliations_str)
    {
        	var clean_reconciliations_filter_str=gft_reconciliations_str.replace(/{{qreconciliations}}/g, magic_clean_str(qreconciliations_str));
            
            return  clean_reconciliations_filter_str;

    }
    
    function load_reconciliations(reconciliations_qstr, reconciliations_where_str, reconciliations_ret_cols, reconciliations_user_function, reconciliations_result_function, reconciliations_data_tray, route_url_name="iptv")
    {
    
    var freconciliations_result_function="push_result";
      
    if(reconciliations_result_function!="")
    {
          var freconciliations_result_function=reconciliations_result_function;

    }
    	var clean_reconciliations_filter_str=gft_reconciliations_str.replace(/{{qreconciliations}}/g, magic_clean_str(reconciliations_qstr));
        
        var freconciliations_where_str=" where "+clean_reconciliations_filter_str;

    if(reconciliations_where_str!="")
    {
          var freconciliations_where_str=" "+reconciliations_where_str;

    }

	  var req_url=route_url_name;

      get_reconciliations("*", freconciliations_where_str, reconciliations_ret_cols, reconciliations_user_function, freconciliations_result_function, reconciliations_data_tray,"",req_url);

  }
    ///=============== load reconciliations data on the fly ==============


 ///=quick load 
 
function qkload_reconciliations(qstr, push_fun="", ui_card="", and_query="", additional_cols="", reconciliations_pagination="",route_url_name="iptv")
{


      reconciliations_list_nodes_str=ui_card;
  
   
   var reconciliations_qret_fun="push_grid_result:reconciliations_tbl_list";
   
   if(push_fun!="")
   {
    reconciliations_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }

   var req_url=route_url_name;

   get_reconciliations("*", ajaxw+" ("+gft_reconciliations(qstr)+") "+combined_query+"  order by primkey desc ", reconciliations_list_cols+additional_cols_str, "",reconciliations_qret_fun, "c=>"+reconciliations_list_nodes_str, reconciliations_pagination, req_url);
}


////////////// arithmetic function 


//count 

function count_reconciliations(where_str, push_to, callback_function_string="", num_form="yes", route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }

   var req_url=route_url_name;

   get_reconciliations("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "","",req_url);
   ///get_reconciliations(reconciliations_colstr, reconciliations_filter_col, reconciliations_cols, reconciliations_node_function_name, reconciliations_callback_function_string, reconciliations_ui_tag, reconciliations_pagination, route_url_name="iptv") 

}


//qddata
function qreconciliations_ddata(where_str, disp_col , push_to, callback_function_string="",route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }

   var req_url=route_url_name;

   get_reconciliations("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "","",req_url);
   ///get_reconciliations(reconciliations_colstr, reconciliations_filter_col, reconciliations_cols, reconciliations_node_function_name, reconciliations_callback_function_string, reconciliations_ui_tag, reconciliations_pagination, route_url_name="iptv")    

}



//sum 

function sum_reconciliations(sum_col, where_str, push_to, callback_function_string="", num_form="yes",route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
           
    var req_url=route_url_name;

   get_reconciliations("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "","",req_url);

}


///request handlers 

  
  function conf_del_reconciliations_(reconciliations_data_key, after_delete="blackhole",  cancel_function="blackhole()", push_to="alert_box")
  {


    magic_yes_no_alert('Delete record?', push_to, 'reconciliations_rem_(\''+reconciliations_data_key+'\', \''+after_delete+'\')', cancel_function)

  }


function mosy_reconciliations_ins_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form",route_url_name="iptv")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
    magic_message("Processing", "dialog_box")

    var req_url=route_url_name;

   reconciliations_ins_(formid,"",response_fun,req_url)
 }
}

function mosy_reconciliations_updt_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form", route_url_name="iptv")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
   magic_message("Processing", "dialog_box")

   var req_url=route_url_name;

   reconciliations_updt_(formid,"",response_fun,req_url)
 }
}

function reconciliations_ins_(formid, required_inp=null, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }

    var req_url=route_url_name;

    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "reconciliations_insert_btn", callback_function_string_str, "", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function reconciliations_updt_(formid, required_inp, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);

     var req_url=route_url_name;
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "reconciliations_update_btn", callback_function_string_str,"", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function reconciliations_rem_(req_token, callback_function_string="",route_url_name="iptv")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

 var req_url=route_url_name;
 
 mosyajax_get('conf_deletereconciliations&reconciliations_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str,req_url);

}


function grid_reconciliations_updt_(updt_key,colstr,newcolval, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 

 var req_url=route_url_name;

mosyajax_get("_grid_updt_="+btoa('reconciliations')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str,req_url);

}
  //============================================================ ++++ End reconciliations datahandler js =============================
   
   ///reconciliations data_nodes 
  var reconciliations_data_nodes ='{{row_count}}|{{primkey}}|{{trxkey}}|{{trx_id}}|{{trx_date}}|{{trx_month_year}}|{{trx_remark}}|{{amount}}|{{trx_type}}|{{business_id}}|{{client_id}}|{{admin_id}}|{{TransactionType}}|{{BusinessShortCode}}|{{BillRefNumber}}|{{InvoiceNumber}}|{{OrgAccountBalance}}|{{ThirdPartyTransID}}|{{MSISDN}}|{{FirstName}}|{{MiddleName}}|{{LastName}}|{{trx_msg}}|{{account_id}}|{{used_status}}|{{filter_date}}|{{flag_state}}|{{reconciled}}|{{hive_site_id}}|{{hive_site_name}}';



   var reconciliations_list_cols ="primkey:primkey,trxkey:trxkey,trx_id:trx_id,trx_date:trx_date,trx_month_year:trx_month_year,trx_remark:trx_remark,amount:amount,trx_type:trx_type,business_id:business_id,client_id:client_id,admin_id:admin_id,TransactionType:TransactionType,BusinessShortCode:BusinessShortCode,BillRefNumber:BillRefNumber,InvoiceNumber:InvoiceNumber,OrgAccountBalance:OrgAccountBalance,ThirdPartyTransID:ThirdPartyTransID,MSISDN:MSISDN,FirstName:FirstName,MiddleName:MiddleName,LastName:LastName,trx_msg:trx_msg,account_id:account_id,used_status:used_status,filter_date:filter_date,flag_state:flag_state,reconciled:reconciled,hive_site_id:hive_site_id,hive_site_name:hive_site_name";

;
        
   ///start reconciliations search columns 
   
   var data_nodes_gft_reconciliations_str="(primkey LIKE '%{{qreconciliations}}%' OR  trxkey LIKE '%{{qreconciliations}}%' OR  trx_id LIKE '%{{qreconciliations}}%' OR  trx_date LIKE '%{{qreconciliations}}%' OR  trx_month_year LIKE '%{{qreconciliations}}%' OR  trx_remark LIKE '%{{qreconciliations}}%' OR  amount LIKE '%{{qreconciliations}}%' OR  trx_type LIKE '%{{qreconciliations}}%' OR  business_id LIKE '%{{qreconciliations}}%' OR  client_id LIKE '%{{qreconciliations}}%' OR  admin_id LIKE '%{{qreconciliations}}%' OR  TransactionType LIKE '%{{qreconciliations}}%' OR  BusinessShortCode LIKE '%{{qreconciliations}}%' OR  BillRefNumber LIKE '%{{qreconciliations}}%' OR  InvoiceNumber LIKE '%{{qreconciliations}}%' OR  OrgAccountBalance LIKE '%{{qreconciliations}}%' OR  ThirdPartyTransID LIKE '%{{qreconciliations}}%' OR  MSISDN LIKE '%{{qreconciliations}}%' OR  FirstName LIKE '%{{qreconciliations}}%' OR  MiddleName LIKE '%{{qreconciliations}}%' OR  LastName LIKE '%{{qreconciliations}}%' OR  trx_msg LIKE '%{{qreconciliations}}%' OR  account_id LIKE '%{{qreconciliations}}%' OR  used_status LIKE '%{{qreconciliations}}%' OR  filter_date LIKE '%{{qreconciliations}}%' OR  flag_state LIKE '%{{qreconciliations}}%' OR  reconciled LIKE '%{{qreconciliations}}%' OR  hive_site_id LIKE '%{{qreconciliations}}%' OR  hive_site_name LIKE '%{{qreconciliations}}%')";
    
    function  data_nodes_gft_reconciliations(qreconciliations_str)
    {
        	var data_nodes_clean_reconciliations_filter_str=data_nodes_gft_reconciliations_str.replace(/{{qreconciliations}}/g, magic_clean_str(qreconciliations_str));
            
            return  data_nodes_clean_reconciliations_filter_str;

    }
       ///end reconciliations search columns 

  function mosy_reconciliations_ui_node (reconciliations_json_data, reconciliations_load_to, reconciliations_cols_, reconciliations_template_ui)
  {
     ////alert(reconciliations_template_ui);
     var reconciliations_cols_fun_cols_str ="";
     
     if(typeof reconciliations_cols_fun_cols !== "undefined")
      {
        reconciliations_cols_fun_cols_str=reconciliations_cols_fun_cols;
        
        ///alert(reconciliations_cols_fun_cols)
      } 
      
     var reconciliations_ui__ = mosy_list_render_(reconciliations_json_data, reconciliations_cols_fun_cols_str+reconciliations_cols_, reconciliations_template_ui) 

     ////push_html(reconciliations_load_to, reconciliations_ui__)  

     push_grid_result(reconciliations_ui__, reconciliations_load_to)
  }
  
 
 ///////
 
 var reconciliations_auto_function= '{"cbfun":"process_reconciliations_json_data","_data_isle":"reconciliations_data_isle","_pagination_isle":"reconciliations_pagination_isle","_data_template":"hive_reconciliations_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_reconciliations","req_url":"iptv"}';

 
 
 ///============ auto renders 
 
 
function mosy_reconciliations_json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", reconciliations_pagination_prefix_="__pgnt_reconciliations", colstr="*", req_url="iptv")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("reconciliations", btoa(qstr))
  }else{
    mosy_delete_get_pram("reconciliations")
  }
  
  if(mosy_get_param("reconciliations")!==undefined)
  {
    qstr=atob(mosy_get_param("reconciliations"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:reconciliations_page_no:"+mosy_limit;
  }
  
  ///hive_reconciliations_data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_reconciliations_json_data","_data_isle":"reconciliations_data_isle","_pagination_isle":"reconciliations_pagination_isle","_data_template":"hive_reconciliations_data_template","_payload_str":"req","_pagination_prefix":"'+reconciliations_pagination_prefix_+'","req_url":"'+req_url+'"}';
            
  }
  
  return mosyrender_reconciliations_(response_fun," where "+gft_reconciliations(qstr)+" "+and_query_str+"  order by primkey desc ",function_cols,colstr,pagination, reconciliations_pagination_prefix_,req_url)
  
}


  
  function autoprocess_reconciliations_json_data(reconciliations_server_resp)
  {  
    mosy_reconciliations_ui_node(reconciliations_server_resp, "reconciliations_data_isle", reconciliations_data_nodes, get_html(hive_reconciliations_data_template),"", "l:reconciliations_page_no:15")
    mosy_paginate_api(reconciliations_server_resp, "reconciliations_page_no", "reconciliations_pagination_isle", "15")
  }
  
  function process_reconciliations_json_data(reconciliations_server_resp, reconciliations_callback="")
  {  
      var reconciliations_data_isle="reconciliations_data_isle";
      var reconciliations_data_node_template="hive_reconciliations_data_template";
      var reconciliations_pagination_isle="reconciliations_pagination_isle";
      var reconciliations_payload_str="";
      var reconciliations__pagination_prefix_str="__pgnt_reconciliations";
      
       ///alert(reconciliations_callback)
       ///alert(reconciliations_server_resp)
       ///console.log(reconciliations_server_resp)
              
      try {
        
           const reconciliations_jsonObject = JSON.parse(reconciliations_callback);
        
           reconciliations_data_isle=reconciliations_jsonObject._data_isle;
           reconciliations_data_node_template=reconciliations_jsonObject._data_template;
           reconciliations_pagination_isle=reconciliations_jsonObject._pagination_isle;
           reconciliations_payload_str=reconciliations_jsonObject._payload_str;
           reconciliations__pagination_prefix_str=reconciliations_jsonObject._pagination_prefix;
           reconciliations__req_url=reconciliations_jsonObject.req_url;

           ///console.log("paginate == : valid JSON"+reconciliations_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+reconciliations_callback);
        
         if(reconciliations_callback.indexOf(",") >= 0)
         {
              reconciliations_data_handler_ui =reconciliations_callback.split(",");                                 

              if(reconciliations_data_handler_ui[0]!=undefined){ reconciliations_data_isle=reconciliations_data_handler_ui[0];}

              if(reconciliations_data_handler_ui[1]!=undefined){reconciliations_data_node_template =reconciliations_data_handler_ui[1];}

              if(reconciliations_data_handler_ui[2]!=undefined){ reconciliations_pagination_isle=reconciliations_data_handler_ui[2]};

              if(reconciliations_data_handler_ui[3]!=undefined){ reconciliations_payload_str=btoa(reconciliations_data_handler_ui[3])};
              
              if(reconciliations_data_handler_ui[4]!=undefined){ reconciliations__pagination_prefix_str=btoa(reconciliations_data_handler_ui[4])};

			  if(reconciliations_data_handler_ui[5]!=undefined){ reconciliations__req_url=reconciliations_data_handler_ui[5]};                            
              
         }       
        
      }

       ///alert(" dtisle == "+reconciliations_data_isle)
       
            mosy_reconciliations_ui_node(reconciliations_server_resp, reconciliations_data_isle, reconciliations_data_nodes, get_html(reconciliations_data_node_template),"", "l:reconciliations_page_no:"+mosy_limit)                       
            
             if(reconciliations_payload_str==="req")
             {
                
                mosy_paginate_api(reconciliations_server_resp, "reconciliations_page_no", reconciliations_pagination_isle, "process_reconciliations_json_data", reconciliations__pagination_prefix_str,reconciliations__req_url)

             }
           
  }
    

function mosyrender_reconciliations_(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_reconciliations", req_url="iptv")
{
   
  if(pagination==="")
  {
    pagination="l:reconciliations_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _reconciliations_payload="mosyget_&tbl=reconciliations&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_reconciliations_payload+curl_url)
  
  var _reconciliations_pagination_json = '{"_payload":"'+_reconciliations_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _reconciliations_payload_input = document.createElement("input");
                _reconciliations_payload_input.setAttribute('type', 'hidden');
                _reconciliations_payload_input.setAttribute('name',_txt_payload);
                _reconciliations_payload_input.setAttribute('id', _txt_payload);

                // Add the _reconciliations_payload_input element to the DOM
                document.body.appendChild(_reconciliations_payload_input);
                
      }
      
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
  push_newval(_txt_payload, _reconciliations_pagination_json)
  mosyajax_get(_reconciliations_payload, response_fun, req_url);
  
  return _reconciliations_payload;
  
}


function mginitialize_reconciliations(reqkey, response_fun="",req_url="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _reconciliations_payload="mosyget_&tbl=reconciliations&colstr="+btoa("*")+"&where_str="+btoa(" where primkey ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
     mosyajax_get(_reconciliations_payload, response_fun, req_url);


}

 

