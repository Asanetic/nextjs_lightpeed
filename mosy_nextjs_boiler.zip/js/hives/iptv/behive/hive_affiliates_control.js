//============================================================ ++++ start affiliates datahandler js =============================
   
    

    //Start get  affiliates Data ===============
    
      function get_affiliates(affiliates_colstr, affiliates_filter_col, affiliates_cols, affiliates_node_function_name, affiliates_callback_function_string, affiliates_ui_tag, affiliates_pagination, route_url_name="iptv")
      {        
        var req_url=route_url_name;

        mosyflex_sel("affiliates", affiliates_colstr, affiliates_filter_col , affiliates_cols, affiliates_node_function_name, affiliates_callback_function_string, affiliates_ui_tag, affiliates_pagination,req_url);
        
      }
    //End get  affiliates Data ===============

    //Start insert  affiliates Data ===============

	function add_affiliates(affiliates_cols, affiliates_vals, affiliates_callback_function_string)
    {
		
        mosyajax_create_data("affiliates", affiliates_cols, affiliates_vals, affiliates_callback_function_string);
     }
     
    //End insert  affiliates Data ===============

    
    //Start update  affiliates Data ===============

    function update_affiliates(affiliates_update_str, affiliates_where_str, affiliates_callback_function_string){
    
		mosyajax_update("affiliates", affiliates_update_str, affiliates_where_str, affiliates_callback_function_string)
    
    }
    //end  update  affiliates Data ===============

	//Start drop  affiliates Data ===============
    function affiliates_drop(affiliates_where_str, affiliates_callback_function_string)
    {
        mosyajax_drop("affiliates", affiliates_where_str, affiliates_callback_function_string)

    }
	//End drop  affiliates Data ===============
    
    function initialize_affiliates(qstr="", affiliates_callback_function_string="",route_url_name="iptv")
    {
    
    ///alert(qstr);
      var affiliates_token_query =qstr;
      if(qstr=="")
      {
       var affiliates_token_query_param="";
       var affiliates_js_uptoken=mosy_get_param("affiliates_uptoken");
       //alert(affiliates_js_uptoken);
       if(affiliates_js_uptoken!==undefined)
       {
       
        affiliates_token_query_param = atob(affiliates_js_uptoken);
       }
        affiliates_token_query = " where primkey='"+(affiliates_token_query_param)+"'";
        
           if (document.getElementById("affiliates_uptoken") !==null) {
           	if(document.getElementById("affiliates_uptoken").value!="")
            {
            
            var affiliates_atob_tbl_key =atob(document.getElementById("affiliates_uptoken").value);
            
                   
            affiliates_token_query = " where primkey='"+(affiliates_atob_tbl_key)+"'";

            }
           }
      }
      
      var affiliates_push_ui_data_to =affiliates_callback_function_string;
      if(affiliates_callback_function_string=="")
      {
      affiliates_push_ui_data_to = "add_affiliates_ui_data";
      }
                
      console.log(affiliates_token_query+" -- "+affiliates_js_uptoken);

	  //alert(affiliates_push_ui_data_to);

	 var req_url=route_url_name;

     get_affiliates("*", affiliates_token_query, "primkey", "blackhole", affiliates_push_ui_data_to, "", "", req_url);
     

    }
    
    function add_affiliates_ui_data(affiliates_server_resp) 
    {
    
    ///alert(affiliates_server_resp);
    
    var json_decoded_str=JSON.parse(affiliates_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          mosy_push_data_class("mosy_data_"+keys[i], val);
          
          // use val
      }
        
    }
    

    ///=============== load affiliates data on the fly ==============
    
	var gft_affiliates_str="(primkey LIKE '%{{qaffiliates}}%' OR  record_id LIKE '%{{qaffiliates}}%' OR  name LIKE '%{{qaffiliates}}%' OR  tel LIKE '%{{qaffiliates}}%' OR  email LIKE '%{{qaffiliates}}%' OR  code LIKE '%{{qaffiliates}}%' OR  password LIKE '%{{qaffiliates}}%' OR  photo LIKE '%{{qaffiliates}}%' OR  date_registered LIKE '%{{qaffiliates}}%' OR  category LIKE '%{{qaffiliates}}%' OR  remark LIKE '%{{qaffiliates}}%')";
    
    function  gft_affiliates(qaffiliates_str)
    {
        	var clean_affiliates_filter_str=gft_affiliates_str.replace(/{{qaffiliates}}/g, magic_clean_str(qaffiliates_str));
            
            return  clean_affiliates_filter_str;

    }
    
    function load_affiliates(affiliates_qstr, affiliates_where_str, affiliates_ret_cols, affiliates_user_function, affiliates_result_function, affiliates_data_tray, route_url_name="iptv")
    {
    
    var faffiliates_result_function="push_result";
      
    if(affiliates_result_function!="")
    {
          var faffiliates_result_function=affiliates_result_function;

    }
    	var clean_affiliates_filter_str=gft_affiliates_str.replace(/{{qaffiliates}}/g, magic_clean_str(affiliates_qstr));
        
        var faffiliates_where_str=" where "+clean_affiliates_filter_str;

    if(affiliates_where_str!="")
    {
          var faffiliates_where_str=" "+affiliates_where_str;

    }

	  var req_url=route_url_name;

      get_affiliates("*", faffiliates_where_str, affiliates_ret_cols, affiliates_user_function, faffiliates_result_function, affiliates_data_tray,"",req_url);

  }
    ///=============== load affiliates data on the fly ==============


 ///=quick load 
 
function qkload_affiliates(qstr, push_fun="", ui_card="", and_query="", additional_cols="", affiliates_pagination="",route_url_name="iptv")
{


      affiliates_list_nodes_str=ui_card;
  
   
   var affiliates_qret_fun="push_grid_result:affiliates_tbl_list";
   
   if(push_fun!="")
   {
    affiliates_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }

   var req_url=route_url_name;

   get_affiliates("*", ajaxw+" ("+gft_affiliates(qstr)+") "+combined_query+"  order by primkey desc ", affiliates_list_cols+additional_cols_str, "",affiliates_qret_fun, "c=>"+affiliates_list_nodes_str, affiliates_pagination, req_url);
}


////////////// arithmetic function 


//count 

function count_affiliates(where_str, push_to, callback_function_string="", num_form="yes", route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }

   var req_url=route_url_name;

   get_affiliates("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "","",req_url);
   ///get_affiliates(affiliates_colstr, affiliates_filter_col, affiliates_cols, affiliates_node_function_name, affiliates_callback_function_string, affiliates_ui_tag, affiliates_pagination, route_url_name="iptv") 

}


//qddata
function qaffiliates_ddata(where_str, disp_col , push_to, callback_function_string="",route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }

   var req_url=route_url_name;

   get_affiliates("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "","",req_url);
   ///get_affiliates(affiliates_colstr, affiliates_filter_col, affiliates_cols, affiliates_node_function_name, affiliates_callback_function_string, affiliates_ui_tag, affiliates_pagination, route_url_name="iptv")    

}



//sum 

function sum_affiliates(sum_col, where_str, push_to, callback_function_string="", num_form="yes",route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
           
    var req_url=route_url_name;

   get_affiliates("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "","",req_url);

}


///request handlers 

  
  function conf_del_affiliates_(affiliates_data_key, after_delete="blackhole",  cancel_function="blackhole()", push_to="alert_box")
  {


    magic_yes_no_alert('Delete record?', push_to, 'affiliates_rem_(\''+affiliates_data_key+'\', \''+after_delete+'\')', cancel_function)

  }


function mosy_affiliates_ins_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form",route_url_name="iptv")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
    magic_message("Processing", "dialog_box")

    var req_url=route_url_name;

   affiliates_ins_(formid,"",response_fun,req_url)
 }
}

function mosy_affiliates_updt_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form", route_url_name="iptv")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
   magic_message("Processing", "dialog_box")

   var req_url=route_url_name;

   affiliates_updt_(formid,"",response_fun,req_url)
 }
}

function affiliates_ins_(formid, required_inp=null, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }

    var req_url=route_url_name;

    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "affiliates_insert_btn", callback_function_string_str, "", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function affiliates_updt_(formid, required_inp, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);

     var req_url=route_url_name;
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "affiliates_update_btn", callback_function_string_str,"", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function affiliates_rem_(req_token, callback_function_string="",route_url_name="iptv")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

 var req_url=route_url_name;
 
 mosyajax_get('conf_deleteaffiliates&affiliates_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str,req_url);

}


function grid_affiliates_updt_(updt_key,colstr,newcolval, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 

 var req_url=route_url_name;

mosyajax_get("_grid_updt_="+btoa('affiliates')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str,req_url);

}
  //============================================================ ++++ End affiliates datahandler js =============================
   
   ///affiliates data_nodes 
  var affiliates_data_nodes ='{{row_count}}|{{primkey}}|{{record_id}}|{{name}}|{{tel}}|{{email}}|{{code}}|{{password}}|{{photo}}|{{date_registered}}|{{category}}|{{remark}}';



   var affiliates_list_cols ="primkey:primkey,record_id:record_id,name:name,tel:tel,email:email,code:code,password:password,photo:photo,date_registered:date_registered,category:category,remark:remark";

;
        
   ///start affiliates search columns 
   
   var data_nodes_gft_affiliates_str="(primkey LIKE '%{{qaffiliates}}%' OR  record_id LIKE '%{{qaffiliates}}%' OR  name LIKE '%{{qaffiliates}}%' OR  tel LIKE '%{{qaffiliates}}%' OR  email LIKE '%{{qaffiliates}}%' OR  code LIKE '%{{qaffiliates}}%' OR  password LIKE '%{{qaffiliates}}%' OR  photo LIKE '%{{qaffiliates}}%' OR  date_registered LIKE '%{{qaffiliates}}%' OR  category LIKE '%{{qaffiliates}}%' OR  remark LIKE '%{{qaffiliates}}%')";
    
    function  data_nodes_gft_affiliates(qaffiliates_str)
    {
        	var data_nodes_clean_affiliates_filter_str=data_nodes_gft_affiliates_str.replace(/{{qaffiliates}}/g, magic_clean_str(qaffiliates_str));
            
            return  data_nodes_clean_affiliates_filter_str;

    }
       ///end affiliates search columns 

  function mosy_affiliates_ui_node (affiliates_json_data, affiliates_load_to, affiliates_cols_, affiliates_template_ui)
  {
     ////alert(affiliates_template_ui);
     var affiliates_cols_fun_cols_str ="";
     
     if(typeof affiliates_cols_fun_cols !== "undefined")
      {
        affiliates_cols_fun_cols_str=affiliates_cols_fun_cols;
        
        ///alert(affiliates_cols_fun_cols)
      } 
      
     var affiliates_ui__ = mosy_list_render_(affiliates_json_data, affiliates_cols_fun_cols_str+affiliates_cols_, affiliates_template_ui) 

     ////push_html(affiliates_load_to, affiliates_ui__)  

     push_grid_result(affiliates_ui__, affiliates_load_to)
  }
  
 
 ///////
 
 var affiliates_auto_function= '{"cbfun":"process_affiliates_json_data","_data_isle":"affiliates_data_isle","_pagination_isle":"affiliates_pagination_isle","_data_template":"hive_affiliates_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_affiliates","req_url":"iptv"}';

 
 
 ///============ auto renders 
 
 
function mosy_affiliates_json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", affiliates_pagination_prefix_="__pgnt_affiliates", colstr="*", req_url="iptv")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("affiliates", btoa(qstr))
  }else{
    mosy_delete_get_pram("affiliates")
  }
  
  if(mosy_get_param("affiliates")!==undefined)
  {
    qstr=atob(mosy_get_param("affiliates"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:affiliates_page_no:"+mosy_limit;
  }
  
  ///hive_affiliates_data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_affiliates_json_data","_data_isle":"affiliates_data_isle","_pagination_isle":"affiliates_pagination_isle","_data_template":"hive_affiliates_data_template","_payload_str":"req","_pagination_prefix":"'+affiliates_pagination_prefix_+'","req_url":"'+req_url+'"}';
            
  }
  
  return mosyrender_affiliates_(response_fun," where "+gft_affiliates(qstr)+" "+and_query_str+"  order by primkey desc ",function_cols,colstr,pagination, affiliates_pagination_prefix_,req_url)
  
}


  
  function autoprocess_affiliates_json_data(affiliates_server_resp)
  {  
    mosy_affiliates_ui_node(affiliates_server_resp, "affiliates_data_isle", affiliates_data_nodes, get_html(hive_affiliates_data_template),"", "l:affiliates_page_no:15")
    mosy_paginate_api(affiliates_server_resp, "affiliates_page_no", "affiliates_pagination_isle", "15")
  }
  
  function process_affiliates_json_data(affiliates_server_resp, affiliates_callback="")
  {  
      var affiliates_data_isle="affiliates_data_isle";
      var affiliates_data_node_template="hive_affiliates_data_template";
      var affiliates_pagination_isle="affiliates_pagination_isle";
      var affiliates_payload_str="";
      var affiliates__pagination_prefix_str="__pgnt_affiliates";
      
       ///alert(affiliates_callback)
       ///alert(affiliates_server_resp)
       ///console.log(affiliates_server_resp)
              
      try {
        
           const affiliates_jsonObject = JSON.parse(affiliates_callback);
        
           affiliates_data_isle=affiliates_jsonObject._data_isle;
           affiliates_data_node_template=affiliates_jsonObject._data_template;
           affiliates_pagination_isle=affiliates_jsonObject._pagination_isle;
           affiliates_payload_str=affiliates_jsonObject._payload_str;
           affiliates__pagination_prefix_str=affiliates_jsonObject._pagination_prefix;
           affiliates__req_url=affiliates_jsonObject.req_url;

           ///console.log("paginate == : valid JSON"+affiliates_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+affiliates_callback);
        
         if(affiliates_callback.indexOf(",") >= 0)
         {
              affiliates_data_handler_ui =affiliates_callback.split(",");                                 

              if(affiliates_data_handler_ui[0]!=undefined){ affiliates_data_isle=affiliates_data_handler_ui[0];}

              if(affiliates_data_handler_ui[1]!=undefined){affiliates_data_node_template =affiliates_data_handler_ui[1];}

              if(affiliates_data_handler_ui[2]!=undefined){ affiliates_pagination_isle=affiliates_data_handler_ui[2]};

              if(affiliates_data_handler_ui[3]!=undefined){ affiliates_payload_str=btoa(affiliates_data_handler_ui[3])};
              
              if(affiliates_data_handler_ui[4]!=undefined){ affiliates__pagination_prefix_str=btoa(affiliates_data_handler_ui[4])};

			  if(affiliates_data_handler_ui[5]!=undefined){ affiliates__req_url=affiliates_data_handler_ui[5]};                            
              
         }       
        
      }

       ///alert(" dtisle == "+affiliates_data_isle)
       
            mosy_affiliates_ui_node(affiliates_server_resp, affiliates_data_isle, affiliates_data_nodes, get_html(affiliates_data_node_template),"", "l:affiliates_page_no:"+mosy_limit)                       
            
             if(affiliates_payload_str==="req")
             {
                
                mosy_paginate_api(affiliates_server_resp, "affiliates_page_no", affiliates_pagination_isle, "process_affiliates_json_data", affiliates__pagination_prefix_str,affiliates__req_url)

             }
           
  }
    

function mosyrender_affiliates_(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_affiliates", req_url="iptv")
{
   
  if(pagination==="")
  {
    pagination="l:affiliates_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _affiliates_payload="mosyget_&tbl=affiliates&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_affiliates_payload+curl_url)
  
  var _affiliates_pagination_json = '{"_payload":"'+_affiliates_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _affiliates_payload_input = document.createElement("input");
                _affiliates_payload_input.setAttribute('type', 'hidden');
                _affiliates_payload_input.setAttribute('name',_txt_payload);
                _affiliates_payload_input.setAttribute('id', _txt_payload);

                // Add the _affiliates_payload_input element to the DOM
                document.body.appendChild(_affiliates_payload_input);
                
      }
      
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
  push_newval(_txt_payload, _affiliates_pagination_json)
  mosyajax_get(_affiliates_payload, response_fun, req_url);
  
  return _affiliates_payload;
  
}


function mginitialize_affiliates(reqkey, response_fun="",req_url="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _affiliates_payload="mosyget_&tbl=affiliates&colstr="+btoa("*")+"&where_str="+btoa(" where primkey ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
     mosyajax_get(_affiliates_payload, response_fun, req_url);


}

 

