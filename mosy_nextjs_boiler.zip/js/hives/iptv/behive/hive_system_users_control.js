//============================================================ ++++ start system_users datahandler js =============================
   
    

    //Start get  system_users Data ===============
    
      function get_system_users(system_users_colstr, system_users_filter_col, system_users_cols, system_users_node_function_name, system_users_callback_function_string, system_users_ui_tag, system_users_pagination, route_url_name="iptv")
      {        
        var req_url=route_url_name;

        mosyflex_sel("system_users", system_users_colstr, system_users_filter_col , system_users_cols, system_users_node_function_name, system_users_callback_function_string, system_users_ui_tag, system_users_pagination,req_url);
        
      }
    //End get  system_users Data ===============

    //Start insert  system_users Data ===============

	function add_system_users(system_users_cols, system_users_vals, system_users_callback_function_string)
    {
		
        mosyajax_create_data("system_users", system_users_cols, system_users_vals, system_users_callback_function_string);
     }
     
    //End insert  system_users Data ===============

    
    //Start update  system_users Data ===============

    function update_system_users(system_users_update_str, system_users_where_str, system_users_callback_function_string){
    
		mosyajax_update("system_users", system_users_update_str, system_users_where_str, system_users_callback_function_string)
    
    }
    //end  update  system_users Data ===============

	//Start drop  system_users Data ===============
    function system_users_drop(system_users_where_str, system_users_callback_function_string)
    {
        mosyajax_drop("system_users", system_users_where_str, system_users_callback_function_string)

    }
	//End drop  system_users Data ===============
    
    function initialize_system_users(qstr="", system_users_callback_function_string="",route_url_name="iptv")
    {
    
    ///alert(qstr);
      var system_users_token_query =qstr;
      if(qstr=="")
      {
       var system_users_token_query_param="";
       var system_users_js_uptoken=mosy_get_param("system_users_uptoken");
       //alert(system_users_js_uptoken);
       if(system_users_js_uptoken!==undefined)
       {
       
        system_users_token_query_param = atob(system_users_js_uptoken);
       }
        system_users_token_query = " where login_password='"+(system_users_token_query_param)+"'";
        
           if (document.getElementById("system_users_uptoken") !==null) {
           	if(document.getElementById("system_users_uptoken").value!="")
            {
            
            var system_users_atob_tbl_key =atob(document.getElementById("system_users_uptoken").value);
            
                   
            system_users_token_query = " where login_password='"+(system_users_atob_tbl_key)+"'";

            }
           }
      }
      
      var system_users_push_ui_data_to =system_users_callback_function_string;
      if(system_users_callback_function_string=="")
      {
      system_users_push_ui_data_to = "add_system_users_ui_data";
      }
                
      console.log(system_users_token_query+" -- "+system_users_js_uptoken);

	  //alert(system_users_push_ui_data_to);

	 var req_url=route_url_name;

     get_system_users("*", system_users_token_query, "login_password", "blackhole", system_users_push_ui_data_to, "", "", req_url);
     

    }
    
    function add_system_users_ui_data(system_users_server_resp) 
    {
    
    ///alert(system_users_server_resp);
    
    var json_decoded_str=JSON.parse(system_users_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          mosy_push_data_class("mosy_data_"+keys[i], val);
          
          // use val
      }
        
    }
    

    ///=============== load system_users data on the fly ==============
    
	var gft_system_users_str="(login_password LIKE '%{{qsystem_users}}%' OR  primkey LIKE '%{{qsystem_users}}%' OR  user_id LIKE '%{{qsystem_users}}%' OR  name LIKE '%{{qsystem_users}}%' OR  email LIKE '%{{qsystem_users}}%' OR  tel LIKE '%{{qsystem_users}}%' OR  ref_id LIKE '%{{qsystem_users}}%' OR  regdate LIKE '%{{qsystem_users}}%' OR  user_no LIKE '%{{qsystem_users}}%' OR  user_pic LIKE '%{{qsystem_users}}%' OR  user_gender LIKE '%{{qsystem_users}}%' OR  last_seen LIKE '%{{qsystem_users}}%' OR  about LIKE '%{{qsystem_users}}%' OR  hive_site_id LIKE '%{{qsystem_users}}%' OR  hive_site_name LIKE '%{{qsystem_users}}%' OR  auth_token LIKE '%{{qsystem_users}}%' OR  token_status LIKE '%{{qsystem_users}}%' OR  token_expiring_in LIKE '%{{qsystem_users}}%' OR  project_id LIKE '%{{qsystem_users}}%' OR  project_name LIKE '%{{qsystem_users}}%')";
    
    function  gft_system_users(qsystem_users_str)
    {
        	var clean_system_users_filter_str=gft_system_users_str.replace(/{{qsystem_users}}/g, magic_clean_str(qsystem_users_str));
            
            return  clean_system_users_filter_str;

    }
    
    function load_system_users(system_users_qstr, system_users_where_str, system_users_ret_cols, system_users_user_function, system_users_result_function, system_users_data_tray, route_url_name="iptv")
    {
    
    var fsystem_users_result_function="push_result";
      
    if(system_users_result_function!="")
    {
          var fsystem_users_result_function=system_users_result_function;

    }
    	var clean_system_users_filter_str=gft_system_users_str.replace(/{{qsystem_users}}/g, magic_clean_str(system_users_qstr));
        
        var fsystem_users_where_str=" where "+clean_system_users_filter_str;

    if(system_users_where_str!="")
    {
          var fsystem_users_where_str=" "+system_users_where_str;

    }

	  var req_url=route_url_name;

      get_system_users("*", fsystem_users_where_str, system_users_ret_cols, system_users_user_function, fsystem_users_result_function, system_users_data_tray,"",req_url);

  }
    ///=============== load system_users data on the fly ==============


 ///=quick load 
 
function qkload_system_users(qstr, push_fun="", ui_card="", and_query="", additional_cols="", system_users_pagination="",route_url_name="iptv")
{


      system_users_list_nodes_str=ui_card;
  
   
   var system_users_qret_fun="push_grid_result:system_users_tbl_list";
   
   if(push_fun!="")
   {
    system_users_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }

   var req_url=route_url_name;

   get_system_users("*", ajaxw+" ("+gft_system_users(qstr)+") "+combined_query+"  order by login_password desc ", system_users_list_cols+additional_cols_str, "",system_users_qret_fun, "c=>"+system_users_list_nodes_str, system_users_pagination, req_url);
}


////////////// arithmetic function 


//count 

function count_system_users(where_str, push_to, callback_function_string="", num_form="yes", route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }

   var req_url=route_url_name;

   get_system_users("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "","",req_url);
   ///get_system_users(system_users_colstr, system_users_filter_col, system_users_cols, system_users_node_function_name, system_users_callback_function_string, system_users_ui_tag, system_users_pagination, route_url_name="iptv") 

}


//qddata
function qsystem_users_ddata(where_str, disp_col , push_to, callback_function_string="",route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }

   var req_url=route_url_name;

   get_system_users("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "","",req_url);
   ///get_system_users(system_users_colstr, system_users_filter_col, system_users_cols, system_users_node_function_name, system_users_callback_function_string, system_users_ui_tag, system_users_pagination, route_url_name="iptv")    

}



//sum 

function sum_system_users(sum_col, where_str, push_to, callback_function_string="", num_form="yes",route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
           
    var req_url=route_url_name;

   get_system_users("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "","",req_url);

}


///request handlers 

  
  function conf_del_system_users_(system_users_data_key, after_delete="blackhole",  cancel_function="blackhole()", push_to="alert_box")
  {


    magic_yes_no_alert('Delete record?', push_to, 'system_users_rem_(\''+system_users_data_key+'\', \''+after_delete+'\')', cancel_function)

  }


function mosy_system_users_ins_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form",route_url_name="iptv")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
    magic_message("Processing", "dialog_box")

    var req_url=route_url_name;

   system_users_ins_(formid,"",response_fun,req_url)
 }
}

function mosy_system_users_updt_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form", route_url_name="iptv")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
   magic_message("Processing", "dialog_box")

   var req_url=route_url_name;

   system_users_updt_(formid,"",response_fun,req_url)
 }
}

function system_users_ins_(formid, required_inp=null, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }

    var req_url=route_url_name;

    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "system_users_insert_btn", callback_function_string_str, "", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function system_users_updt_(formid, required_inp, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);

     var req_url=route_url_name;
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "system_users_update_btn", callback_function_string_str,"", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function system_users_rem_(req_token, callback_function_string="",route_url_name="iptv")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

 var req_url=route_url_name;
 
 mosyajax_get('conf_deletesystem_users&system_users_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str,req_url);

}


function grid_system_users_updt_(updt_key,colstr,newcolval, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 

 var req_url=route_url_name;

mosyajax_get("_grid_updt_="+btoa('system_users')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('login_password')+"", callback_function_string_str,req_url);

}
  //============================================================ ++++ End system_users datahandler js =============================
   
   ///system_users data_nodes 
  var system_users_data_nodes ='{{row_count}}|{{login_password}}|{{primkey}}|{{user_id}}|{{name}}|{{email}}|{{tel}}|{{ref_id}}|{{regdate}}|{{user_no}}|{{user_pic}}|{{user_gender}}|{{last_seen}}|{{about}}|{{hive_site_id}}|{{hive_site_name}}|{{auth_token}}|{{token_status}}|{{token_expiring_in}}|{{project_id}}|{{project_name}}';



   var system_users_list_cols ="login_password:login_password,primkey:primkey,user_id:user_id,name:name,email:email,tel:tel,ref_id:ref_id,regdate:regdate,user_no:user_no,user_pic:user_pic,user_gender:user_gender,last_seen:last_seen,about:about,hive_site_id:hive_site_id,hive_site_name:hive_site_name,auth_token:auth_token,token_status:token_status,token_expiring_in:token_expiring_in,project_id:project_id,project_name:project_name";

;
        
   ///start system_users search columns 
   
   var data_nodes_gft_system_users_str="(login_password LIKE '%{{qsystem_users}}%' OR  primkey LIKE '%{{qsystem_users}}%' OR  user_id LIKE '%{{qsystem_users}}%' OR  name LIKE '%{{qsystem_users}}%' OR  email LIKE '%{{qsystem_users}}%' OR  tel LIKE '%{{qsystem_users}}%' OR  ref_id LIKE '%{{qsystem_users}}%' OR  regdate LIKE '%{{qsystem_users}}%' OR  user_no LIKE '%{{qsystem_users}}%' OR  user_pic LIKE '%{{qsystem_users}}%' OR  user_gender LIKE '%{{qsystem_users}}%' OR  last_seen LIKE '%{{qsystem_users}}%' OR  about LIKE '%{{qsystem_users}}%' OR  hive_site_id LIKE '%{{qsystem_users}}%' OR  hive_site_name LIKE '%{{qsystem_users}}%' OR  auth_token LIKE '%{{qsystem_users}}%' OR  token_status LIKE '%{{qsystem_users}}%' OR  token_expiring_in LIKE '%{{qsystem_users}}%' OR  project_id LIKE '%{{qsystem_users}}%' OR  project_name LIKE '%{{qsystem_users}}%')";
    
    function  data_nodes_gft_system_users(qsystem_users_str)
    {
        	var data_nodes_clean_system_users_filter_str=data_nodes_gft_system_users_str.replace(/{{qsystem_users}}/g, magic_clean_str(qsystem_users_str));
            
            return  data_nodes_clean_system_users_filter_str;

    }
       ///end system_users search columns 

  function mosy_system_users_ui_node (system_users_json_data, system_users_load_to, system_users_cols_, system_users_template_ui)
  {
     ////alert(system_users_template_ui);
     var system_users_cols_fun_cols_str ="";
     
     if(typeof system_users_cols_fun_cols !== "undefined")
      {
        system_users_cols_fun_cols_str=system_users_cols_fun_cols;
        
        ///alert(system_users_cols_fun_cols)
      } 
      
     var system_users_ui__ = mosy_list_render_(system_users_json_data, system_users_cols_fun_cols_str+system_users_cols_, system_users_template_ui) 

     ////push_html(system_users_load_to, system_users_ui__)  

     push_grid_result(system_users_ui__, system_users_load_to)
  }
  
 
 ///////
 
 var system_users_auto_function= '{"cbfun":"process_system_users_json_data","_data_isle":"system_users_data_isle","_pagination_isle":"system_users_pagination_isle","_data_template":"hive_system_users_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_system_users","req_url":"iptv"}';

 
 
 ///============ auto renders 
 
 
function mosy_system_users_json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", system_users_pagination_prefix_="__pgnt_system_users", colstr="*", req_url="iptv")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("system_users", btoa(qstr))
  }else{
    mosy_delete_get_pram("system_users")
  }
  
  if(mosy_get_param("system_users")!==undefined)
  {
    qstr=atob(mosy_get_param("system_users"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:system_users_page_no:"+mosy_limit;
  }
  
  ///hive_system_users_data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_system_users_json_data","_data_isle":"system_users_data_isle","_pagination_isle":"system_users_pagination_isle","_data_template":"hive_system_users_data_template","_payload_str":"req","_pagination_prefix":"'+system_users_pagination_prefix_+'","req_url":"'+req_url+'"}';
            
  }
  
  return mosyrender_system_users_(response_fun," where "+gft_system_users(qstr)+" "+and_query_str+"  order by login_password desc ",function_cols,colstr,pagination, system_users_pagination_prefix_,req_url)
  
}


  
  function autoprocess_system_users_json_data(system_users_server_resp)
  {  
    mosy_system_users_ui_node(system_users_server_resp, "system_users_data_isle", system_users_data_nodes, get_html(hive_system_users_data_template),"", "l:system_users_page_no:15")
    mosy_paginate_api(system_users_server_resp, "system_users_page_no", "system_users_pagination_isle", "15")
  }
  
  function process_system_users_json_data(system_users_server_resp, system_users_callback="")
  {  
      var system_users_data_isle="system_users_data_isle";
      var system_users_data_node_template="hive_system_users_data_template";
      var system_users_pagination_isle="system_users_pagination_isle";
      var system_users_payload_str="";
      var system_users__pagination_prefix_str="__pgnt_system_users";
      
       ///alert(system_users_callback)
       ///alert(system_users_server_resp)
       ///console.log(system_users_server_resp)
              
      try {
        
           const system_users_jsonObject = JSON.parse(system_users_callback);
        
           system_users_data_isle=system_users_jsonObject._data_isle;
           system_users_data_node_template=system_users_jsonObject._data_template;
           system_users_pagination_isle=system_users_jsonObject._pagination_isle;
           system_users_payload_str=system_users_jsonObject._payload_str;
           system_users__pagination_prefix_str=system_users_jsonObject._pagination_prefix;
           system_users__req_url=system_users_jsonObject.req_url;

           ///console.log("paginate == : valid JSON"+system_users_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+system_users_callback);
        
         if(system_users_callback.indexOf(",") >= 0)
         {
              system_users_data_handler_ui =system_users_callback.split(",");                                 

              if(system_users_data_handler_ui[0]!=undefined){ system_users_data_isle=system_users_data_handler_ui[0];}

              if(system_users_data_handler_ui[1]!=undefined){system_users_data_node_template =system_users_data_handler_ui[1];}

              if(system_users_data_handler_ui[2]!=undefined){ system_users_pagination_isle=system_users_data_handler_ui[2]};

              if(system_users_data_handler_ui[3]!=undefined){ system_users_payload_str=btoa(system_users_data_handler_ui[3])};
              
              if(system_users_data_handler_ui[4]!=undefined){ system_users__pagination_prefix_str=btoa(system_users_data_handler_ui[4])};

			  if(system_users_data_handler_ui[5]!=undefined){ system_users__req_url=system_users_data_handler_ui[5]};                            
              
         }       
        
      }

       ///alert(" dtisle == "+system_users_data_isle)
       
            mosy_system_users_ui_node(system_users_server_resp, system_users_data_isle, system_users_data_nodes, get_html(system_users_data_node_template),"", "l:system_users_page_no:"+mosy_limit)                       
            
             if(system_users_payload_str==="req")
             {
                
                mosy_paginate_api(system_users_server_resp, "system_users_page_no", system_users_pagination_isle, "process_system_users_json_data", system_users__pagination_prefix_str,system_users__req_url)

             }
           
  }
    

function mosyrender_system_users_(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_system_users", req_url="iptv")
{
   
  if(pagination==="")
  {
    pagination="l:system_users_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _system_users_payload="mosyget_&tbl=system_users&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_system_users_payload+curl_url)
  
  var _system_users_pagination_json = '{"_payload":"'+_system_users_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _system_users_payload_input = document.createElement("input");
                _system_users_payload_input.setAttribute('type', 'hidden');
                _system_users_payload_input.setAttribute('name',_txt_payload);
                _system_users_payload_input.setAttribute('id', _txt_payload);

                // Add the _system_users_payload_input element to the DOM
                document.body.appendChild(_system_users_payload_input);
                
      }
      
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
  push_newval(_txt_payload, _system_users_pagination_json)
  mosyajax_get(_system_users_payload, response_fun, req_url);
  
  return _system_users_payload;
  
}


function mginitialize_system_users(reqkey, response_fun="",req_url="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _system_users_payload="mosyget_&tbl=system_users&colstr="+btoa("*")+"&where_str="+btoa(" where login_password ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
     mosyajax_get(_system_users_payload, response_fun, req_url);


}

 

