//============================================================ ++++ start services datahandler js =============================
   
    

    //Start get  services Data ===============
    
      function get_services(services_colstr, services_filter_col, services_cols, services_node_function_name, services_callback_function_string, services_ui_tag, services_pagination, route_url_name="iptv")
      {        
        var req_url=route_url_name;

        mosyflex_sel("services", services_colstr, services_filter_col , services_cols, services_node_function_name, services_callback_function_string, services_ui_tag, services_pagination,req_url);
        
      }
    //End get  services Data ===============

    //Start insert  services Data ===============

	function add_services(services_cols, services_vals, services_callback_function_string)
    {
		
        mosyajax_create_data("services", services_cols, services_vals, services_callback_function_string);
     }
     
    //End insert  services Data ===============

    
    //Start update  services Data ===============

    function update_services(services_update_str, services_where_str, services_callback_function_string){
    
		mosyajax_update("services", services_update_str, services_where_str, services_callback_function_string)
    
    }
    //end  update  services Data ===============

	//Start drop  services Data ===============
    function services_drop(services_where_str, services_callback_function_string)
    {
        mosyajax_drop("services", services_where_str, services_callback_function_string)

    }
	//End drop  services Data ===============
    
    function initialize_services(qstr="", services_callback_function_string="",route_url_name="iptv")
    {
    
    ///alert(qstr);
      var services_token_query =qstr;
      if(qstr=="")
      {
       var services_token_query_param="";
       var services_js_uptoken=mosy_get_param("services_uptoken");
       //alert(services_js_uptoken);
       if(services_js_uptoken!==undefined)
       {
       
        services_token_query_param = atob(services_js_uptoken);
       }
        services_token_query = " where primkey='"+(services_token_query_param)+"'";
        
           if (document.getElementById("services_uptoken") !==null) {
           	if(document.getElementById("services_uptoken").value!="")
            {
            
            var services_atob_tbl_key =atob(document.getElementById("services_uptoken").value);
            
                   
            services_token_query = " where primkey='"+(services_atob_tbl_key)+"'";

            }
           }
      }
      
      var services_push_ui_data_to =services_callback_function_string;
      if(services_callback_function_string=="")
      {
      services_push_ui_data_to = "add_services_ui_data";
      }
                
      console.log(services_token_query+" -- "+services_js_uptoken);

	  //alert(services_push_ui_data_to);

	 var req_url=route_url_name;

     get_services("*", services_token_query, "primkey", "blackhole", services_push_ui_data_to, "", "", req_url);
     

    }
    
    function add_services_ui_data(services_server_resp) 
    {
    
    ///alert(services_server_resp);
    
    var json_decoded_str=JSON.parse(services_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          mosy_push_data_class("mosy_data_"+keys[i], val);
          
          // use val
      }
        
    }
    

    ///=============== load services data on the fly ==============
    
	var gft_services_str="(primkey LIKE '%{{qservices}}%' OR  record_id LIKE '%{{qservices}}%' OR  service_name LIKE '%{{qservices}}%' OR  service_code LIKE '%{{qservices}}%' OR  purchase_price LIKE '%{{qservices}}%' OR  selling_price LIKE '%{{qservices}}%' OR  service_type LIKE '%{{qservices}}%' OR  remark LIKE '%{{qservices}}%' OR  commission LIKE '%{{qservices}}%' OR  profit LIKE '%{{qservices}}%' OR  onboarding_commission LIKE '%{{qservices}}%' OR  onboarding_percentage LIKE '%{{qservices}}%' OR  renewal_percentage LIKE '%{{qservices}}%' OR  service_duration LIKE '%{{qservices}}%')";
    
    function  gft_services(qservices_str)
    {
        	var clean_services_filter_str=gft_services_str.replace(/{{qservices}}/g, magic_clean_str(qservices_str));
            
            return  clean_services_filter_str;

    }
    
    function load_services(services_qstr, services_where_str, services_ret_cols, services_user_function, services_result_function, services_data_tray, route_url_name="iptv")
    {
    
    var fservices_result_function="push_result";
      
    if(services_result_function!="")
    {
          var fservices_result_function=services_result_function;

    }
    	var clean_services_filter_str=gft_services_str.replace(/{{qservices}}/g, magic_clean_str(services_qstr));
        
        var fservices_where_str=" where "+clean_services_filter_str;

    if(services_where_str!="")
    {
          var fservices_where_str=" "+services_where_str;

    }

	  var req_url=route_url_name;

      get_services("*", fservices_where_str, services_ret_cols, services_user_function, fservices_result_function, services_data_tray,"",req_url);

  }
    ///=============== load services data on the fly ==============


 ///=quick load 
 
function qkload_services(qstr, push_fun="", ui_card="", and_query="", additional_cols="", services_pagination="",route_url_name="iptv")
{


      services_list_nodes_str=ui_card;
  
   
   var services_qret_fun="push_grid_result:services_tbl_list";
   
   if(push_fun!="")
   {
    services_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }

   var req_url=route_url_name;

   get_services("*", ajaxw+" ("+gft_services(qstr)+") "+combined_query+"  order by primkey desc ", services_list_cols+additional_cols_str, "",services_qret_fun, "c=>"+services_list_nodes_str, services_pagination, req_url);
}


////////////// arithmetic function 


//count 

function count_services(where_str, push_to, callback_function_string="", num_form="yes", route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }

   var req_url=route_url_name;

   get_services("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "","",req_url);
   ///get_services(services_colstr, services_filter_col, services_cols, services_node_function_name, services_callback_function_string, services_ui_tag, services_pagination, route_url_name="iptv") 

}


//qddata
function qservices_ddata(where_str, disp_col , push_to, callback_function_string="",route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }

   var req_url=route_url_name;

   get_services("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "","",req_url);
   ///get_services(services_colstr, services_filter_col, services_cols, services_node_function_name, services_callback_function_string, services_ui_tag, services_pagination, route_url_name="iptv")    

}



//sum 

function sum_services(sum_col, where_str, push_to, callback_function_string="", num_form="yes",route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
           
    var req_url=route_url_name;

   get_services("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "","",req_url);

}


///request handlers 

  
  function conf_del_services_(services_data_key, after_delete="blackhole",  cancel_function="blackhole()", push_to="alert_box")
  {


    magic_yes_no_alert('Delete record?', push_to, 'services_rem_(\''+services_data_key+'\', \''+after_delete+'\')', cancel_function)

  }


function mosy_services_ins_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form",route_url_name="iptv")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
    magic_message("Processing", "dialog_box")

    var req_url=route_url_name;

   services_ins_(formid,"",response_fun,req_url)
 }
}

function mosy_services_updt_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form", route_url_name="iptv")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
   magic_message("Processing", "dialog_box")

   var req_url=route_url_name;

   services_updt_(formid,"",response_fun,req_url)
 }
}

function services_ins_(formid, required_inp=null, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }

    var req_url=route_url_name;

    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "services_insert_btn", callback_function_string_str, "", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function services_updt_(formid, required_inp, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);

     var req_url=route_url_name;
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "services_update_btn", callback_function_string_str,"", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function services_rem_(req_token, callback_function_string="",route_url_name="iptv")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

 var req_url=route_url_name;
 
 mosyajax_get('conf_deleteservices&services_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str,req_url);

}


function grid_services_updt_(updt_key,colstr,newcolval, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 

 var req_url=route_url_name;

mosyajax_get("_grid_updt_="+btoa('services')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str,req_url);

}
  //============================================================ ++++ End services datahandler js =============================
   
   ///services data_nodes 
  var services_data_nodes ='{{row_count}}|{{primkey}}|{{record_id}}|{{service_name}}|{{service_code}}|{{purchase_price}}|{{selling_price}}|{{service_type}}|{{remark}}|{{commission}}|{{profit}}|{{onboarding_commission}}|{{onboarding_percentage}}|{{renewal_percentage}}|{{service_duration}}';



   var services_list_cols ="primkey:primkey,record_id:record_id,service_name:service_name,service_code:service_code,purchase_price:purchase_price,selling_price:selling_price,service_type:service_type,remark:remark,commission:commission,profit:profit,onboarding_commission:onboarding_commission,onboarding_percentage:onboarding_percentage,renewal_percentage:renewal_percentage,service_duration:service_duration";

;
        
   ///start services search columns 
   
   var data_nodes_gft_services_str="(primkey LIKE '%{{qservices}}%' OR  record_id LIKE '%{{qservices}}%' OR  service_name LIKE '%{{qservices}}%' OR  service_code LIKE '%{{qservices}}%' OR  purchase_price LIKE '%{{qservices}}%' OR  selling_price LIKE '%{{qservices}}%' OR  service_type LIKE '%{{qservices}}%' OR  remark LIKE '%{{qservices}}%' OR  commission LIKE '%{{qservices}}%' OR  profit LIKE '%{{qservices}}%' OR  onboarding_commission LIKE '%{{qservices}}%' OR  onboarding_percentage LIKE '%{{qservices}}%' OR  renewal_percentage LIKE '%{{qservices}}%' OR  service_duration LIKE '%{{qservices}}%')";
    
    function  data_nodes_gft_services(qservices_str)
    {
        	var data_nodes_clean_services_filter_str=data_nodes_gft_services_str.replace(/{{qservices}}/g, magic_clean_str(qservices_str));
            
            return  data_nodes_clean_services_filter_str;

    }
       ///end services search columns 

  function mosy_services_ui_node (services_json_data, services_load_to, services_cols_, services_template_ui)
  {
     ////alert(services_template_ui);
     var services_cols_fun_cols_str ="";
     
     if(typeof services_cols_fun_cols !== "undefined")
      {
        services_cols_fun_cols_str=services_cols_fun_cols;
        
        ///alert(services_cols_fun_cols)
      } 
      
     var services_ui__ = mosy_list_render_(services_json_data, services_cols_fun_cols_str+services_cols_, services_template_ui) 

     ////push_html(services_load_to, services_ui__)  

     push_grid_result(services_ui__, services_load_to)
  }
  
 
 ///////
 
 var services_auto_function= '{"cbfun":"process_services_json_data","_data_isle":"services_data_isle","_pagination_isle":"services_pagination_isle","_data_template":"hive_services_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_services","req_url":"iptv"}';

 
 
 ///============ auto renders 
 
 
function mosy_services_json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", services_pagination_prefix_="__pgnt_services", colstr="*", req_url="iptv")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("services", btoa(qstr))
  }else{
    mosy_delete_get_pram("services")
  }
  
  if(mosy_get_param("services")!==undefined)
  {
    qstr=atob(mosy_get_param("services"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:services_page_no:"+mosy_limit;
  }
  
  ///hive_services_data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_services_json_data","_data_isle":"services_data_isle","_pagination_isle":"services_pagination_isle","_data_template":"hive_services_data_template","_payload_str":"req","_pagination_prefix":"'+services_pagination_prefix_+'","req_url":"'+req_url+'"}';
            
  }
  
  return mosyrender_services_(response_fun," where "+gft_services(qstr)+" "+and_query_str+"  order by primkey desc ",function_cols,colstr,pagination, services_pagination_prefix_,req_url)
  
}


  
  function autoprocess_services_json_data(services_server_resp)
  {  
    mosy_services_ui_node(services_server_resp, "services_data_isle", services_data_nodes, get_html(hive_services_data_template),"", "l:services_page_no:15")
    mosy_paginate_api(services_server_resp, "services_page_no", "services_pagination_isle", "15")
  }
  
  function process_services_json_data(services_server_resp, services_callback="")
  {  
      var services_data_isle="services_data_isle";
      var services_data_node_template="hive_services_data_template";
      var services_pagination_isle="services_pagination_isle";
      var services_payload_str="";
      var services__pagination_prefix_str="__pgnt_services";
      
       ///alert(services_callback)
       ///alert(services_server_resp)
       ///console.log(services_server_resp)
              
      try {
        
           const services_jsonObject = JSON.parse(services_callback);
        
           services_data_isle=services_jsonObject._data_isle;
           services_data_node_template=services_jsonObject._data_template;
           services_pagination_isle=services_jsonObject._pagination_isle;
           services_payload_str=services_jsonObject._payload_str;
           services__pagination_prefix_str=services_jsonObject._pagination_prefix;
           services__req_url=services_jsonObject.req_url;

           ///console.log("paginate == : valid JSON"+services_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+services_callback);
        
         if(services_callback.indexOf(",") >= 0)
         {
              services_data_handler_ui =services_callback.split(",");                                 

              if(services_data_handler_ui[0]!=undefined){ services_data_isle=services_data_handler_ui[0];}

              if(services_data_handler_ui[1]!=undefined){services_data_node_template =services_data_handler_ui[1];}

              if(services_data_handler_ui[2]!=undefined){ services_pagination_isle=services_data_handler_ui[2]};

              if(services_data_handler_ui[3]!=undefined){ services_payload_str=btoa(services_data_handler_ui[3])};
              
              if(services_data_handler_ui[4]!=undefined){ services__pagination_prefix_str=btoa(services_data_handler_ui[4])};

			  if(services_data_handler_ui[5]!=undefined){ services__req_url=services_data_handler_ui[5]};                            
              
         }       
        
      }

       ///alert(" dtisle == "+services_data_isle)
       
            mosy_services_ui_node(services_server_resp, services_data_isle, services_data_nodes, get_html(services_data_node_template),"", "l:services_page_no:"+mosy_limit)                       
            
             if(services_payload_str==="req")
             {
                
                mosy_paginate_api(services_server_resp, "services_page_no", services_pagination_isle, "process_services_json_data", services__pagination_prefix_str,services__req_url)

             }
           
  }
    

function mosyrender_services_(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_services", req_url="iptv")
{
   
  if(pagination==="")
  {
    pagination="l:services_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _services_payload="mosyget_&tbl=services&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_services_payload+curl_url)
  
  var _services_pagination_json = '{"_payload":"'+_services_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _services_payload_input = document.createElement("input");
                _services_payload_input.setAttribute('type', 'hidden');
                _services_payload_input.setAttribute('name',_txt_payload);
                _services_payload_input.setAttribute('id', _txt_payload);

                // Add the _services_payload_input element to the DOM
                document.body.appendChild(_services_payload_input);
                
      }
      
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
  push_newval(_txt_payload, _services_pagination_json)
  mosyajax_get(_services_payload, response_fun, req_url);
  
  return _services_payload;
  
}


function mginitialize_services(reqkey, response_fun="",req_url="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _services_payload="mosyget_&tbl=services&colstr="+btoa("*")+"&where_str="+btoa(" where primkey ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
     mosyajax_get(_services_payload, response_fun, req_url);


}

 

