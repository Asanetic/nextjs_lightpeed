//============================================================ ++++ start system_role_bundles datahandler js =============================
   
    

    //Start get  system_role_bundles Data ===============
    
      function get_system_role_bundles(system_role_bundles_colstr, system_role_bundles_filter_col, system_role_bundles_cols, system_role_bundles_node_function_name, system_role_bundles_callback_function_string, system_role_bundles_ui_tag, system_role_bundles_pagination, route_url_name="iptv")
      {        
        var req_url=route_url_name;

        mosyflex_sel("system_role_bundles", system_role_bundles_colstr, system_role_bundles_filter_col , system_role_bundles_cols, system_role_bundles_node_function_name, system_role_bundles_callback_function_string, system_role_bundles_ui_tag, system_role_bundles_pagination,req_url);
        
      }
    //End get  system_role_bundles Data ===============

    //Start insert  system_role_bundles Data ===============

	function add_system_role_bundles(system_role_bundles_cols, system_role_bundles_vals, system_role_bundles_callback_function_string)
    {
		
        mosyajax_create_data("system_role_bundles", system_role_bundles_cols, system_role_bundles_vals, system_role_bundles_callback_function_string);
     }
     
    //End insert  system_role_bundles Data ===============

    
    //Start update  system_role_bundles Data ===============

    function update_system_role_bundles(system_role_bundles_update_str, system_role_bundles_where_str, system_role_bundles_callback_function_string){
    
		mosyajax_update("system_role_bundles", system_role_bundles_update_str, system_role_bundles_where_str, system_role_bundles_callback_function_string)
    
    }
    //end  update  system_role_bundles Data ===============

	//Start drop  system_role_bundles Data ===============
    function system_role_bundles_drop(system_role_bundles_where_str, system_role_bundles_callback_function_string)
    {
        mosyajax_drop("system_role_bundles", system_role_bundles_where_str, system_role_bundles_callback_function_string)

    }
	//End drop  system_role_bundles Data ===============
    
    function initialize_system_role_bundles(qstr="", system_role_bundles_callback_function_string="",route_url_name="iptv")
    {
    
    ///alert(qstr);
      var system_role_bundles_token_query =qstr;
      if(qstr=="")
      {
       var system_role_bundles_token_query_param="";
       var system_role_bundles_js_uptoken=mosy_get_param("system_role_bundles_uptoken");
       //alert(system_role_bundles_js_uptoken);
       if(system_role_bundles_js_uptoken!==undefined)
       {
       
        system_role_bundles_token_query_param = atob(system_role_bundles_js_uptoken);
       }
        system_role_bundles_token_query = " where primkey='"+(system_role_bundles_token_query_param)+"'";
        
           if (document.getElementById("system_role_bundles_uptoken") !==null) {
           	if(document.getElementById("system_role_bundles_uptoken").value!="")
            {
            
            var system_role_bundles_atob_tbl_key =atob(document.getElementById("system_role_bundles_uptoken").value);
            
                   
            system_role_bundles_token_query = " where primkey='"+(system_role_bundles_atob_tbl_key)+"'";

            }
           }
      }
      
      var system_role_bundles_push_ui_data_to =system_role_bundles_callback_function_string;
      if(system_role_bundles_callback_function_string=="")
      {
      system_role_bundles_push_ui_data_to = "add_system_role_bundles_ui_data";
      }
                
      console.log(system_role_bundles_token_query+" -- "+system_role_bundles_js_uptoken);

	  //alert(system_role_bundles_push_ui_data_to);

	 var req_url=route_url_name;

     get_system_role_bundles("*", system_role_bundles_token_query, "primkey", "blackhole", system_role_bundles_push_ui_data_to, "", "", req_url);
     

    }
    
    function add_system_role_bundles_ui_data(system_role_bundles_server_resp) 
    {
    
    ///alert(system_role_bundles_server_resp);
    
    var json_decoded_str=JSON.parse(system_role_bundles_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          mosy_push_data_class("mosy_data_"+keys[i], val);
          
          // use val
      }
        
    }
    

    ///=============== load system_role_bundles data on the fly ==============
    
	var gft_system_role_bundles_str="(primkey LIKE '%{{qsystem_role_bundles}}%' OR  record_id LIKE '%{{qsystem_role_bundles}}%' OR  bundle_id LIKE '%{{qsystem_role_bundles}}%' OR  bundle_name LIKE '%{{qsystem_role_bundles}}%' OR  remark LIKE '%{{qsystem_role_bundles}}%' OR  hive_site_id LIKE '%{{qsystem_role_bundles}}%' OR  hive_site_name LIKE '%{{qsystem_role_bundles}}%')";
    
    function  gft_system_role_bundles(qsystem_role_bundles_str)
    {
        	var clean_system_role_bundles_filter_str=gft_system_role_bundles_str.replace(/{{qsystem_role_bundles}}/g, magic_clean_str(qsystem_role_bundles_str));
            
            return  clean_system_role_bundles_filter_str;

    }
    
    function load_system_role_bundles(system_role_bundles_qstr, system_role_bundles_where_str, system_role_bundles_ret_cols, system_role_bundles_user_function, system_role_bundles_result_function, system_role_bundles_data_tray, route_url_name="iptv")
    {
    
    var fsystem_role_bundles_result_function="push_result";
      
    if(system_role_bundles_result_function!="")
    {
          var fsystem_role_bundles_result_function=system_role_bundles_result_function;

    }
    	var clean_system_role_bundles_filter_str=gft_system_role_bundles_str.replace(/{{qsystem_role_bundles}}/g, magic_clean_str(system_role_bundles_qstr));
        
        var fsystem_role_bundles_where_str=" where "+clean_system_role_bundles_filter_str;

    if(system_role_bundles_where_str!="")
    {
          var fsystem_role_bundles_where_str=" "+system_role_bundles_where_str;

    }

	  var req_url=route_url_name;

      get_system_role_bundles("*", fsystem_role_bundles_where_str, system_role_bundles_ret_cols, system_role_bundles_user_function, fsystem_role_bundles_result_function, system_role_bundles_data_tray,"",req_url);

  }
    ///=============== load system_role_bundles data on the fly ==============


 ///=quick load 
 
function qkload_system_role_bundles(qstr, push_fun="", ui_card="", and_query="", additional_cols="", system_role_bundles_pagination="",route_url_name="iptv")
{


      system_role_bundles_list_nodes_str=ui_card;
  
   
   var system_role_bundles_qret_fun="push_grid_result:system_role_bundles_tbl_list";
   
   if(push_fun!="")
   {
    system_role_bundles_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }

   var req_url=route_url_name;

   get_system_role_bundles("*", ajaxw+" ("+gft_system_role_bundles(qstr)+") "+combined_query+"  order by primkey desc ", system_role_bundles_list_cols+additional_cols_str, "",system_role_bundles_qret_fun, "c=>"+system_role_bundles_list_nodes_str, system_role_bundles_pagination, req_url);
}


////////////// arithmetic function 


//count 

function count_system_role_bundles(where_str, push_to, callback_function_string="", num_form="yes", route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }

   var req_url=route_url_name;

   get_system_role_bundles("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "","",req_url);
   ///get_system_role_bundles(system_role_bundles_colstr, system_role_bundles_filter_col, system_role_bundles_cols, system_role_bundles_node_function_name, system_role_bundles_callback_function_string, system_role_bundles_ui_tag, system_role_bundles_pagination, route_url_name="iptv") 

}


//qddata
function qsystem_role_bundles_ddata(where_str, disp_col , push_to, callback_function_string="",route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }

   var req_url=route_url_name;

   get_system_role_bundles("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "","",req_url);
   ///get_system_role_bundles(system_role_bundles_colstr, system_role_bundles_filter_col, system_role_bundles_cols, system_role_bundles_node_function_name, system_role_bundles_callback_function_string, system_role_bundles_ui_tag, system_role_bundles_pagination, route_url_name="iptv")    

}



//sum 

function sum_system_role_bundles(sum_col, where_str, push_to, callback_function_string="", num_form="yes",route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
           
    var req_url=route_url_name;

   get_system_role_bundles("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "","",req_url);

}


///request handlers 

  
  function conf_del_system_role_bundles_(system_role_bundles_data_key, after_delete="blackhole",  cancel_function="blackhole()", push_to="alert_box")
  {


    magic_yes_no_alert('Delete record?', push_to, 'system_role_bundles_rem_(\''+system_role_bundles_data_key+'\', \''+after_delete+'\')', cancel_function)

  }


function mosy_system_role_bundles_ins_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form",route_url_name="iptv")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
    magic_message("Processing", "dialog_box")

    var req_url=route_url_name;

   system_role_bundles_ins_(formid,"",response_fun,req_url)
 }
}

function mosy_system_role_bundles_updt_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form", route_url_name="iptv")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
   magic_message("Processing", "dialog_box")

   var req_url=route_url_name;

   system_role_bundles_updt_(formid,"",response_fun,req_url)
 }
}

function system_role_bundles_ins_(formid, required_inp=null, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }

    var req_url=route_url_name;

    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "system_role_bundles_insert_btn", callback_function_string_str, "", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function system_role_bundles_updt_(formid, required_inp, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);

     var req_url=route_url_name;
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "system_role_bundles_update_btn", callback_function_string_str,"", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function system_role_bundles_rem_(req_token, callback_function_string="",route_url_name="iptv")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

 var req_url=route_url_name;
 
 mosyajax_get('conf_deletesystem_role_bundles&system_role_bundles_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str,req_url);

}


function grid_system_role_bundles_updt_(updt_key,colstr,newcolval, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 

 var req_url=route_url_name;

mosyajax_get("_grid_updt_="+btoa('system_role_bundles')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str,req_url);

}
  //============================================================ ++++ End system_role_bundles datahandler js =============================
   
   ///system_role_bundles data_nodes 
  var system_role_bundles_data_nodes ='{{row_count}}|{{primkey}}|{{record_id}}|{{bundle_id}}|{{bundle_name}}|{{remark}}|{{hive_site_id}}|{{hive_site_name}}';



   var system_role_bundles_list_cols ="primkey:primkey,record_id:record_id,bundle_id:bundle_id,bundle_name:bundle_name,remark:remark,hive_site_id:hive_site_id,hive_site_name:hive_site_name";

;
        
   ///start system_role_bundles search columns 
   
   var data_nodes_gft_system_role_bundles_str="(primkey LIKE '%{{qsystem_role_bundles}}%' OR  record_id LIKE '%{{qsystem_role_bundles}}%' OR  bundle_id LIKE '%{{qsystem_role_bundles}}%' OR  bundle_name LIKE '%{{qsystem_role_bundles}}%' OR  remark LIKE '%{{qsystem_role_bundles}}%' OR  hive_site_id LIKE '%{{qsystem_role_bundles}}%' OR  hive_site_name LIKE '%{{qsystem_role_bundles}}%')";
    
    function  data_nodes_gft_system_role_bundles(qsystem_role_bundles_str)
    {
        	var data_nodes_clean_system_role_bundles_filter_str=data_nodes_gft_system_role_bundles_str.replace(/{{qsystem_role_bundles}}/g, magic_clean_str(qsystem_role_bundles_str));
            
            return  data_nodes_clean_system_role_bundles_filter_str;

    }
       ///end system_role_bundles search columns 

  function mosy_system_role_bundles_ui_node (system_role_bundles_json_data, system_role_bundles_load_to, system_role_bundles_cols_, system_role_bundles_template_ui)
  {
     ////alert(system_role_bundles_template_ui);
     var system_role_bundles_cols_fun_cols_str ="";
     
     if(typeof system_role_bundles_cols_fun_cols !== "undefined")
      {
        system_role_bundles_cols_fun_cols_str=system_role_bundles_cols_fun_cols;
        
        ///alert(system_role_bundles_cols_fun_cols)
      } 
      
     var system_role_bundles_ui__ = mosy_list_render_(system_role_bundles_json_data, system_role_bundles_cols_fun_cols_str+system_role_bundles_cols_, system_role_bundles_template_ui) 

     ////push_html(system_role_bundles_load_to, system_role_bundles_ui__)  

     push_grid_result(system_role_bundles_ui__, system_role_bundles_load_to)
  }
  
 
 ///////
 
 var system_role_bundles_auto_function= '{"cbfun":"process_system_role_bundles_json_data","_data_isle":"system_role_bundles_data_isle","_pagination_isle":"system_role_bundles_pagination_isle","_data_template":"hive_system_role_bundles_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_system_role_bundles","req_url":"iptv"}';

 
 
 ///============ auto renders 
 
 
function mosy_system_role_bundles_json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", system_role_bundles_pagination_prefix_="__pgnt_system_role_bundles", colstr="*", req_url="iptv")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("system_role_bundles", btoa(qstr))
  }else{
    mosy_delete_get_pram("system_role_bundles")
  }
  
  if(mosy_get_param("system_role_bundles")!==undefined)
  {
    qstr=atob(mosy_get_param("system_role_bundles"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:system_role_bundles_page_no:"+mosy_limit;
  }
  
  ///hive_system_role_bundles_data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_system_role_bundles_json_data","_data_isle":"system_role_bundles_data_isle","_pagination_isle":"system_role_bundles_pagination_isle","_data_template":"hive_system_role_bundles_data_template","_payload_str":"req","_pagination_prefix":"'+system_role_bundles_pagination_prefix_+'","req_url":"'+req_url+'"}';
            
  }
  
  return mosyrender_system_role_bundles_(response_fun," where "+gft_system_role_bundles(qstr)+" "+and_query_str+"  order by primkey desc ",function_cols,colstr,pagination, system_role_bundles_pagination_prefix_,req_url)
  
}


  
  function autoprocess_system_role_bundles_json_data(system_role_bundles_server_resp)
  {  
    mosy_system_role_bundles_ui_node(system_role_bundles_server_resp, "system_role_bundles_data_isle", system_role_bundles_data_nodes, get_html(hive_system_role_bundles_data_template),"", "l:system_role_bundles_page_no:15")
    mosy_paginate_api(system_role_bundles_server_resp, "system_role_bundles_page_no", "system_role_bundles_pagination_isle", "15")
  }
  
  function process_system_role_bundles_json_data(system_role_bundles_server_resp, system_role_bundles_callback="")
  {  
      var system_role_bundles_data_isle="system_role_bundles_data_isle";
      var system_role_bundles_data_node_template="hive_system_role_bundles_data_template";
      var system_role_bundles_pagination_isle="system_role_bundles_pagination_isle";
      var system_role_bundles_payload_str="";
      var system_role_bundles__pagination_prefix_str="__pgnt_system_role_bundles";
      
       ///alert(system_role_bundles_callback)
       ///alert(system_role_bundles_server_resp)
       ///console.log(system_role_bundles_server_resp)
              
      try {
        
           const system_role_bundles_jsonObject = JSON.parse(system_role_bundles_callback);
        
           system_role_bundles_data_isle=system_role_bundles_jsonObject._data_isle;
           system_role_bundles_data_node_template=system_role_bundles_jsonObject._data_template;
           system_role_bundles_pagination_isle=system_role_bundles_jsonObject._pagination_isle;
           system_role_bundles_payload_str=system_role_bundles_jsonObject._payload_str;
           system_role_bundles__pagination_prefix_str=system_role_bundles_jsonObject._pagination_prefix;
           system_role_bundles__req_url=system_role_bundles_jsonObject.req_url;

           ///console.log("paginate == : valid JSON"+system_role_bundles_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+system_role_bundles_callback);
        
         if(system_role_bundles_callback.indexOf(",") >= 0)
         {
              system_role_bundles_data_handler_ui =system_role_bundles_callback.split(",");                                 

              if(system_role_bundles_data_handler_ui[0]!=undefined){ system_role_bundles_data_isle=system_role_bundles_data_handler_ui[0];}

              if(system_role_bundles_data_handler_ui[1]!=undefined){system_role_bundles_data_node_template =system_role_bundles_data_handler_ui[1];}

              if(system_role_bundles_data_handler_ui[2]!=undefined){ system_role_bundles_pagination_isle=system_role_bundles_data_handler_ui[2]};

              if(system_role_bundles_data_handler_ui[3]!=undefined){ system_role_bundles_payload_str=btoa(system_role_bundles_data_handler_ui[3])};
              
              if(system_role_bundles_data_handler_ui[4]!=undefined){ system_role_bundles__pagination_prefix_str=btoa(system_role_bundles_data_handler_ui[4])};

			  if(system_role_bundles_data_handler_ui[5]!=undefined){ system_role_bundles__req_url=system_role_bundles_data_handler_ui[5]};                            
              
         }       
        
      }

       ///alert(" dtisle == "+system_role_bundles_data_isle)
       
            mosy_system_role_bundles_ui_node(system_role_bundles_server_resp, system_role_bundles_data_isle, system_role_bundles_data_nodes, get_html(system_role_bundles_data_node_template),"", "l:system_role_bundles_page_no:"+mosy_limit)                       
            
             if(system_role_bundles_payload_str==="req")
             {
                
                mosy_paginate_api(system_role_bundles_server_resp, "system_role_bundles_page_no", system_role_bundles_pagination_isle, "process_system_role_bundles_json_data", system_role_bundles__pagination_prefix_str,system_role_bundles__req_url)

             }
           
  }
    

function mosyrender_system_role_bundles_(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_system_role_bundles", req_url="iptv")
{
   
  if(pagination==="")
  {
    pagination="l:system_role_bundles_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _system_role_bundles_payload="mosyget_&tbl=system_role_bundles&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_system_role_bundles_payload+curl_url)
  
  var _system_role_bundles_pagination_json = '{"_payload":"'+_system_role_bundles_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _system_role_bundles_payload_input = document.createElement("input");
                _system_role_bundles_payload_input.setAttribute('type', 'hidden');
                _system_role_bundles_payload_input.setAttribute('name',_txt_payload);
                _system_role_bundles_payload_input.setAttribute('id', _txt_payload);

                // Add the _system_role_bundles_payload_input element to the DOM
                document.body.appendChild(_system_role_bundles_payload_input);
                
      }
      
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
  push_newval(_txt_payload, _system_role_bundles_pagination_json)
  mosyajax_get(_system_role_bundles_payload, response_fun, req_url);
  
  return _system_role_bundles_payload;
  
}


function mginitialize_system_role_bundles(reqkey, response_fun="",req_url="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _system_role_bundles_payload="mosyget_&tbl=system_role_bundles&colstr="+btoa("*")+"&where_str="+btoa(" where primkey ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
     mosyajax_get(_system_role_bundles_payload, response_fun, req_url);


}

 

