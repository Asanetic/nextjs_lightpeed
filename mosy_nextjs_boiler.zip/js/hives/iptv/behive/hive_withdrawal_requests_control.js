//============================================================ ++++ start withdrawal_requests datahandler js =============================
   
    

    //Start get  withdrawal_requests Data ===============
    
      function get_withdrawal_requests(withdrawal_requests_colstr, withdrawal_requests_filter_col, withdrawal_requests_cols, withdrawal_requests_node_function_name, withdrawal_requests_callback_function_string, withdrawal_requests_ui_tag, withdrawal_requests_pagination, route_url_name="iptv")
      {        
        var req_url=route_url_name;

        mosyflex_sel("withdrawal_requests", withdrawal_requests_colstr, withdrawal_requests_filter_col , withdrawal_requests_cols, withdrawal_requests_node_function_name, withdrawal_requests_callback_function_string, withdrawal_requests_ui_tag, withdrawal_requests_pagination,req_url);
        
      }
    //End get  withdrawal_requests Data ===============

    //Start insert  withdrawal_requests Data ===============

	function add_withdrawal_requests(withdrawal_requests_cols, withdrawal_requests_vals, withdrawal_requests_callback_function_string)
    {
		
        mosyajax_create_data("withdrawal_requests", withdrawal_requests_cols, withdrawal_requests_vals, withdrawal_requests_callback_function_string);
     }
     
    //End insert  withdrawal_requests Data ===============

    
    //Start update  withdrawal_requests Data ===============

    function update_withdrawal_requests(withdrawal_requests_update_str, withdrawal_requests_where_str, withdrawal_requests_callback_function_string){
    
		mosyajax_update("withdrawal_requests", withdrawal_requests_update_str, withdrawal_requests_where_str, withdrawal_requests_callback_function_string)
    
    }
    //end  update  withdrawal_requests Data ===============

	//Start drop  withdrawal_requests Data ===============
    function withdrawal_requests_drop(withdrawal_requests_where_str, withdrawal_requests_callback_function_string)
    {
        mosyajax_drop("withdrawal_requests", withdrawal_requests_where_str, withdrawal_requests_callback_function_string)

    }
	//End drop  withdrawal_requests Data ===============
    
    function initialize_withdrawal_requests(qstr="", withdrawal_requests_callback_function_string="",route_url_name="iptv")
    {
    
    ///alert(qstr);
      var withdrawal_requests_token_query =qstr;
      if(qstr=="")
      {
       var withdrawal_requests_token_query_param="";
       var withdrawal_requests_js_uptoken=mosy_get_param("withdrawal_requests_uptoken");
       //alert(withdrawal_requests_js_uptoken);
       if(withdrawal_requests_js_uptoken!==undefined)
       {
       
        withdrawal_requests_token_query_param = atob(withdrawal_requests_js_uptoken);
       }
        withdrawal_requests_token_query = " where primkey='"+(withdrawal_requests_token_query_param)+"'";
        
           if (document.getElementById("withdrawal_requests_uptoken") !==null) {
           	if(document.getElementById("withdrawal_requests_uptoken").value!="")
            {
            
            var withdrawal_requests_atob_tbl_key =atob(document.getElementById("withdrawal_requests_uptoken").value);
            
                   
            withdrawal_requests_token_query = " where primkey='"+(withdrawal_requests_atob_tbl_key)+"'";

            }
           }
      }
      
      var withdrawal_requests_push_ui_data_to =withdrawal_requests_callback_function_string;
      if(withdrawal_requests_callback_function_string=="")
      {
      withdrawal_requests_push_ui_data_to = "add_withdrawal_requests_ui_data";
      }
                
      console.log(withdrawal_requests_token_query+" -- "+withdrawal_requests_js_uptoken);

	  //alert(withdrawal_requests_push_ui_data_to);

	 var req_url=route_url_name;

     get_withdrawal_requests("*", withdrawal_requests_token_query, "primkey", "blackhole", withdrawal_requests_push_ui_data_to, "", "", req_url);
     

    }
    
    function add_withdrawal_requests_ui_data(withdrawal_requests_server_resp) 
    {
    
    ///alert(withdrawal_requests_server_resp);
    
    var json_decoded_str=JSON.parse(withdrawal_requests_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          mosy_push_data_class("mosy_data_"+keys[i], val);
          
          // use val
      }
        
    }
    

    ///=============== load withdrawal_requests data on the fly ==============
    
	var gft_withdrawal_requests_str="(primkey LIKE '%{{qwithdrawal_requests}}%' OR  record_id LIKE '%{{qwithdrawal_requests}}%' OR  affiliate LIKE '%{{qwithdrawal_requests}}%' OR  amount LIKE '%{{qwithdrawal_requests}}%' OR  date_requested LIKE '%{{qwithdrawal_requests}}%' OR  approval_status LIKE '%{{qwithdrawal_requests}}%' OR  amount_sent LIKE '%{{qwithdrawal_requests}}%' OR  payment_ref LIKE '%{{qwithdrawal_requests}}%' OR  date_sent LIKE '%{{qwithdrawal_requests}}%' OR  remark LIKE '%{{qwithdrawal_requests}}%')";
    
    function  gft_withdrawal_requests(qwithdrawal_requests_str)
    {
        	var clean_withdrawal_requests_filter_str=gft_withdrawal_requests_str.replace(/{{qwithdrawal_requests}}/g, magic_clean_str(qwithdrawal_requests_str));
            
            return  clean_withdrawal_requests_filter_str;

    }
    
    function load_withdrawal_requests(withdrawal_requests_qstr, withdrawal_requests_where_str, withdrawal_requests_ret_cols, withdrawal_requests_user_function, withdrawal_requests_result_function, withdrawal_requests_data_tray, route_url_name="iptv")
    {
    
    var fwithdrawal_requests_result_function="push_result";
      
    if(withdrawal_requests_result_function!="")
    {
          var fwithdrawal_requests_result_function=withdrawal_requests_result_function;

    }
    	var clean_withdrawal_requests_filter_str=gft_withdrawal_requests_str.replace(/{{qwithdrawal_requests}}/g, magic_clean_str(withdrawal_requests_qstr));
        
        var fwithdrawal_requests_where_str=" where "+clean_withdrawal_requests_filter_str;

    if(withdrawal_requests_where_str!="")
    {
          var fwithdrawal_requests_where_str=" "+withdrawal_requests_where_str;

    }

	  var req_url=route_url_name;

      get_withdrawal_requests("*", fwithdrawal_requests_where_str, withdrawal_requests_ret_cols, withdrawal_requests_user_function, fwithdrawal_requests_result_function, withdrawal_requests_data_tray,"",req_url);

  }
    ///=============== load withdrawal_requests data on the fly ==============


 ///=quick load 
 
function qkload_withdrawal_requests(qstr, push_fun="", ui_card="", and_query="", additional_cols="", withdrawal_requests_pagination="",route_url_name="iptv")
{


      withdrawal_requests_list_nodes_str=ui_card;
  
   
   var withdrawal_requests_qret_fun="push_grid_result:withdrawal_requests_tbl_list";
   
   if(push_fun!="")
   {
    withdrawal_requests_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }

   var req_url=route_url_name;

   get_withdrawal_requests("*", ajaxw+" ("+gft_withdrawal_requests(qstr)+") "+combined_query+"  order by primkey desc ", withdrawal_requests_list_cols+additional_cols_str, "",withdrawal_requests_qret_fun, "c=>"+withdrawal_requests_list_nodes_str, withdrawal_requests_pagination, req_url);
}


////////////// arithmetic function 


//count 

function count_withdrawal_requests(where_str, push_to, callback_function_string="", num_form="yes", route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }

   var req_url=route_url_name;

   get_withdrawal_requests("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "","",req_url);
   ///get_withdrawal_requests(withdrawal_requests_colstr, withdrawal_requests_filter_col, withdrawal_requests_cols, withdrawal_requests_node_function_name, withdrawal_requests_callback_function_string, withdrawal_requests_ui_tag, withdrawal_requests_pagination, route_url_name="iptv") 

}


//qddata
function qwithdrawal_requests_ddata(where_str, disp_col , push_to, callback_function_string="",route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }

   var req_url=route_url_name;

   get_withdrawal_requests("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "","",req_url);
   ///get_withdrawal_requests(withdrawal_requests_colstr, withdrawal_requests_filter_col, withdrawal_requests_cols, withdrawal_requests_node_function_name, withdrawal_requests_callback_function_string, withdrawal_requests_ui_tag, withdrawal_requests_pagination, route_url_name="iptv")    

}



//sum 

function sum_withdrawal_requests(sum_col, where_str, push_to, callback_function_string="", num_form="yes",route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
           
    var req_url=route_url_name;

   get_withdrawal_requests("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "","",req_url);

}


///request handlers 

  
  function conf_del_withdrawal_requests_(withdrawal_requests_data_key, after_delete="blackhole",  cancel_function="blackhole()", push_to="alert_box")
  {


    magic_yes_no_alert('Delete record?', push_to, 'withdrawal_requests_rem_(\''+withdrawal_requests_data_key+'\', \''+after_delete+'\')', cancel_function)

  }


function mosy_withdrawal_requests_ins_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form",route_url_name="iptv")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
    magic_message("Processing", "dialog_box")

    var req_url=route_url_name;

   withdrawal_requests_ins_(formid,"",response_fun,req_url)
 }
}

function mosy_withdrawal_requests_updt_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form", route_url_name="iptv")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
   magic_message("Processing", "dialog_box")

   var req_url=route_url_name;

   withdrawal_requests_updt_(formid,"",response_fun,req_url)
 }
}

function withdrawal_requests_ins_(formid, required_inp=null, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }

    var req_url=route_url_name;

    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "withdrawal_requests_insert_btn", callback_function_string_str, "", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function withdrawal_requests_updt_(formid, required_inp, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);

     var req_url=route_url_name;
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "withdrawal_requests_update_btn", callback_function_string_str,"", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function withdrawal_requests_rem_(req_token, callback_function_string="",route_url_name="iptv")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

 var req_url=route_url_name;
 
 mosyajax_get('conf_deletewithdrawal_requests&withdrawal_requests_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str,req_url);

}


function grid_withdrawal_requests_updt_(updt_key,colstr,newcolval, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 

 var req_url=route_url_name;

mosyajax_get("_grid_updt_="+btoa('withdrawal_requests')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str,req_url);

}
  //============================================================ ++++ End withdrawal_requests datahandler js =============================
   
   ///withdrawal_requests data_nodes 
  var withdrawal_requests_data_nodes ='{{row_count}}|{{primkey}}|{{record_id}}|{{affiliate}}|{{amount}}|{{date_requested}}|{{approval_status}}|{{amount_sent}}|{{payment_ref}}|{{date_sent}}|{{remark}}';



   var withdrawal_requests_list_cols ="primkey:primkey,record_id:record_id,affiliate:affiliate,amount:amount,date_requested:date_requested,approval_status:approval_status,amount_sent:amount_sent,payment_ref:payment_ref,date_sent:date_sent,remark:remark";

;
        
   ///start withdrawal_requests search columns 
   
   var data_nodes_gft_withdrawal_requests_str="(primkey LIKE '%{{qwithdrawal_requests}}%' OR  record_id LIKE '%{{qwithdrawal_requests}}%' OR  affiliate LIKE '%{{qwithdrawal_requests}}%' OR  amount LIKE '%{{qwithdrawal_requests}}%' OR  date_requested LIKE '%{{qwithdrawal_requests}}%' OR  approval_status LIKE '%{{qwithdrawal_requests}}%' OR  amount_sent LIKE '%{{qwithdrawal_requests}}%' OR  payment_ref LIKE '%{{qwithdrawal_requests}}%' OR  date_sent LIKE '%{{qwithdrawal_requests}}%' OR  remark LIKE '%{{qwithdrawal_requests}}%')";
    
    function  data_nodes_gft_withdrawal_requests(qwithdrawal_requests_str)
    {
        	var data_nodes_clean_withdrawal_requests_filter_str=data_nodes_gft_withdrawal_requests_str.replace(/{{qwithdrawal_requests}}/g, magic_clean_str(qwithdrawal_requests_str));
            
            return  data_nodes_clean_withdrawal_requests_filter_str;

    }
       ///end withdrawal_requests search columns 

  function mosy_withdrawal_requests_ui_node (withdrawal_requests_json_data, withdrawal_requests_load_to, withdrawal_requests_cols_, withdrawal_requests_template_ui)
  {
     ////alert(withdrawal_requests_template_ui);
     var withdrawal_requests_cols_fun_cols_str ="";
     
     if(typeof withdrawal_requests_cols_fun_cols !== "undefined")
      {
        withdrawal_requests_cols_fun_cols_str=withdrawal_requests_cols_fun_cols;
        
        ///alert(withdrawal_requests_cols_fun_cols)
      } 
      
     var withdrawal_requests_ui__ = mosy_list_render_(withdrawal_requests_json_data, withdrawal_requests_cols_fun_cols_str+withdrawal_requests_cols_, withdrawal_requests_template_ui) 

     ////push_html(withdrawal_requests_load_to, withdrawal_requests_ui__)  

     push_grid_result(withdrawal_requests_ui__, withdrawal_requests_load_to)
  }
  
 
 ///////
 
 var withdrawal_requests_auto_function= '{"cbfun":"process_withdrawal_requests_json_data","_data_isle":"withdrawal_requests_data_isle","_pagination_isle":"withdrawal_requests_pagination_isle","_data_template":"hive_withdrawal_requests_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_withdrawal_requests","req_url":"iptv"}';

 
 
 ///============ auto renders 
 
 
function mosy_withdrawal_requests_json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", withdrawal_requests_pagination_prefix_="__pgnt_withdrawal_requests", colstr="*", req_url="iptv")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("withdrawal_requests", btoa(qstr))
  }else{
    mosy_delete_get_pram("withdrawal_requests")
  }
  
  if(mosy_get_param("withdrawal_requests")!==undefined)
  {
    qstr=atob(mosy_get_param("withdrawal_requests"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:withdrawal_requests_page_no:"+mosy_limit;
  }
  
  ///hive_withdrawal_requests_data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_withdrawal_requests_json_data","_data_isle":"withdrawal_requests_data_isle","_pagination_isle":"withdrawal_requests_pagination_isle","_data_template":"hive_withdrawal_requests_data_template","_payload_str":"req","_pagination_prefix":"'+withdrawal_requests_pagination_prefix_+'","req_url":"'+req_url+'"}';
            
  }
  
  return mosyrender_withdrawal_requests_(response_fun," where "+gft_withdrawal_requests(qstr)+" "+and_query_str+"  order by primkey desc ",function_cols,colstr,pagination, withdrawal_requests_pagination_prefix_,req_url)
  
}


  
  function autoprocess_withdrawal_requests_json_data(withdrawal_requests_server_resp)
  {  
    mosy_withdrawal_requests_ui_node(withdrawal_requests_server_resp, "withdrawal_requests_data_isle", withdrawal_requests_data_nodes, get_html(hive_withdrawal_requests_data_template),"", "l:withdrawal_requests_page_no:15")
    mosy_paginate_api(withdrawal_requests_server_resp, "withdrawal_requests_page_no", "withdrawal_requests_pagination_isle", "15")
  }
  
  function process_withdrawal_requests_json_data(withdrawal_requests_server_resp, withdrawal_requests_callback="")
  {  
      var withdrawal_requests_data_isle="withdrawal_requests_data_isle";
      var withdrawal_requests_data_node_template="hive_withdrawal_requests_data_template";
      var withdrawal_requests_pagination_isle="withdrawal_requests_pagination_isle";
      var withdrawal_requests_payload_str="";
      var withdrawal_requests__pagination_prefix_str="__pgnt_withdrawal_requests";
      
       ///alert(withdrawal_requests_callback)
       ///alert(withdrawal_requests_server_resp)
       ///console.log(withdrawal_requests_server_resp)
              
      try {
        
           const withdrawal_requests_jsonObject = JSON.parse(withdrawal_requests_callback);
        
           withdrawal_requests_data_isle=withdrawal_requests_jsonObject._data_isle;
           withdrawal_requests_data_node_template=withdrawal_requests_jsonObject._data_template;
           withdrawal_requests_pagination_isle=withdrawal_requests_jsonObject._pagination_isle;
           withdrawal_requests_payload_str=withdrawal_requests_jsonObject._payload_str;
           withdrawal_requests__pagination_prefix_str=withdrawal_requests_jsonObject._pagination_prefix;
           withdrawal_requests__req_url=withdrawal_requests_jsonObject.req_url;

           ///console.log("paginate == : valid JSON"+withdrawal_requests_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+withdrawal_requests_callback);
        
         if(withdrawal_requests_callback.indexOf(",") >= 0)
         {
              withdrawal_requests_data_handler_ui =withdrawal_requests_callback.split(",");                                 

              if(withdrawal_requests_data_handler_ui[0]!=undefined){ withdrawal_requests_data_isle=withdrawal_requests_data_handler_ui[0];}

              if(withdrawal_requests_data_handler_ui[1]!=undefined){withdrawal_requests_data_node_template =withdrawal_requests_data_handler_ui[1];}

              if(withdrawal_requests_data_handler_ui[2]!=undefined){ withdrawal_requests_pagination_isle=withdrawal_requests_data_handler_ui[2]};

              if(withdrawal_requests_data_handler_ui[3]!=undefined){ withdrawal_requests_payload_str=btoa(withdrawal_requests_data_handler_ui[3])};
              
              if(withdrawal_requests_data_handler_ui[4]!=undefined){ withdrawal_requests__pagination_prefix_str=btoa(withdrawal_requests_data_handler_ui[4])};

			  if(withdrawal_requests_data_handler_ui[5]!=undefined){ withdrawal_requests__req_url=withdrawal_requests_data_handler_ui[5]};                            
              
         }       
        
      }

       ///alert(" dtisle == "+withdrawal_requests_data_isle)
       
            mosy_withdrawal_requests_ui_node(withdrawal_requests_server_resp, withdrawal_requests_data_isle, withdrawal_requests_data_nodes, get_html(withdrawal_requests_data_node_template),"", "l:withdrawal_requests_page_no:"+mosy_limit)                       
            
             if(withdrawal_requests_payload_str==="req")
             {
                
                mosy_paginate_api(withdrawal_requests_server_resp, "withdrawal_requests_page_no", withdrawal_requests_pagination_isle, "process_withdrawal_requests_json_data", withdrawal_requests__pagination_prefix_str,withdrawal_requests__req_url)

             }
           
  }
    

function mosyrender_withdrawal_requests_(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_withdrawal_requests", req_url="iptv")
{
   
  if(pagination==="")
  {
    pagination="l:withdrawal_requests_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _withdrawal_requests_payload="mosyget_&tbl=withdrawal_requests&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_withdrawal_requests_payload+curl_url)
  
  var _withdrawal_requests_pagination_json = '{"_payload":"'+_withdrawal_requests_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _withdrawal_requests_payload_input = document.createElement("input");
                _withdrawal_requests_payload_input.setAttribute('type', 'hidden');
                _withdrawal_requests_payload_input.setAttribute('name',_txt_payload);
                _withdrawal_requests_payload_input.setAttribute('id', _txt_payload);

                // Add the _withdrawal_requests_payload_input element to the DOM
                document.body.appendChild(_withdrawal_requests_payload_input);
                
      }
      
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
  push_newval(_txt_payload, _withdrawal_requests_pagination_json)
  mosyajax_get(_withdrawal_requests_payload, response_fun, req_url);
  
  return _withdrawal_requests_payload;
  
}


function mginitialize_withdrawal_requests(reqkey, response_fun="",req_url="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _withdrawal_requests_payload="mosyget_&tbl=withdrawal_requests&colstr="+btoa("*")+"&where_str="+btoa(" where primkey ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
     mosyajax_get(_withdrawal_requests_payload, response_fun, req_url);


}

 

