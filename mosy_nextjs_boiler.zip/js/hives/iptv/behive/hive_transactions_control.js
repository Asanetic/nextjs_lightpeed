//============================================================ ++++ start transactions datahandler js =============================
   
    

    //Start get  transactions Data ===============
    
      function get_transactions(transactions_colstr, transactions_filter_col, transactions_cols, transactions_node_function_name, transactions_callback_function_string, transactions_ui_tag, transactions_pagination, route_url_name="iptv")
      {        
        var req_url=route_url_name;

        mosyflex_sel("transactions", transactions_colstr, transactions_filter_col , transactions_cols, transactions_node_function_name, transactions_callback_function_string, transactions_ui_tag, transactions_pagination,req_url);
        
      }
    //End get  transactions Data ===============

    //Start insert  transactions Data ===============

	function add_transactions(transactions_cols, transactions_vals, transactions_callback_function_string)
    {
		
        mosyajax_create_data("transactions", transactions_cols, transactions_vals, transactions_callback_function_string);
     }
     
    //End insert  transactions Data ===============

    
    //Start update  transactions Data ===============

    function update_transactions(transactions_update_str, transactions_where_str, transactions_callback_function_string){
    
		mosyajax_update("transactions", transactions_update_str, transactions_where_str, transactions_callback_function_string)
    
    }
    //end  update  transactions Data ===============

	//Start drop  transactions Data ===============
    function transactions_drop(transactions_where_str, transactions_callback_function_string)
    {
        mosyajax_drop("transactions", transactions_where_str, transactions_callback_function_string)

    }
	//End drop  transactions Data ===============
    
    function initialize_transactions(qstr="", transactions_callback_function_string="",route_url_name="iptv")
    {
    
    ///alert(qstr);
      var transactions_token_query =qstr;
      if(qstr=="")
      {
       var transactions_token_query_param="";
       var transactions_js_uptoken=mosy_get_param("transactions_uptoken");
       //alert(transactions_js_uptoken);
       if(transactions_js_uptoken!==undefined)
       {
       
        transactions_token_query_param = atob(transactions_js_uptoken);
       }
        transactions_token_query = " where primkey='"+(transactions_token_query_param)+"'";
        
           if (document.getElementById("transactions_uptoken") !==null) {
           	if(document.getElementById("transactions_uptoken").value!="")
            {
            
            var transactions_atob_tbl_key =atob(document.getElementById("transactions_uptoken").value);
            
                   
            transactions_token_query = " where primkey='"+(transactions_atob_tbl_key)+"'";

            }
           }
      }
      
      var transactions_push_ui_data_to =transactions_callback_function_string;
      if(transactions_callback_function_string=="")
      {
      transactions_push_ui_data_to = "add_transactions_ui_data";
      }
                
      console.log(transactions_token_query+" -- "+transactions_js_uptoken);

	  //alert(transactions_push_ui_data_to);

	 var req_url=route_url_name;

     get_transactions("*", transactions_token_query, "primkey", "blackhole", transactions_push_ui_data_to, "", "", req_url);
     

    }
    
    function add_transactions_ui_data(transactions_server_resp) 
    {
    
    ///alert(transactions_server_resp);
    
    var json_decoded_str=JSON.parse(transactions_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          mosy_push_data_class("mosy_data_"+keys[i], val);
          
          // use val
      }
        
    }
    

    ///=============== load transactions data on the fly ==============
    
	var gft_transactions_str="(primkey LIKE '%{{qtransactions}}%' OR  trxkey LIKE '%{{qtransactions}}%' OR  trx_id LIKE '%{{qtransactions}}%' OR  trx_date LIKE '%{{qtransactions}}%' OR  trx_month_year LIKE '%{{qtransactions}}%' OR  trx_remark LIKE '%{{qtransactions}}%' OR  amount LIKE '%{{qtransactions}}%' OR  trx_type LIKE '%{{qtransactions}}%' OR  business_id LIKE '%{{qtransactions}}%' OR  client_id LIKE '%{{qtransactions}}%' OR  admin_id LIKE '%{{qtransactions}}%' OR  TransactionType LIKE '%{{qtransactions}}%' OR  BusinessShortCode LIKE '%{{qtransactions}}%' OR  BillRefNumber LIKE '%{{qtransactions}}%' OR  InvoiceNumber LIKE '%{{qtransactions}}%' OR  OrgAccountBalance LIKE '%{{qtransactions}}%' OR  ThirdPartyTransID LIKE '%{{qtransactions}}%' OR  MSISDN LIKE '%{{qtransactions}}%' OR  FirstName LIKE '%{{qtransactions}}%' OR  MiddleName LIKE '%{{qtransactions}}%' OR  LastName LIKE '%{{qtransactions}}%' OR  trx_msg LIKE '%{{qtransactions}}%' OR  account_id LIKE '%{{qtransactions}}%' OR  used_status LIKE '%{{qtransactions}}%' OR  filter_date LIKE '%{{qtransactions}}%' OR  flw_id LIKE '%{{qtransactions}}%' OR  flag_state LIKE '%{{qtransactions}}%' OR  reconciled LIKE '%{{qtransactions}}%' OR  trx_timestamp LIKE '%{{qtransactions}}%' OR  hive_site_id LIKE '%{{qtransactions}}%' OR  hive_site_name LIKE '%{{qtransactions}}%')";
    
    function  gft_transactions(qtransactions_str)
    {
        	var clean_transactions_filter_str=gft_transactions_str.replace(/{{qtransactions}}/g, magic_clean_str(qtransactions_str));
            
            return  clean_transactions_filter_str;

    }
    
    function load_transactions(transactions_qstr, transactions_where_str, transactions_ret_cols, transactions_user_function, transactions_result_function, transactions_data_tray, route_url_name="iptv")
    {
    
    var ftransactions_result_function="push_result";
      
    if(transactions_result_function!="")
    {
          var ftransactions_result_function=transactions_result_function;

    }
    	var clean_transactions_filter_str=gft_transactions_str.replace(/{{qtransactions}}/g, magic_clean_str(transactions_qstr));
        
        var ftransactions_where_str=" where "+clean_transactions_filter_str;

    if(transactions_where_str!="")
    {
          var ftransactions_where_str=" "+transactions_where_str;

    }

	  var req_url=route_url_name;

      get_transactions("*", ftransactions_where_str, transactions_ret_cols, transactions_user_function, ftransactions_result_function, transactions_data_tray,"",req_url);

  }
    ///=============== load transactions data on the fly ==============


 ///=quick load 
 
function qkload_transactions(qstr, push_fun="", ui_card="", and_query="", additional_cols="", transactions_pagination="",route_url_name="iptv")
{


      transactions_list_nodes_str=ui_card;
  
   
   var transactions_qret_fun="push_grid_result:transactions_tbl_list";
   
   if(push_fun!="")
   {
    transactions_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }

   var req_url=route_url_name;

   get_transactions("*", ajaxw+" ("+gft_transactions(qstr)+") "+combined_query+"  order by primkey desc ", transactions_list_cols+additional_cols_str, "",transactions_qret_fun, "c=>"+transactions_list_nodes_str, transactions_pagination, req_url);
}


////////////// arithmetic function 


//count 

function count_transactions(where_str, push_to, callback_function_string="", num_form="yes", route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }

   var req_url=route_url_name;

   get_transactions("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "","",req_url);
   ///get_transactions(transactions_colstr, transactions_filter_col, transactions_cols, transactions_node_function_name, transactions_callback_function_string, transactions_ui_tag, transactions_pagination, route_url_name="iptv") 

}


//qddata
function qtransactions_ddata(where_str, disp_col , push_to, callback_function_string="",route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }

   var req_url=route_url_name;

   get_transactions("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "","",req_url);
   ///get_transactions(transactions_colstr, transactions_filter_col, transactions_cols, transactions_node_function_name, transactions_callback_function_string, transactions_ui_tag, transactions_pagination, route_url_name="iptv")    

}



//sum 

function sum_transactions(sum_col, where_str, push_to, callback_function_string="", num_form="yes",route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
           
    var req_url=route_url_name;

   get_transactions("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "","",req_url);

}


///request handlers 

  
  function conf_del_transactions_(transactions_data_key, after_delete="blackhole",  cancel_function="blackhole()", push_to="alert_box")
  {


    magic_yes_no_alert('Delete record?', push_to, 'transactions_rem_(\''+transactions_data_key+'\', \''+after_delete+'\')', cancel_function)

  }


function mosy_transactions_ins_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form",route_url_name="iptv")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
    magic_message("Processing", "dialog_box")

    var req_url=route_url_name;

   transactions_ins_(formid,"",response_fun,req_url)
 }
}

function mosy_transactions_updt_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form", route_url_name="iptv")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
   magic_message("Processing", "dialog_box")

   var req_url=route_url_name;

   transactions_updt_(formid,"",response_fun,req_url)
 }
}

function transactions_ins_(formid, required_inp=null, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }

    var req_url=route_url_name;

    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "transactions_insert_btn", callback_function_string_str, "", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function transactions_updt_(formid, required_inp, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);

     var req_url=route_url_name;
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "transactions_update_btn", callback_function_string_str,"", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function transactions_rem_(req_token, callback_function_string="",route_url_name="iptv")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

 var req_url=route_url_name;
 
 mosyajax_get('conf_deletetransactions&transactions_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str,req_url);

}


function grid_transactions_updt_(updt_key,colstr,newcolval, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 

 var req_url=route_url_name;

mosyajax_get("_grid_updt_="+btoa('transactions')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str,req_url);

}
  //============================================================ ++++ End transactions datahandler js =============================
   
   ///transactions data_nodes 
  var transactions_data_nodes ='{{row_count}}|{{primkey}}|{{trxkey}}|{{trx_id}}|{{trx_date}}|{{trx_month_year}}|{{trx_remark}}|{{amount}}|{{trx_type}}|{{business_id}}|{{client_id}}|{{admin_id}}|{{TransactionType}}|{{BusinessShortCode}}|{{BillRefNumber}}|{{InvoiceNumber}}|{{OrgAccountBalance}}|{{ThirdPartyTransID}}|{{MSISDN}}|{{FirstName}}|{{MiddleName}}|{{LastName}}|{{trx_msg}}|{{account_id}}|{{used_status}}|{{filter_date}}|{{flw_id}}|{{flag_state}}|{{reconciled}}|{{trx_timestamp}}|{{hive_site_id}}|{{hive_site_name}}';



   var transactions_list_cols ="primkey:primkey,trxkey:trxkey,trx_id:trx_id,trx_date:trx_date,trx_month_year:trx_month_year,trx_remark:trx_remark,amount:amount,trx_type:trx_type,business_id:business_id,client_id:client_id,admin_id:admin_id,TransactionType:TransactionType,BusinessShortCode:BusinessShortCode,BillRefNumber:BillRefNumber,InvoiceNumber:InvoiceNumber,OrgAccountBalance:OrgAccountBalance,ThirdPartyTransID:ThirdPartyTransID,MSISDN:MSISDN,FirstName:FirstName,MiddleName:MiddleName,LastName:LastName,trx_msg:trx_msg,account_id:account_id,used_status:used_status,filter_date:filter_date,flw_id:flw_id,flag_state:flag_state,reconciled:reconciled,trx_timestamp:trx_timestamp,hive_site_id:hive_site_id,hive_site_name:hive_site_name";

;
        
   ///start transactions search columns 
   
   var data_nodes_gft_transactions_str="(primkey LIKE '%{{qtransactions}}%' OR  trxkey LIKE '%{{qtransactions}}%' OR  trx_id LIKE '%{{qtransactions}}%' OR  trx_date LIKE '%{{qtransactions}}%' OR  trx_month_year LIKE '%{{qtransactions}}%' OR  trx_remark LIKE '%{{qtransactions}}%' OR  amount LIKE '%{{qtransactions}}%' OR  trx_type LIKE '%{{qtransactions}}%' OR  business_id LIKE '%{{qtransactions}}%' OR  client_id LIKE '%{{qtransactions}}%' OR  admin_id LIKE '%{{qtransactions}}%' OR  TransactionType LIKE '%{{qtransactions}}%' OR  BusinessShortCode LIKE '%{{qtransactions}}%' OR  BillRefNumber LIKE '%{{qtransactions}}%' OR  InvoiceNumber LIKE '%{{qtransactions}}%' OR  OrgAccountBalance LIKE '%{{qtransactions}}%' OR  ThirdPartyTransID LIKE '%{{qtransactions}}%' OR  MSISDN LIKE '%{{qtransactions}}%' OR  FirstName LIKE '%{{qtransactions}}%' OR  MiddleName LIKE '%{{qtransactions}}%' OR  LastName LIKE '%{{qtransactions}}%' OR  trx_msg LIKE '%{{qtransactions}}%' OR  account_id LIKE '%{{qtransactions}}%' OR  used_status LIKE '%{{qtransactions}}%' OR  filter_date LIKE '%{{qtransactions}}%' OR  flw_id LIKE '%{{qtransactions}}%' OR  flag_state LIKE '%{{qtransactions}}%' OR  reconciled LIKE '%{{qtransactions}}%' OR  trx_timestamp LIKE '%{{qtransactions}}%' OR  hive_site_id LIKE '%{{qtransactions}}%' OR  hive_site_name LIKE '%{{qtransactions}}%')";
    
    function  data_nodes_gft_transactions(qtransactions_str)
    {
        	var data_nodes_clean_transactions_filter_str=data_nodes_gft_transactions_str.replace(/{{qtransactions}}/g, magic_clean_str(qtransactions_str));
            
            return  data_nodes_clean_transactions_filter_str;

    }
       ///end transactions search columns 

  function mosy_transactions_ui_node (transactions_json_data, transactions_load_to, transactions_cols_, transactions_template_ui)
  {
     ////alert(transactions_template_ui);
     var transactions_cols_fun_cols_str ="";
     
     if(typeof transactions_cols_fun_cols !== "undefined")
      {
        transactions_cols_fun_cols_str=transactions_cols_fun_cols;
        
        ///alert(transactions_cols_fun_cols)
      } 
      
     var transactions_ui__ = mosy_list_render_(transactions_json_data, transactions_cols_fun_cols_str+transactions_cols_, transactions_template_ui) 

     ////push_html(transactions_load_to, transactions_ui__)  

     push_grid_result(transactions_ui__, transactions_load_to)
  }
  
 
 ///////
 
 var transactions_auto_function= '{"cbfun":"process_transactions_json_data","_data_isle":"transactions_data_isle","_pagination_isle":"transactions_pagination_isle","_data_template":"hive_transactions_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_transactions","req_url":"iptv"}';

 
 
 ///============ auto renders 
 
 
function mosy_transactions_json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", transactions_pagination_prefix_="__pgnt_transactions", colstr="*", req_url="iptv")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("transactions", btoa(qstr))
  }else{
    mosy_delete_get_pram("transactions")
  }
  
  if(mosy_get_param("transactions")!==undefined)
  {
    qstr=atob(mosy_get_param("transactions"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:transactions_page_no:"+mosy_limit;
  }
  
  ///hive_transactions_data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_transactions_json_data","_data_isle":"transactions_data_isle","_pagination_isle":"transactions_pagination_isle","_data_template":"hive_transactions_data_template","_payload_str":"req","_pagination_prefix":"'+transactions_pagination_prefix_+'","req_url":"'+req_url+'"}';
            
  }
  
  return mosyrender_transactions_(response_fun," where "+gft_transactions(qstr)+" "+and_query_str+"  order by primkey desc ",function_cols,colstr,pagination, transactions_pagination_prefix_,req_url)
  
}


  
  function autoprocess_transactions_json_data(transactions_server_resp)
  {  
    mosy_transactions_ui_node(transactions_server_resp, "transactions_data_isle", transactions_data_nodes, get_html(hive_transactions_data_template),"", "l:transactions_page_no:15")
    mosy_paginate_api(transactions_server_resp, "transactions_page_no", "transactions_pagination_isle", "15")
  }
  
  function process_transactions_json_data(transactions_server_resp, transactions_callback="")
  {  
      var transactions_data_isle="transactions_data_isle";
      var transactions_data_node_template="hive_transactions_data_template";
      var transactions_pagination_isle="transactions_pagination_isle";
      var transactions_payload_str="";
      var transactions__pagination_prefix_str="__pgnt_transactions";
      
       ///alert(transactions_callback)
       ///alert(transactions_server_resp)
       ///console.log(transactions_server_resp)
              
      try {
        
           const transactions_jsonObject = JSON.parse(transactions_callback);
        
           transactions_data_isle=transactions_jsonObject._data_isle;
           transactions_data_node_template=transactions_jsonObject._data_template;
           transactions_pagination_isle=transactions_jsonObject._pagination_isle;
           transactions_payload_str=transactions_jsonObject._payload_str;
           transactions__pagination_prefix_str=transactions_jsonObject._pagination_prefix;
           transactions__req_url=transactions_jsonObject.req_url;

           ///console.log("paginate == : valid JSON"+transactions_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+transactions_callback);
        
         if(transactions_callback.indexOf(",") >= 0)
         {
              transactions_data_handler_ui =transactions_callback.split(",");                                 

              if(transactions_data_handler_ui[0]!=undefined){ transactions_data_isle=transactions_data_handler_ui[0];}

              if(transactions_data_handler_ui[1]!=undefined){transactions_data_node_template =transactions_data_handler_ui[1];}

              if(transactions_data_handler_ui[2]!=undefined){ transactions_pagination_isle=transactions_data_handler_ui[2]};

              if(transactions_data_handler_ui[3]!=undefined){ transactions_payload_str=btoa(transactions_data_handler_ui[3])};
              
              if(transactions_data_handler_ui[4]!=undefined){ transactions__pagination_prefix_str=btoa(transactions_data_handler_ui[4])};

			  if(transactions_data_handler_ui[5]!=undefined){ transactions__req_url=transactions_data_handler_ui[5]};                            
              
         }       
        
      }

       ///alert(" dtisle == "+transactions_data_isle)
       
            mosy_transactions_ui_node(transactions_server_resp, transactions_data_isle, transactions_data_nodes, get_html(transactions_data_node_template),"", "l:transactions_page_no:"+mosy_limit)                       
            
             if(transactions_payload_str==="req")
             {
                
                mosy_paginate_api(transactions_server_resp, "transactions_page_no", transactions_pagination_isle, "process_transactions_json_data", transactions__pagination_prefix_str,transactions__req_url)

             }
           
  }
    

function mosyrender_transactions_(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_transactions", req_url="iptv")
{
   
  if(pagination==="")
  {
    pagination="l:transactions_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _transactions_payload="mosyget_&tbl=transactions&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_transactions_payload+curl_url)
  
  var _transactions_pagination_json = '{"_payload":"'+_transactions_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _transactions_payload_input = document.createElement("input");
                _transactions_payload_input.setAttribute('type', 'hidden');
                _transactions_payload_input.setAttribute('name',_txt_payload);
                _transactions_payload_input.setAttribute('id', _txt_payload);

                // Add the _transactions_payload_input element to the DOM
                document.body.appendChild(_transactions_payload_input);
                
      }
      
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
  push_newval(_txt_payload, _transactions_pagination_json)
  mosyajax_get(_transactions_payload, response_fun, req_url);
  
  return _transactions_payload;
  
}


function mginitialize_transactions(reqkey, response_fun="",req_url="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _transactions_payload="mosyget_&tbl=transactions&colstr="+btoa("*")+"&where_str="+btoa(" where primkey ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
     mosyajax_get(_transactions_payload, response_fun, req_url);


}

 

