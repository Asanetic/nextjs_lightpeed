//============================================================ ++++ start paybill_disbursments datahandler js =============================
   
    

    //Start get  paybill_disbursments Data ===============
    
      function get_paybill_disbursments(paybill_disbursments_colstr, paybill_disbursments_filter_col, paybill_disbursments_cols, paybill_disbursments_node_function_name, paybill_disbursments_callback_function_string, paybill_disbursments_ui_tag, paybill_disbursments_pagination, route_url_name="iptv")
      {        
        var req_url=route_url_name;

        mosyflex_sel("paybill_disbursments", paybill_disbursments_colstr, paybill_disbursments_filter_col , paybill_disbursments_cols, paybill_disbursments_node_function_name, paybill_disbursments_callback_function_string, paybill_disbursments_ui_tag, paybill_disbursments_pagination,req_url);
        
      }
    //End get  paybill_disbursments Data ===============

    //Start insert  paybill_disbursments Data ===============

	function add_paybill_disbursments(paybill_disbursments_cols, paybill_disbursments_vals, paybill_disbursments_callback_function_string)
    {
		
        mosyajax_create_data("paybill_disbursments", paybill_disbursments_cols, paybill_disbursments_vals, paybill_disbursments_callback_function_string);
     }
     
    //End insert  paybill_disbursments Data ===============

    
    //Start update  paybill_disbursments Data ===============

    function update_paybill_disbursments(paybill_disbursments_update_str, paybill_disbursments_where_str, paybill_disbursments_callback_function_string){
    
		mosyajax_update("paybill_disbursments", paybill_disbursments_update_str, paybill_disbursments_where_str, paybill_disbursments_callback_function_string)
    
    }
    //end  update  paybill_disbursments Data ===============

	//Start drop  paybill_disbursments Data ===============
    function paybill_disbursments_drop(paybill_disbursments_where_str, paybill_disbursments_callback_function_string)
    {
        mosyajax_drop("paybill_disbursments", paybill_disbursments_where_str, paybill_disbursments_callback_function_string)

    }
	//End drop  paybill_disbursments Data ===============
    
    function initialize_paybill_disbursments(qstr="", paybill_disbursments_callback_function_string="",route_url_name="iptv")
    {
    
    ///alert(qstr);
      var paybill_disbursments_token_query =qstr;
      if(qstr=="")
      {
       var paybill_disbursments_token_query_param="";
       var paybill_disbursments_js_uptoken=mosy_get_param("paybill_disbursments_uptoken");
       //alert(paybill_disbursments_js_uptoken);
       if(paybill_disbursments_js_uptoken!==undefined)
       {
       
        paybill_disbursments_token_query_param = atob(paybill_disbursments_js_uptoken);
       }
        paybill_disbursments_token_query = " where primkey='"+(paybill_disbursments_token_query_param)+"'";
        
           if (document.getElementById("paybill_disbursments_uptoken") !==null) {
           	if(document.getElementById("paybill_disbursments_uptoken").value!="")
            {
            
            var paybill_disbursments_atob_tbl_key =atob(document.getElementById("paybill_disbursments_uptoken").value);
            
                   
            paybill_disbursments_token_query = " where primkey='"+(paybill_disbursments_atob_tbl_key)+"'";

            }
           }
      }
      
      var paybill_disbursments_push_ui_data_to =paybill_disbursments_callback_function_string;
      if(paybill_disbursments_callback_function_string=="")
      {
      paybill_disbursments_push_ui_data_to = "add_paybill_disbursments_ui_data";
      }
                
      console.log(paybill_disbursments_token_query+" -- "+paybill_disbursments_js_uptoken);

	  //alert(paybill_disbursments_push_ui_data_to);

	 var req_url=route_url_name;

     get_paybill_disbursments("*", paybill_disbursments_token_query, "primkey", "blackhole", paybill_disbursments_push_ui_data_to, "", "", req_url);
     

    }
    
    function add_paybill_disbursments_ui_data(paybill_disbursments_server_resp) 
    {
    
    ///alert(paybill_disbursments_server_resp);
    
    var json_decoded_str=JSON.parse(paybill_disbursments_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          mosy_push_data_class("mosy_data_"+keys[i], val);
          
          // use val
      }
        
    }
    

    ///=============== load paybill_disbursments data on the fly ==============
    
	var gft_paybill_disbursments_str="(primkey LIKE '%{{qpaybill_disbursments}}%' OR  trxkey LIKE '%{{qpaybill_disbursments}}%' OR  trx_id LIKE '%{{qpaybill_disbursments}}%' OR  trx_date LIKE '%{{qpaybill_disbursments}}%' OR  trx_month_year LIKE '%{{qpaybill_disbursments}}%' OR  trx_remark LIKE '%{{qpaybill_disbursments}}%' OR  amount LIKE '%{{qpaybill_disbursments}}%' OR  trx_type LIKE '%{{qpaybill_disbursments}}%' OR  business_id LIKE '%{{qpaybill_disbursments}}%' OR  client_id LIKE '%{{qpaybill_disbursments}}%' OR  admin_id LIKE '%{{qpaybill_disbursments}}%' OR  TransactionType LIKE '%{{qpaybill_disbursments}}%' OR  BusinessShortCode LIKE '%{{qpaybill_disbursments}}%' OR  BillRefNumber LIKE '%{{qpaybill_disbursments}}%' OR  InvoiceNumber LIKE '%{{qpaybill_disbursments}}%' OR  OrgAccountBalance LIKE '%{{qpaybill_disbursments}}%' OR  ThirdPartyTransID LIKE '%{{qpaybill_disbursments}}%' OR  MSISDN LIKE '%{{qpaybill_disbursments}}%' OR  FirstName LIKE '%{{qpaybill_disbursments}}%' OR  MiddleName LIKE '%{{qpaybill_disbursments}}%' OR  LastName LIKE '%{{qpaybill_disbursments}}%' OR  trx_msg LIKE '%{{qpaybill_disbursments}}%' OR  account_id LIKE '%{{qpaybill_disbursments}}%' OR  used_status LIKE '%{{qpaybill_disbursments}}%' OR  filter_date LIKE '%{{qpaybill_disbursments}}%' OR  flw_id LIKE '%{{qpaybill_disbursments}}%' OR  flag_state LIKE '%{{qpaybill_disbursments}}%' OR  reconciled LIKE '%{{qpaybill_disbursments}}%' OR  trx_timestamp LIKE '%{{qpaybill_disbursments}}%' OR  hive_site_id LIKE '%{{qpaybill_disbursments}}%' OR  hive_site_name LIKE '%{{qpaybill_disbursments}}%')";
    
    function  gft_paybill_disbursments(qpaybill_disbursments_str)
    {
        	var clean_paybill_disbursments_filter_str=gft_paybill_disbursments_str.replace(/{{qpaybill_disbursments}}/g, magic_clean_str(qpaybill_disbursments_str));
            
            return  clean_paybill_disbursments_filter_str;

    }
    
    function load_paybill_disbursments(paybill_disbursments_qstr, paybill_disbursments_where_str, paybill_disbursments_ret_cols, paybill_disbursments_user_function, paybill_disbursments_result_function, paybill_disbursments_data_tray, route_url_name="iptv")
    {
    
    var fpaybill_disbursments_result_function="push_result";
      
    if(paybill_disbursments_result_function!="")
    {
          var fpaybill_disbursments_result_function=paybill_disbursments_result_function;

    }
    	var clean_paybill_disbursments_filter_str=gft_paybill_disbursments_str.replace(/{{qpaybill_disbursments}}/g, magic_clean_str(paybill_disbursments_qstr));
        
        var fpaybill_disbursments_where_str=" where "+clean_paybill_disbursments_filter_str;

    if(paybill_disbursments_where_str!="")
    {
          var fpaybill_disbursments_where_str=" "+paybill_disbursments_where_str;

    }

	  var req_url=route_url_name;

      get_paybill_disbursments("*", fpaybill_disbursments_where_str, paybill_disbursments_ret_cols, paybill_disbursments_user_function, fpaybill_disbursments_result_function, paybill_disbursments_data_tray,"",req_url);

  }
    ///=============== load paybill_disbursments data on the fly ==============


 ///=quick load 
 
function qkload_paybill_disbursments(qstr, push_fun="", ui_card="", and_query="", additional_cols="", paybill_disbursments_pagination="",route_url_name="iptv")
{


      paybill_disbursments_list_nodes_str=ui_card;
  
   
   var paybill_disbursments_qret_fun="push_grid_result:paybill_disbursments_tbl_list";
   
   if(push_fun!="")
   {
    paybill_disbursments_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }

   var req_url=route_url_name;

   get_paybill_disbursments("*", ajaxw+" ("+gft_paybill_disbursments(qstr)+") "+combined_query+"  order by primkey desc ", paybill_disbursments_list_cols+additional_cols_str, "",paybill_disbursments_qret_fun, "c=>"+paybill_disbursments_list_nodes_str, paybill_disbursments_pagination, req_url);
}


////////////// arithmetic function 


//count 

function count_paybill_disbursments(where_str, push_to, callback_function_string="", num_form="yes", route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }

   var req_url=route_url_name;

   get_paybill_disbursments("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "","",req_url);
   ///get_paybill_disbursments(paybill_disbursments_colstr, paybill_disbursments_filter_col, paybill_disbursments_cols, paybill_disbursments_node_function_name, paybill_disbursments_callback_function_string, paybill_disbursments_ui_tag, paybill_disbursments_pagination, route_url_name="iptv") 

}


//qddata
function qpaybill_disbursments_ddata(where_str, disp_col , push_to, callback_function_string="",route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }

   var req_url=route_url_name;

   get_paybill_disbursments("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "","",req_url);
   ///get_paybill_disbursments(paybill_disbursments_colstr, paybill_disbursments_filter_col, paybill_disbursments_cols, paybill_disbursments_node_function_name, paybill_disbursments_callback_function_string, paybill_disbursments_ui_tag, paybill_disbursments_pagination, route_url_name="iptv")    

}



//sum 

function sum_paybill_disbursments(sum_col, where_str, push_to, callback_function_string="", num_form="yes",route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
           
    var req_url=route_url_name;

   get_paybill_disbursments("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "","",req_url);

}


///request handlers 

  
  function conf_del_paybill_disbursments_(paybill_disbursments_data_key, after_delete="blackhole",  cancel_function="blackhole()", push_to="alert_box")
  {


    magic_yes_no_alert('Delete record?', push_to, 'paybill_disbursments_rem_(\''+paybill_disbursments_data_key+'\', \''+after_delete+'\')', cancel_function)

  }


function mosy_paybill_disbursments_ins_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form",route_url_name="iptv")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
    magic_message("Processing", "dialog_box")

    var req_url=route_url_name;

   paybill_disbursments_ins_(formid,"",response_fun,req_url)
 }
}

function mosy_paybill_disbursments_updt_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form", route_url_name="iptv")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
   magic_message("Processing", "dialog_box")

   var req_url=route_url_name;

   paybill_disbursments_updt_(formid,"",response_fun,req_url)
 }
}

function paybill_disbursments_ins_(formid, required_inp=null, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }

    var req_url=route_url_name;

    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "paybill_disbursments_insert_btn", callback_function_string_str, "", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function paybill_disbursments_updt_(formid, required_inp, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);

     var req_url=route_url_name;
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "paybill_disbursments_update_btn", callback_function_string_str,"", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function paybill_disbursments_rem_(req_token, callback_function_string="",route_url_name="iptv")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

 var req_url=route_url_name;
 
 mosyajax_get('conf_deletepaybill_disbursments&paybill_disbursments_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str,req_url);

}


function grid_paybill_disbursments_updt_(updt_key,colstr,newcolval, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 

 var req_url=route_url_name;

mosyajax_get("_grid_updt_="+btoa('paybill_disbursments')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str,req_url);

}
  //============================================================ ++++ End paybill_disbursments datahandler js =============================
   
   ///paybill_disbursments data_nodes 
  var paybill_disbursments_data_nodes ='{{row_count}}|{{primkey}}|{{trxkey}}|{{trx_id}}|{{trx_date}}|{{trx_month_year}}|{{trx_remark}}|{{amount}}|{{trx_type}}|{{business_id}}|{{client_id}}|{{admin_id}}|{{TransactionType}}|{{BusinessShortCode}}|{{BillRefNumber}}|{{InvoiceNumber}}|{{OrgAccountBalance}}|{{ThirdPartyTransID}}|{{MSISDN}}|{{FirstName}}|{{MiddleName}}|{{LastName}}|{{trx_msg}}|{{account_id}}|{{used_status}}|{{filter_date}}|{{flw_id}}|{{flag_state}}|{{reconciled}}|{{trx_timestamp}}|{{hive_site_id}}|{{hive_site_name}}';



   var paybill_disbursments_list_cols ="primkey:primkey,trxkey:trxkey,trx_id:trx_id,trx_date:trx_date,trx_month_year:trx_month_year,trx_remark:trx_remark,amount:amount,trx_type:trx_type,business_id:business_id,client_id:client_id,admin_id:admin_id,TransactionType:TransactionType,BusinessShortCode:BusinessShortCode,BillRefNumber:BillRefNumber,InvoiceNumber:InvoiceNumber,OrgAccountBalance:OrgAccountBalance,ThirdPartyTransID:ThirdPartyTransID,MSISDN:MSISDN,FirstName:FirstName,MiddleName:MiddleName,LastName:LastName,trx_msg:trx_msg,account_id:account_id,used_status:used_status,filter_date:filter_date,flw_id:flw_id,flag_state:flag_state,reconciled:reconciled,trx_timestamp:trx_timestamp,hive_site_id:hive_site_id,hive_site_name:hive_site_name";

;
        
   ///start paybill_disbursments search columns 
   
   var data_nodes_gft_paybill_disbursments_str="(primkey LIKE '%{{qpaybill_disbursments}}%' OR  trxkey LIKE '%{{qpaybill_disbursments}}%' OR  trx_id LIKE '%{{qpaybill_disbursments}}%' OR  trx_date LIKE '%{{qpaybill_disbursments}}%' OR  trx_month_year LIKE '%{{qpaybill_disbursments}}%' OR  trx_remark LIKE '%{{qpaybill_disbursments}}%' OR  amount LIKE '%{{qpaybill_disbursments}}%' OR  trx_type LIKE '%{{qpaybill_disbursments}}%' OR  business_id LIKE '%{{qpaybill_disbursments}}%' OR  client_id LIKE '%{{qpaybill_disbursments}}%' OR  admin_id LIKE '%{{qpaybill_disbursments}}%' OR  TransactionType LIKE '%{{qpaybill_disbursments}}%' OR  BusinessShortCode LIKE '%{{qpaybill_disbursments}}%' OR  BillRefNumber LIKE '%{{qpaybill_disbursments}}%' OR  InvoiceNumber LIKE '%{{qpaybill_disbursments}}%' OR  OrgAccountBalance LIKE '%{{qpaybill_disbursments}}%' OR  ThirdPartyTransID LIKE '%{{qpaybill_disbursments}}%' OR  MSISDN LIKE '%{{qpaybill_disbursments}}%' OR  FirstName LIKE '%{{qpaybill_disbursments}}%' OR  MiddleName LIKE '%{{qpaybill_disbursments}}%' OR  LastName LIKE '%{{qpaybill_disbursments}}%' OR  trx_msg LIKE '%{{qpaybill_disbursments}}%' OR  account_id LIKE '%{{qpaybill_disbursments}}%' OR  used_status LIKE '%{{qpaybill_disbursments}}%' OR  filter_date LIKE '%{{qpaybill_disbursments}}%' OR  flw_id LIKE '%{{qpaybill_disbursments}}%' OR  flag_state LIKE '%{{qpaybill_disbursments}}%' OR  reconciled LIKE '%{{qpaybill_disbursments}}%' OR  trx_timestamp LIKE '%{{qpaybill_disbursments}}%' OR  hive_site_id LIKE '%{{qpaybill_disbursments}}%' OR  hive_site_name LIKE '%{{qpaybill_disbursments}}%')";
    
    function  data_nodes_gft_paybill_disbursments(qpaybill_disbursments_str)
    {
        	var data_nodes_clean_paybill_disbursments_filter_str=data_nodes_gft_paybill_disbursments_str.replace(/{{qpaybill_disbursments}}/g, magic_clean_str(qpaybill_disbursments_str));
            
            return  data_nodes_clean_paybill_disbursments_filter_str;

    }
       ///end paybill_disbursments search columns 

  function mosy_paybill_disbursments_ui_node (paybill_disbursments_json_data, paybill_disbursments_load_to, paybill_disbursments_cols_, paybill_disbursments_template_ui)
  {
     ////alert(paybill_disbursments_template_ui);
     var paybill_disbursments_cols_fun_cols_str ="";
     
     if(typeof paybill_disbursments_cols_fun_cols !== "undefined")
      {
        paybill_disbursments_cols_fun_cols_str=paybill_disbursments_cols_fun_cols;
        
        ///alert(paybill_disbursments_cols_fun_cols)
      } 
      
     var paybill_disbursments_ui__ = mosy_list_render_(paybill_disbursments_json_data, paybill_disbursments_cols_fun_cols_str+paybill_disbursments_cols_, paybill_disbursments_template_ui) 

     ////push_html(paybill_disbursments_load_to, paybill_disbursments_ui__)  

     push_grid_result(paybill_disbursments_ui__, paybill_disbursments_load_to)
  }
  
 
 ///////
 
 var paybill_disbursments_auto_function= '{"cbfun":"process_paybill_disbursments_json_data","_data_isle":"paybill_disbursments_data_isle","_pagination_isle":"paybill_disbursments_pagination_isle","_data_template":"hive_paybill_disbursments_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_paybill_disbursments","req_url":"iptv"}';

 
 
 ///============ auto renders 
 
 
function mosy_paybill_disbursments_json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", paybill_disbursments_pagination_prefix_="__pgnt_paybill_disbursments", colstr="*", req_url="iptv")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("paybill_disbursments", btoa(qstr))
  }else{
    mosy_delete_get_pram("paybill_disbursments")
  }
  
  if(mosy_get_param("paybill_disbursments")!==undefined)
  {
    qstr=atob(mosy_get_param("paybill_disbursments"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:paybill_disbursments_page_no:"+mosy_limit;
  }
  
  ///hive_paybill_disbursments_data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_paybill_disbursments_json_data","_data_isle":"paybill_disbursments_data_isle","_pagination_isle":"paybill_disbursments_pagination_isle","_data_template":"hive_paybill_disbursments_data_template","_payload_str":"req","_pagination_prefix":"'+paybill_disbursments_pagination_prefix_+'","req_url":"'+req_url+'"}';
            
  }
  
  return mosyrender_paybill_disbursments_(response_fun," where "+gft_paybill_disbursments(qstr)+" "+and_query_str+"  order by primkey desc ",function_cols,colstr,pagination, paybill_disbursments_pagination_prefix_,req_url)
  
}


  
  function autoprocess_paybill_disbursments_json_data(paybill_disbursments_server_resp)
  {  
    mosy_paybill_disbursments_ui_node(paybill_disbursments_server_resp, "paybill_disbursments_data_isle", paybill_disbursments_data_nodes, get_html(hive_paybill_disbursments_data_template),"", "l:paybill_disbursments_page_no:15")
    mosy_paginate_api(paybill_disbursments_server_resp, "paybill_disbursments_page_no", "paybill_disbursments_pagination_isle", "15")
  }
  
  function process_paybill_disbursments_json_data(paybill_disbursments_server_resp, paybill_disbursments_callback="")
  {  
      var paybill_disbursments_data_isle="paybill_disbursments_data_isle";
      var paybill_disbursments_data_node_template="hive_paybill_disbursments_data_template";
      var paybill_disbursments_pagination_isle="paybill_disbursments_pagination_isle";
      var paybill_disbursments_payload_str="";
      var paybill_disbursments__pagination_prefix_str="__pgnt_paybill_disbursments";
      
       ///alert(paybill_disbursments_callback)
       ///alert(paybill_disbursments_server_resp)
       ///console.log(paybill_disbursments_server_resp)
              
      try {
        
           const paybill_disbursments_jsonObject = JSON.parse(paybill_disbursments_callback);
        
           paybill_disbursments_data_isle=paybill_disbursments_jsonObject._data_isle;
           paybill_disbursments_data_node_template=paybill_disbursments_jsonObject._data_template;
           paybill_disbursments_pagination_isle=paybill_disbursments_jsonObject._pagination_isle;
           paybill_disbursments_payload_str=paybill_disbursments_jsonObject._payload_str;
           paybill_disbursments__pagination_prefix_str=paybill_disbursments_jsonObject._pagination_prefix;
           paybill_disbursments__req_url=paybill_disbursments_jsonObject.req_url;

           ///console.log("paginate == : valid JSON"+paybill_disbursments_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+paybill_disbursments_callback);
        
         if(paybill_disbursments_callback.indexOf(",") >= 0)
         {
              paybill_disbursments_data_handler_ui =paybill_disbursments_callback.split(",");                                 

              if(paybill_disbursments_data_handler_ui[0]!=undefined){ paybill_disbursments_data_isle=paybill_disbursments_data_handler_ui[0];}

              if(paybill_disbursments_data_handler_ui[1]!=undefined){paybill_disbursments_data_node_template =paybill_disbursments_data_handler_ui[1];}

              if(paybill_disbursments_data_handler_ui[2]!=undefined){ paybill_disbursments_pagination_isle=paybill_disbursments_data_handler_ui[2]};

              if(paybill_disbursments_data_handler_ui[3]!=undefined){ paybill_disbursments_payload_str=btoa(paybill_disbursments_data_handler_ui[3])};
              
              if(paybill_disbursments_data_handler_ui[4]!=undefined){ paybill_disbursments__pagination_prefix_str=btoa(paybill_disbursments_data_handler_ui[4])};

			  if(paybill_disbursments_data_handler_ui[5]!=undefined){ paybill_disbursments__req_url=paybill_disbursments_data_handler_ui[5]};                            
              
         }       
        
      }

       ///alert(" dtisle == "+paybill_disbursments_data_isle)
       
            mosy_paybill_disbursments_ui_node(paybill_disbursments_server_resp, paybill_disbursments_data_isle, paybill_disbursments_data_nodes, get_html(paybill_disbursments_data_node_template),"", "l:paybill_disbursments_page_no:"+mosy_limit)                       
            
             if(paybill_disbursments_payload_str==="req")
             {
                
                mosy_paginate_api(paybill_disbursments_server_resp, "paybill_disbursments_page_no", paybill_disbursments_pagination_isle, "process_paybill_disbursments_json_data", paybill_disbursments__pagination_prefix_str,paybill_disbursments__req_url)

             }
           
  }
    

function mosyrender_paybill_disbursments_(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_paybill_disbursments", req_url="iptv")
{
   
  if(pagination==="")
  {
    pagination="l:paybill_disbursments_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _paybill_disbursments_payload="mosyget_&tbl=paybill_disbursments&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_paybill_disbursments_payload+curl_url)
  
  var _paybill_disbursments_pagination_json = '{"_payload":"'+_paybill_disbursments_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _paybill_disbursments_payload_input = document.createElement("input");
                _paybill_disbursments_payload_input.setAttribute('type', 'hidden');
                _paybill_disbursments_payload_input.setAttribute('name',_txt_payload);
                _paybill_disbursments_payload_input.setAttribute('id', _txt_payload);

                // Add the _paybill_disbursments_payload_input element to the DOM
                document.body.appendChild(_paybill_disbursments_payload_input);
                
      }
      
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
  push_newval(_txt_payload, _paybill_disbursments_pagination_json)
  mosyajax_get(_paybill_disbursments_payload, response_fun, req_url);
  
  return _paybill_disbursments_payload;
  
}


function mginitialize_paybill_disbursments(reqkey, response_fun="",req_url="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _paybill_disbursments_payload="mosyget_&tbl=paybill_disbursments&colstr="+btoa("*")+"&where_str="+btoa(" where primkey ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
     mosyajax_get(_paybill_disbursments_payload, response_fun, req_url);


}

 

