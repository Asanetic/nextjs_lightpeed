//============================================================ ++++ start payment_confirmations datahandler js =============================
   
    

    //Start get  payment_confirmations Data ===============
    
      function get_payment_confirmations(payment_confirmations_colstr, payment_confirmations_filter_col, payment_confirmations_cols, payment_confirmations_node_function_name, payment_confirmations_callback_function_string, payment_confirmations_ui_tag, payment_confirmations_pagination, route_url_name="iptv")
      {        
        var req_url=route_url_name;

        mosyflex_sel("payment_confirmations", payment_confirmations_colstr, payment_confirmations_filter_col , payment_confirmations_cols, payment_confirmations_node_function_name, payment_confirmations_callback_function_string, payment_confirmations_ui_tag, payment_confirmations_pagination,req_url);
        
      }
    //End get  payment_confirmations Data ===============

    //Start insert  payment_confirmations Data ===============

	function add_payment_confirmations(payment_confirmations_cols, payment_confirmations_vals, payment_confirmations_callback_function_string)
    {
		
        mosyajax_create_data("payment_confirmations", payment_confirmations_cols, payment_confirmations_vals, payment_confirmations_callback_function_string);
     }
     
    //End insert  payment_confirmations Data ===============

    
    //Start update  payment_confirmations Data ===============

    function update_payment_confirmations(payment_confirmations_update_str, payment_confirmations_where_str, payment_confirmations_callback_function_string){
    
		mosyajax_update("payment_confirmations", payment_confirmations_update_str, payment_confirmations_where_str, payment_confirmations_callback_function_string)
    
    }
    //end  update  payment_confirmations Data ===============

	//Start drop  payment_confirmations Data ===============
    function payment_confirmations_drop(payment_confirmations_where_str, payment_confirmations_callback_function_string)
    {
        mosyajax_drop("payment_confirmations", payment_confirmations_where_str, payment_confirmations_callback_function_string)

    }
	//End drop  payment_confirmations Data ===============
    
    function initialize_payment_confirmations(qstr="", payment_confirmations_callback_function_string="",route_url_name="iptv")
    {
    
    ///alert(qstr);
      var payment_confirmations_token_query =qstr;
      if(qstr=="")
      {
       var payment_confirmations_token_query_param="";
       var payment_confirmations_js_uptoken=mosy_get_param("payment_confirmations_uptoken");
       //alert(payment_confirmations_js_uptoken);
       if(payment_confirmations_js_uptoken!==undefined)
       {
       
        payment_confirmations_token_query_param = atob(payment_confirmations_js_uptoken);
       }
        payment_confirmations_token_query = " where primkey='"+(payment_confirmations_token_query_param)+"'";
        
           if (document.getElementById("payment_confirmations_uptoken") !==null) {
           	if(document.getElementById("payment_confirmations_uptoken").value!="")
            {
            
            var payment_confirmations_atob_tbl_key =atob(document.getElementById("payment_confirmations_uptoken").value);
            
                   
            payment_confirmations_token_query = " where primkey='"+(payment_confirmations_atob_tbl_key)+"'";

            }
           }
      }
      
      var payment_confirmations_push_ui_data_to =payment_confirmations_callback_function_string;
      if(payment_confirmations_callback_function_string=="")
      {
      payment_confirmations_push_ui_data_to = "add_payment_confirmations_ui_data";
      }
                
      console.log(payment_confirmations_token_query+" -- "+payment_confirmations_js_uptoken);

	  //alert(payment_confirmations_push_ui_data_to);

	 var req_url=route_url_name;

     get_payment_confirmations("*", payment_confirmations_token_query, "primkey", "blackhole", payment_confirmations_push_ui_data_to, "", "", req_url);
     

    }
    
    function add_payment_confirmations_ui_data(payment_confirmations_server_resp) 
    {
    
    ///alert(payment_confirmations_server_resp);
    
    var json_decoded_str=JSON.parse(payment_confirmations_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          mosy_push_data_class("mosy_data_"+keys[i], val);
          
          // use val
      }
        
    }
    

    ///=============== load payment_confirmations data on the fly ==============
    
	var gft_payment_confirmations_str="(primkey LIKE '%{{qpayment_confirmations}}%' OR  record_id LIKE '%{{qpayment_confirmations}}%' OR  result_type LIKE '%{{qpayment_confirmations}}%' OR  result_code LIKE '%{{qpayment_confirmations}}%' OR  result_desc LIKE '%{{qpayment_confirmations}}%' OR  originator_conversation_id LIKE '%{{qpayment_confirmations}}%' OR  conversation_id LIKE '%{{qpayment_confirmations}}%' OR  transaction_id LIKE '%{{qpayment_confirmations}}%' OR  transaction_amount LIKE '%{{qpayment_confirmations}}%' OR  transaction_receipt LIKE '%{{qpayment_confirmations}}%' OR  recipient_registered LIKE '%{{qpayment_confirmations}}%' OR  charges_paid_funds LIKE '%{{qpayment_confirmations}}%' OR  receiver_public_name LIKE '%{{qpayment_confirmations}}%' OR  transaction_date_time LIKE '%{{qpayment_confirmations}}%' OR  utility_funds LIKE '%{{qpayment_confirmations}}%' OR  working_funds LIKE '%{{qpayment_confirmations}}%' OR  queue_timeout_url LIKE '%{{qpayment_confirmations}}%' OR  created_at LIKE '%{{qpayment_confirmations}}%' OR  hive_site_id LIKE '%{{qpayment_confirmations}}%' OR  hive_site_name LIKE '%{{qpayment_confirmations}}%')";
    
    function  gft_payment_confirmations(qpayment_confirmations_str)
    {
        	var clean_payment_confirmations_filter_str=gft_payment_confirmations_str.replace(/{{qpayment_confirmations}}/g, magic_clean_str(qpayment_confirmations_str));
            
            return  clean_payment_confirmations_filter_str;

    }
    
    function load_payment_confirmations(payment_confirmations_qstr, payment_confirmations_where_str, payment_confirmations_ret_cols, payment_confirmations_user_function, payment_confirmations_result_function, payment_confirmations_data_tray, route_url_name="iptv")
    {
    
    var fpayment_confirmations_result_function="push_result";
      
    if(payment_confirmations_result_function!="")
    {
          var fpayment_confirmations_result_function=payment_confirmations_result_function;

    }
    	var clean_payment_confirmations_filter_str=gft_payment_confirmations_str.replace(/{{qpayment_confirmations}}/g, magic_clean_str(payment_confirmations_qstr));
        
        var fpayment_confirmations_where_str=" where "+clean_payment_confirmations_filter_str;

    if(payment_confirmations_where_str!="")
    {
          var fpayment_confirmations_where_str=" "+payment_confirmations_where_str;

    }

	  var req_url=route_url_name;

      get_payment_confirmations("*", fpayment_confirmations_where_str, payment_confirmations_ret_cols, payment_confirmations_user_function, fpayment_confirmations_result_function, payment_confirmations_data_tray,"",req_url);

  }
    ///=============== load payment_confirmations data on the fly ==============


 ///=quick load 
 
function qkload_payment_confirmations(qstr, push_fun="", ui_card="", and_query="", additional_cols="", payment_confirmations_pagination="",route_url_name="iptv")
{


      payment_confirmations_list_nodes_str=ui_card;
  
   
   var payment_confirmations_qret_fun="push_grid_result:payment_confirmations_tbl_list";
   
   if(push_fun!="")
   {
    payment_confirmations_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }

   var req_url=route_url_name;

   get_payment_confirmations("*", ajaxw+" ("+gft_payment_confirmations(qstr)+") "+combined_query+"  order by primkey desc ", payment_confirmations_list_cols+additional_cols_str, "",payment_confirmations_qret_fun, "c=>"+payment_confirmations_list_nodes_str, payment_confirmations_pagination, req_url);
}


////////////// arithmetic function 


//count 

function count_payment_confirmations(where_str, push_to, callback_function_string="", num_form="yes", route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }

   var req_url=route_url_name;

   get_payment_confirmations("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "","",req_url);
   ///get_payment_confirmations(payment_confirmations_colstr, payment_confirmations_filter_col, payment_confirmations_cols, payment_confirmations_node_function_name, payment_confirmations_callback_function_string, payment_confirmations_ui_tag, payment_confirmations_pagination, route_url_name="iptv") 

}


//qddata
function qpayment_confirmations_ddata(where_str, disp_col , push_to, callback_function_string="",route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }

   var req_url=route_url_name;

   get_payment_confirmations("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "","",req_url);
   ///get_payment_confirmations(payment_confirmations_colstr, payment_confirmations_filter_col, payment_confirmations_cols, payment_confirmations_node_function_name, payment_confirmations_callback_function_string, payment_confirmations_ui_tag, payment_confirmations_pagination, route_url_name="iptv")    

}



//sum 

function sum_payment_confirmations(sum_col, where_str, push_to, callback_function_string="", num_form="yes",route_url_name="iptv")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
           
    var req_url=route_url_name;

   get_payment_confirmations("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "","",req_url);

}


///request handlers 

  
  function conf_del_payment_confirmations_(payment_confirmations_data_key, after_delete="blackhole",  cancel_function="blackhole()", push_to="alert_box")
  {


    magic_yes_no_alert('Delete record?', push_to, 'payment_confirmations_rem_(\''+payment_confirmations_data_key+'\', \''+after_delete+'\')', cancel_function)

  }


function mosy_payment_confirmations_ins_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form",route_url_name="iptv")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
    magic_message("Processing", "dialog_box")

    var req_url=route_url_name;

   payment_confirmations_ins_(formid,"",response_fun,req_url)
 }
}

function mosy_payment_confirmations_updt_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form", route_url_name="iptv")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
   magic_message("Processing", "dialog_box")

   var req_url=route_url_name;

   payment_confirmations_updt_(formid,"",response_fun,req_url)
 }
}

function payment_confirmations_ins_(formid, required_inp=null, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }

    var req_url=route_url_name;

    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "payment_confirmations_insert_btn", callback_function_string_str, "", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function payment_confirmations_updt_(formid, required_inp, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);

     var req_url=route_url_name;
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "payment_confirmations_update_btn", callback_function_string_str,"", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function payment_confirmations_rem_(req_token, callback_function_string="",route_url_name="iptv")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

 var req_url=route_url_name;
 
 mosyajax_get('conf_deletepayment_confirmations&payment_confirmations_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str,req_url);

}


function grid_payment_confirmations_updt_(updt_key,colstr,newcolval, callback_function_string="",route_url_name="iptv")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 

 var req_url=route_url_name;

mosyajax_get("_grid_updt_="+btoa('payment_confirmations')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str,req_url);

}
  //============================================================ ++++ End payment_confirmations datahandler js =============================
   
   ///payment_confirmations data_nodes 
  var payment_confirmations_data_nodes ='{{row_count}}|{{primkey}}|{{record_id}}|{{result_type}}|{{result_code}}|{{result_desc}}|{{originator_conversation_id}}|{{conversation_id}}|{{transaction_id}}|{{transaction_amount}}|{{transaction_receipt}}|{{recipient_registered}}|{{charges_paid_funds}}|{{receiver_public_name}}|{{transaction_date_time}}|{{utility_funds}}|{{working_funds}}|{{queue_timeout_url}}|{{created_at}}|{{hive_site_id}}|{{hive_site_name}}';



   var payment_confirmations_list_cols ="primkey:primkey,record_id:record_id,result_type:result_type,result_code:result_code,result_desc:result_desc,originator_conversation_id:originator_conversation_id,conversation_id:conversation_id,transaction_id:transaction_id,transaction_amount:transaction_amount,transaction_receipt:transaction_receipt,recipient_registered:recipient_registered,charges_paid_funds:charges_paid_funds,receiver_public_name:receiver_public_name,transaction_date_time:transaction_date_time,utility_funds:utility_funds,working_funds:working_funds,queue_timeout_url:queue_timeout_url,created_at:created_at,hive_site_id:hive_site_id,hive_site_name:hive_site_name";

;
        
   ///start payment_confirmations search columns 
   
   var data_nodes_gft_payment_confirmations_str="(primkey LIKE '%{{qpayment_confirmations}}%' OR  record_id LIKE '%{{qpayment_confirmations}}%' OR  result_type LIKE '%{{qpayment_confirmations}}%' OR  result_code LIKE '%{{qpayment_confirmations}}%' OR  result_desc LIKE '%{{qpayment_confirmations}}%' OR  originator_conversation_id LIKE '%{{qpayment_confirmations}}%' OR  conversation_id LIKE '%{{qpayment_confirmations}}%' OR  transaction_id LIKE '%{{qpayment_confirmations}}%' OR  transaction_amount LIKE '%{{qpayment_confirmations}}%' OR  transaction_receipt LIKE '%{{qpayment_confirmations}}%' OR  recipient_registered LIKE '%{{qpayment_confirmations}}%' OR  charges_paid_funds LIKE '%{{qpayment_confirmations}}%' OR  receiver_public_name LIKE '%{{qpayment_confirmations}}%' OR  transaction_date_time LIKE '%{{qpayment_confirmations}}%' OR  utility_funds LIKE '%{{qpayment_confirmations}}%' OR  working_funds LIKE '%{{qpayment_confirmations}}%' OR  queue_timeout_url LIKE '%{{qpayment_confirmations}}%' OR  created_at LIKE '%{{qpayment_confirmations}}%' OR  hive_site_id LIKE '%{{qpayment_confirmations}}%' OR  hive_site_name LIKE '%{{qpayment_confirmations}}%')";
    
    function  data_nodes_gft_payment_confirmations(qpayment_confirmations_str)
    {
        	var data_nodes_clean_payment_confirmations_filter_str=data_nodes_gft_payment_confirmations_str.replace(/{{qpayment_confirmations}}/g, magic_clean_str(qpayment_confirmations_str));
            
            return  data_nodes_clean_payment_confirmations_filter_str;

    }
       ///end payment_confirmations search columns 

  function mosy_payment_confirmations_ui_node (payment_confirmations_json_data, payment_confirmations_load_to, payment_confirmations_cols_, payment_confirmations_template_ui)
  {
     ////alert(payment_confirmations_template_ui);
     var payment_confirmations_cols_fun_cols_str ="";
     
     if(typeof payment_confirmations_cols_fun_cols !== "undefined")
      {
        payment_confirmations_cols_fun_cols_str=payment_confirmations_cols_fun_cols;
        
        ///alert(payment_confirmations_cols_fun_cols)
      } 
      
     var payment_confirmations_ui__ = mosy_list_render_(payment_confirmations_json_data, payment_confirmations_cols_fun_cols_str+payment_confirmations_cols_, payment_confirmations_template_ui) 

     ////push_html(payment_confirmations_load_to, payment_confirmations_ui__)  

     push_grid_result(payment_confirmations_ui__, payment_confirmations_load_to)
  }
  
 
 ///////
 
 var payment_confirmations_auto_function= '{"cbfun":"process_payment_confirmations_json_data","_data_isle":"payment_confirmations_data_isle","_pagination_isle":"payment_confirmations_pagination_isle","_data_template":"hive_payment_confirmations_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_payment_confirmations","req_url":"iptv"}';

 
 
 ///============ auto renders 
 
 
function mosy_payment_confirmations_json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", payment_confirmations_pagination_prefix_="__pgnt_payment_confirmations", colstr="*", req_url="iptv")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("payment_confirmations", btoa(qstr))
  }else{
    mosy_delete_get_pram("payment_confirmations")
  }
  
  if(mosy_get_param("payment_confirmations")!==undefined)
  {
    qstr=atob(mosy_get_param("payment_confirmations"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:payment_confirmations_page_no:"+mosy_limit;
  }
  
  ///hive_payment_confirmations_data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_payment_confirmations_json_data","_data_isle":"payment_confirmations_data_isle","_pagination_isle":"payment_confirmations_pagination_isle","_data_template":"hive_payment_confirmations_data_template","_payload_str":"req","_pagination_prefix":"'+payment_confirmations_pagination_prefix_+'","req_url":"'+req_url+'"}';
            
  }
  
  return mosyrender_payment_confirmations_(response_fun," where "+gft_payment_confirmations(qstr)+" "+and_query_str+"  order by primkey desc ",function_cols,colstr,pagination, payment_confirmations_pagination_prefix_,req_url)
  
}


  
  function autoprocess_payment_confirmations_json_data(payment_confirmations_server_resp)
  {  
    mosy_payment_confirmations_ui_node(payment_confirmations_server_resp, "payment_confirmations_data_isle", payment_confirmations_data_nodes, get_html(hive_payment_confirmations_data_template),"", "l:payment_confirmations_page_no:15")
    mosy_paginate_api(payment_confirmations_server_resp, "payment_confirmations_page_no", "payment_confirmations_pagination_isle", "15")
  }
  
  function process_payment_confirmations_json_data(payment_confirmations_server_resp, payment_confirmations_callback="")
  {  
      var payment_confirmations_data_isle="payment_confirmations_data_isle";
      var payment_confirmations_data_node_template="hive_payment_confirmations_data_template";
      var payment_confirmations_pagination_isle="payment_confirmations_pagination_isle";
      var payment_confirmations_payload_str="";
      var payment_confirmations__pagination_prefix_str="__pgnt_payment_confirmations";
      
       ///alert(payment_confirmations_callback)
       ///alert(payment_confirmations_server_resp)
       ///console.log(payment_confirmations_server_resp)
              
      try {
        
           const payment_confirmations_jsonObject = JSON.parse(payment_confirmations_callback);
        
           payment_confirmations_data_isle=payment_confirmations_jsonObject._data_isle;
           payment_confirmations_data_node_template=payment_confirmations_jsonObject._data_template;
           payment_confirmations_pagination_isle=payment_confirmations_jsonObject._pagination_isle;
           payment_confirmations_payload_str=payment_confirmations_jsonObject._payload_str;
           payment_confirmations__pagination_prefix_str=payment_confirmations_jsonObject._pagination_prefix;
           payment_confirmations__req_url=payment_confirmations_jsonObject.req_url;

           ///console.log("paginate == : valid JSON"+payment_confirmations_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+payment_confirmations_callback);
        
         if(payment_confirmations_callback.indexOf(",") >= 0)
         {
              payment_confirmations_data_handler_ui =payment_confirmations_callback.split(",");                                 

              if(payment_confirmations_data_handler_ui[0]!=undefined){ payment_confirmations_data_isle=payment_confirmations_data_handler_ui[0];}

              if(payment_confirmations_data_handler_ui[1]!=undefined){payment_confirmations_data_node_template =payment_confirmations_data_handler_ui[1];}

              if(payment_confirmations_data_handler_ui[2]!=undefined){ payment_confirmations_pagination_isle=payment_confirmations_data_handler_ui[2]};

              if(payment_confirmations_data_handler_ui[3]!=undefined){ payment_confirmations_payload_str=btoa(payment_confirmations_data_handler_ui[3])};
              
              if(payment_confirmations_data_handler_ui[4]!=undefined){ payment_confirmations__pagination_prefix_str=btoa(payment_confirmations_data_handler_ui[4])};

			  if(payment_confirmations_data_handler_ui[5]!=undefined){ payment_confirmations__req_url=payment_confirmations_data_handler_ui[5]};                            
              
         }       
        
      }

       ///alert(" dtisle == "+payment_confirmations_data_isle)
       
            mosy_payment_confirmations_ui_node(payment_confirmations_server_resp, payment_confirmations_data_isle, payment_confirmations_data_nodes, get_html(payment_confirmations_data_node_template),"", "l:payment_confirmations_page_no:"+mosy_limit)                       
            
             if(payment_confirmations_payload_str==="req")
             {
                
                mosy_paginate_api(payment_confirmations_server_resp, "payment_confirmations_page_no", payment_confirmations_pagination_isle, "process_payment_confirmations_json_data", payment_confirmations__pagination_prefix_str,payment_confirmations__req_url)

             }
           
  }
    

function mosyrender_payment_confirmations_(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_payment_confirmations", req_url="iptv")
{
   
  if(pagination==="")
  {
    pagination="l:payment_confirmations_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _payment_confirmations_payload="mosyget_&tbl=payment_confirmations&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_payment_confirmations_payload+curl_url)
  
  var _payment_confirmations_pagination_json = '{"_payload":"'+_payment_confirmations_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _payment_confirmations_payload_input = document.createElement("input");
                _payment_confirmations_payload_input.setAttribute('type', 'hidden');
                _payment_confirmations_payload_input.setAttribute('name',_txt_payload);
                _payment_confirmations_payload_input.setAttribute('id', _txt_payload);

                // Add the _payment_confirmations_payload_input element to the DOM
                document.body.appendChild(_payment_confirmations_payload_input);
                
      }
      
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
  push_newval(_txt_payload, _payment_confirmations_pagination_json)
  mosyajax_get(_payment_confirmations_payload, response_fun, req_url);
  
  return _payment_confirmations_payload;
  
}


function mginitialize_payment_confirmations(reqkey, response_fun="",req_url="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _payment_confirmations_payload="mosyget_&tbl=payment_confirmations&colstr="+btoa("*")+"&where_str="+btoa(" where primkey ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
     mosyajax_get(_payment_confirmations_payload, response_fun, req_url);


}

 

