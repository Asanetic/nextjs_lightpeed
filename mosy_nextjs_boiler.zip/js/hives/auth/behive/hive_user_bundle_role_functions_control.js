//============================================================ ++++ start user_bundle_role_functions datahandler js =============================
   
    

    //Start get  user_bundle_role_functions Data ===============
    
      function get_user_bundle_role_functions(user_bundle_role_functions_colstr, user_bundle_role_functions_filter_col, user_bundle_role_functions_cols, user_bundle_role_functions_node_function_name, user_bundle_role_functions_callback_function_string, user_bundle_role_functions_ui_tag, user_bundle_role_functions_pagination, route_url_name="auth")
      {        
        var req_url=route_url_name;

        mosyflex_sel("user_bundle_role_functions", user_bundle_role_functions_colstr, user_bundle_role_functions_filter_col , user_bundle_role_functions_cols, user_bundle_role_functions_node_function_name, user_bundle_role_functions_callback_function_string, user_bundle_role_functions_ui_tag, user_bundle_role_functions_pagination,req_url);
        
      }
    //End get  user_bundle_role_functions Data ===============

    //Start insert  user_bundle_role_functions Data ===============

	function add_user_bundle_role_functions(user_bundle_role_functions_cols, user_bundle_role_functions_vals, user_bundle_role_functions_callback_function_string)
    {
		
        mosyajax_create_data("user_bundle_role_functions", user_bundle_role_functions_cols, user_bundle_role_functions_vals, user_bundle_role_functions_callback_function_string);
     }
     
    //End insert  user_bundle_role_functions Data ===============

    
    //Start update  user_bundle_role_functions Data ===============

    function update_user_bundle_role_functions(user_bundle_role_functions_update_str, user_bundle_role_functions_where_str, user_bundle_role_functions_callback_function_string){
    
		mosyajax_update("user_bundle_role_functions", user_bundle_role_functions_update_str, user_bundle_role_functions_where_str, user_bundle_role_functions_callback_function_string)
    
    }
    //end  update  user_bundle_role_functions Data ===============

	//Start drop  user_bundle_role_functions Data ===============
    function user_bundle_role_functions_drop(user_bundle_role_functions_where_str, user_bundle_role_functions_callback_function_string)
    {
        mosyajax_drop("user_bundle_role_functions", user_bundle_role_functions_where_str, user_bundle_role_functions_callback_function_string)

    }
	//End drop  user_bundle_role_functions Data ===============
    
    function initialize_user_bundle_role_functions(qstr="", user_bundle_role_functions_callback_function_string="",route_url_name="auth")
    {
    
    ///alert(qstr);
      var user_bundle_role_functions_token_query =qstr;
      if(qstr=="")
      {
       var user_bundle_role_functions_token_query_param="";
       var user_bundle_role_functions_js_uptoken=mosy_get_param("user_bundle_role_functions_uptoken");
       //alert(user_bundle_role_functions_js_uptoken);
       if(user_bundle_role_functions_js_uptoken!==undefined)
       {
       
        user_bundle_role_functions_token_query_param = atob(user_bundle_role_functions_js_uptoken);
       }
        user_bundle_role_functions_token_query = " where primkey='"+(user_bundle_role_functions_token_query_param)+"'";
        
           if (document.getElementById("user_bundle_role_functions_uptoken") !==null) {
           	if(document.getElementById("user_bundle_role_functions_uptoken").value!="")
            {
            
            var user_bundle_role_functions_atob_tbl_key =atob(document.getElementById("user_bundle_role_functions_uptoken").value);
            
                   
            user_bundle_role_functions_token_query = " where primkey='"+(user_bundle_role_functions_atob_tbl_key)+"'";

            }
           }
      }
      
      var user_bundle_role_functions_push_ui_data_to =user_bundle_role_functions_callback_function_string;
      if(user_bundle_role_functions_callback_function_string=="")
      {
      user_bundle_role_functions_push_ui_data_to = "add_user_bundle_role_functions_ui_data";
      }
                
      console.log(user_bundle_role_functions_token_query+" -- "+user_bundle_role_functions_js_uptoken);

	  //alert(user_bundle_role_functions_push_ui_data_to);

	 var req_url=route_url_name;

     get_user_bundle_role_functions("*", user_bundle_role_functions_token_query, "primkey", "blackhole", user_bundle_role_functions_push_ui_data_to, "", "", req_url);
     

    }
    
    function add_user_bundle_role_functions_ui_data(user_bundle_role_functions_server_resp) 
    {
    
    ///alert(user_bundle_role_functions_server_resp);
    
    var json_decoded_str=JSON.parse(user_bundle_role_functions_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          mosy_push_data_class("mosy_data_"+keys[i], val);
          
          // use val
      }
        
    }
    

    ///=============== load user_bundle_role_functions data on the fly ==============
    
	var gft_user_bundle_role_functions_str="(primkey LIKE '%{{quser_bundle_role_functions}}%' OR  record_id LIKE '%{{quser_bundle_role_functions}}%' OR  bundle_id LIKE '%{{quser_bundle_role_functions}}%' OR  bundle_name LIKE '%{{quser_bundle_role_functions}}%' OR  role_id LIKE '%{{quser_bundle_role_functions}}%' OR  role_name LIKE '%{{quser_bundle_role_functions}}%' OR  remark LIKE '%{{quser_bundle_role_functions}}%' OR  hive_site_id LIKE '%{{quser_bundle_role_functions}}%' OR  hive_site_name LIKE '%{{quser_bundle_role_functions}}%')";
    
    function  gft_user_bundle_role_functions(quser_bundle_role_functions_str)
    {
        	var clean_user_bundle_role_functions_filter_str=gft_user_bundle_role_functions_str.replace(/{{quser_bundle_role_functions}}/g, magic_clean_str(quser_bundle_role_functions_str));
            
            return  clean_user_bundle_role_functions_filter_str;

    }
    
    function load_user_bundle_role_functions(user_bundle_role_functions_qstr, user_bundle_role_functions_where_str, user_bundle_role_functions_ret_cols, user_bundle_role_functions_user_function, user_bundle_role_functions_result_function, user_bundle_role_functions_data_tray, route_url_name="auth")
    {
    
    var fuser_bundle_role_functions_result_function="push_result";
      
    if(user_bundle_role_functions_result_function!="")
    {
          var fuser_bundle_role_functions_result_function=user_bundle_role_functions_result_function;

    }
    	var clean_user_bundle_role_functions_filter_str=gft_user_bundle_role_functions_str.replace(/{{quser_bundle_role_functions}}/g, magic_clean_str(user_bundle_role_functions_qstr));
        
        var fuser_bundle_role_functions_where_str=" where "+clean_user_bundle_role_functions_filter_str;

    if(user_bundle_role_functions_where_str!="")
    {
          var fuser_bundle_role_functions_where_str=" "+user_bundle_role_functions_where_str;

    }

	  var req_url=route_url_name;

      get_user_bundle_role_functions("*", fuser_bundle_role_functions_where_str, user_bundle_role_functions_ret_cols, user_bundle_role_functions_user_function, fuser_bundle_role_functions_result_function, user_bundle_role_functions_data_tray,"",req_url);

  }
    ///=============== load user_bundle_role_functions data on the fly ==============


 ///=quick load 
 
function qkload_user_bundle_role_functions(qstr, push_fun="", ui_card="", and_query="", additional_cols="", user_bundle_role_functions_pagination="",route_url_name="auth")
{


      user_bundle_role_functions_list_nodes_str=ui_card;
  
   
   var user_bundle_role_functions_qret_fun="push_grid_result:user_bundle_role_functions_tbl_list";
   
   if(push_fun!="")
   {
    user_bundle_role_functions_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }

   var req_url=route_url_name;

   get_user_bundle_role_functions("*", ajaxw+" ("+gft_user_bundle_role_functions(qstr)+") "+combined_query+"  order by primkey desc ", user_bundle_role_functions_list_cols+additional_cols_str, "",user_bundle_role_functions_qret_fun, "c=>"+user_bundle_role_functions_list_nodes_str, user_bundle_role_functions_pagination, req_url);
}


////////////// arithmetic function 


//count 

function count_user_bundle_role_functions(where_str, push_to, callback_function_string="", num_form="yes", route_url_name="auth")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }

   var req_url=route_url_name;

   get_user_bundle_role_functions("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "","",req_url);
   ///get_user_bundle_role_functions(user_bundle_role_functions_colstr, user_bundle_role_functions_filter_col, user_bundle_role_functions_cols, user_bundle_role_functions_node_function_name, user_bundle_role_functions_callback_function_string, user_bundle_role_functions_ui_tag, user_bundle_role_functions_pagination, route_url_name="auth") 

}


//qddata
function quser_bundle_role_functions_ddata(where_str, disp_col , push_to, callback_function_string="",route_url_name="auth")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }

   var req_url=route_url_name;

   get_user_bundle_role_functions("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "","",req_url);
   ///get_user_bundle_role_functions(user_bundle_role_functions_colstr, user_bundle_role_functions_filter_col, user_bundle_role_functions_cols, user_bundle_role_functions_node_function_name, user_bundle_role_functions_callback_function_string, user_bundle_role_functions_ui_tag, user_bundle_role_functions_pagination, route_url_name="auth")    

}



//sum 

function sum_user_bundle_role_functions(sum_col, where_str, push_to, callback_function_string="", num_form="yes",route_url_name="auth")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_ddata";

        }
      
      }
           
    var req_url=route_url_name;

   get_user_bundle_role_functions("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "","",req_url);

}


///request handlers 

  
  function conf_del_user_bundle_role_functions_(user_bundle_role_functions_data_key, after_delete="blackhole",  cancel_function="blackhole()", push_to="alert_box")
  {


    magic_yes_no_alert('Delete record?', push_to, 'user_bundle_role_functions_rem_(\''+user_bundle_role_functions_data_key+'\', \''+after_delete+'\')', cancel_function)

  }


function mosy_user_bundle_role_functions_ins_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form",route_url_name="auth")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
    magic_message("Processing", "dialog_box")

    var req_url=route_url_name;

   user_bundle_role_functions_ins_(formid,"",response_fun,req_url)
 }
}

function mosy_user_bundle_role_functions_updt_fun(response_fun="blackhole", required_container="mosy_form", formid="mosy_form", route_url_name="auth")
{
 if(mosy_required_form_inputs(required_container)==1)
 {
   magic_message("Processing", "dialog_box")

   var req_url=route_url_name;

   user_bundle_role_functions_updt_(formid,"",response_fun,req_url)
 }
}

function user_bundle_role_functions_ins_(formid, required_inp=null, callback_function_string="",route_url_name="auth")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }

    var req_url=route_url_name;

    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "user_bundle_role_functions_insert_btn", callback_function_string_str, "", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
}

function user_bundle_role_functions_updt_(formid, required_inp, callback_function_string="",route_url_name="auth")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    var validate_msg="Kindly fill out the required fields<br> ";
    
  for(curr_input of required_inp)
    {
          
       if(curr_input.indexOf(":") >= 0)
  	   {
            input_id_explode=curr_input.split(":");
         
   	     validate_req +=magic_validate_required(input_id_explode[1], input_id_explode[0]);
             
         if(document.getElementById(input_id_explode[0]).value=="")
         {
		 	validate_msg+="<b class=validate_error_class> * "+input_id_explode[1]+'</b><br>';
         }
       
       }else{

		validate_req +=magic_validate_required('', curr_input);

       }
    }
    
    //alert(validate_req);

     var req_url=route_url_name;
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "user_bundle_role_functions_update_btn", callback_function_string_str,"", required_inp, req_url);
        
  	  }else{
        magic_message(validate_msg, 'dialog_box');
      }
      

}


function user_bundle_role_functions_rem_(req_token, callback_function_string="",route_url_name="auth")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

 var req_url=route_url_name;
 
 mosyajax_get('conf_deleteuser_bundle_role_functions&user_bundle_role_functions_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str,req_url);

}


function grid_user_bundle_role_functions_updt_(updt_key,colstr,newcolval, callback_function_string="",route_url_name="auth")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 

 var req_url=route_url_name;

mosyajax_get("_grid_updt_="+btoa('user_bundle_role_functions')+"&updt_key="+btoa(updt_key)+"&colstr="+btoa(colstr)+"&newcolval="+btoa(newcolval)+"&editor="+btoa('primkey')+"", callback_function_string_str,req_url);

}
  //============================================================ ++++ End user_bundle_role_functions datahandler js =============================
   
   ///user_bundle_role_functions data_nodes 
  var user_bundle_role_functions_data_nodes ='{{row_count}}|{{primkey}}|{{record_id}}|{{bundle_id}}|{{bundle_name}}|{{role_id}}|{{role_name}}|{{remark}}|{{hive_site_id}}|{{hive_site_name}}';



   var user_bundle_role_functions_list_cols ="primkey:primkey,record_id:record_id,bundle_id:bundle_id,bundle_name:bundle_name,role_id:role_id,role_name:role_name,remark:remark,hive_site_id:hive_site_id,hive_site_name:hive_site_name";

;
        
   ///start user_bundle_role_functions search columns 
   
   var data_nodes_gft_user_bundle_role_functions_str="(primkey LIKE '%{{quser_bundle_role_functions}}%' OR  record_id LIKE '%{{quser_bundle_role_functions}}%' OR  bundle_id LIKE '%{{quser_bundle_role_functions}}%' OR  bundle_name LIKE '%{{quser_bundle_role_functions}}%' OR  role_id LIKE '%{{quser_bundle_role_functions}}%' OR  role_name LIKE '%{{quser_bundle_role_functions}}%' OR  remark LIKE '%{{quser_bundle_role_functions}}%' OR  hive_site_id LIKE '%{{quser_bundle_role_functions}}%' OR  hive_site_name LIKE '%{{quser_bundle_role_functions}}%')";
    
    function  data_nodes_gft_user_bundle_role_functions(quser_bundle_role_functions_str)
    {
        	var data_nodes_clean_user_bundle_role_functions_filter_str=data_nodes_gft_user_bundle_role_functions_str.replace(/{{quser_bundle_role_functions}}/g, magic_clean_str(quser_bundle_role_functions_str));
            
            return  data_nodes_clean_user_bundle_role_functions_filter_str;

    }
       ///end user_bundle_role_functions search columns 

  function mosy_user_bundle_role_functions_ui_node (user_bundle_role_functions_json_data, user_bundle_role_functions_load_to, user_bundle_role_functions_cols_, user_bundle_role_functions_template_ui)
  {
     ////alert(user_bundle_role_functions_template_ui);
     var user_bundle_role_functions_cols_fun_cols_str ="";
     
     if(typeof user_bundle_role_functions_cols_fun_cols !== "undefined")
      {
        user_bundle_role_functions_cols_fun_cols_str=user_bundle_role_functions_cols_fun_cols;
        
        ///alert(user_bundle_role_functions_cols_fun_cols)
      } 
      
     var user_bundle_role_functions_ui__ = mosy_list_render_(user_bundle_role_functions_json_data, user_bundle_role_functions_cols_fun_cols_str+user_bundle_role_functions_cols_, user_bundle_role_functions_template_ui) 

     ////push_html(user_bundle_role_functions_load_to, user_bundle_role_functions_ui__)  

     push_grid_result(user_bundle_role_functions_ui__, user_bundle_role_functions_load_to)
  }
  
 
 ///////
 
 var user_bundle_role_functions_auto_function= '{"cbfun":"process_user_bundle_role_functions_json_data","_data_isle":"user_bundle_role_functions_data_isle","_pagination_isle":"user_bundle_role_functions_pagination_isle","_data_template":"hive_user_bundle_role_functions_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_user_bundle_role_functions","req_url":"auth"}';

 
 
 ///============ auto renders 
 
 
function mosy_user_bundle_role_functions_json_data_list(qstr="", response_fun="", and_query="", function_cols="", pagination="", user_bundle_role_functions_pagination_prefix_="__pgnt_user_bundle_role_functions", colstr="*", req_url="auth")
{
  
  /*if(qstr!="")
  {
   mosy_update_get_param("user_bundle_role_functions", btoa(qstr))
  }else{
    mosy_delete_get_pram("user_bundle_role_functions")
  }
  
  if(mosy_get_param("user_bundle_role_functions")!==undefined)
  {
    qstr=atob(mosy_get_param("user_bundle_role_functions"))
  }
  */ 
  var and_query_str="";
  
  if(and_query!="")
  {
    and_query_str=" and "+and_query;   
  }
  
  if(pagination==="")
  {
    pagination="l:user_bundle_role_functions_page_no:"+mosy_limit;
  }
  
  ///hive_user_bundle_role_functions_data_template

  
  if(response_fun=="")
  {
      		response_fun='{"cbfun":"process_user_bundle_role_functions_json_data","_data_isle":"user_bundle_role_functions_data_isle","_pagination_isle":"user_bundle_role_functions_pagination_isle","_data_template":"hive_user_bundle_role_functions_data_template","_payload_str":"req","_pagination_prefix":"'+user_bundle_role_functions_pagination_prefix_+'","req_url":"'+req_url+'"}';
            
  }
  
  return mosyrender_user_bundle_role_functions_(response_fun," where "+gft_user_bundle_role_functions(qstr)+" "+and_query_str+"  order by primkey desc ",function_cols,colstr,pagination, user_bundle_role_functions_pagination_prefix_,req_url)
  
}


  
  function autoprocess_user_bundle_role_functions_json_data(user_bundle_role_functions_server_resp)
  {  
    mosy_user_bundle_role_functions_ui_node(user_bundle_role_functions_server_resp, "user_bundle_role_functions_data_isle", user_bundle_role_functions_data_nodes, get_html(hive_user_bundle_role_functions_data_template),"", "l:user_bundle_role_functions_page_no:15")
    mosy_paginate_api(user_bundle_role_functions_server_resp, "user_bundle_role_functions_page_no", "user_bundle_role_functions_pagination_isle", "15")
  }
  
  function process_user_bundle_role_functions_json_data(user_bundle_role_functions_server_resp, user_bundle_role_functions_callback="")
  {  
      var user_bundle_role_functions_data_isle="user_bundle_role_functions_data_isle";
      var user_bundle_role_functions_data_node_template="hive_user_bundle_role_functions_data_template";
      var user_bundle_role_functions_pagination_isle="user_bundle_role_functions_pagination_isle";
      var user_bundle_role_functions_payload_str="";
      var user_bundle_role_functions__pagination_prefix_str="__pgnt_user_bundle_role_functions";
      
       ///alert(user_bundle_role_functions_callback)
       ///alert(user_bundle_role_functions_server_resp)
       ///console.log(user_bundle_role_functions_server_resp)
              
      try {
        
           const user_bundle_role_functions_jsonObject = JSON.parse(user_bundle_role_functions_callback);
        
           user_bundle_role_functions_data_isle=user_bundle_role_functions_jsonObject._data_isle;
           user_bundle_role_functions_data_node_template=user_bundle_role_functions_jsonObject._data_template;
           user_bundle_role_functions_pagination_isle=user_bundle_role_functions_jsonObject._pagination_isle;
           user_bundle_role_functions_payload_str=user_bundle_role_functions_jsonObject._payload_str;
           user_bundle_role_functions__pagination_prefix_str=user_bundle_role_functions_jsonObject._pagination_prefix;
           user_bundle_role_functions__req_url=user_bundle_role_functions_jsonObject.req_url;

           ///console.log("paginate == : valid JSON"+user_bundle_role_functions_callback);
        
      } catch (error) {
      
        ///console.error("Invalid JSON:", error);
        ///console.log("paginate == : invalid"+user_bundle_role_functions_callback);
        
         if(user_bundle_role_functions_callback.indexOf(",") >= 0)
         {
              user_bundle_role_functions_data_handler_ui =user_bundle_role_functions_callback.split(",");                                 

              if(user_bundle_role_functions_data_handler_ui[0]!=undefined){ user_bundle_role_functions_data_isle=user_bundle_role_functions_data_handler_ui[0];}

              if(user_bundle_role_functions_data_handler_ui[1]!=undefined){user_bundle_role_functions_data_node_template =user_bundle_role_functions_data_handler_ui[1];}

              if(user_bundle_role_functions_data_handler_ui[2]!=undefined){ user_bundle_role_functions_pagination_isle=user_bundle_role_functions_data_handler_ui[2]};

              if(user_bundle_role_functions_data_handler_ui[3]!=undefined){ user_bundle_role_functions_payload_str=btoa(user_bundle_role_functions_data_handler_ui[3])};
              
              if(user_bundle_role_functions_data_handler_ui[4]!=undefined){ user_bundle_role_functions__pagination_prefix_str=btoa(user_bundle_role_functions_data_handler_ui[4])};

			  if(user_bundle_role_functions_data_handler_ui[5]!=undefined){ user_bundle_role_functions__req_url=user_bundle_role_functions_data_handler_ui[5]};                            
              
         }       
        
      }

       ///alert(" dtisle == "+user_bundle_role_functions_data_isle)
       
            mosy_user_bundle_role_functions_ui_node(user_bundle_role_functions_server_resp, user_bundle_role_functions_data_isle, user_bundle_role_functions_data_nodes, get_html(user_bundle_role_functions_data_node_template),"", "l:user_bundle_role_functions_page_no:"+mosy_limit)                       
            
             if(user_bundle_role_functions_payload_str==="req")
             {
                
                mosy_paginate_api(user_bundle_role_functions_server_resp, "user_bundle_role_functions_page_no", user_bundle_role_functions_pagination_isle, "process_user_bundle_role_functions_json_data", user_bundle_role_functions__pagination_prefix_str,user_bundle_role_functions__req_url)

             }
           
  }
    

function mosyrender_user_bundle_role_functions_(response_fun="",where_str="",function_cols="", colstr="*", pagination="", _txt_payload="__pgnt_user_bundle_role_functions", req_url="auth")
{
   
  if(pagination==="")
  {
    pagination="l:user_bundle_role_functions_page_no:"+mosy_limit;
  }

  var pagination_label="pagination_label";
  
  if(pagination.indexOf(":") >= 0)
  {
   
   pagination_label=pagination.split(":")[1];
  
  }

  var requested_page_label="";
  
  if(mosy_get_param(pagination_label)!==undefined)
  {
   requested_page_label=mosy_get_param(pagination_label);
  }
      
  var _user_bundle_role_functions_payload="mosyget_&tbl=user_bundle_role_functions&colstr="+btoa(colstr)+"&where_str="+btoa(where_str)+"&pagination="+pagination+"&function_cols="+btoa(function_cols)+"&"+pagination_label+"="+requested_page_label;

  //console.log(_user_bundle_role_functions_payload+curl_url)
  
  var _user_bundle_role_functions_pagination_json = '{"_payload":"'+_user_bundle_role_functions_payload+'", "pagination_label":"'+pagination_label+'", "response_attr":'+response_fun+'}';
  
       if (document.getElementById(_txt_payload) ===null) 
       {
                  const _user_bundle_role_functions_payload_input = document.createElement("input");
                _user_bundle_role_functions_payload_input.setAttribute('type', 'hidden');
                _user_bundle_role_functions_payload_input.setAttribute('name',_txt_payload);
                _user_bundle_role_functions_payload_input.setAttribute('id', _txt_payload);

                // Add the _user_bundle_role_functions_payload_input element to the DOM
                document.body.appendChild(_user_bundle_role_functions_payload_input);
                
      }
      
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
  push_newval(_txt_payload, _user_bundle_role_functions_pagination_json)
  mosyajax_get(_user_bundle_role_functions_payload, response_fun, req_url);
  
  return _user_bundle_role_functions_payload;
  
}


function mginitialize_user_bundle_role_functions(reqkey, response_fun="",req_url="")
{
  
    
     if(response_fun=="")
     {
       response_fun="mosy_ui_data_nodes";
     }
     
     ////alert(response_fun)
     var _user_bundle_role_functions_payload="mosyget_&tbl=user_bundle_role_functions&colstr="+btoa("*")+"&where_str="+btoa(" where primkey ='"+reqkey+"' ")+"&pagination=l&function_cols=";
   
      if(req_url=="")
      {
      	req_url=curl_url
      }
      
     mosyajax_get(_user_bundle_role_functions_payload, response_fun, req_url);


}

 

