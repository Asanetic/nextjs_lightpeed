
   const hive_mosy_sql_roll_back_ins_btn = document.querySelectorAll(".hive_mosy_sql_roll_back_ins_btn");
        hive_mosy_sql_roll_back_ins_btn.forEach(mosy_sql_roll_back_ins_btn => {
          mosy_sql_roll_back_ins_btn.addEventListener("click", event => {
          
          mosy_mosy_sql_roll_back_ins_fun()
          
          });
        });
        
        
   const hive_mosy_sql_roll_back_updt_btn = document.querySelectorAll(".hive_mosy_sql_roll_back_updt_btn");
        hive_mosy_sql_roll_back_updt_btn.forEach(mosy_sql_roll_back_updt_btn => {
          mosy_sql_roll_back_updt_btn.addEventListener("click", event => {
          
          mosy_mosy_sql_roll_back_updt_fun()
          
          });
        });

	  //// ================== cc view data nodes template =============
      ////var mosy_sql_roll_back_data_template=get_html("mosy_sql_roll_back_tbl_nodes");
	  //// ================== cc view data nodes template =============

      function loop_mosy_sql_roll_back_ui_data(qstr="",callback="", andquery="", _mosy_sql_roll_back_auto_function="")
      {      
        
        
         /// ==============mosy_sql_roll_back custom js auto response function  ================
    var custom_mosy_sql_roll_back_auto_function= '{"cbfun":"process_mosy_sql_roll_back_json_data","_data_isle":"mosy_sql_roll_back_data_isle:7","_pagination_isle":"mosy_sql_roll_back_pagination_isle","_data_template":"hive_mosy_sql_roll_back_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_mosy_sql_roll_back"}';
    
/// ==============mosy_sql_roll_back custom js auto response function  ================
   
    
      if(_mosy_sql_roll_back_auto_function!="")
      {
      	custom_mosy_sql_roll_back_auto_function = _mosy_sql_roll_back_auto_function
      }
    	
    
       if(callback!="")
       {
         qstr="";
         magic_message(callback, "dialog_box")
       }
       
       mosy_mosy_sql_roll_back_json_data_list(qstr, custom_mosy_sql_roll_back_auto_function, andquery);
       
       var and_count ="";
       if(andquery!="")
       {
          and_count=" and "+andquery
       }
        
      }
      

//== custom component mosy_sql_roll_back JS functions


