
   const hive_user_manifest__ins_btn = document.querySelectorAll(".hive_user_manifest__ins_btn");
        hive_user_manifest__ins_btn.forEach(user_manifest__ins_btn => {
          user_manifest__ins_btn.addEventListener("click", event => {
          
          mosy_user_manifest__ins_fun()
          
          });
        });
        
        
   const hive_user_manifest__updt_btn = document.querySelectorAll(".hive_user_manifest__updt_btn");
        hive_user_manifest__updt_btn.forEach(user_manifest__updt_btn => {
          user_manifest__updt_btn.addEventListener("click", event => {
          
          mosy_user_manifest__updt_fun()
          
          });
        });

	  //// ================== cc view data nodes template =============
      ////var user_manifest__data_template=get_html("user_manifest__tbl_nodes");
	  //// ================== cc view data nodes template =============

      function loop_user_manifest__ui_data(qstr="",callback="", andquery="", _user_manifest__auto_function="")
      {      
        
        
         /// ==============user_manifest_ custom js auto response function  ================
    var custom_user_manifest__auto_function= '{"cbfun":"process_user_manifest__json_data","_data_isle":"user_manifest__data_isle:11","_pagination_isle":"user_manifest__pagination_isle","_data_template":"hive_user_manifest__data_template","_payload_str":"req","_pagination_prefix":"__pgnt_user_manifest_"}';
    
/// ==============user_manifest_ custom js auto response function  ================
   
    
      if(_user_manifest__auto_function!="")
      {
      	custom_user_manifest__auto_function = _user_manifest__auto_function
      }
    	
    
       if(callback!="")
       {
         qstr="";
         magic_message(callback, "dialog_box")
       }
       
       mosy_user_manifest__json_data_list(qstr, custom_user_manifest__auto_function, andquery);
       
       var and_count ="";
       if(andquery!="")
       {
          and_count=" and "+andquery
       }
        
      }
      

//== custom component user_manifest_ JS functions


