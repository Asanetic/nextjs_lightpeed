
   const hive_page_manifest__ins_btn = document.querySelectorAll(".hive_page_manifest__ins_btn");
        hive_page_manifest__ins_btn.forEach(page_manifest__ins_btn => {
          page_manifest__ins_btn.addEventListener("click", event => {
          
          mosy_page_manifest__ins_fun()
          
          });
        });
        
        
   const hive_page_manifest__updt_btn = document.querySelectorAll(".hive_page_manifest__updt_btn");
        hive_page_manifest__updt_btn.forEach(page_manifest__updt_btn => {
          page_manifest__updt_btn.addEventListener("click", event => {
          
          mosy_page_manifest__updt_fun()
          
          });
        });

	  //// ================== cc view data nodes template =============
      ////var page_manifest__data_template=get_html("page_manifest__tbl_nodes");
	  //// ================== cc view data nodes template =============

      function loop_page_manifest__ui_data(qstr="",callback="", andquery="", _page_manifest__auto_function="")
      {      
        
        
         /// ==============page_manifest_ custom js auto response function  ================
    var custom_page_manifest__auto_function= '{"cbfun":"process_page_manifest__json_data","_data_isle":"page_manifest__data_isle:9","_pagination_isle":"page_manifest__pagination_isle","_data_template":"hive_page_manifest__data_template","_payload_str":"req","_pagination_prefix":"__pgnt_page_manifest_"}';
    
/// ==============page_manifest_ custom js auto response function  ================
   
    
      if(_page_manifest__auto_function!="")
      {
      	custom_page_manifest__auto_function = _page_manifest__auto_function
      }
    	
    
       if(callback!="")
       {
         qstr="";
         magic_message(callback, "dialog_box")
       }
       
       mosy_page_manifest__json_data_list(qstr, custom_page_manifest__auto_function, andquery);
       
       var and_count ="";
       if(andquery!="")
       {
          and_count=" and "+andquery
       }
        
      }
      

//== custom component page_manifest_ JS functions


