
   const hive_mosycomms_array_ins_btn = document.querySelectorAll(".hive_mosycomms_array_ins_btn");
        hive_mosycomms_array_ins_btn.forEach(mosycomms_array_ins_btn => {
          mosycomms_array_ins_btn.addEventListener("click", event => {
          
          mosy_mosycomms_array_ins_fun()
          
          });
        });
        
        
   const hive_mosycomms_array_updt_btn = document.querySelectorAll(".hive_mosycomms_array_updt_btn");
        hive_mosycomms_array_updt_btn.forEach(mosycomms_array_updt_btn => {
          mosycomms_array_updt_btn.addEventListener("click", event => {
          
          mosy_mosycomms_array_updt_fun()
          
          });
        });

	  //// ================== cc view data nodes template =============
      ////var mosycomms_array_data_template=get_html("mosycomms_array_tbl_nodes");
	  //// ================== cc view data nodes template =============

      function loop_mosycomms_array_ui_data(qstr="",callback="", andquery="", _mosycomms_array_auto_function="")
      {      
        
        
         /// ==============mosycomms_array custom js auto response function  ================
    var custom_mosycomms_array_auto_function= '{"cbfun":"process_mosycomms_array_json_data","_data_isle":"mosycomms_array_data_isle:19","_pagination_isle":"mosycomms_array_pagination_isle","_data_template":"hive_mosycomms_array_data_template","_payload_str":"req","_pagination_prefix":"__pgnt_mosycomms_array"}';
    
/// ==============mosycomms_array custom js auto response function  ================
   
    
      if(_mosycomms_array_auto_function!="")
      {
      	custom_mosycomms_array_auto_function = _mosycomms_array_auto_function
      }
    	
    
       if(callback!="")
       {
         qstr="";
         magic_message(callback, "dialog_box")
       }
       
       mosy_mosycomms_array_json_data_list(qstr, custom_mosycomms_array_auto_function, andquery);
       
       var and_count ="";
       if(andquery!="")
       {
          and_count=" and "+andquery
       }
        
      }
      