                        
                      var hive_user_bundle_role_functions_data_template = 
                      `<!--- user_bundle_role_functions data nodes -->
                        <div id="user_bundle_role_functions_tbl_nodes">
                         <tr class="cpointer mosy_msdn " data-mosy_msdn="push_newval('user_bundle_role_functions_uptoken',btoa('{{primkey}}'));mginitialize_user_bundle_role_functions('{{primkey}}');">
                           <td scope="col" ><b class="">{{row_count}}</b></td>
                          
                          							<td>{{bundle_id}}</td>
							<td>{{bundle_name}}</td>
							<td>{{role_id}}</td>
							<td>{{role_name}}</td>
							<td>{{remark}}</td>
							<td>{{hive_site_id}}</td>
							<td>{{hive_site_name}}</td>
    
                        </tr>
                        </div>`
                        
                     var hive_user_bundle_role_functions_head_template = 
                      `<!--- user_bundle_role_functions data head -->
                         <tr class="cpointer mosy_msdn ">
                           <td scope="col" ><b class="">#</b></td>
                           
                              
                          							<th>BUNDLE ID</th>
							<th>BUNDLE NAME</th>
							<th>ROLE ID</th>
							<th>ROLE NAME</th>
							<th>REMARK</th>
							<th>HIVE SITE ID</th>
							<th>HIVE SITE NAME</th>
    
                        </tr>`                                              
                        
              var hive_cv_user_bundle_role_functions_search_input=` 
             <div class="col-md-12 m-0 p-0 ">
                     <input type="text" class="col-md-4 mb-2 ml-2 bg-transparent"  placeholder="Search user bundle role functions " name="qtxt_user_bundle_role_functions" id="qtxt_user_bundle_role_functions" style="color:#000; border:none; border-bottom:1px solid #000;"/>
                     <button type="button" data-mosy_msdn="loop_user_bundle_role_functions_ui_data(get_newval('qtxt_user_bundle_role_functions'))" class="badge border-0 mr-2 mb-2 badge-primary p-2 shadow-sm btn_neoo2 mosy_msdn" name="quser_bundle_role_functions_btn" id="quser_bundle_role_functions_btn"><i class="fa fa-search"></i> Go </button>
                     <button type="button" class="badge badge-primary btn_neoo2 p-2 ml-2 mb-3 mosy_msdn " data-mosy_msdn="loop_user_bundle_role_functions_ui_data()" ><i class="fa fa-refresh"></i> Refresh </button>                    
              </div>`;
