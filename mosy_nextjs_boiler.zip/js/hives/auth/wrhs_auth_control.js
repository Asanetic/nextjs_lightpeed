
   
   
     /***************************************** global data warehouse for mosy_sql_roll_back ***********************************/
   var wh_mosy_sql_roll_back_list_cols ="primkey:primkey,roll_bk_key:roll_bk_key,table_name:table_name,roll_type:roll_type,where_str:where_str,roll_timestamp:roll_timestamp,value_entries:value_entries";
        
   ///start mosy_sql_roll_back search columns 
   
   var wh_gft_mosy_sql_roll_back_str="(primkey LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_bk_key LIKE '%{{qmosy_sql_roll_back}}%' OR  table_name LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_type LIKE '%{{qmosy_sql_roll_back}}%' OR  where_str LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_timestamp LIKE '%{{qmosy_sql_roll_back}}%' OR  value_entries LIKE '%{{qmosy_sql_roll_back}}%')";
   
   
   ///mosy_sql_roll_back data_nodes 
  var wh_mosy_sql_roll_back_data_nodes ="{{row_count}}|{{primkey}}|{{roll_bk_key}}|{{table_name}}|{{roll_type}}|{{where_str}}|{{roll_timestamp}}|{{value_entries}}"
   
   
   
   
     /***************************************** global data warehouse for mosycomms_array ***********************************/
   var wh_mosycomms_array_list_cols ="primkey:primkey,messageid:messageid,receiver_contacts:receiver_contacts,reciver_names:reciver_names,message_type:message_type,site_id:site_id,group_name:group_name,message_date:message_date,sent_state:sent_state,msg_read_state:msg_read_state,subject:subject,message_label:message_label,message:message,delvery_receipt:delvery_receipt,mosycomms_dictionary:mosycomms_dictionary,sms_cost:sms_cost,page_count:page_count,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start mosycomms_array search columns 
   
   var wh_gft_mosycomms_array_str="(primkey LIKE '%{{qmosycomms_array}}%' OR  messageid LIKE '%{{qmosycomms_array}}%' OR  receiver_contacts LIKE '%{{qmosycomms_array}}%' OR  reciver_names LIKE '%{{qmosycomms_array}}%' OR  message_type LIKE '%{{qmosycomms_array}}%' OR  site_id LIKE '%{{qmosycomms_array}}%' OR  group_name LIKE '%{{qmosycomms_array}}%' OR  message_date LIKE '%{{qmosycomms_array}}%' OR  sent_state LIKE '%{{qmosycomms_array}}%' OR  msg_read_state LIKE '%{{qmosycomms_array}}%' OR  subject LIKE '%{{qmosycomms_array}}%' OR  message_label LIKE '%{{qmosycomms_array}}%' OR  message LIKE '%{{qmosycomms_array}}%' OR  delvery_receipt LIKE '%{{qmosycomms_array}}%' OR  mosycomms_dictionary LIKE '%{{qmosycomms_array}}%' OR  sms_cost LIKE '%{{qmosycomms_array}}%' OR  page_count LIKE '%{{qmosycomms_array}}%' OR  hive_site_id LIKE '%{{qmosycomms_array}}%' OR  hive_site_name LIKE '%{{qmosycomms_array}}%')";
   
   
   ///mosycomms_array data_nodes 
  var wh_mosycomms_array_data_nodes ="{{row_count}}|{{primkey}}|{{messageid}}|{{receiver_contacts}}|{{reciver_names}}|{{message_type}}|{{site_id}}|{{group_name}}|{{message_date}}|{{sent_state}}|{{msg_read_state}}|{{subject}}|{{message_label}}|{{message}}|{{delvery_receipt}}|{{mosycomms_dictionary}}|{{sms_cost}}|{{page_count}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for mosycomms_settings ***********************************/
   var wh_mosycomms_settings_list_cols ="primkey:primkey,record_id:record_id,company_name:company_name,company_email:company_email,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start mosycomms_settings search columns 
   
   var wh_gft_mosycomms_settings_str="(primkey LIKE '%{{qmosycomms_settings}}%' OR  record_id LIKE '%{{qmosycomms_settings}}%' OR  company_name LIKE '%{{qmosycomms_settings}}%' OR  company_email LIKE '%{{qmosycomms_settings}}%' OR  hive_site_id LIKE '%{{qmosycomms_settings}}%' OR  hive_site_name LIKE '%{{qmosycomms_settings}}%')";
   
   
   ///mosycomms_settings data_nodes 
  var wh_mosycomms_settings_data_nodes ="{{row_count}}|{{primkey}}|{{record_id}}|{{company_name}}|{{company_email}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for page_manifest_ ***********************************/
   var wh_page_manifest__list_cols ="primkey:primkey,manikey:manikey,page_group:page_group,site_id:site_id,page_url:page_url,hive_site_id:hive_site_id,hive_site_name:hive_site_name,project_id:project_id,project_name:project_name";
        
   ///start page_manifest_ search columns 
   
   var wh_gft_page_manifest__str="(primkey LIKE '%{{qpage_manifest_}}%' OR  manikey LIKE '%{{qpage_manifest_}}%' OR  page_group LIKE '%{{qpage_manifest_}}%' OR  site_id LIKE '%{{qpage_manifest_}}%' OR  page_url LIKE '%{{qpage_manifest_}}%' OR  hive_site_id LIKE '%{{qpage_manifest_}}%' OR  hive_site_name LIKE '%{{qpage_manifest_}}%' OR  project_id LIKE '%{{qpage_manifest_}}%' OR  project_name LIKE '%{{qpage_manifest_}}%')";
   
   
   ///page_manifest_ data_nodes 
  var wh_page_manifest__data_nodes ="{{row_count}}|{{primkey}}|{{manikey}}|{{page_group}}|{{site_id}}|{{page_url}}|{{hive_site_id}}|{{hive_site_name}}|{{project_id}}|{{project_name}}"
   
   
   
   
     /***************************************** global data warehouse for system_role_bundles ***********************************/
   var wh_system_role_bundles_list_cols ="primkey:primkey,record_id:record_id,bundle_id:bundle_id,bundle_name:bundle_name,remark:remark,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start system_role_bundles search columns 
   
   var wh_gft_system_role_bundles_str="(primkey LIKE '%{{qsystem_role_bundles}}%' OR  record_id LIKE '%{{qsystem_role_bundles}}%' OR  bundle_id LIKE '%{{qsystem_role_bundles}}%' OR  bundle_name LIKE '%{{qsystem_role_bundles}}%' OR  remark LIKE '%{{qsystem_role_bundles}}%' OR  hive_site_id LIKE '%{{qsystem_role_bundles}}%' OR  hive_site_name LIKE '%{{qsystem_role_bundles}}%')";
   
   
   ///system_role_bundles data_nodes 
  var wh_system_role_bundles_data_nodes ="{{row_count}}|{{primkey}}|{{record_id}}|{{bundle_id}}|{{bundle_name}}|{{remark}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for system_users ***********************************/
   var wh_system_users_list_cols ="login_password:login_password,primkey:primkey,user_id:user_id,name:name,email:email,tel:tel,ref_id:ref_id,regdate:regdate,user_no:user_no,user_pic:user_pic,user_gender:user_gender,last_seen:last_seen,about:about,hive_site_id:hive_site_id,hive_site_name:hive_site_name,auth_token:auth_token,token_status:token_status,token_expiring_in:token_expiring_in,project_id:project_id,project_name:project_name";
        
   ///start system_users search columns 
   
   var wh_gft_system_users_str="(login_password LIKE '%{{qsystem_users}}%' OR  primkey LIKE '%{{qsystem_users}}%' OR  user_id LIKE '%{{qsystem_users}}%' OR  name LIKE '%{{qsystem_users}}%' OR  email LIKE '%{{qsystem_users}}%' OR  tel LIKE '%{{qsystem_users}}%' OR  ref_id LIKE '%{{qsystem_users}}%' OR  regdate LIKE '%{{qsystem_users}}%' OR  user_no LIKE '%{{qsystem_users}}%' OR  user_pic LIKE '%{{qsystem_users}}%' OR  user_gender LIKE '%{{qsystem_users}}%' OR  last_seen LIKE '%{{qsystem_users}}%' OR  about LIKE '%{{qsystem_users}}%' OR  hive_site_id LIKE '%{{qsystem_users}}%' OR  hive_site_name LIKE '%{{qsystem_users}}%' OR  auth_token LIKE '%{{qsystem_users}}%' OR  token_status LIKE '%{{qsystem_users}}%' OR  token_expiring_in LIKE '%{{qsystem_users}}%' OR  project_id LIKE '%{{qsystem_users}}%' OR  project_name LIKE '%{{qsystem_users}}%')";
   
   
   ///system_users data_nodes 
  var wh_system_users_data_nodes ="{{row_count}}|{{login_password}}|{{primkey}}|{{user_id}}|{{name}}|{{email}}|{{tel}}|{{ref_id}}|{{regdate}}|{{user_no}}|{{user_pic}}|{{user_gender}}|{{last_seen}}|{{about}}|{{hive_site_id}}|{{hive_site_name}}|{{auth_token}}|{{token_status}}|{{token_expiring_in}}|{{project_id}}|{{project_name}}"
   
   
   
   
     /***************************************** global data warehouse for user_bundle_role_functions ***********************************/
   var wh_user_bundle_role_functions_list_cols ="primkey:primkey,record_id:record_id,bundle_id:bundle_id,bundle_name:bundle_name,role_id:role_id,role_name:role_name,remark:remark,hive_site_id:hive_site_id,hive_site_name:hive_site_name";
        
   ///start user_bundle_role_functions search columns 
   
   var wh_gft_user_bundle_role_functions_str="(primkey LIKE '%{{quser_bundle_role_functions}}%' OR  record_id LIKE '%{{quser_bundle_role_functions}}%' OR  bundle_id LIKE '%{{quser_bundle_role_functions}}%' OR  bundle_name LIKE '%{{quser_bundle_role_functions}}%' OR  role_id LIKE '%{{quser_bundle_role_functions}}%' OR  role_name LIKE '%{{quser_bundle_role_functions}}%' OR  remark LIKE '%{{quser_bundle_role_functions}}%' OR  hive_site_id LIKE '%{{quser_bundle_role_functions}}%' OR  hive_site_name LIKE '%{{quser_bundle_role_functions}}%')";
   
   
   ///user_bundle_role_functions data_nodes 
  var wh_user_bundle_role_functions_data_nodes ="{{row_count}}|{{primkey}}|{{record_id}}|{{bundle_id}}|{{bundle_name}}|{{role_id}}|{{role_name}}|{{remark}}|{{hive_site_id}}|{{hive_site_name}}"
   
   
   
   
     /***************************************** global data warehouse for user_manifest_ ***********************************/
   var wh_user_manifest__list_cols ="primkey:primkey,admin_mkey:admin_mkey,user_id:user_id,user_name:user_name,role_id:role_id,site_id:site_id,role_name:role_name,hive_site_id:hive_site_id,hive_site_name:hive_site_name,project_id:project_id,project_name:project_name";
        
   ///start user_manifest_ search columns 
   
   var wh_gft_user_manifest__str="(primkey LIKE '%{{quser_manifest_}}%' OR  admin_mkey LIKE '%{{quser_manifest_}}%' OR  user_id LIKE '%{{quser_manifest_}}%' OR  user_name LIKE '%{{quser_manifest_}}%' OR  role_id LIKE '%{{quser_manifest_}}%' OR  site_id LIKE '%{{quser_manifest_}}%' OR  role_name LIKE '%{{quser_manifest_}}%' OR  hive_site_id LIKE '%{{quser_manifest_}}%' OR  hive_site_name LIKE '%{{quser_manifest_}}%' OR  project_id LIKE '%{{quser_manifest_}}%' OR  project_name LIKE '%{{quser_manifest_}}%')";
   
   
   ///user_manifest_ data_nodes 
  var wh_user_manifest__data_nodes ="{{row_count}}|{{primkey}}|{{admin_mkey}}|{{user_id}}|{{user_name}}|{{role_id}}|{{site_id}}|{{role_name}}|{{hive_site_id}}|{{hive_site_name}}|{{project_id}}|{{project_name}}"
   
   