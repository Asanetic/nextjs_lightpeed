'use client';
import React from 'react';
import Link from 'next/link';
import Image from 'next/image';

function getGreeting() {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 18) return 'Good afternoon';
  return 'Good evening';
}

export default function NavSidebar({
  username = 'John Doe',
  appName = 'MosyApp',
  appLogo = '/img/sampleimg1.jpg',
  appLogoStyle = '',
  indexPage = '/',
  commonRoot = '',
  navRoutes = {
    sedco: '/sedco',
    auth: '/auth'
  }
}) {
  const userAvatar = `${commonRoot}/img/useravatar.png`;
  const userRole = 'User';
  const notificationCount = 0;

  return (
    <>
      <div className="header">
        <div className="header-left">
          <a className="mobile_btn" id="mobile_btn">
            <i className="fa fa-bars" />
          </a>
          <a href="javascript:void(0);" id="toggle_btn">
            <i className="fe fe-text-align-left" />
          </a>
          <Link href={indexPage} className="logo logo-small text-dark" style={{ marginLeft: '-100px' }}>
            <Image src={appLogo} alt="Logo" width={30} height={30} />
            <span className="bold h5">{appName}</span>
          </Link>
        </div>

        <div className="top-nav-search pt-2">
          <Link href={indexPage} className="logo text-dark">
            <Image src={appLogo} alt="Logo" style={appLogoStyle ? JSON.parse(appLogoStyle) : {}} width={30} height={30} />
            <span className="bold h5">{appName}</span>
          </Link>
        </div>

        <ul className="nav user-menu">
          <li className="nav-item dropdown noti-dropdown d-none">
            <a href="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown">
              <i className="fa fa-bell text-success" /> <span className="badge badge-pill text-white">{notificationCount}</span>
            </a>
            <div className="dropdown-menu notifications">
              <div className="topnav-dropdown-header">
                <span className="notification-title">Notifications</span>
              </div>
              <div className="noti-content">
                <ul className="notification-list">
                  {/* Notifications injected dynamically via JS/JSX */}
                </ul>
              </div>
              <div className="topnav-dropdown-footer">
                <Link href="/mosy_notific">View all Notifications</Link>
              </div>
            </div>
          </li>

          <li className="nav-item dropdown has-arrow">
            <a href="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown">
              <span className="text-primary mr-2">
                {getGreeting()} {username.split(' ')[0]}
              </span>
              <span className="user-img">
                <Image className="rounded-circle" src={userAvatar} onError={(e) => { e.target.src = `${commonRoot}/img/useravatar.png`; }} width={31} height={31} alt="Avatar" />
              </span>
            </a>
            <div className="dropdown-menu">
              <div className="user-header">
                <div className="avatar avatar-sm">
                  <Image src={userAvatar} alt="User Image" className="avatar-img rounded-circle" width={40} height={40} />
                </div>
                <div className="user-text">
                  <h6>{username}</h6>
                  <p className="text-muted mb-0">{userRole}</p>
                </div>
              </div>
              <a className="dropdown-item d-none" href="/adminaccount">My Profile</a>
              <a className="dropdown-item d-none" href="/adminaccount">Account Settings</a>
              <Link className="dropdown-item" href={`${commonRoot}/auth/sauth_sessionlogout`}>Logout</Link>
            </div>
          </li>
        </ul>
      </div>

      <div className="sidebar" id="sidebar">
        <div className="sidebar-inner slimscroll">
          <div id="sidebar-menu" className="sidebar-menu">
            <ul>
              <li className="menu-title"> </li>
              <li><Link href={indexPage}><i className="fe fe-home" /> <span>Dashboard</span></Link></li>
              <li><Link href={`${navRoutes.sedco}/members_profile`}><i className="fa fa-user-plus" /> <span>Register member</span></Link></li>
              <li><Link href={`${navRoutes.sedco}/members_list`}><i className="fa fa-users" /> <span>Members list</span></Link></li>
              <li><Link href={`${navRoutes.sedco}/member_deposits_list`}><i className="fa fa-dollar" /> <span>Deposits</span></Link></li>
              <li><Link href={`${navRoutes.sedco}/daily_interest_list`}><i className="fa fa-gift" /> <span>Daily Interest</span></Link></li>
              <li><Link href={`${navRoutes.sedco}/withdrawal_requests_list`}><i className="fa fa-credit-card" /> <span>Withdrawals</span></Link></li>
              <li><Link href={`${navRoutes.sedco}/payment_modes_list`}><i className="fa fa-gear" /> <span>System settings</span></Link></li>
              <li><Link href={`${navRoutes.auth}/system_users_list`}><i className="fa fa-shield" /> <span>System users</span></Link></li>
            </ul>
          </div>
        </div>
      </div>
    </>
  );
}
