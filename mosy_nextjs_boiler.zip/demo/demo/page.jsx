'use client';

import React from 'react';

export default function DashboardPage() {
  const mosy_page_title = "Dashboard";

  return (
    <form method="post" encType="multipart/form-data" id="mosy_form">
      <div className="main-wrapper">
        <div className="page-wrapper">
          <div className="content container-fluid">
            <div className="page-header p-0 m-0">
              <div className="row m-0 p-0 col-md-12">
                <div className="col-md-12 p-0 m-0">
                  <h3 className="page-title">{mosy_page_title}</h3>
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col-sm-12">
                <div className="col-md-12 p-3">
                  {/* Start body content */}

                  {/* End body content */}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </form>
  );
}
