'use client'; // Only needed if you use interactive logic

import React from 'react';

function LoginBox(props) {
  const loginBgImg = props.loginBgImg;
  const appLogo = props.appLogo;
  const appName = props.appName;
  const showResetLink = props.showResetLink || false;
  const changePasswordUrl = props.changePasswordUrl || '#';
  const showCreateAccount = props.showCreateAccount || false;
  const registerUrl = props.registerUrl || '#';

  return (
    <div
      className="row justify-content-center m-0 p-0 col-md-12 bg_w_img"
      style={{ backgroundImage: `url('${loginBgImg}')` }}
    >
      <div className="col-md-5 m-0 p-0">
        <div className="main-wrapper login-body">
          <div className="login-wrapper">
            <div className="container m-0 p-1 p-lg-0">
              <div className="loginbox bg-white">
                <div className="login-right">
                  <div className="login-right-wrap">
                    <div className="col-md-12 py-3 text-center">
                      <img src={appLogo} alt="App Logo" style={{ width: '100px' }} />
                    </div>

                    <h1 className="col-md-12 mb-3">Welcome to {appName}</h1>
                    <p className="account-subtitle">Login to proceed</p>

                    <form method="post">
                      <div className="form-group">
                        <label>Username</label>
                        <input
                          className="form-control"
                          required
                          id="txt_username"
                          name="txt_username"
                          placeholder="Enter your username"
                          type="text"
                        />
                      </div>
                      <div className="form-group">
                        <label>Password</label>
                        <input
                          className="form-control"
                          required
                          id="txt_password"
                          name="txt_password"
                          placeholder="Enter password"
                          type="password"
                        />
                      </div>
                      <div className="form-group">
                        <button className="btn btn-primary btn-block" name="btn_login" type="submit">
                          Login
                        </button>
                      </div>
                    </form>

                    {showResetLink && (
                      <div className="text-center">
                        <a href={changePasswordUrl}>Reset Password</a>
                      </div>
                    )}

                    {showCreateAccount && (
                      <div className="text-center pt-4 text-dark">
                        <a href={registerUrl} className="text-dark">
                          <b>New Here? Join {appName}</b>
                        </a>
                      </div>
                    )}

                    <div className="col-md-12 pt-3 p-0" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LoginBox;
