<!doctype html>

<title>CodeMirror: Tornado template mode</title>
<meta charset="utf-8"/>
<link rel=stylesheet href="../../doc/docs.css">

<link rel="stylesheet" href="../../lib/codemirror.css">
<script src="../../lib/codemirror.js"></script>
<script src="../../addon/mode/overlay.js"></script>
<script src="../xml/xml.js"></script>
<script src="../htmlmixed/htmlmixed.js"></script>
<script src="tornado.js"></script>
<style>.CodeMirror {border-top: 1px solid black; border-bottom: 1px solid black;}</style>
<div id=nav>
  <a href="https://codemirror.net"><h1>CodeMirror</h1><img id=logo src="../../doc/logo.png" alt=""></a>

  <ul>
    <li><a href="../../index.php">Home</a>
    <li><a href="../../doc/manual.php">Manual</a>
    <li><a href="https://github.com/marijnh/codemirror">Code</a>
  </ul>
  <ul>
    <li><a href="../index.php">Language modes</a>
    <li><a class=active href="#">Tornado</a>
  </ul>
</div>

<article>
<h2>Tornado template mode</h2>
<form><textarea id="code" name="code">
<!doctype html>
<html>
    <head>
        <title>My Tornado web application</title>
    </head>
    <body>
        <h1>
            {{ title }}
        </h1>
        <ul class="my-list">
            {% for item in items %}
                <li>{% item.name %}</li>
            {% empty %}
                <li>You have no items in your list.</li>
            {% end %}
        </ul>
    </body>
</html>
</textarea></form>

    <script>
      var editor = CodeMirror.fromTextArea(document.getElementById("code"), {
        lineNumbers: true,
        mode: "tornado",
        indentUnit: 4,
        indentWithTabs: true
      });
    </script>

    <p>Mode for HTML with embedded Tornado template markup.</p>

    <p><strong>MIME types defined:</strong> <code>text/x-tornado</code></p>
  </article>
