<?php
ob_start();

include('./appdbconfig.php');

include('./svrconn.php');

$curr_proj_theme='cobalt';

if(isset($_SESSION['editor_proj_theme'])){

  $curr_proj_theme=$_SESSION['new_proj_theme'];
}

$tableNames = [];
$query = "SHOW TABLES from $db";
$result = mysqli_query($single_conn, "SHOW TABLES FROM `$dbname`");

while ($row = mysqli_fetch_array($result)) {
  $tableNames[] = $row[0];
}

?><meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="./terminal.css?v=99">
<link rel="stylesheet" href="./cm/lib/codemirror.css">
<link rel="stylesheet" href="./cm/addon/dialog/dialog.css">
<link rel="stylesheet" href="./cm/addon/search/matchesonscrollbar.css">
<link rel="stylesheet" href="./cm/addon/hint/show-hint.css">

<link rel="stylesheet" href="./cm/theme/3024-day.css">
<link rel="stylesheet" href="./cm/theme/3024-night.css">
<link rel="stylesheet" href="./cm/theme/abcdef.css">
<link rel="stylesheet" href="./cm/theme/ambiance.css">
<link rel="stylesheet" href="./cm/theme/ayu-dark.css">
<link rel="stylesheet" href="./cm/theme/ayu-mirage.css">
<link rel="stylesheet" href="./cm/theme/base16-dark.css">
<link rel="stylesheet" href="./cm/theme/bespin.css">
<link rel="stylesheet" href="./cm/theme/base16-light.css">
<link rel="stylesheet" href="./cm/theme/blackboard.css">
<link rel="stylesheet" href="./cm/theme/cobalt.css">
<link rel="stylesheet" href="./cm/theme/colorforth.css">
<link rel="stylesheet" href="./cm/theme/dracula.css">
<link rel="stylesheet" href="./cm/theme/duotone-dark.css">
<link rel="stylesheet" href="./cm/theme/duotone-light.css">
<link rel="stylesheet" href="./cm/theme/eclipse.css">
<link rel="stylesheet" href="./cm/theme/elegant.css">
<link rel="stylesheet" href="./cm/theme/erlang-dark.css">
<link rel="stylesheet" href="./cm/theme/gruvbox-dark.css">
<link rel="stylesheet" href="./cm/theme/hopscotch.css">
<link rel="stylesheet" href="./cm/theme/icecoder.css">
<link rel="stylesheet" href="./cm/theme/isotope.css">
<link rel="stylesheet" href="./cm/theme/lesser-dark.css">
<link rel="stylesheet" href="./cm/theme/liquibyte.css">
<link rel="stylesheet" href="./cm/theme/lucario.css">
<link rel="stylesheet" href="./cm/theme/material.css">
<link rel="stylesheet" href="./cm/theme/material-darker.css">
<link rel="stylesheet" href="./cm/theme/material-palenight.css">
<link rel="stylesheet" href="./cm/theme/material-ocean.css">
<link rel="stylesheet" href="./cm/theme/mbo.css">
<link rel="stylesheet" href="./cm/theme/mdn-like.css">
<link rel="stylesheet" href="./cm/theme/midnight.css">
<link rel="stylesheet" href="./cm/theme/monokai.css">
<link rel="stylesheet" href="./cm/theme/moxer.css">
<link rel="stylesheet" href="./cm/theme/neat.css">
<link rel="stylesheet" href="./cm/theme/neo.css">
<link rel="stylesheet" href="./cm/theme/night.css">
<link rel="stylesheet" href="./cm/theme/nord.css">
<link rel="stylesheet" href="./cm/theme/oceanic-next.css">
<link rel="stylesheet" href="./cm/theme/panda-syntax.css">
<link rel="stylesheet" href="./cm/theme/paraiso-dark.css">
<link rel="stylesheet" href="./cm/theme/paraiso-light.css">
<link rel="stylesheet" href="./cm/theme/pastel-on-dark.css">
<link rel="stylesheet" href="./cm/theme/railscasts.css">
<link rel="stylesheet" href="./cm/theme/rubyblue.css">
<link rel="stylesheet" href="./cm/theme/seti.css">
<link rel="stylesheet" href="./cm/theme/shadowfox.css">
<link rel="stylesheet" href="./cm/theme/solarized.css">
<link rel="stylesheet" href="./cm/theme/the-matrix.css">
<link rel="stylesheet" href="./cm/theme/tomorrow-night-bright.css">
<link rel="stylesheet" href="./cm/theme/tomorrow-night-eighties.css">
<link rel="stylesheet" href="./cm/theme/ttcn.css">
<link rel="stylesheet" href="./cm/theme/twilight.css">
<link rel="stylesheet" href="./cm/theme/vibrant-ink.css">
<link rel="stylesheet" href="./cm/theme/xq-dark.css">
<link rel="stylesheet" href="./cm/theme/xq-light.css">
<link rel="stylesheet" href="./cm/theme/yeti.css">
<link rel="stylesheet" href="./cm/theme/idea.css">
<link rel="stylesheet" href="./cm/theme/darcula.css">
<link rel="stylesheet" href="./cm/theme/yonce.css">
<link rel="stylesheet" href="./cm/theme/zenburn.css">

<script src="./cm/lib/codemirror.js"></script>
<script src="./cm/addon/selection/active-line.js"></script>
<script src="./cm/addon/hint/show-hint.js?v=fj4343k3k393"></script>
<script src="./cm/addon/hint/anyword-hint.js"></script>
<script src="./cm/addon/edit/closebrackets.js"></script>
<script src="./cm/mode/javascript/javascript.js"></script>
<script src="./cm/addon/edit/closetag.js"></script>
<script src="./cm/mode/htmlmixed/htmlmixed.js"></script>

<script src="./cm/addon/fold/xml-fold.js"></script>
<script src="./cm/addon/edit/matchtags.js"></script>
<script src="./cm/mode/xml/xml.js"></script>
<script src="./cm/addon/mode/loadmode.js"></script>
<script src="./cm/mode/meta.js"></script>
<script src="./cm/addon/dialog/dialog.js"></script>
<script src="./cm/addon/search/searchcursor.js"></script>
<script src="./cm/addon/search/search.js"></script>
<script src="./cm/addon/scroll/annotatescrollbar.js"></script>
<script src="./cm/addon/search/matchesonscrollbar.js"></script>
<script src="./cm/addon/search/jump-to-line.js"></script>
<script src="./cm/addon/search/match-highlighter.js"></script>
<script src="./cm/addon/edit/matchbrackets.js"></script>




<style type="text/css">
  .CodeMirror {
    position: fixed;
    overflow: hidden;
    top: 30px;
    width: 100%;
    min-height: 89vh;
    background-color: rgba(0,0,0,0.9)!important;
    text-align: left;
    left: 0px;
    border-bottom: 60px solid #000;
    font-size: 14px;
}


 #active_code_window::-webkit-scrollbar-track{
  background-color: #e2e2e2;
}

 #active_code_window::-webkit-scrollbar{
  width: 6px;
  background-color: #F5F5F5;
}

 #active_code_window::-webkit-scrollbar-thumb{
  border-radius: 100px;
  background-color: #545454;
}
.clock_skin{
  
     position: fixed;
    top: 39px;
    width: 96%;
    left: 0px;
    height: 80vh;
    font-size: 270px;
  color:purple;
}
.CodeMirror-focused .cm-matchhighlight {
  background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAYAAABytg0kAAAAFklEQVQI12NgYGBgkKzc8x9CMDAwAAAmhwSbidEoSQAAAABJRU5ErkJggg==);
  background-position: bottom;
  background-repeat: repeat-x;
}
.cm-matchhighlight {background-color: rgba(0,0,0, 0.2); border-bottom:1px solid #FFF;}
.CodeMirror-selection-highlight-scrollbar {background-color: lightgreen}

.cm-s-erlang-dark .CodeMirror-activeline-background {
    background: #373737;
}
.function_card u
{
   cursor:pointer;
}
.function_card
{
   margin-bottom: 34px;
   border-bottom: 4px solid #CCC;
   word-break: break-word;
}
.tbl_row:hover
{
    background-color: darkblue;
}
</style>
<title>Terminal</title>

<div style="text-align: center;">
	<img src="./deskfull.png" class="screen_frame">
	<iframe src="./index" class="desk_iframe"  id="load_desk_iframe" onLoad="change_scroll_bar_desk();"></iframe>
	<img src="./mobiview2.png" class="mobi_screen_frame" id="mobile_screen">
	<div class="close_mobile_view" onclick="close_mobile_view();this.style.display='none'" id="close_mobile_view_btn" title="Close Mobile View">X</div>
	<iframe src="./index" class="mobi_iframe"  id="load_mobi_iFrame" onLoad="change_scroll_bar_mobi();"></iframe>
<div class="preview_desk_iframe" id="preview_desk_iframe" style="display: none;"  onclick="push_to_top('preview_desk_iframe')">
  <div class="min_cast" id="load_preview_iframe_btn">
    <div class="exe_btn"><span onclick="expand_mobi()" id="expand_mobi" style="display: none;"><b>Desktop </b> | </span><span onclick="fold_mobi()" id="fold_mobi"><b>Mobile </b> | </span><span onclick="min_preview()"><b>Min </b></span>|<span onclick="loadwebpage();min_preview()"><b> Cast </b></span> | <span id="preview_desk_iframeheader" style="cursor: pointer;"><b> Drag </b></span></div>

  </div>
  <iframe style="width: 100%; height: 100%;" id="load_preview_iframe0" onLoad="change_scroll_bar_prev0();"></iframe>
  <iframe style="width: 100%; height: 100%;" id="load_preview_iframe1" onLoad="change_scroll_bar_prev1();"></iframe>
    <input type="text" id="prevscroll_px" style="position: absolute; bottom: 30px; right: 10px; width: 100px; background-color: rgba(0,0,0, 0.3); z-index: 9999999; color: #FFF;" placeholder="Scroll to" onclick="move_elem_to(100, 200, 'preview_desk_iframe')">
</div>
<input type="hidden" id="foundfile" name="" style="position: fixed; bottom: 72px; right: 20px; width: 70%; background-color: rgba(0,0,0, 0.9); z-index: 999; color: #FFF;" >
	<div class="bottom_tray" style="color: #FFF;">
  <input type="hidden" id="active_terminal" style="width: 5%; background-color: #000; color:#FFF; border: none; display: inline-block; ">
    <a href="./sketch/home" class="exe_btn" style="display: none;" target="_blank">Sketch</a>      

      <div class="exe_btn"  id="open_quick_vars" onclick="document.getElementById('quick_vars_card').style.display='inline-block'; this.style.display='none'; document.getElementById('close_quick_vars').style.display='inline-block';show_quick_vars();document.getElementById('quick_file_edit').style.display='block'" style="display: none;">Quick Vars</div>

       <div  class="exe_btn" style="display:none;" id="close_quick_vars" onclick="document.getElementById('quick_vars_card').style.display='none'; this.style.display='none'; document.getElementById('open_quick_vars').style.display='inline-block'">Close Vars</div>

    <div class="exe_btn" onclick="switch_dna()" id="switch_dna_btn" style="font-size:12px; display: none;">DNA : <?php echo $_SESSION['dna_session']?></div>      
    <div class="exe_btn" onclick="flip_config()" id="flip_config" style="font-size:12px;"> Flip config</div>      
    <div class="exe_btn" onclick="autoRunMiniCode()" style="font-size:12px;">Compile</div>      
    
  <input type="hidden" id="switch_dna_input" value="<?php echo $_SESSION['dna_session']?>"/>
      <div class="exe_btn" >TCT : <span id="tct_span"></span></div>
    <!--<button class="exe_btn" id="scrollUp" onclick="scrollWinup()">&#x2191;</button>
    <button class="exe_btn" id="scrollDown" onclick="scrollWindown()">&#x2193;</button>-->
    <div 
    style="display:inline-block;"
    >
          <input type="text"
          style="display:inline-block; padding:6px 10px;border-radius:6px;border:1px solid #ccc; background-color: #000; color:#FFF;"
          id="customModuleInput" list="availableTables" placeholder="Show cols for" 
          onchange="showColsFor(this.value)"
          onkeydown="if (event.key === 'Enter') { showColsFor(this.value); }"

          />

          <datalist id="availableTables">
            <?php foreach ($tableNames as $tbl): ?>
              <option value="<?= htmlspecialchars($tbl) ?>"></option>
            <?php endforeach; ?>
          </datalist>
  <input
    list="config_jump_list"
    id="config_jump_input"
    placeholder="Jump to config key..."
    onkeydown="handleJumpKey(event)"
    onchange="jumpToConfigKeyFuzzy(this.value)"
    style="display:inline-block; padding:6px 10px;border-radius:6px;border:1px solid #ccc; background-color: #000; color:#FFF;"
  />

  <div  onclick="removeCurrentKeyword()" class="exe_btn" style="display:inline-block;" title="Remove from history">❌</div>
</div>

<datalist id="config_jump_list"></datalist>

		<input type="text" id="iframeurl" placeholder="Url to show" style="display:none; width: 10%; background-color: #000; color:#FFF; border: none; ">
            <input type="hidden" id="txt_code_transparency" onkeyup="code_transparency(this.value)" placeholder="Opacity" style="width: 70px; background-color: #000; color:#FFF; border: none; display: inline-block; " value="0.9">
		<div class="exe_btn" onclick="loadwebpage()" style="display: none;">Go</div>
		<div class="exe_btn" onclick="loadapp_plan('appnotes')">Notes</div>
    <div class="exe_btn" onclick="loadapp_plan('appvars')" style="display: none;">Vars</div>
    <div class="exe_btn" onclick="loadapp_plan('appdbconfig')">DB</div>
    <div class="exe_btn" onclick="document.getElementById('parent_log_window').style.display='block';">Show Log</div>
<!--     <div class="exe_btn" onclick="find_in_page()">Find</div>
 -->       <select   onchange="change('text.'+this.value)"  style="width: 8%; background-color: #000; color:#FFF; border: none; display: inline-block; ">
                <option value="php">Doctype</option>
                <option>php</option>
                <option>html</option>
                <option>js</option>
                <option>php</option>
                <option>css</option>
                <option>json</option>

        </select>
<select  style="width: 8%; background-color: #000; color:#FFF; border: none; display: inline-block; " onchange="selectTheme(this.value);set_proj_theme(this.value)">
    <option selected><?php echo $curr_proj_theme; ?></option>
    <option>3024-day</option>
    <option>3024-night</option>
    <option>abcdef</option>
    <option>ambiance</option>
    <option>ayu-dark</option>
    <option>ayu-mirage</option>
    <option>base16-dark</option>
    <option>base16-light</option>
    <option>bespin</option>
    <option>blackboard</option>
    <option>cobalt</option>
    <option>colorforth</option>
    <option>darcula</option>
    <option>dracula</option>
    <option>duotone-dark</option>
    <option>duotone-light</option>
    <option>eclipse</option>
    <option>elegant</option>
    <option>erlang-dark</option>
    <option>gruvbox-dark</option>
    <option>hopscotch</option>
    <option>icecoder</option>
    <option>idea</option>
    <option>isotope</option>
    <option>lesser-dark</option>
    <option>liquibyte</option>
    <option>lucario</option>
    <option>material</option>
    <option>material-darker</option>
    <option>material-palenight</option>
    <option>material-ocean</option>
    <option>mbo</option>
    <option>mdn-like</option>
    <option>midnight</option>
    <option>monokai</option>
    <option>moxer</option>
    <option>neat</option>
    <option>neo</option>
    <option>night</option>
    <option>nord</option>
    <option>oceanic-next</option>
    <option>panda-syntax</option>
    <option>paraiso-dark</option>
    <option>paraiso-light</option>
    <option>pastel-on-dark</option>
    <option>railscasts</option>
    <option>rubyblue</option>
    <option>seti</option>
    <option>shadowfox</option>
    <option>solarized dark</option>
    <option>solarized light</option>
    <option>the-matrix</option>
    <option>tomorrow-night-bright</option>
    <option>tomorrow-night-eighties</option>
    <option>ttcn</option>
    <option>twilight</option>
    <option>vibrant-ink</option>
    <option>xq-dark</option>
    <option>xq-light</option>
    <option>yeti</option>
    <option>yonce</option>
    <option>zenburn</option>
</select>
	</div>
	<div class="minimized_mobi" id="minimized_mobi_div" title="Show Mobile View" onclick="show_mobi(); this.style.display='none'" >
		[Show Mobile View]
	</div>
<!--Start editor-->
<div class="navbar_ribbon">
    <input type="text" id="basepath_txt" style="font-size: 12px; width: 70px; background-color: #000; color:#FFF; border: none; display: inline-block; padding-left: 2px;" value=".." required="" placeholder="DirBase" onkeyup='loop_folder(this.value); trigger_log_search(this.value);flag_search(this.value)'>
    <input type="text" id="mainsearch" style="font-size: 12px; width: 15%; background-color: #000; color:#FFF; border: none; display: inline-block; padding-left: 2px;" value="Search" required="" placeholder=" Search System"   autocomplete="off" onkeyup='loop_folder(this.value); trigger_log_search(this.value);flag_search(this.value);'>
    <div  class="minifolder" id="minifolder" >
    	<div id="qfolder_res" onclick="document.getElementById('minifolder').style.display='none'"></div>
    </div>
	<div class="exe_btn" onclick="execute_terminal('');">Run</div>
	<div class="exe_btn" onclick="max_preview();showeditor()">Preview</div>

	<div class="exe_btn" onclick="pop_snippet();">Snippets</div>
    <input type="hidden" style="font-size: 12px; width: 15%; background-color: #000; color:#FFF; border: none; display: inline-block; padding-left: 2px;" value="<?php if(isset($_POST['txt_directory'])){ echo $_POST['txt_directory'];}else{ echo "./terminal_exe.php";}?>" name="txt_directory" id="txt_directory" required="" placeholder=" Enter exe file path">

	<div class="exe_btn" onclick="load_file();">Load File</div>
    <input type="text" style="font-size: 12px; width: 15%; background-color: #000; color:#FFF; border: none; display: inline-block; padding-left: 2px;" value="<?php if(isset($_POST['txt_writeto'])){ echo $_POST['txt_writeto'];}else{ echo "./txt_writeto.php";}?>" id="txt_writeto" name="txt_writeto" required="" placeholder=" Enter writable file path" onkeyup="loop_folder(this.value); trigger_log_search(this.value);push_title()" onchange="push_title()">
	<div class="exe_btn" id="showeditor" onclick="this.style.display='none';showeditor()">Code</div>

	<div class="exe_btn" id="hideeditor" style="display: none;" onclick="this.style.display='none';hideeditor();clearframeurl()">Live</div>
	<a href="./home" target="_blank" class="exe_btn" >New Instance</a>
	<a href="./home" class="exe_btn">Reload</a>
	<div class="exe_btn" onclick="save_file()">Save File</div>
</div>

<div class="log_window" id="parent_log_window" style="display: none;" onclick="push_to_top('parent_log_window')">

<div style="padding:5px;cursor:pointer; display:inline-block; border-right:1px solid #ccc;" onclick="pop_db_tables()">Db Tables</div>

      
<div style="padding:5px;cursor:pointer; display:inline-block;" onclick="loadapp_plan('quick_vars')">Edit Vars</div>
<div style="padding:5px; font-size: 28px; display: none;" onclick="this.style.display='none'" id="notification_card">Notifications</div>

<input type="text" style="font-size: 12px; width: 100%; background-color: #000; color:#FFF; border: none; display: inline-block; padding-left: 2px; margin-top: 5px; padding: 5px;" onkeyup="search_log()" required="" id="function_card" name="function_card" placeholder=" Search Window"  autocomplete="off">

<input type="text" id="folderpath" style="font-size: 12px; width: 100%; background-color: #000; color:#FFF; border: none; display: inline-block; padding-left: 2px; margin-top: 5px; padding: 5px;" onkeyup="loop_folder(this.value)" onchange="loop_folder(this.value)"  required="" placeholder="Search Folders"  autocomplete="off">

<div id="log_window" style="max-height: 300px; overflow-y: auto; margin-top: 12px;"></div>
<div style="text-align: left;">
      <a class="" href="#" title="Maximize" onclick="resize_move_elem_to(400, 50, 'parent_log_window', '75%')">[]</a>
    | <a class="" href="#" title="Restore" onclick="resize_move_elem_to(1200, 50, 'parent_log_window', '260px')"><></a>
    | <a class="" href="#" title="Minimize" onclick="document.getElementById('parent_log_window').style.display='none';">__</a>
    | <a class="" href="#" onclick="loadapp_plan('varurls');" title="Variable Urls">VURL</a>
	<span id="parent_log_windowheader" style="cursor: move;">< Drag ></span>
</div>
<textarea id="append_text" onclick="switch_terminals('console');this.style.width='100%';this.style.height='100%';" style="
    background-color: rgb(0, 0, 0, 0.2);
    width: 0px;
    color: #4eacff;
    height: 0px;
    margin: 10px 0px 0px;
    border: none;" placeholder="Php Console"></textarea>
<iframe src="./minicode.php" id="minicodeiframe" onclick="this.style.width='100%';this.style.height='100%';" style="
    background-color: rgb(0, 0, 0, 0.2);
    width: 100%;
    color: #4eacff;
    height: 500px;
    margin: 10px 0px 0px;
    border: none;"></iframe>

</div>
        <div class="clock_skin" id="time" ></div>

<textarea class="editor_skin_new" id="txt_new_code"  onclick="switch_terminals('main');"></textarea>
<div onclick="this.style.display='none'" id="flag_search_div" style="position: fixed;
    bottom: 200px;
    left: 200px;
    width: 400px;
    display: none;
    padding: 20px;
    background-color: #000; color: #FFF; max-height: 200px; overflow-y: auto; text-align: left; z-index: 9999999999">
</div>

<div onclick="this.style.display='none'" id="flag_search_hash" style="position: fixed;
    bottom: 200px;
    left: 600px;
    width: 400px;
    display: none;
    padding: 20px;
    background-color: #000; color: #FFF; max-height: 200px; overflow-y: auto; text-align: left; z-index: 9999999999">
</div>
<div onclick="this.style.display='none'" id="flag_search_pin" style="position: fixed;
    bottom: 85px;
    left: 200px;
    width: 400px;
    display: none;
    padding: 20px;
    background-color: #000; color: #FFF; max-height: 70px; overflow-y: auto; text-align: left; z-index: 9999999999">
</div>
 <div onclick="show_quick_vars();" style="text-align: left; cursor:pointer; font-size:14px; border-bottom:1px solid #CCC; padding:7px; max-height:70px; overflow-y:auto;  position:fixed; bottom:450px; max-width:200px; left:400px; color:#FFF; display:none; background: rgba(0,0,0, 0.4);" id="quick_vars_card"></div>
 <div style="
    text-align: left;
    cursor: pointer;
    font-size: 14px;
    border-bottom: 1px solid #CCC;
    padding: 7px;
    height: 300px;
    overflow-y: auto;
    position: fixed;
    bottom: 50px;
    width: 40vw;
    left: 10%;
    color: #FFF;
    display: none;
    background: rgba(0,0,0, 0.4);
    top: 143px;" id="quick_file_edit">
   <div class="width:100%" onclick="document.getElementById('quick_file_edit').style.display='none'">Close</div>
 <iframe src="" onclick="this.style.width='100%';this.style.height='100%';" style="
    background-color: rgb(0, 0, 0, 0.2);
    width: 100%;
    color: #4eacff;
    height: 100vh;
    margin: 10px 0px 0px;
    border: none;" id="pop_quick_code"></iframe>
      
</div>      
<input type="hidden" style="position: fixed; bottom: 72px; right: 20px; width: 70%; background-color: rgba(0,0,0, 0.9); z-index: 999; color: #FFF;" id="flag_search" name="">
<input type="hidden" style="position: fixed; bottom: 172px; right: 20px; width: 70%; background-color: rgba(0,0,0, 0.9); z-index: 999; color: #FFF;" id="hash_text_search" name="">
<input type="hidden" style="position: fixed; bottom: 72px; right: 20px; width: 40%; background-color: rgba(0,0,0, 0.9); z-index: 999; color: #FFF;" id="trigger_arrow_keys" name="">
<input type="hidden" id="load_preview_iframe_txt">
<input type="hidden" id="appvars_txt">
<input type="hidden" id="app_notes_append">
<input type="text" id="setcursor">
<input type="text" id="snippkey">
<input type="text" id="flag_focused">
<input type="text" id="alwaysontop" value="99999999">
<input type=text value="php" id=mode> 

<input type="hidden" id="txt_scroll_to" value="100" style="position: fixed; bottom: 72px; right: 20px; width: 40%; background-color: rgba(0,0,0, 0.9); z-index: 999; color: #FFF;">

<!--End editor-->
<!-- $("#a_input_id", parent.document).val($(this).text());
 -->
</div>
<div id="alert_box"></div>
        <span id="modeinfo">text/plain</span>


<script>

CodeMirror.modeURL = "./cm/mode/%N/%N.js";
var editor = CodeMirror.fromTextArea(document.getElementById("txt_new_code"), {
  lineNumbers: true,
  lineWrapping: true,
    value: "<html>\n  " + document.documentElement.innerHTML + "\n</html>",
    matchTags: {bothTags: true},
  extraKeys: {"Alt-F": "findPersistent", "Ctrl-Space": "autocomplete"},
 autoCloseBrackets: true,
styleActiveLine: true,
  autoCloseTags: true,
  highlightSelectionMatches: {showToken: /\w/, annotateScrollbar: true},
    matchBrackets: true

});
                   
                    
editor.on("keydown", function (cm, event) {
  if (
     event.keyCode != 13 && !(event.ctrlKey) && 
    (event.keyCode >= 65 && event.keyCode <= 90) || 
    (event.keyCode >= 97 && event.keyCode <= 122) || 
    (event.keyCode >= 46 && event.keyCode <= 57)
  ) {

  if (!cm.state.completionActive && /*Enables keyboard navigation in autocomplete list*/
      event.keyCode != 13) {        /*Enter - do not open autocomplete list just after item has been selected in it*/ 
      
		cm.showHint({hint: CodeMirror.hint.anyword, completeSingle: false}); 
  
  }
    }
}); 
                    
function change(curr_mode) {
  var val = curr_mode, m, mode, spec;
  if (m = /.+\.([^.]+)$/.exec(val)) {
    var info = CodeMirror.findModeByExtension(m[1]);
    if (info) {
      mode = info.mode;
      spec = info.mime;
    }
  } else if (/\//.test(val)) {
    var info = CodeMirror.findModeByMIME(val);
    if (info) {
      mode = info.mode;
      spec = val;
    }
  } else {
    mode = spec = val;
  }
  if (mode) {
    editor.setOption("mode", spec);
    CodeMirror.autoLoadMode(editor, mode);
    document.getElementById("modeinfo").textContent = spec;
  } else {
    //alert("Could not find a mode corresponding to " + val);
  }
}

  function selectTheme(theme_name) {
    var theme = theme_name;
    editor.setOption("theme", theme);
    location.hash = "#" + theme;
  }
  var choice = (location.hash && location.hash.slice(1)) ||
               (document.location.search &&
                decodeURIComponent(document.location.search.slice(1)));
  if (choice) {
    editor.setOption("theme", choice);
  }
  CodeMirror.on(window, "hashchange", function() {
    var theme = location.hash.slice(1);
    if (theme) { selectTheme(); }
  });

</script>

<script type="text/javascript" src="./jquery.js"></script>
<script type="text/javascript" src="./cm_terminal.js?v=<?php echo date("hisa")?>"></script>
<script type="text/javascript" src="./jsfunctions.js"></script>
<?php include("codeoasis.php") ?>
<script type="text/javascript">
    window.onload=showeditor();check_autoload();load_start_folder('..');

    function check_autoload()
    {

var url =new URL(window.location.href);
var c = url.searchParams.get("check_autoload");

if(c!=undefined){

document.getElementById('txt_writeto').value=atob(c);

load_file()

}
}

function load_mirror()
{

    window.open('./home?check_autoload='+btoa(document.getElementById('txt_writeto').value));
}

function code_transparency(new_val)
{
document.getElementById('active_code_window').style.opacity=''+new_val+'';
}

</script>

<script type="text/javascript">
function scrollWinup()
{
    var editorheight=editor.lineCount();

      if ( document.getElementById('txt_scroll_to').value>=editorheight*10)
    {
      document.getElementById('txt_scroll_to').value=editorheight*9;
     }

  editor.scrollTo(0, document.getElementById('txt_scroll_to').value);




    if ( document.getElementById('txt_scroll_to').value<0)
    {
   document.getElementById('txt_scroll_to').value=0;
    }else{
         document.getElementById('txt_scroll_to').value=parseInt(document.getElementById('txt_scroll_to').value)-250;

    }
}

function scrollWindown()

{

   editor.scrollTo(0, document.getElementById('txt_scroll_to').value);

var editorheight=editor.lineCount();

    if ( document.getElementById('txt_scroll_to').value>=editorheight*15)
    {
   document.getElementById('txt_scroll_to').value=editorheight*15;
    }else{
         document.getElementById('txt_scroll_to').value=parseInt(document.getElementById('txt_scroll_to').value)+250;

    }


  }

window.onload=change('txt.php'); selectTheme('<?php echo $curr_proj_theme?>');document.getElementById('parent_log_window').style.display='none';

function autoRunMiniCode() {
  const iframe = document.getElementById("minicodeiframe");

  iframe.contentWindow.execute_terminal("editor", parentNotify);

}

window.showGlobalSnackbar = function(message, type = "info") {
  let bar = document.getElementById("ajax_snackbar");

  if (!bar) {
    bar = document.createElement("div");
    bar.id = "ajax_snackbar";

    Object.assign(bar.style, {
      position: "fixed",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%) scale(0.9)",
      minWidth: "280px",
      maxWidth: "420px",
      padding: "16px 22px",
      borderRadius: "12px",
      color: "#fff",
      fontFamily: "sans-serif",
      fontSize: "15px",
      textAlign: "center",
      zIndex: "99999999999",
      boxShadow: "0 10px 30px rgba(0,0,0,0.25)",
      opacity: "0",
      pointerEvents: "none",
      transition: "all 0.25s ease",
      cursor: "pointer"
    });

    bar.onclick = () => window.hideGlobalSnackbar();
    document.body.appendChild(bar);
  }

  const colors = {
    info: "#0d6efd",
    success: "#198754",
    error: "#dc3545",
    processing: "#6c757d"
  };

  bar.style.background = colors[type] || colors.info;
  bar.innerHTML = message + "<br><small>(Click to dismiss)</small>";
  bar.style.opacity = "1";
  bar.style.transform = "translate(-50%, -50%) scale(1)";
  bar.style.pointerEvents = "auto";
};

window.hideGlobalSnackbar = function() {
  const bar = document.getElementById("ajax_snackbar");
  if (!bar) return;

  bar.style.opacity = "0";
  bar.style.transform = "translate(-50%, -50%) scale(0.9)";
  bar.style.pointerEvents = "none";
};

function showLocalSnackbar(message, type = "info") {
  let bar = document.getElementById("ajax_snackbar_local");

  if (!bar) {
    bar = document.createElement("div");
    bar.id = "ajax_snackbar_local";

    Object.assign(bar.style, {
      position: "fixed",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%) scale(0.9)",
      minWidth: "280px",
      maxWidth: "420px",
      padding: "16px 22px",
      borderRadius: "12px",
      color: "#fff",
      fontFamily: "sans-serif",
      fontSize: "15px",
      textAlign: "center",
      zIndex: "99999999999",
      boxShadow: "0 10px 30px rgba(0,0,0,0.25)",
      opacity: "0",
      pointerEvents: "none",
      transition: "all 0.25s ease",
      cursor: "pointer"
    });

    bar.onclick = () => hideLocalSnackbar();
    document.body.appendChild(bar);
  }

  const colors = {
    info: "#0d6efd",
    success: "#198754",
    error: "#dc3545",
    processing: "#6c757d"
  };

  bar.style.background = colors[type] || colors.info;
  bar.innerHTML = message + "<br><small>(Click to dismiss)</small>";
  bar.style.opacity = "1";
  bar.style.transform = "translate(-50%, -50%) scale(1)";
  bar.style.pointerEvents = "auto";
}

function hideLocalSnackbar() {
  const bar = document.getElementById("ajax_snackbar_local");
  if (!bar) return;

  bar.style.opacity = "0";
  bar.style.transform = "translate(-50%, -50%) scale(0.9)";
  bar.style.pointerEvents = "none";
}

function parentNotify(message, type) {
  // if (window.showGlobalSnackbar) {
  //   window.showGlobalSnackbar(message, type);
  // }
  showLocalSnackbar(message, type);

}

</script>