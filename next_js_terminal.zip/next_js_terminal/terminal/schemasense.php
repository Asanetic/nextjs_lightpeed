<?php
include('./appdbconfig.php');
include('./svrconn.php');

$tableNames = [];
$query = "SHOW TABLES from $db";
$result = mysqli_query($single_conn, "SHOW TABLES FROM `$dbname`");

while ($row = mysqli_fetch_array($result)) {
  $tableNames[] = $row[0];
}

$basePath = "../appdna/funcapp/";
$modules = array_filter(glob($basePath . '*'), 'is_dir');
$moduleNames = array_map('basename', $modules);
sort($moduleNames);


?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>🧬 Light speed module builder</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      padding: 2rem;
      background: #f8f9fa;
    }
    .log-box {
      background: #1e1e1e;
      color: #d4d4d4;
      font-family: monospace;
      font-size: 0.9rem;
      border-radius: 0.5rem;
      padding: 1rem;
      height: 50vh;
      overflow-y: auto;
    }
    .success { color: #28a745; }
    .error { color: #ffc107; font-weight: bold; }
    .stopped { color: #dc3545; }
    .module-select, #customModuleInputWrap { max-width: 300px; }
    .action-buttons button { margin-right: 0.5rem; }
  </style>
</head>
<body>

<div class="container">
  <h2 class="mb-4 text-primary"><strong> Light speed module builder</strong></h2>

  <div class="row mb-4">
    <div class="col-md-6">
      <label for="moduleSelect" class="form-label">📦 Select Module</label>
        <select id="moduleSelect" class="form-select module-select" onchange="checkForCustomModule(this)">
          <option value="all">🔁 Build ALL Modules</option>
          <?php foreach ($moduleNames as $mod): ?>
            <option value="<?= $mod ?>"><?= ucfirst($mod) ?></option>
          <?php endforeach; ?>
          <option value="__custom__">➕ New Module...</option>
        </select>

        <!-- Hidden input appears if user selects custom -->
        <div id="customModuleInputWrap" class="col-md-9" style="margin-top: 0.5rem; display: none;">
          <input type="text" class="form-control" id="customModuleInput" list="availableTables" placeholder="Type new module name" />

          <datalist id="availableTables">
            <?php foreach ($tableNames as $tbl): ?>
              <option value="<?= htmlspecialchars($tbl) ?>"></option>
            <?php endforeach; ?>
          </datalist>
        </div>


    </div>
  </div>

  <div class="row mb-4 action-buttons">
    <div class="col-md-6 d-flex">
      <button id="runBtn" class="btn btn-success" onclick="confirmAndRunBuild()">▶️ Run Build</button>
      <button class="btn btn-danger" onclick="stopBuild()">⏹️ Stop</button>
    </div>
  </div>

  <div class="mb-3">
    <label class="form-label">🚀 Progress</label>
    <div class="progress">
      <div class="progress-bar progress-bar-striped progress-bar-animated" id="progBar" role="progressbar" style="width: 0%">0%</div>
    </div>
  </div>

  <div class="mb-3">
    <label class="form-label">📋 Logs</label>
    <div class="log-box" id="logBox"></div>
  </div>
</div>

<!-- 🔐 Confirmation Modal -->
<div class="modal fade" id="confirmBuildModal" tabindex="-1" aria-labelledby="confirmBuildModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0">
      <div class="modal-header bg-warning text-dark">
        <h5 class="modal-title" id="confirmBuildModalLabel">Confirm Build</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Are you sure you want to build <strong id="modalTargetText">the selected module</strong>?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-success" id="confirmBuildBtn">Yes, Build</button>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap JS for modal -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Inject PHP data into JS -->
<script>
const availableModules = <?= json_encode($moduleNames) ?>;
const moduleFiles = {};
<?php foreach ($moduleNames as $mod):
  $files = glob($basePath . $mod . "/*.Dnaaf");
  $files = array_map('basename', $files);
?>
  moduleFiles["<?= $mod ?>"] = <?= json_encode($files) ?>;
<?php endforeach; ?>

let stopRequested = false;
let confirmedBuildTarget = null;

function confirmAndRunBuild() {
  
let selected = document.getElementById("moduleSelect").value;
if (selected === "__custom__") {
  const customVal = document.getElementById("customModuleInput").value.trim();
  if (customVal) {
    selected = customVal;
  } else {
    alert("Please enter a valid custom module name.");
    return;
  }
}

  
 // const selected = document.getElementById("moduleSelect").value;
  const targetText = selected === "all" ? "ALL modules" : `the <strong>${selected}</strong> module`;

  confirmedBuildTarget = selected;
  document.getElementById("modalTargetText").innerHTML = targetText;

  const confirmModal = new bootstrap.Modal(document.getElementById("confirmBuildModal"));
  confirmModal.show();
}

document.getElementById("confirmBuildBtn").addEventListener("click", function () {
  const modal = bootstrap.Modal.getInstance(document.getElementById("confirmBuildModal"));
  modal.hide();
  if (confirmedBuildTarget) {
    runBuild(confirmedBuildTarget);
  }
});

async function runBuild(selectedModule) {
  stopRequested = false;

  const progBar = document.getElementById("progBar");
  const logBox = document.getElementById("logBox");
  const runBtn = document.getElementById("runBtn");

  progBar.style.width = "0%";
  progBar.innerText = "0%";
  logBox.innerHTML = "🧪 Starting build...";
  runBtn.disabled = true;

  let allFiles = [];

  // 🧩 Collect files
  if (selectedModule === "all") {
    for (const mod of availableModules) {
      if (moduleFiles[mod]) {
        moduleFiles[mod].forEach(file => allFiles.push({ module: mod, file }));
      }
    }
  } else {
    if (moduleFiles[selectedModule]) {
      moduleFiles[selectedModule].forEach(file => allFiles.push({ module: selectedModule, file }));
    } else {
      // 🆕 Assume new module
      allFiles.push({ module: selectedModule, file: `${selectedModule}.Dnaaf` });
    }
  }

  const total = allFiles.length;
  let done = 0;

  for (const { module, file } of allFiles) {
    if (stopRequested) {
      logMessage("🛑 Build manually stopped by user.", "stopped");
      break;
    }

    const params = new URLSearchParams({ module, file });

    try {
      const res = await fetch('lightspeedbuilder.php?' + params.toString());
      const rawText = await res.text(); // 👈 read body once!

      let result;
      try {
        result = JSON.parse(rawText); // 🎯 attempt to parse
      } catch (jsonErr) {
        logMessage(`⚠️ JSON parse failed for <b>${module}/${file}</b>:<br><pre>${rawText}</pre>`, "error");
        continue;
      }

      for (const item of result) {
        const status = item.status;
        const summary = `🔧 [${item.module}] ${item.file} => ${status}`;

        if (status === 'success') {
          logMessage(summary, 'success');
          if (item.html) {
            const subLogs = parseSubLogs(item.html);
            subLogs.forEach(log => logMessage(log.content, log.type));
          }
        } else if (status === 'error') {
          logMessage(`${summary} ❌ ${item.message}`, 'error');
        } else if (status === 'stopped') {
          logMessage(`${summary} 🛑`, 'stopped');
          stopRequested = true;
          break;
        }
      }
    } catch (err) {
      logMessage(`⚠️ Error building <b>${module}/${file}</b>: ${err.message}`, "error");
    }


    done++;
    const percent = Math.floor((done / total) * 100);
    progBar.style.width = percent + "%";
    progBar.innerText = percent + "%";

    await new Promise(r => setTimeout(r, 300)); // delay for UX smoothness
  }

  runBtn.disabled = false;
}


async function stopBuild() {
  stopRequested = true;
  await fetch("lightspeedbuilder.php?stop=1");
  logMessage("🛑 Stop requested.", "stopped");
}

function logMessage(msg, status) {
  const box = document.getElementById("logBox");
  const div = document.createElement("div");
  div.className = status;
  div.innerHTML = msg;
  box.appendChild(div);
  box.scrollTop = box.scrollHeight;
}

function parseSubLogs(html) {
  const entries = html.split(/<hr\s*\/?>/i);
  const logs = [];

  for (let entry of entries) {
    entry = entry.trim();
    if (!entry) continue;

    if (entry.includes("File Moved to")) {
      const file = entry.match(/\.\/deleted_files\/[^\s<]+/);
      if (file) {
        logs.push({ content: `🗃️ File moved: <code>${file[0]}</code>`, type: 'success' });
      }
    } else if (entry.includes("component created at") || entry.includes("Route js api at")) {
      const link = entry.match(/<a[^>]+href=['"]([^'"]+)['"][^>]*>(.*?)<\/a>/i);
      if (link) {
        logs.push({ content: `✅ ${link[2]} ➜ <a href="${link[1]}" target="_blank">${link[1]}</a>`, type: 'success' });
      }
    } else if (entry.includes("Sorry, File Overwrite is not allowed")) {
      logs.push({ content: `❌ ${entry.replace(/<[^>]+>/g, '')}`, type: 'error' });
    } else if (entry.includes("http://localhost") || entry.includes("localhost:3000") || entry.includes("<a ")) {
      const links = [...entry.matchAll(/<a[^>]+href=['"]([^'"]+)['"][^>]*>(.*?)<\/a>/gi)];
      for (let link of links) {
        logs.push({ content: `🔗 ${link[2]} ➜ <a href="${link[1]}" target="_blank">${link[1]}</a>`, type: 'success' });
      }
    } else {
      logs.push({ content: entry.replace(/<[^>]+>/g, '').trim(), type: 'success' });
    }
  }

  return logs;
}
  
function checkForCustomModule(selectEl) {
  const inputWrap = document.getElementById("customModuleInputWrap");
  const inputBox = document.getElementById("customModuleInput");

  if (selectEl.value === "__custom__") {
    inputWrap.style.display = "block";
    setTimeout(() => inputBox.focus(), 100); // focus new input
  } else {
    inputWrap.style.display = "none";
    inputBox.value = "";
  }
}

  
</script>
</body>
</html>
