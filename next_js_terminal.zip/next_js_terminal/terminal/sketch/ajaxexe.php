<?php
ob_start();

include('./appdbconfig.php');

include('./svrconn.php');

include("./phpmagicbits.php");
function Recycle($filename)
{
  $new_file_name='./deleted_files/'.magic_basename($filename)."_".date("d_m_y_h_s_a").'_bkup.tmx';
  
     if (!file_exists('./deleted_files')) @mkdir('./deleted_files');
  
    $exec_move = rename($filename, $new_file_name);
  
  if($exec_move)
  {
    
  echo "File Moved to ".$new_file_name;
    
  }else{
  
  echo "<hr>Opps! Error While Deleting File <hr>";
  
  }

}

function help()
{
return "Type echo fend_help(); for front end and echo bend_help(); for back end";
}


  //error handler function

  function customError($errno, $errstr) {
    echo "<b>Error:</b> [$errno] $errstr<hr>".help();
  }

  //set error handler
  //set_error_handler("customError");
if(isset($_POST['switch_dna_session']))
{
    $_SESSION['dna_session']=$_POST['switch_dna_input'];

}

if(isset($_POST['execute_terminal']))
{

  
      $file_to_write = fopen($_POST['txt_directory'], 'w') or die("can't open file");
      fwrite($file_to_write, "<?php ".$_POST['txt_new_code']."?>");
      fclose($file_to_write);

     // echo "Input : ".$_POST['txt_new_code'].'<hr style="border : 1px solid #7f7e7e">Output : ';
      echo '<hr style="border : 1px solid #7f7e7e">Output : <br>--------<br> ';

      include(($_POST['txt_directory']));
  
      if(isset($create_dna))
      {

      $dna_app_name=str_replace(" ", "", strtolower($ls_application_name));
      $new_dna_file_name='../appdna/'.$dna_app_name."_".$dna_file_name.'.lsdna';
      $new_dna_file_name_w_date='../appdna/'.$dna_app_name."_".$dna_file_name.'_'.date("dmyhsa").'.lsdna';

        if($create_dna=='yes')
        {
           if (!file_exists('../appdna')) @mkdir('../appdna');

       if($overwrite_dna_file=='yes')
           {
            file_put_contents($new_dna_file_name, ($_POST['txt_new_code']));
           }else{

          file_put_contents($new_dna_file_name_w_date, ($_POST['txt_new_code']));

        }
        }
    }
          

}




if(isset($_POST['load_file']))
{
  echo file_get_contents($_POST['txt_writeto']);

}

if(isset($_POST['load_notes']))
{
  if (!file_exists($_POST['txt_writeto'])) {
      $file_to_write = fopen($_POST['txt_writeto'], 'w') or die("can't open file");
      fwrite($file_to_write, '');
      fclose($file_to_write);
  }

  echo file_get_contents($_POST['txt_writeto']);

}

if(isset($_POST['delete_design_file'])) {

  Recycle($_POST['delete_file_path']);

}

if(isset($_POST['save_file']))
{

   if (!file_exists('./edithistory')) @mkdir('./edithistory');

    if($_POST['save_file']==''){
      echo "File path cannot be empty";
    }else{
        
      if (!file_exists($_POST['txt_writeto'])){
        echo "<hr>File Not Found, Creating file...<hr>";
      }else{
        
        $backup= file_get_contents($_POST['txt_writeto']);

              $file_to_write = fopen('./edithistory/'.magic_basename($_POST['txt_writeto'])."_".date("dmyhisa").'_bkup.tmx', 'w') or die("can't open file");
              fwrite($file_to_write, $backup);
              fclose($file_to_write);
      };


         if(file_put_contents($_POST['txt_writeto'], $_POST['txt_new_code'])){
             echo "File Saved :)";

         }else{
             echo "<hr>File Not Found, Creating file<hr>";
         }
    };

}


if(isset($_POST['loop_folder']))
{

$parent=$_POST['folder'];

 if (!file_exists($parent)){
  echo "DNF";
 }else{

//folder only 
   
if ($folder_handle = opendir($parent)) {

  while (false !== ($folder_str = readdir($folder_handle))) {

          if ($folder_str != "." && $folder_str != "..") 
          {
            $a = $folder_str;

            if (strpos($a, '.') == false) {
                $folderrec= '<a href="#"  onclick="document.getElementById(\'folderpath\').value=\''.$parent.'/'.$folder_str.'\';loop_open_folder(\''.$parent.'/'.$folder_str.'\')">Open Folder</a>' ;


        echo '
        <div class="function_card" style="border-bottom:1px solid #CCC; margin-bottom:9px;">
        <div style="display:inline-block; padding:3px;">
        <img src="fld.png" style="width:20px;"/>
         <span onclick="load_to_editor(\''.$folder_str.'\')">'.$folder_str.'</span>
        </div>
        <div style=" font-size:12px; margin:7px;">
        <div class="cpointer">'.$folderrec.'</div>
        </div>
        </div>';

             }
       }
    }
 
    closedir($folder_handle);
}



if ($handle = opendir($parent)) {

   //files only
    while (false !== ($entry = readdir($handle))) {

        if ($entry != "." && $entry != "..") {
          $a = $entry;

            if (strpos($a, '.') !== false) {

              $folderrec2= '
                    <a href="'.$parent.'/'.$entry.'" target="_blank" title="View File">VF</a>  
                    | <a href="#"  onclick="load_to_path(\''.$parent.'/'.$entry.'\')" title="Load to Path">LTP</a> 
                    | <a href="#"  onclick="load_to_path(\''.$parent.'/'.$entry.'\');load_file()" title="Open File">Open</a> 
                    | <a href="./home?check_autoload='.base64_encode($parent.'/'.$entry).'" target="_blank" title="Mirror to New Window">MTW</a> 
                    | <a href="#" onclick="document.getElementById(\'txt_trashfile\').value=\''.$parent.'/'.$entry.'\';" title="Execute Unlink">DEL</a> 
                    ';

                  echo '
                  <div class="function_card" style="border-bottom:1px solid #CCC; margin-bottom:9px;">
                  <div style="display:inline-block; padding:3px;">
                  <img src="file.png" style="width:20px;"/>
                   <span onclick="load_to_editor(\''.$entry.'\')">'.$entry.'</span>
                  </div>
                  <div style=" font-size:12px; margin:7px;">
                  <div class="cpointer">'.$folderrec2.'</div>
                  </div>
                  </div>';
            }
      }
    }
}
   

}
}

function format_time($t,$f=':') // t = seconds, f = separator 
{
  return sprintf("%02d%s%02d%s%02d", floor(($t*60)/3600), $f, (($t*60)/60)%60, $f, ($t*60)%60);
}
?>