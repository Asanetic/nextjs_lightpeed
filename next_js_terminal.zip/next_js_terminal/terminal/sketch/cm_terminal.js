
function load_to_editor(load_str)
{
    $('#canvas-editor').append(canvas.getHtml());
    canvas.onInsert();
    canvas.api.startEditing();
    canvas.loadCanvas(load_str); 
}


function load_file()
{
 
 var  txt_writeto = document.getElementById('txt_writeto').value;

    $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'load_file':'ok',
        'txt_writeto':txt_writeto
      },

      success: function (data) {

    $('#canvas-editor').append(canvas.getHtml());
    canvas.onInsert();
    canvas.api.startEditing();
    canvas.loadCanvas(data); 
    push_title();
     //alert(data);

      }

  })
}

function save_file()
{
 
 var  txt_writeto = document.getElementById('txt_writeto').value;
 var  txt_new_code = JSON.stringify(canvas.getCanvasData());

    $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'save_file':'ok',
        'txt_writeto':txt_writeto,
        'txt_new_code':txt_new_code
      },

      success: function (data) {

        document.getElementById('notification_card').style.display='block';
        document.getElementById('notification_card').innerHTML=data;
        load_start_folder('./projects');
      }

  })
}




//==============


 

//--------------------------- End -----------------

function load_start_folder(folder)
{
var basepath_txt = folder;

  //alert(folder);
  
    $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'loop_folder':'ok',
        'folder':basepath_txt
      },

      success: function (data) {
          if(data=='DNF'){
        //document.getElementById('notification_card').style.display='block';
        //ocument.getElementById('notification_card').innerHTML='Directory '+basepath_txt+' Not found';
          }else{
        var folder_card= '<div  class="function_card" > Project Directory <br>'+data+'<hr></div>'
        document.getElementById('log_window').innerHTML=folder_card;
        document.getElementById('log_window').scrollTop=0;
          }

      }

  })
}



function loop_open_folder(folder)
{
var basepath_txt = folder;

    $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'loop_folder':'ok',
        'folder':basepath_txt
      },

      success: function (data) {
          if(data=='DNF'){
        //document.getElementById('notification_card').style.display='block';
        //ocument.getElementById('notification_card').innerHTML='Directory '+basepath_txt+' Not found';
          }else{
        var folder_card= '<div  class="function_card" >Directory Listing for '+basepath_txt+'<br>'+data+'<hr></div>'
        document.getElementById('log_window').innerHTML=folder_card+document.getElementById('log_window').innerHTML;            
        document.getElementById('log_window').scrollTop=0;
          }

      }

  })
}


function delete_file(delete_file)
{
    $.ajax({ 
      url: './ajaxexe.php',
      type: "POST",
      data: {
        'delete_design_file':'ok',
        'delete_file_path':delete_file
      },

      success: function (data) {
        ///alert(data);
        document.getElementById('notification_card').style.display='block';
        document.getElementById('notification_card').innerHTML=data;
        load_start_folder('./projects');

      }

  })
}

function load_to_path(content)
{

  document.getElementById('txt_writeto').value=content;

}


setInterval(function () 
{
  document.getElementById('notification_card').style.display='none';
}, 30000);


function check_if_file_exists(filepath)
{
    if(document.getElementById('load_preview_iframe_txt').value=='yes'){

  $.ajax({
    url:filepath,
    type:'HEAD',
    error: function()
    {
        //file not exists
        document.getElementById('foundfile').value='404';

    },
    success: function()
    {
        //file exists
        document.getElementById('foundfile').value='200';

     //alert(200);

    }
});
}
}


function trigger_log_search(qstr)
{
  document.getElementById("function_card").value=qstr;

  search_log();
}


function dope_search_log(count_nodes)
{
 
  if(count_nodes=='')
  {
  document.getElementById('flag_search_pin').style.display='none';

  }else{
     
    document.getElementById('flag_search_pin').style.display='block';

  }

}

function search_log() {
    var input = document.getElementById("function_card");
    var filter = input.value.toLowerCase();
    var nodes = document.getElementsByClassName('function_card');  

    var count_nodes=0;

  if(input.value=='clearlog'){

    document.getElementById('log_window').innerHTML='';
  }else{
    for (i = 0; i < nodes.length; i++) {
      if (nodes[i].innerText.toLowerCase().includes(filter)) {  

        nodes[i].style.display = "block";  
        count_nodes=1;
              
      } else {
        nodes[i].style.display = "none";
      }
    }
    
   dope_search_log(count_nodes);


  }
}


function push_title()
{
    document.title='Lightspeed Sketch Active File : - '+document.getElementById('txt_writeto').value ;
}


