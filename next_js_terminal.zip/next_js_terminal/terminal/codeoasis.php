

<script type="text/javascript">
  //auto written codeoasis
  // Select the target element
const tctSpan = document.getElementById('tct_span');

// Define the new component as HTML
const newComponent = ' <span id="total_file_time">Project / File </span>';

// Inject the new component after tct_span
tctSpan.insertAdjacentHTML('afterend', newComponent);
tctSpan.style.display='none';

  document.getElementById('active_code_window').addEventListener('keyup', e => {
        var file_path =document.getElementById('txt_writeto').value;

          $.ajax({ 
              url: 'http://localhost/hive/codeoasis/be/hiveapi.php',
            
              type: 'POST',
              data: {
                 'track_project': 'ok',
                 'main_url': window.location.href,
                 'file_path': file_path
                },

              success: function (data) {

                document.getElementById('total_file_time').innerHTML=data
                console.log(data);

              }

          });

  })


</script>   