<?php
ob_start();

include('./appdbconfig.php');

include('./svrconn.php');

$curr_proj_theme='cobalt';

if(isset($_SESSION['editor_proj_theme'])){

  $curr_proj_theme=$_SESSION['new_proj_theme'];
}
?><meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="./terminal.css?v=99">
<link rel="stylesheet" href="./cm/lib/codemirror.css">
<link rel="stylesheet" href="./cm/addon/dialog/dialog.css">
<link rel="stylesheet" href="./cm/addon/search/matchesonscrollbar.css">
<link rel="stylesheet" href="./cm/addon/hint/show-hint.css">

<link rel="stylesheet" href="./cm/theme/3024-day.css">
<link rel="stylesheet" href="./cm/theme/3024-night.css">
<link rel="stylesheet" href="./cm/theme/abcdef.css">
<link rel="stylesheet" href="./cm/theme/ambiance.css">
<link rel="stylesheet" href="./cm/theme/ayu-dark.css">
<link rel="stylesheet" href="./cm/theme/ayu-mirage.css">
<link rel="stylesheet" href="./cm/theme/base16-dark.css">
<link rel="stylesheet" href="./cm/theme/bespin.css">
<link rel="stylesheet" href="./cm/theme/base16-light.css">
<link rel="stylesheet" href="./cm/theme/blackboard.css">
<link rel="stylesheet" href="./cm/theme/cobalt.css">
<link rel="stylesheet" href="./cm/theme/colorforth.css">
<link rel="stylesheet" href="./cm/theme/dracula.css">
<link rel="stylesheet" href="./cm/theme/duotone-dark.css">
<link rel="stylesheet" href="./cm/theme/duotone-light.css">
<link rel="stylesheet" href="./cm/theme/eclipse.css">
<link rel="stylesheet" href="./cm/theme/elegant.css">
<link rel="stylesheet" href="./cm/theme/erlang-dark.css">
<link rel="stylesheet" href="./cm/theme/gruvbox-dark.css">
<link rel="stylesheet" href="./cm/theme/hopscotch.css">
<link rel="stylesheet" href="./cm/theme/icecoder.css">
<link rel="stylesheet" href="./cm/theme/isotope.css">
<link rel="stylesheet" href="./cm/theme/lesser-dark.css">
<link rel="stylesheet" href="./cm/theme/liquibyte.css">
<link rel="stylesheet" href="./cm/theme/lucario.css">
<link rel="stylesheet" href="./cm/theme/material.css">
<link rel="stylesheet" href="./cm/theme/material-darker.css">
<link rel="stylesheet" href="./cm/theme/material-palenight.css">
<link rel="stylesheet" href="./cm/theme/material-ocean.css">
<link rel="stylesheet" href="./cm/theme/mbo.css">
<link rel="stylesheet" href="./cm/theme/mdn-like.css">
<link rel="stylesheet" href="./cm/theme/midnight.css">
<link rel="stylesheet" href="./cm/theme/monokai.css">
<link rel="stylesheet" href="./cm/theme/moxer.css">
<link rel="stylesheet" href="./cm/theme/neat.css">
<link rel="stylesheet" href="./cm/theme/neo.css">
<link rel="stylesheet" href="./cm/theme/night.css">
<link rel="stylesheet" href="./cm/theme/nord.css">
<link rel="stylesheet" href="./cm/theme/oceanic-next.css">
<link rel="stylesheet" href="./cm/theme/panda-syntax.css">
<link rel="stylesheet" href="./cm/theme/paraiso-dark.css">
<link rel="stylesheet" href="./cm/theme/paraiso-light.css">
<link rel="stylesheet" href="./cm/theme/pastel-on-dark.css">
<link rel="stylesheet" href="./cm/theme/railscasts.css">
<link rel="stylesheet" href="./cm/theme/rubyblue.css">
<link rel="stylesheet" href="./cm/theme/seti.css">
<link rel="stylesheet" href="./cm/theme/shadowfox.css">
<link rel="stylesheet" href="./cm/theme/solarized.css">
<link rel="stylesheet" href="./cm/theme/the-matrix.css">
<link rel="stylesheet" href="./cm/theme/tomorrow-night-bright.css">
<link rel="stylesheet" href="./cm/theme/tomorrow-night-eighties.css">
<link rel="stylesheet" href="./cm/theme/ttcn.css">
<link rel="stylesheet" href="./cm/theme/twilight.css">
<link rel="stylesheet" href="./cm/theme/vibrant-ink.css">
<link rel="stylesheet" href="./cm/theme/xq-dark.css">
<link rel="stylesheet" href="./cm/theme/xq-light.css">
<link rel="stylesheet" href="./cm/theme/yeti.css">
<link rel="stylesheet" href="./cm/theme/idea.css">
<link rel="stylesheet" href="./cm/theme/darcula.css">
<link rel="stylesheet" href="./cm/theme/yonce.css">
<link rel="stylesheet" href="./cm/theme/zenburn.css">

<script src="./cm/lib/codemirror.js"></script>
<script src="./cm/addon/selection/active-line.js"></script>
<script src="./cm/addon/hint/show-hint.js"></script>
<script src="./cm/addon/hint/anyword-hint.js"></script>
<script src="./cm/addon/edit/closebrackets.js"></script>
<script src="./cm/mode/javascript/javascript.js"></script>
<script src="./cm/addon/edit/closetag.js"></script>
<script src="./cm/mode/htmlmixed/htmlmixed.js"></script>

<script src="./cm/addon/fold/xml-fold.js"></script>
<script src="./cm/addon/edit/matchtags.js"></script>
<script src="./cm/mode/xml/xml.js"></script>
<script src="./cm/addon/mode/loadmode.js"></script>
<script src="./cm/mode/meta.js"></script>
<script src="./cm/addon/dialog/dialog.js"></script>
<script src="./cm/addon/search/searchcursor.js"></script>
<script src="./cm/addon/search/search.js"></script>
<script src="./cm/addon/scroll/annotatescrollbar.js"></script>
<script src="./cm/addon/search/matchesonscrollbar.js"></script>
<script src="./cm/addon/search/jump-to-line.js"></script>
<script src="./cm/addon/search/match-highlighter.js"></script>
<script src="./cm/addon/edit/matchbrackets.js"></script>




<style type="text/css">
  .CodeMirror {
    position: fixed;
    overflow: hidden;
    top: 30px;
    width: 100%;
    min-height: 89vh;
    background-color: rgba(0,0,0,0.9)!important;
    text-align: left;
    left: 0px;
    border-bottom: 60px solid #000;
    font-size: 14px;
}


 #active_code_window::-webkit-scrollbar-track{
  background-color: #e2e2e2;
}

 #active_code_window::-webkit-scrollbar{
  width: 6px;
  background-color: #F5F5F5;
}

 #active_code_window::-webkit-scrollbar-thumb{
  border-radius: 100px;
  background-color: #545454;
}
.clock_skin{
  
     position: fixed;
    top: 39px;
    width: 96%;
    left: 0px;
    height: 80vh;
    font-size: 270px;
  color:purple;
}
.CodeMirror-focused .cm-matchhighlight {
  background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAYAAABytg0kAAAAFklEQVQI12NgYGBgkKzc8x9CMDAwAAAmhwSbidEoSQAAAABJRU5ErkJggg==);
  background-position: bottom;
  background-repeat: repeat-x;
}
.cm-matchhighlight {background-color: rgba(0,0,0, 0.2); border-bottom:1px solid #FFF;}
.CodeMirror-selection-highlight-scrollbar {background-color: lightgreen}

.cm-s-erlang-dark .CodeMirror-activeline-background {
    background: #373737;
}
.function_card u
{
   cursor:pointer;
}
.function_card
{
   margin-bottom: 34px;
   border-bottom: 4px solid #CCC;
   word-break: break-word;
}
.tbl_row:hover
{
    background-color: darkblue;
}
</style>
<title>Terminal</title>

<div style="text-align: center;">
	<iframe src="" class="desk_iframe"  id="load_desk_iframe" onLoad="change_scroll_bar_desk();"></iframe>
	<div class="close_mobile_view" onclick="close_mobile_view();this.style.display='none'" id="close_mobile_view_btn" title="Close Mobile View">X</div>
	<iframe src="" class="mobi_iframe"  id="load_mobi_iFrame" onLoad="change_scroll_bar_mobi();"></iframe>
<div class="preview_desk_iframe" id="preview_desk_iframe" style="display: none;"  onclick="push_to_top('preview_desk_iframe')">
  <iframe style="width: 100%; height: 100%;" id="load_preview_iframe0" onLoad="change_scroll_bar_prev0();"></iframe>
  <iframe style="width: 100%; height: 100%;" id="load_preview_iframe1" onLoad="change_scroll_bar_prev1();"></iframe>
    <input type="text" id="prevscroll_px" style="position: absolute; bottom: 30px; right: 10px; width: 100px; background-color: rgba(0,0,0, 0.3); z-index: 9999999; color: #FFF;" placeholder="Scroll to" onclick="move_elem_to(100, 200, 'preview_desk_iframe')">
</div>
<input type="hidden" id="foundfile" name="" style="position: fixed; bottom: 72px; right: 20px; width: 70%; background-color: rgba(0,0,0, 0.9); z-index: 999; color: #FFF;" >
	<div class="bottom_tray" style="color: #FFF;">
  <input type="text" id="active_terminal" style="width: 5%; background-color: #000; color:#FFF; border: none; display: inline-block; ">

      <div class="exe_btn"  id="open_quick_vars" onclick="document.getElementById('quick_vars_card').style.display='inline-block'; this.style.display='none'; document.getElementById('close_quick_vars').style.display='inline-block';show_quick_vars()">Quick Vars</div>

       <div  class="exe_btn" style="display:none;" id="close_quick_vars" onclick="document.getElementById('quick_vars_card').style.display='none'; this.style.display='none'; document.getElementById('open_quick_vars').style.display='inline-block'">Close Vars</div>

    <div class="exe_btn" onclick="switch_dna()" id="switch_dna_btn" style="font-size:12px;">DNA : <?php echo $_SESSION['dna_session']?></div>      

  <input type="hidden" id="switch_dna_input" value="<?php echo $_SESSION['dna_session']?>"/>
      <div class="exe_btn" >TCT : <span id="tct_span"></span></div>
    <!--<button class="exe_btn" id="scrollUp" onclick="scrollWinup()">&#x2191;</button>
    <button class="exe_btn" id="scrollDown" onclick="scrollWindown()">&#x2193;</button>-->

		<input type="hidden" id="iframeurl" placeholder="Url to show" style="width: 10%; background-color: #000; color:#FFF; border: none; display: inline-block; ">
            <input type="hidden" id="txt_code_transparency" onkeyup="code_transparency(this.value)" placeholder="Opacity" style="width: 70px; background-color: #000; color:#FFF; border: none; display: inline-block; " value="0.9">
		<div class="exe_btn" onclick="loadapp_plan('appnotes')">Notes</div>
    <div class="exe_btn" onclick="loadapp_plan('appvars')">Vars</div>
    <div class="exe_btn" onclick="loadapp_plan('appdbconfig')">DB</div>
    <div class="exe_btn" onclick="document.getElementById('parent_log_window').style.display='block';">Show Log</div>
<!--     <div class="exe_btn" onclick="find_in_page()">Find</div>
 -->       <select   onchange="change('text.'+this.value)"  style="width: 8%; background-color: #000; color:#FFF; border: none; display: inline-block; ">
                <option value="php">Doctype</option>
                <option>php</option>
                <option>html</option>
                <option>js</option>
                <option>php</option>
                <option>css</option>
                <option>json</option>

        </select>
	</div>
	<div class="minimized_mobi" id="minimized_mobi_div" title="Show Mobile View" onclick="show_mobi(); this.style.display='none'" >
		[Show Mobile View]
	</div>
<!--Start editor-->
<div class="navbar_ribbon">
    <input type="text" id="basepath_txt" style="font-size: 12px; width: 70px; background-color: #000; color:#FFF; border: none; display: inline-block; padding-left: 2px;" value=".." required="" placeholder="DirBase" onkeyup='loop_folder(this.value); trigger_log_search(this.value);flag_search(this.value)'>
    <input type="text" id="mainsearch" style="font-size: 12px; width: 15%; background-color: #000; color:#FFF; border: none; display: inline-block; padding-left: 2px;" value="Search" required="" placeholder=" Search System"   autocomplete="off" onkeyup='loop_folder(this.value); trigger_log_search(this.value);flag_search(this.value);'>
    <div  class="minifolder" id="minifolder" >
    	<div id="qfolder_res" onclick="document.getElementById('minifolder').style.display='none'"></div>
    </div>
	<div class="exe_btn" onclick="execute_terminal('');">Run</div>

    <input type="hidden" style="font-size: 12px; width: 15%; background-color: #000; color:#FFF; border: none; display: inline-block; padding-left: 2px;" value="<?php if(isset($_POST['txt_directory'])){ echo $_POST['txt_directory'];}else{ echo "./terminal_exe.php";}?>" name="txt_directory" id="txt_directory" required="" placeholder=" Enter exe file path">

	<div class="exe_btn" onclick="load_file();">Load File</div>
    <input type="text" style="font-size: 12px; width: 15%; background-color: #000; color:#FFF; border: none; display: inline-block; padding-left: 2px;" value="<?php if(isset($_POST['txt_writeto'])){ echo $_POST['txt_writeto'];}else{ echo "./txt_writeto.php";}?>" id="txt_writeto" name="txt_writeto" required="" placeholder=" Enter writable file path" onkeyup="loop_folder(this.value); trigger_log_search(this.value);push_title()" onchange="push_title()">
	<div class="exe_btn" onclick="save_file()">Save File</div>
</div>

<div class="log_window" id="parent_log_window" style="display: none;" onclick="push_to_top('parent_log_window')">
  
<div style="padding:5px;cursor:pointer; display:inline-block; border-right:1px solid #ccc;" onclick="pop_db_tables()">Db Tables</div>

      
<div style="padding:5px;cursor:pointer; display:inline-block;" onclick="loadapp_plan('quick_vars')">Edit Vars</div>
<div style="padding:5px; font-size: 28px; display: none;" onclick="this.style.display='none'" id="notification_card">Notifications</div>

<input type="text" style="font-size: 12px; width: 100%; background-color: #000; color:#FFF; border: none; display: inline-block; padding-left: 2px; margin-top: 5px; padding: 5px;" onkeyup="search_log()" required="" id="function_card" placeholder=" Search Window"  autocomplete="off">

<input type="text" id="folderpath" style="font-size: 12px; width: 100%; background-color: #000; color:#FFF; border: none; display: inline-block; padding-left: 2px; margin-top: 5px; padding: 5px;" onkeyup="loop_folder(this.value)" onchange="loop_folder(this.value)"  required="" placeholder="Search Folders"  autocomplete="off">

<div id="log_window" style="max-height: 300px; overflow-y: auto; margin-top: 12px;"></div>
<div style="text-align: left;">
      <a class="" href="#" title="Maximize" onclick="resize_move_elem_to(400, 50, 'parent_log_window', '65%')">[]</a>
    | <a class="" href="#" title="Minimize" onclick="document.getElementById('parent_log_window').style.display='none';">__</a>
    | <a class="" href="#" onclick="execute_terminal('console');" title="Run Console" >Run</a>
    | <a class="" href="#" onclick="loadapp_plan('varurls');" title="Variable Urls">VURL</a>
    <span id="parent_log_windowheader" style="cursor: move;">< Drag ></span>
</div>
<textarea id="append_text" onclick="switch_terminals('console');this.style.width='100%';this.style.height='100%';" style="
    background-color: rgb(0, 0, 0, 0.2);
    width: 252px;
    color: #4eacff;
    height: 250px;
    margin: 10px 0px 0px;
    border: none;" placeholder="Php Console"></textarea>

</div>
        <div class="clock_skin" id="time" ></div>

<textarea class="editor_skin_new" id="txt_new_code"  onclick=" switch_terminals('main');"></textarea>
<div onclick="this.style.display='none'" id="flag_search_div" style="position: fixed;
    bottom: 200px;
    left: 200px;
    width: 400px;
    display: none;
    padding: 20px;
    background-color: #000; color: #FFF; max-height: 200px; overflow-y: auto; text-align: left; z-index: 9999999999">
</div>

<div onclick="this.style.display='none'" id="flag_search_hash" style="position: fixed;
    bottom: 200px;
    left: 600px;
    width: 400px;
    display: none;
    padding: 20px;
    background-color: #000; color: #FFF; max-height: 200px; overflow-y: auto; text-align: left; z-index: 9999999999">
</div>
<div onclick="this.style.display='none'" id="flag_search_pin" style="position: fixed;
    bottom: 85px;
    left: 200px;
    width: 400px;
    display: none;
    padding: 20px;
    background-color: #000; color: #FFF; max-height: 70px; overflow-y: auto; text-align: left; z-index: 9999999999">
</div>
 <div onclick="show_quick_vars();" style="text-align: left; cursor:pointer; font-size:14px; border-bottom:1px solid #CCC; padding:7px; max-height:70px; overflow-y:auto;  position:fixed; bottom:450px; max-width:200px; left:400px; color:#FFF; display:none; background: rgba(0,0,0, 0.4);" id="quick_vars_card"></div>
      
      
<input type="hidden" style="position: fixed; bottom: 72px; right: 20px; width: 70%; background-color: rgba(0,0,0, 0.9); z-index: 999; color: #FFF;" id="flag_search" name="">
<input type="hidden" style="position: fixed; bottom: 172px; right: 20px; width: 70%; background-color: rgba(0,0,0, 0.9); z-index: 999; color: #FFF;" id="hash_text_search" name="">
<input type="hidden" style="position: fixed; bottom: 72px; right: 20px; width: 40%; background-color: rgba(0,0,0, 0.9); z-index: 999; color: #FFF;" id="trigger_arrow_keys" name="">
<input type="hidden" id="load_preview_iframe_txt">
<input type="hidden" id="appvars_txt">
<input type="hidden" id="app_notes_append">
<input type="text" id="setcursor">
<input type="text" id="snippkey">
<input type="text" id="flag_focused">
<input type="text" id="alwaysontop" value="99999999">
<input type=text value="php" id=mode> 

<input type="hidden" id="txt_scroll_to" value="100" style="position: fixed; bottom: 72px; right: 20px; width: 40%; background-color: rgba(0,0,0, 0.9); z-index: 999; color: #FFF;">

<!--End editor-->
<!-- $("#a_input_id", parent.document).val($(this).text());
 -->
</div>
<div id="alert_box"></div>
        <span id="modeinfo">text/plain</span>


<script>

CodeMirror.modeURL = "./cm/mode/%N/%N.js";
var editor = CodeMirror.fromTextArea(document.getElementById("txt_new_code"), {
  lineNumbers: true,
  lineWrapping: true,
    value: "<html>\n  " + document.documentElement.innerHTML + "\n</html>",
    matchTags: {bothTags: true},
  extraKeys: {"Alt-F": "findPersistent", "Ctrl-Space": "autocomplete"},
 autoCloseBrackets: true,
styleActiveLine: true,
  autoCloseTags: true,
  highlightSelectionMatches: {showToken: /\w/, annotateScrollbar: true},
    matchBrackets: true

});


function find_in_page(){ 
  editor.execCommand("find"); 
};

CodeMirror.commands.autocomplete = function(cm) {
  cm.showHint({hint: CodeMirror.hint.anyword});
}

editor.on("keydown", function (cm, event) {
  if (
     event.keyCode != 13 && !(event.ctrlKey) && 
    (event.keyCode >= 65 && event.keyCode <= 90) || 
    (event.keyCode >= 97 && event.keyCode <= 122) || 
    (event.keyCode >= 46 && event.keyCode <= 57)
  ) {

  if (!cm.state.completionActive && /*Enables keyboard navigation in autocomplete list*/
      event.keyCode != 13) {        /*Enter - do not open autocomplete list just after item has been selected in it*/ 

    cm.showHint({hint: CodeMirror.hint.anyword, completeSingle: false});

        }
    }
});

// editor.on("keyup", function (cm, event) {
//         if (!cm.state.completionActive && /*Enables keyboard navigation in autocomplete list*/
//             event.keyCode != 13) {        /*Enter - do not open autocomplete list just after item has been selected in it*/ 

//   cm.showHint({hint: CodeMirror.hint.anyword});

//         }
//     });

function change(curr_mode) {
  var val = curr_mode, m, mode, spec;
  if (m = /.+\.([^.]+)$/.exec(val)) {
    var info = CodeMirror.findModeByExtension(m[1]);
    if (info) {
      mode = info.mode;
      spec = info.mime;
    }
  } else if (/\//.test(val)) {
    var info = CodeMirror.findModeByMIME(val);
    if (info) {
      mode = info.mode;
      spec = val;
    }
  } else {
    mode = spec = val;
  }
  if (mode) {
    editor.setOption("mode", spec);
    CodeMirror.autoLoadMode(editor, mode);
    document.getElementById("modeinfo").textContent = spec;
  } else {
    //alert("Could not find a mode corresponding to " + val);
  }
}

  function selectTheme(theme_name) {
    var theme = theme_name;
    editor.setOption("theme", theme);
    location.hash = "#" + theme;
  }
  var choice = (location.hash && location.hash.slice(1)) ||
               (document.location.search &&
                decodeURIComponent(document.location.search.slice(1)));
  if (choice) {
    editor.setOption("theme", choice);
  }
  CodeMirror.on(window, "hashchange", function() {
    var theme = location.hash.slice(1);
    if (theme) { selectTheme(); }
  });

</script>

<script type="text/javascript" src="./jquery.js"></script>
<script type="text/javascript" src="./cm_terminal.js?v=<?php echo date("hisa")?>"></script>
<script type="text/javascript" src="./jsfunctions.js"></script>
<script type="text/javascript">
    window.onload=check_autoload();load_start_folder('..');

    function check_autoload()
    {

var url =new URL(window.location.href);
var c = url.searchParams.get("check_autoload");

if(c!=undefined){

document.getElementById('txt_writeto').value=atob(c);

load_file()

}
}

function load_mirror()
{

    window.open('./home?check_autoload='+btoa(document.getElementById('txt_writeto').value));
}

function code_transparency(new_val)
{
document.getElementById('active_code_window').style.opacity=''+new_val+'';
}

</script>

<script type="text/javascript">
function scrollWinup()
{
    var editorheight=editor.lineCount();

      if ( document.getElementById('txt_scroll_to').value>=editorheight*10)
    {
      document.getElementById('txt_scroll_to').value=editorheight*9;
     }

  editor.scrollTo(0, document.getElementById('txt_scroll_to').value);




    if ( document.getElementById('txt_scroll_to').value<0)
    {
   document.getElementById('txt_scroll_to').value=0;
    }else{
         document.getElementById('txt_scroll_to').value=parseInt(document.getElementById('txt_scroll_to').value)-250;

    }
}

function scrollWindown()

{

   editor.scrollTo(0, document.getElementById('txt_scroll_to').value);

var editorheight=editor.lineCount();

    if ( document.getElementById('txt_scroll_to').value>=editorheight*15)
    {
   document.getElementById('txt_scroll_to').value=editorheight*15;
    }else{
         document.getElementById('txt_scroll_to').value=parseInt(document.getElementById('txt_scroll_to').value)+250;

    }


  }

window.onload=change('txt.php'); selectTheme('<?php echo $curr_proj_theme?>');

</script>