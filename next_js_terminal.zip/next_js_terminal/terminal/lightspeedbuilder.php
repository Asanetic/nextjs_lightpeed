<?php
ob_start();

// Include your main app dependencies
include('./appdbconfig.php');
include('./svrconn.php');
include('./phpmagicbits.php');
include('./phpmagicui.php');
include('./phpmagicbackend.php');

// Elforge Dnaaf Runner – Echo Capture + Legacy PHP compatible
$basePath = "../appdna/funcapp/";
$stopFlag = "stop_flag.txt";

// Handle stop requests
if (isset($_GET['stop'])) {
  file_put_contents($stopFlag, "stop");
  echo json_encode(["status" => "stopped"]);
  exit;
}

// Reset stop flag
if (file_exists($stopFlag)) {
  unlink($stopFlag);
}

$selectedModule = isset($_GET['module']) ? $_GET['module'] : 'all';
$selectedFile   = isset($_GET['file']) ? $_GET['file'] : null;

$response = [];

function trapPhpErrors(&$errorStorage) {
  set_error_handler(function ($errno, $errstr, $errfile, $errline) use (&$errorStorage) {
    $errorStorage = "PHP ERROR: $errstr in $errfile on line $errline";
    return true;
  });
  set_exception_handler(function ($exception) use (&$errorStorage) {
    $errorStorage = "UNCAUGHT EXCEPTION: " . $exception->getMessage();
  });
}


function createModuleDnaafIfMissing($currtbl_name, $source_file_path = 'mdna.php') {
  // Extract table and project context
  $main_table_name = $currtbl_name;

  // Dynamically detect project name from URL, fallback to "nextinvoice"
  $primary_path = str_replace("http://localhost/", "", magic_current_url());
  $main_primary_segments = explode('/', $primary_path);

  $primary_project_name = isset($main_primary_segments[2]) ? $main_primary_segments[2] : 'smartypro';

  // Construct DNA folder path
  $module_folder = "../appdna/$primary_project_name/$main_table_name";
  $attr_folder   = "$module_folder/tbl_attr";

  // Ensure tbl_attr folder exists
  if (!is_dir($attr_folder)) {
    mkdir($attr_folder, 0777, true);
  }

  // Build destination path for DNA file
  $destination_path = "$attr_folder/tbl_attr_{$currtbl_name}_dnaaf.php";

  // 🧬 Generate DNA file if missing
  if (!file_exists($destination_path)) {
    $template = file_exists($source_file_path)
      ? file_get_contents($source_file_path)
      : "<?php\n// Blank DNA file\nreturn [];";

    bend_write_to_file($destination_path, $template);

    echo '<div style="padding:5px; font-style:italic" onclick="load_to_editor(\'' . $destination_path . '\')">✅ ' . $destination_path . ' Created</div>';
  }

  // 🛠 Generate assembler file (for MDNA config)
  $assembler_snippet = find_snippet("1181");
  $file_title_name   = ucwords(str_replace("_", " ", $currtbl_name));

  // Ensure base module folder exists
  if (!is_dir($module_folder)) {
    mkdir($module_folder, 0777, true);
  }

  $assembler_path = "$module_folder/{$currtbl_name}Profile_{$currtbl_name}.Dnaaf";

  // Inject variables into snippet
  $replaced_content_1 = str_replace("{{tblname}}", $currtbl_name, $assembler_snippet);
  $replaced_content_2 = str_replace("{{tblname_title}}", $file_title_name, $replaced_content_1);
  $replaced_content = str_replace("mdna.php", $destination_path, $replaced_content_2);

  bend_write_to_file($assembler_path, $replaced_content);

  return $assembler_path;
}




// 👉 Handle single file request
if ($selectedFile !== null && $selectedModule !== 'all') {
  $modulePath = $basePath . $selectedModule;

  // 🔨 If the module folder doesn't exist, create it
  if (!is_dir($modulePath)) {
    if (!mkdir($modulePath, 0777, true)) {
      echo json_encode([[
        "module" => $selectedModule,
        "file" => $selectedFile,
        "status" => "error",
        "message" => "❌ Failed to create module folder: $modulePath"
      ]]);
      exit;
    }
  }

  $filePath = $modulePath . "/" . basename($selectedFile);

  // 🧬 If the file doesn’t exist, create a placeholder .Dnaaf
  if (!file_exists($filePath)) {

  if (!is_dir($modulePath) || !file_exists($filePath)) {
  // Get file name without extension
  $currtbl_name = pathinfo($selectedFile, PATHINFO_FILENAME);
  
  // Try to create missing file & folder
  $created_path = createModuleDnaafIfMissing($currtbl_name);

  // Update file path for execution
  $filePath = realpath($created_path);

    // If still not found, bail out
    if (!file_exists($filePath)) {
      echo json_encode([[ 
        "module" => $selectedModule, 
        "file" => $selectedFile, 
        "status" => "error", 
        "message" => "❌ Failed to auto-create: $created_path" 
      ]]); 
      exit;
    }
  }

  
  }

  // ✅ Continue as normal
  $filePath = realpath($filePath);
  $modulePath = realpath($modulePath);

  if (!is_dir($modulePath) || !file_exists($filePath)) {
    echo json_encode([[
      "module" => $selectedModule,
      "file" => $selectedFile,
      "status" => "error",
      "message" => "❌ Invalid module or file."
    ]]);
    exit;
  }

  // ⛏ Run the file
  $errorMessage = null;
  trapPhpErrors($errorMessage);

  try {
    $originalCode = file_get_contents($filePath);

    if (!isset($_POST['txt_new_code'])) {
      $_POST['txt_new_code'] = $originalCode;
    }

    if ($originalCode === false || trim($originalCode) === '') {
      $response[] = [
        "module" => $selectedModule,
        "file" => basename($filePath),
        "status" => "error",
        "message" => "❌ Empty or unreadable file: " . realpath($filePath)
      ];
      echo json_encode($response); exit;
    }

    $tempPhpPath = dirname($filePath) . '/' . basename($filePath) . '.temp_runner.php';
    $wrappedCode = "<?php\n" . $originalCode . "\n?>";

    if (file_put_contents($tempPhpPath, $wrappedCode) === false) {
      $response[] = [
        "module" => $selectedModule,
        "file" => basename($filePath),
        "status" => "error",
        "message" => "❌ Failed to write temp file: $tempPhpPath"
      ];
      echo json_encode($response); exit;
    }

    ob_start();
    include($tempPhpPath);
    $htmlOutput = ob_get_clean();

    unlink($tempPhpPath);

    if ($errorMessage) {
      throw new Exception($errorMessage);
    }

    $response[] = [
      "module" => $selectedModule,
      "file" => basename($filePath),
      "status" => "success",
      "html" => $htmlOutput
    ];
  } catch (Exception $e) {
    $response[] = [
      "module" => $selectedModule,
      "file" => basename($filePath),
      "status" => "error",
      "message" => $e->getMessage()
    ];
  }

  echo json_encode($response); exit;
}



?>