<?php 
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/datahandler.php');

if(isset($_POST["mosyajax_sql_data"]))
{
	$sql_function_name=('get_'.$_POST['tbl']);
  
    //=== start packages select  Like Query String packages list  
	$ajax_loop_curr_tbl_q=$sql_function_name("*", $_POST['mosyajax_sql_data'], "l");
	$return_no_tag=$sql_function_name("*", $_POST['mosyajax_sql_data'], "l");
    $return_no_tag_res=array();
  

  
  //echo magic_message($_POST['mosyajax_sql_data']);
  	while($return_no_tag_r=mysqli_fetch_array($return_no_tag))
    {
  	
      $return_no_tag_res[]=$return_no_tag_r;
  	
  	}
  	$node_function_name=$_POST['node_function_name'];
  
  	$ui_tag=$_POST['ui_tag'];
  
    if (strpos($ui_tag, '=>') !== false) 
    {
  
      //$ui_template=explode("=>", $ui_tag)[1];
              
    }
  
  	$js_columns=array();  
	$name_col_arr=array();
  	$name_label_arr=array();
  


  	$ui_columns="";
    $card_str="";
  
  	$exploded_cols=explode(",", $_POST["cols"]);

       foreach($exploded_cols as $colname)
    	{
          
          if (strpos($colname, ':') !== false) 
          {
			$label_str=explode(":", $colname);            
            $name_label_arr[]=$label_str[1];
           	$name_col_arr[]=$label_str[0];
            
            if(array_key_exists(2, $label_str) )
            {
            $name_label_arr[]=$label_str[1].":".$label_str[2];  
            }
			

          }else{
            
            $js_columns[]=magic_clean_str($colname);

          }
           
    	}
	
  
    while($data_res=mysqli_fetch_array($ajax_loop_curr_tbl_q))
    {
    $custom_ui_search_data_point=array();
	$custom_ui_replace_data_point=array();
	$custom_ui_search_label_point=array();
	$custom_ui_replace_label_point=array();
      
      $node_card_len=count($name_label_arr)-1;
      $js_cols_len=count($js_columns)-1;
      
      $data_node_card_c=-1;
      $data_node_card='';
      
      while($data_node_card_c<=$node_card_len)
      {
        $data_node_card_c++;
        
        
        if($data_node_card_c<$node_card_len+1)
        {

          if (strpos($name_label_arr[$data_node_card_c], '|') !== false) 
          {
         
          $custom_data_point=explode("|", $name_label_arr[$data_node_card_c]);  
          $custom_data_node1=eval(("\$custom_data_node= ".$custom_data_point[1].";"));;  
          $custom_label_node=$custom_data_point[0];
  
            //echo $custom_data_node;
          }else{
                     
            $custom_data_node=$data_res[$name_col_arr[$data_node_card_c]];
            $custom_label_node=$name_label_arr[$data_node_card_c];

          }
          
          
          if($ui_tag=='card')
          {
              $data_node_card.='<div class="col-md-12 p-1 m-0"> <b> '.$custom_label_node.'</b> : '.$custom_data_node.'</div>';
          }
          
          if($ui_tag=='option')
          {
              $data_node_card.=''.$custom_data_node.' | ';
          }  
          
          if($ui_tag=='tr')
          {
              $data_node_card.='<td class="">'.$custom_data_node.'</td>';
          }

			$custom_ui_search_data_point[]="{{".$name_col_arr[$data_node_card_c]."}}";
          	$custom_ui_replace_data_point[]=$data_res[$name_col_arr[$data_node_card_c]];
          
          	$custom_ui_search_label_point[]="{{".$custom_label_node."}}";
            $custom_ui_replace_label_point[]=$custom_data_node;
        }
        
      }
      
                
          if (strpos($ui_tag, '=>') !== false) 
          {
	
              $ui_template=explode("=>", $ui_tag)[1];
              $search_data_points_str =$custom_ui_search_data_point;            
         	  $replace_data_points_str =$custom_ui_replace_data_point;
            
              $search_label_points_str =$custom_ui_search_label_point;            
         	  $replace_label_points_str =$custom_ui_replace_label_point;
            
              $data_node_card1= str_replace($search_data_points_str, $replace_data_points_str, $ui_template);
              $data_node_card.= str_replace($search_label_points_str, $replace_label_points_str, $data_node_card1);
            
            
          }

      $jsexe_node_card_c=-1;
      $jsexe_node_card=array();
      
      while($jsexe_node_card_c<=$js_cols_len)
      {
        $jsexe_node_card_c++;
                
        if($jsexe_node_card_c<$js_cols_len+1)
        {
              $jsexe_node_card[]='\''.magic_clean_str($data_res[$js_columns[$jsexe_node_card_c]]).'\'';
          
        }
        
      }
      
      $js_function_data_node=implode(",", $jsexe_node_card);
      
          if($ui_tag=='card')
          {
            
          $card_str.='
              <div class="row col-md-12 p-3 text-left mb-2 border-bottom border-dark ml-0 mr-0 " style="cursor:pointer;" onclick="'.$node_function_name.'('.$js_function_data_node.')">  
				'.$data_node_card.'
			  </div>';
          }

          if($ui_tag=='option')
          {
            
          $card_str.='
              <option onclick="'.$node_function_name.'('.$js_function_data_node.')">'.$data_node_card.'</option>';
          }

          if($ui_tag=='tr')
          {
            $card_str.='
              <tr class="" style="cursor:pointer;" onclick="'.$node_function_name.'('.$js_function_data_node.')">  
				'.$data_node_card.'
			  </tr>';
          }
      
          if (strpos($ui_tag, '=>') !== false) 
          {
              $card_str.=str_replace("{{".$node_function_name."}}", $node_function_name.'('.$js_function_data_node.')', $data_node_card);
          }


    }	

          if($ui_tag=='')
          {
			echo json_encode($return_no_tag_res, true);
          }else{
    		echo  $card_str;
          }
}

if(isset($_POST["mosyajax_create"]))
{
  
  $tbl=$_POST['tbl'];

  //------- begin Insert Query Vars --> 
  //additional insert colmuns and values 
  $tbl_cols_arr=explode(",", $_POST['tbl_cols']);
  $tbl_vals_arr=explode(",", $_POST['tbl_vals']);
  
  $tbl_cols_fin=array();

  $tbl_vals_fin=array();
  
  foreach($tbl_cols_arr as $cols_arr)
  {
    $tbl_cols_fin[]="`".trim($cols_arr)."`";
  }
  
  
  foreach($tbl_vals_arr as $vals_arr)
  {
    if($vals_arr!='NULL')
    {
    $tbl_vals_fin[]="'".$vals_arr."'";
    }else{
    $tbl_vals_fin[]=mmres($vals_arr);
    }
  }
    
  $tbl_cols=implode(",", ($tbl_cols_fin));
  $tbl_vals=implode(",", $tbl_vals_fin);

  echo $tbl_cols."-".$tbl_vals;
   mysqli_query($single_conn, "INSERT INTO `$single_db`.`".$tbl."` (".$tbl_cols.") 
   VALUES 
  (".$tbl_vals.")") or die(mysqli_error($single_conn));

   //--- get primary key id
  echo mysqli_insert_id($mysqliconn);
  
}

if(isset($_POST['mosyajax_update']))
{
  //------- begin Update Query acc_renewals Vars --> 
//additional update colmuns and values 
$tbl_update_str=$_POST["update_str"];
  
$tbl=$_POST['tbl'];
  
$where_str=$_POST['where_str'];

mysqli_query($single_conn, "UPDATE  `$single_db`.`".$tbl."` SET ".$tbl_update_str." WHERE ".$where_str."") or die(mysqli_error($single_conn));

}

if(isset($_POST['mosyajax_drop']))
{
  //------- begin Update Query acc_renewals Vars --> 
//additional update colmuns and values   
$tbl=$_POST['tbl'];
  
$where_str=$_POST['where_str'];

mysqli_query($single_conn, "DELETE FROM  `$single_db`.`".$tbl."` WHERE ".$where_str."") or die(mysqli_error($single_conn));

}



?>