import Script from "next/script";

export default function AdminFooter() {
  return (
    <>
      {/* DOM targets */}
      <div id="snack_box"></div>
      <div id="ajax_snack_id"></div>
      <div id="dialog_box"></div>
      <div id="ajax_snack"></div>
      <div id="alert_box"></div>
      <div id="magic_alert"></div>

      {/* External JS scripts */}
      <Script src="/js/jquery_main.js" strategy="beforeInteractive" />
      <Script src="/js/popper.js" strategy="beforeInteractive" />
      <Script src="/js/boot.js" strategy="beforeInteractive" />
      <Script src="/assets/js/bootstrap.bundle.min.js" strategy="beforeInteractive" />
      <Script src="/assets/plugins/slimscroll/jquery.slimscroll.min.js" strategy="lazyOnload" />
      <Script src="/assets/js/script.js" strategy="lazyOnload" />
      <Script src="/js/hives/jsmagicbits.js" strategy="lazyOnload" />

    </>
  );
}
